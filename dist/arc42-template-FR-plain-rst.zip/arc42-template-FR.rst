**A propos d’arc42**

arc42, le modèle de documentation de l’architecture des logiciels et des
systèmes.

Version du modèle 8.2 FR. (basé sur la version AsciiDoc), January 2023

Créé, maintenu et © par Dr. Peter Hruschka, Dr. Gernot Starke et les
contributeurs. Voir https://arc42.org.

.. _section-introduction-and-goals:

Introduction et Objectifs
=========================

.. _`_aper_u_des_sp_cifications`:

Aperçu des spécifications
-------------------------

.. _`_objectifs_de_qualit`:

Objectifs de Qualité
--------------------

.. _`_parties_prenantes`:

Parties prenantes
-----------------

+-------------+---------------------------+---------------------------+
| Rôle/Nom    | Contact                   | Attentes                  |
+=============+===========================+===========================+
| *<Role-1>*  | *<Contact-1>*             | *<Attente-1>*             |
+-------------+---------------------------+---------------------------+
| *<Role-2>*  | *<Contact-2>*             | *<Attente-2>*             |
+-------------+---------------------------+---------------------------+

.. _section-architecture-constraints:

Contraintes d’Architecture
==========================

.. _section-context-and-scope:

Contexte et périmètre
=====================

.. _`_contexte_m_tier`:

Contexte métier
---------------

**<Schéma ou tableau>**

**<éventuellement : Explication des interfaces de domaines externes>**

.. _`_contexte_technique`:

Contexte Technique
------------------

**<Schéma ou tableau>**

**<en option : Explication des interfaces techniques>**

**<Correspondance des entrées/sorties aux canaux>**

.. _section-solution-strategy:

Stratégie de solution
=====================

.. _section-building-block-view:

Vue en Briques
==============

.. _`_niveau_1_syst_me_global_bo_te_blanche`:

Niveau 1 : Système global Boîte blanche
---------------------------------------

**<Schéma d’ensemble>**

Motivation
   *<texte explicatif>*

Briques contenues
   *<Description de la brique contenue (boîte noire)>*

Interfaces Importantes
   *<Description des interfaces importantes>*

.. _`__nom_bo_te_noire_1`:

<Nom boîte noire 1>
~~~~~~~~~~~~~~~~~~~

*<Objectif/Responsabilité>*

*<Interface(s)>*

*<(Facultatif) Caractéristiques de qualité/performance>*

*<(Facultatif) Emplacement du répertoire/fichier>*

*<(Facultatif) Exigences respectées>*

*<(Facultatif) Questions ouvertes/problèmes/risques>*

.. _`__nom_bo_te_noire_2`:

<Nom boîte noire 2>
~~~~~~~~~~~~~~~~~~~

*<template boîte noire>*

.. _`__nom_bo_te_noire_n`:

<Nom boîte noire n>
~~~~~~~~~~~~~~~~~~~

*<template boîte noire>*

.. _`__nom_interface_1`:

<Nom interface 1>
~~~~~~~~~~~~~~~~~

…

.. _`__nom_interface_m`:

<Nom interface m>
~~~~~~~~~~~~~~~~~

.. _`_niveau_2`:

Niveau 2
--------

.. _`_bo_te_blanche_emphasis_brique_1_emphasis`:

Boîte blanche *<brique 1>*
~~~~~~~~~~~~~~~~~~~~~~~~~~

*<template boîte blanche>*

.. _`_bo_te_blanche_emphasis_brique_2_emphasis`:

Boîte blanche *<brique 2>*
~~~~~~~~~~~~~~~~~~~~~~~~~~

*<template boîte blanche>*

…

.. _`_bo_te_blanche_emphasis_brique_n_emphasis`:

Boîte blanche *<brique n>*
~~~~~~~~~~~~~~~~~~~~~~~~~~

*<template boîte blanche>*

.. _section-runtime-view:

Vue Exécution
=============

.. _`__sc_nario_d_ex_cution_1`:

<Scénario d’exécution 1>
------------------------

-  *<insérer un diagramme d’exécution ou une description textuelle du
   scénario>*

-  *<insérer une description des aspects notables des interactions entre
   les instances des briques représentées dans ce diagramme.>*

.. _`__sc_nario_d_ex_cution_2`:

<Scénario d’exécution 2>
------------------------

.. _`_`:

…
-

.. _`__sc_nario_d_ex_cution_n`:

<Scénario d’exécution n>
------------------------

.. _section-deployment-view:

Vue Déploiement
===============

.. _`_infrastructure_niveau_1`:

Infrastructure Niveau 1
-----------------------

**<Schéma d’ensemble>**

Motivation
   *<explication sous forme de texte>*

Caractéristiques de qualité et/ou de performance
   *<explication sous forme de texte>*

Correspondance des briques vis à vis de l’infrastructure
   *<description de la correspondance>*

.. _`_infrastructure_niveau_2`:

Infrastructure Niveau 2
-----------------------

.. _`__emphasis_infrastructure_element_1_emphasis`:

*<Infrastructure Element 1>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<schéma + explication>*

.. _`__emphasis_infrastructure_element_2_emphasis`:

*<Infrastructure Element 2>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<schéma + explication>*

…

.. _`__emphasis_infrastructure_element_n_emphasis`:

*<Infrastructure Element n>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<schéma + explication>*

.. _section-concepts:

Concepts transversaux
=====================

.. _`__emphasis_concept_1_emphasis`:

*<Concept 1>*
-------------

*<explication>*

.. _`__emphasis_concept_2_emphasis`:

*<Concept 2>*
-------------

*<explication>*

…

.. _`__emphasis_concept_n_emphasis`:

*<Concept n>*
-------------

*<explication>*

.. _section-design-decisions:

Décisions d’architecture
========================

.. _section-quality-scenarios:

Critères de qualité
===================

.. _`_arbre_de_qualit`:

Arbre de qualité
----------------

.. _`_sc_narios_qualit`:

Scénarios Qualité
-----------------

.. _section-technical-risks:

Risques et Dettes techniques
============================

.. _section-glossary:

Glossaire
=========

+-----------------------+-----------------------------------------------+
| Terme                 | Définition                                    |
+=======================+===============================================+
| *<Terme-1>*           | *<Définition-1>*                              |
+-----------------------+-----------------------------------------------+
| *<Terme-2>*           | *<Définition-2>*                              |
+-----------------------+-----------------------------------------------+

.. |arc42| image:: images/arc42-logo.png
