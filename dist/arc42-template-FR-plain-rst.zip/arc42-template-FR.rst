================
|arc42| Template
================

:Date: Avril 2025

**A propos d’arc42**

arc42, le modèle de documentation de l’architecture des logiciels et des
systèmes.

Version du modèle 9.0-FR. (basé sur la version AsciiDoc), Avril 2025

Créé, maintenu et © par Dr. Peter Hruschka, Dr. Gernot Starke et les
contributeurs. Voir https://arc42.org.

.. _section-introduction-and-goals:

Introduction et Objectifs
=========================

.. _`_aperçu_des_spécifications`:

Aperçu des spécifications
-------------------------

.. _`_objectifs_de_qualité`:

Objectifs de Qualité
--------------------

.. _`_parties_prenantes`:

Parties prenantes
-----------------

+-------------+---------------------------+---------------------------+
| Rôle/Nom    | Contact                   | Attentes                  |
+=============+===========================+===========================+
| *<Role-1>*  | *<Contact-1>*             | *<Attente-1>*             |
+-------------+---------------------------+---------------------------+
| *<Role-2>*  | *<Contact-2>*             | *<Attente-2>*             |
+-------------+---------------------------+---------------------------+

.. _section-architecture-constraints:

Contraintes d’Architecture
==========================

.. _section-context-and-scope:

Contexte et périmètre
=====================

.. _`_contexte_métier`:

Contexte métier
---------------

**<Schéma ou tableau>**

**<éventuellement : Explication des interfaces de domaines externes>**

.. _`_contexte_technique`:

Contexte Technique
------------------

**<Schéma ou tableau>**

**<en option : Explication des interfaces techniques>**

**<Correspondance des entrées/sorties aux canaux>**

.. _section-solution-strategy:

Stratégie de solution
=====================

.. _section-building-block-view:

Vue en Briques
==============

.. _`_niveau_1_système_global_boîte_blanche`:

Niveau 1 : Système global Boîte blanche
---------------------------------------

**<Schéma d’ensemble>**

Motivation
   *<texte explicatif>*

Briques contenues
   *<Description de la brique contenue (boîte noire)>*

Interfaces Importantes
   *<Description des interfaces importantes>*

.. _`_nom_boîte_noire_1`:

<Nom boîte noire 1>
~~~~~~~~~~~~~~~~~~~

*<Objectif/Responsabilité>*

*<Interface(s)>*

*<(Facultatif) Caractéristiques de qualité/performance>*

*<(Facultatif) Emplacement du répertoire/fichier>*

*<(Facultatif) Exigences respectées>*

*<(Facultatif) Questions ouvertes/problèmes/risques>*

.. _`_nom_boîte_noire_2`:

<Nom boîte noire 2>
~~~~~~~~~~~~~~~~~~~

*<template boîte noire>*

.. _`_nom_boîte_noire_n`:

<Nom boîte noire n>
~~~~~~~~~~~~~~~~~~~

*<template boîte noire>*

.. _`_nom_interface_1`:

<Nom interface 1>
~~~~~~~~~~~~~~~~~

…​

.. _`_nom_interface_m`:

<Nom interface m>
~~~~~~~~~~~~~~~~~

.. _`_niveau_2`:

Niveau 2
--------

.. _`_boîte_blanche_brique_1`:

Boîte blanche *<brique 1>*
~~~~~~~~~~~~~~~~~~~~~~~~~~

*<template boîte blanche>*

.. _`_boîte_blanche_brique_2`:

Boîte blanche *<brique 2>*
~~~~~~~~~~~~~~~~~~~~~~~~~~

*<template boîte blanche>*

…​

.. _`_boîte_blanche_brique_n`:

Boîte blanche *<brique n>*
~~~~~~~~~~~~~~~~~~~~~~~~~~

*<template boîte blanche>*

.. _section-runtime-view:

Vue Exécution
=============

.. _`_scénario_dexécution_1`:

<Scénario d’exécution 1>
------------------------

-  *<insérer un diagramme d’exécution ou une description textuelle du
   scénario>*

-  *<insérer une description des aspects notables des interactions entre
   les instances des briques représentées dans ce diagramme.>*

.. _`_scénario_dexécution_2`:

<Scénario d’exécution 2>
------------------------

…​
-

.. _`_scénario_dexécution_n`:

<Scénario d’exécution n>
------------------------

.. _section-deployment-view:

Vue Déploiement
===============

.. _`_infrastructure_niveau_1`:

Infrastructure Niveau 1
-----------------------

**<Schéma d’ensemble>**

Motivation
   *<explication sous forme de texte>*

Caractéristiques de qualité et/ou de performance
   *<explication sous forme de texte>*

Correspondance des briques vis à vis de l’infrastructure
   *<description de la correspondance>*

.. _`_infrastructure_niveau_2`:

Infrastructure Niveau 2
-----------------------

.. _`_infrastructure_element_1`:

*<Infrastructure Element 1>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<schéma + explication>*

.. _`_infrastructure_element_2`:

*<Infrastructure Element 2>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<schéma + explication>*

…​

.. _`_infrastructure_element_n`:

*<Infrastructure Element n>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<schéma + explication>*

.. _section-concepts:

Concepts transversaux
=====================

.. _`_concept_1`:

*<Concept 1>*
-------------

*<explication>*

.. _`_concept_2`:

*<Concept 2>*
-------------

*<explication>*

…​

.. _`_concept_n`:

*<Concept n>*
-------------

*<explication>*

.. _section-design-decisions:

Décisions d’architecture
========================

.. _section-quality-scenarios:

Critères de qualité
===================

.. _`_exigences_de_qualité_vue_densemble`:

Exigences de qualité - Vue d’ensemble
-------------------------------------

.. _`_scénarios_qualité`:

Scénarios Qualité
-----------------

.. _section-technical-risks:

Risques et Dettes techniques
============================

.. _section-glossary:

Glossaire
=========

+----------------------+-----------------------------------------------+
| Terme                | Définition                                    |
+======================+===============================================+
| *<Terme-1>*          | *<Définition-1>*                              |
+----------------------+-----------------------------------------------+
| *<Terme-2>*          | *<Définition-2>*                              |
+----------------------+-----------------------------------------------+

.. |arc42| image:: images/arc42-logo.png
