# Introduzione e obiettivi {#section-introduction-and-goals}

## Panoramica dei requisiti {#_panoramica_dei_requisiti}

## Obiettivi di qualità {#_obiettivi_di_qualit}

## Stakeholders {#_stakeholders}

+-------------+---------------------------+---------------------------+
| Rouolo/Nome | Contatto                  | Aspettative               |
+=============+===========================+===========================+
| *           | *\<Contatto-1>*           | *\<Aspettatiive-1>*       |
| \<Ruolo-1>* |                           |                           |
+-------------+---------------------------+---------------------------+
| *           | *\<Contatto-2>*           | *\<Aspettatiive-2>*       |
| \<Ruolo-2>* |                           |                           |
+-------------+---------------------------+---------------------------+
