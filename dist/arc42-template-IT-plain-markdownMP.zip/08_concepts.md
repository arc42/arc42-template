# Concetti trasversali {#section-concepts}

## *\<Concetto 1\>* {#_concetto_1}

*\<spiegazione\>*

## *\<Concetto 2\>* {#_concetto_2}

*\<spiegazione\>*

...​

## *\<Concetto n\>* {#_concetto_n}

*\<spiegazione\>*
