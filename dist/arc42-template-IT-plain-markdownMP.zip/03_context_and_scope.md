# Ambito e contesto del sistema {#section-context-and-scope}

## Contesto di Business {#_contesto_di_business}

**\<Diagramma o Tabella>**

**\<opzionale: spiegazione delle interfacce del dominio esterno>**

## Contesto Tecnico {#_contesto_tecnico}

**\<Diagramma o Tabella>**

**\<opzionale: Spiegazione delle interfacce tecniche>**

**\<Mappatura Input/Output sui canali di comunicazione>**
