# Building Block View {#section-building-block-view}

## Whitebox Overall System {#_whitebox_overall_system}

***\<Overview Diagram>***

Motivazione

:   *\<spiegazione testuale>*

Contenuto dei Building Blocks

:   *\<Descrizione del contenuto del building block (black boxes)>*

Important Interfaces

:   *\<Descrizione delle interfacce importanti>*

### \<Nome black box 1> {#__nome_black_box_1}

*\<Scopo/responsabilità>*

*\<Interfacce>*

*\<(Facoltativo) Caratteristiche di qualità/prestazionali>*

*\<(Facoltativo) percorso file/directory>*

*\<(Facoltativo) Requisiti soddisfatti>*

*\<(Facoltativo) Bug noti/Rischi/problemi>*

### \<Nome black box 2> {#__nome_black_box_2}

*\<black box template>*

### \<Nome black box n> {#__nome_black_box_n}

*\<black box template>*

### \<Nome interface 1> {#__nome_interface_1}

...

### \<Nome interface m> {#__nome_interface_m}

## Livello 2 {#_livello_2}

### White Box *\<building block 1>* {#_white_box_emphasis_building_block_1_emphasis}

*\<white box template>*

### White Box *\<building block 2>* {#_white_box_emphasis_building_block_2_emphasis}

*\<white box template>*

...

### White Box *\<building block m>* {#_white_box_emphasis_building_block_m_emphasis}

*\<white box template>*

## Livello 3 {#_livello_3}

### White Box \<\_building block x.1\_\> {#_white_box_building_block_x_1}

*\<white box template>*

### White Box \<\_building block x.2\_\> {#_white_box_building_block_x_2}

*\<white box template>*

### White Box \<\_building block y.1\_\> {#_white_box_building_block_y_1}

*\<white box template>*
