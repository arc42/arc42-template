# Rischi e debiti tecnici {#section-technical-risks}
