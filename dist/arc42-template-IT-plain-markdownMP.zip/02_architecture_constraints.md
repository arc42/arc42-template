# Vincoli di architettura {#section-architecture-constraints}
