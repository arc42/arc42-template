# 品質需求

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

內容

</div>

本節包含所有相關的品質需求。

</div>

其中最重要的需求已在第 1.2
節（品質目標）中描述，因此在此僅需引用這些需求。 在第 10
節中，也應記錄重要性較低的品質需求；即使未完全達成，也不會造成高風險（但可能是
*加分項目*）。

<div class="formalpara">

<div class="title">

動機

</div>

由於品質需求會大幅影響架構決策，您應以具體且可衡量的方式，了解對利害關係人真正重要的品質。

</div>

<div>

<div class="title">

更多資訊

</div>

- 參見 arc42 文件中的 [品質需求](https://docs.arc42.org/section-10/)。

- 參見詳盡的 [Q42 品質模型](https://quality.arc42.org)。

</div>

</div>

## 品質需求概述

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

內容

</div>

品質需求的概述或摘要。

</div>

<div class="formalpara">

<div class="title">

動機

</div>

我們經常遇到數十（甚至數百）個詳細的品質需求。
在此概述部分，您應嘗試依照類別或主題進行摘要，例如參考 [ISO
25010:2023](https://www.iso.org/obp/ui/#iso:std:iso-iec:25010:ed-2:v1:en)
或 [Q42](https://quality.arc42.org) 的建議。

</div>

如果這些摘要已經足夠精確、具體且可衡量，您可以跳過第 10.2 節。

<div class="formalpara">

<div class="title">

形式

</div>

使用簡單表格，其中每列包含一個類別或主題，以及品質需求的簡短描述。
或者，您可以使用心智圖來組織這些品質需求。 文獻中也描述了 *品質屬性樹*
的概念：以「品質」這個通用術語作為根節點，並以樹狀結構逐步細化「品質」這個概念。
\[Bass+21\] 為此提出了「品質屬性效用樹」一詞。

</div>

</div>

## 品質情境

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

內容

</div>

品質情境使品質需求具體化，並可據此判斷是否達成（就驗收標準而言）。
請確保您的情境具體且可衡量。

</div>

<figure>
<img src="images/10_stimulus-ZH-TW.png" alt="品質情境" />
</figure>

以下兩種情境特別有用：

- *使用情境*（也稱為應用情境或使用案例情境）描述系統對特定刺激的執行階段回應。
  這也包括描述系統效率或效能的情境。 範例：系統在一秒內回應使用者請求。

- *變更情境* 描述修改或擴展系統，或修改其直接環境時所產生的預期效果。
  範例：新增功能或品質屬性的需求發生變化，並衡量變更所需的工作量或持續時間。

<div class="formalpara">

<div class="title">

形式

</div>

詳細情境通常包含以下資訊：

</div>

簡短格式（Q42 模型偏好的格式）：

- **脈絡/背景**：這是什麼類型的系統或元件？環境或情況為何？

- **來源/刺激**：誰或什麼啟動或觸發行為、反應或動作？

- **度量/驗收標準**：包含 *測量值* 或 *度量* 的回應。

情境的長格式（軟體工程研究所及 \[Bass+21\]
偏好的格式）更為詳細，包含以下資訊：

- **情境 ID**：情境的唯一識別碼。

- **情境名稱**：情境的簡短描述性名稱。

- **來源**：啟動情境的實體（使用者、系統或事件）。

- **刺激**：系統必須處理的觸發事件或條件。

- **環境**：系統經歷刺激時的操作脈絡或條件。

- **產出物**：受刺激影響的系統建構模組或其他元素。

- **回應**：系統對刺激的反應所表現出的結果或行為。

- **回應度量**：評估系統回應的準則或度量。

<div class="formalpara">

<div class="title">

範例

</div>

有關品質需求的詳細範例，請參見 [Q42
品質模型網站](https://quality.arc42.org)。

</div>

<div>

<div class="title">

更多資訊

</div>

- Len Bass、Paul Clements、Rick Kazman：《軟體架構實務》（Software
  Architecture in Practice），第 4 版，Addison-Wesley，2021。

</div>

</div>
