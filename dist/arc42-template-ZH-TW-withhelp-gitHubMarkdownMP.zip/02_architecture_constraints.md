# 架構限制

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

內容

</div>

任何會限制軟體架構師在設計與實作決策，或開發流程決策上的自由度之要求。這些限制有時不只適用於個別系統，也適用於整個組織與公司。

</div>

<div class="formalpara">

<div class="title">

動機

</div>

架構師應清楚知道哪些設計決策可以自由決定，以及哪些地方必須遵守限制。
這些限制都必須加以處理；不過，其中有些限制可能仍有協商空間。

</div>

<div class="formalpara">

<div class="title">

形式

</div>

附有說明的簡單限制表格。
如有需要，您可以將其細分為技術限制、組織與政治限制，以及慣例（例如程式設計或版本控制指南、文件或命名慣例）。

</div>

<div class="formalpara">

<div class="title">

更多資訊

</div>

參見 arc42 文件中的 [架構限制](https://docs.arc42.org/section-2/)。

</div>

</div>
