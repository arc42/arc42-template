# 脈絡與範圍

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

內容

</div>

脈絡與範圍，顧名思義，就是將您的系統（即您的範圍）與所有通訊方（周邊系統與使用者，也就是您系統的脈絡）區隔開來，藉此界定外部介面。
如有必要，請區分業務脈絡（特定領域的輸入與輸出）與技術脈絡（通道、通訊協定、硬體）。

</div>

<div class="formalpara">

<div class="title">

動機

</div>

與通訊方的領域介面和技術介面是系統最關鍵的部分，請確保您完全了解它們。

</div>

<div class="formalpara">

<div class="title">

形式

</div>

有以下幾種選擇：

</div>

- 系統脈絡圖

- 通訊方及其介面清單

<div class="formalpara">

<div class="title">

更多資訊

</div>

參見 arc42 文件中的 [脈絡與範圍](https://docs.arc42.org/section-3/)。

</div>

</div>

## 業務脈絡

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

內容

</div>

說明**所有**通訊方（例如使用者、IT
系統等），以及特定領域的輸入與輸出或介面。
您可以選擇新增特定領域的格式或通訊協定。

</div>

<div class="formalpara">

<div class="title">

動機

</div>

所有利害關係人都應了解哪些資料在系統與其環境之間交換。

</div>

<div class="formalpara">

<div class="title">

形式

</div>

使用各種圖表，將系統呈現為黑箱，並說明與通訊方之間的領域介面。
或者（或另外）使用表格。表格標題為系統名稱，三個欄位分別為通訊方名稱、輸入與輸出。

</div>

</div>

**\<圖表或表格\>**

**\<可選：外部領域介面的說明\>**

## 技術脈絡

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

內容

</div>

技術介面（通道與傳輸媒體）將您的系統與其環境連接起來。此外，還要將特定領域的輸入/輸出對應至通道，也就是說明哪些輸入/輸出使用哪些通道。

</div>

<div class="formalpara">

<div class="title">

動機

</div>

許多利害關係人會根據系統與其脈絡之間的技術介面做出架構決策。特別是基礎設施或硬體設計師會決定這些技術介面。

</div>

<div class="formalpara">

<div class="title">

形式

</div>

例如，使用 UML
部署圖描述連接至周邊系統的通道，並附上說明通道與輸入/輸出之間關係的對應表。

</div>

</div>

**\<圖表或表格\>**

**\<可選：技術介面的說明\>**

**\<輸入、輸出與通道之間的對應關係\>**
