# 橫切概念

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

內容

</div>

本節描述橫切概念（實務、模式、規範或解決方案構想）。這些概念通常與多個建構模組相關。
它們可能涵蓋許多不同主題，如下圖所示：

</div>

<figure>
<img src="images/08-concepts-ZH-TW.png" alt="橫切概念的潛在主題" />
</figure>

<div class="formalpara">

<div class="title">

動機

</div>

概念構成架構 *概念完整性*（一致性、同質性）的基礎。
因此，它們是實現系統內在品質的重要貢獻。

</div>

這是範本中用來集中且一致地規範此類概念的位置。

許多概念會涉及或影響您的多個建構模組。

<div class="formalpara">

<div class="title">

形式

</div>

形式可以多樣：

</div>

- 具有任何結構的概念文件

- 實作範例，特別是技術概念

- 使用架構視圖標記的橫切模型摘錄或情境

<div class="formalpara">

<div class="title">

結構

</div>

僅為您的系統挑選 **最必要的**
主題，並在本節中為每個主題設定第二層標題（例如 8.1、8.2 等）。

</div>

請勿 **試圖** 涵蓋上述圖表中的所有主題。

<div class="formalpara">

<div class="title">

更多資訊

</div>

系統內的某些主題通常涉及多個建構模組、硬體元素或開發流程。 將此類 *橫切*
主題集中在一個中央位置傳達或記錄，可能比在相關建構模組、硬體元素或開發流程的描述中重複說明更容易。

</div>

某些概念可能涉及系統的 **所有** 元素，其他概念可能僅與少數元素相關。
在上圖中，日誌記錄涉及全部三個元件，而安全性僅與其中兩個元件相關。

參見 arc42 文件中的 [概念](https://docs.arc42.org/section-8/)。

</div>

## *\<概念 1\>*

*\<解釋\>*

## *\<概念 2\>*

*\<解釋\>*

…​

## *\<概念 n\>*

*\<解釋\>*
