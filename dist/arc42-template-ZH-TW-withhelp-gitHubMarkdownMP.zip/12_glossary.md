# 術語表

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

內容

</div>

利害關係人討論系統時使用的最重要領域與技術術語。

</div>

如果您在多語言團隊中工作，也可以將術語表視為翻譯的依據。

<div class="formalpara">

<div class="title">

動機

</div>

您應清楚定義術語，讓所有利害關係人

</div>

- 對這些術語有相同的理解

- 不使用同義詞和同名異義詞

<div class="formalpara">

<div class="title">

形式

</div>

包含 \<術語\> 與 \<定義\> 欄位的表格。

</div>

如果需要翻譯，也可以增加其他欄位。

<div class="formalpara">

<div class="title">

更多資訊

</div>

參見 arc42 文件中的 [術語表](https://docs.arc42.org/section-12/)。

</div>

</div>

| 術語       | 英文       | 定義       |
|------------|------------|------------|
| \<術語-1\> | \<英文-1\> | \<定義-1\> |
| \<術語-2\> | \<英文-2\> | \<定義-2\> |
