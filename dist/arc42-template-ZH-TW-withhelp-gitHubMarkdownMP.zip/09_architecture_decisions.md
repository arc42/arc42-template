# 架構決策

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

內容

</div>

重要、成本高、規模大或風險高的架構決策及其理由。
我們所說的「決策」是指基於既定標準選擇替代方案。

</div>

請自行判斷架構決策是否應記錄在此中央章節，或是更適合在本地記錄（例如，記錄在某個建構模組的白箱範本中）。

避免重複。 參見第 4 節，您已在該處記錄架構最重要的決策。

<div class="formalpara">

<div class="title">

動機

</div>

您系統的利害關係人應能理解並追溯您的決策。

</div>

<div class="formalpara">

<div class="title">

形式

</div>

各種選擇：

</div>

- 為每個重要決策撰寫一份 ADR（架構決策紀錄，參見 [Documenting
  Architecture
  Decisions](https://cognitect.com/blog/2011/11/15/documenting-architecture-decisions)）

- 依重要性與後果排序的清單或表格；或

- 針對每個決策，以獨立章節提供更詳細的說明

<div class="formalpara">

<div class="title">

更多資訊

</div>

參見 arc42 文件中的 [架構決策](https://docs.arc42.org/section-9/)。
您將在那裡找到關於 ADR 的連結與範例。

</div>

</div>
