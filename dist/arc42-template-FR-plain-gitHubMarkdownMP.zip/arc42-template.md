# 

**A propos d’arc42**

arc42, le modèle de documentation de l’architecture des logiciels et des
systèmes.

Version du modèle 8.2 FR. (basé sur la version AsciiDoc), January 2023

Créé, maintenu et © par Dr. Peter Hruschka, Dr. Gernot Starke et les
contributeurs. Voir <https://arc42.org>.

# Introduction et Objectifs

## Aperçu des spécifications

## Objectifs de Qualité

## Parties prenantes

| Rôle/Nom    | Contact        | Attentes       |
|-------------|----------------|----------------|
| *\<Role-1>* | *\<Contact-1>* | *\<Attente-1>* |
| *\<Role-2>* | *\<Contact-2>* | *\<Attente-2>* |

# Contraintes d’Architecture

# Contexte et périmètre

## Contexte métier

**\<Schéma ou tableau>**

**\<éventuellement : Explication des interfaces de domaines externes>**

## Contexte Technique

**\<Schéma ou tableau>**

**\<en option : Explication des interfaces techniques>**

**\<Correspondance des entrées/sorties aux canaux>**

# Stratégie de solution

# Vue en Briques

## Niveau 1 : Système global Boîte blanche

***\<Schéma d’ensemble>***

Motivation  
*\<texte explicatif>*

Briques contenues  
*\<Description de la brique contenue (boîte noire)>*

Interfaces Importantes  
*\<Description des interfaces importantes>*

### \<Nom boîte noire 1>

*\<Objectif/Responsabilité>*

*\<Interface(s)>*

*\<(Facultatif) Caractéristiques de qualité/performance>*

*\<(Facultatif) Emplacement du répertoire/fichier>*

*\<(Facultatif) Exigences respectées>*

*\<(Facultatif) Questions ouvertes/problèmes/risques>*

### \<Nom boîte noire 2>

*\<template boîte noire>*

### \<Nom boîte noire n>

*\<template boîte noire>*

### \<Nom interface 1>

…

### \<Nom interface m>

## Niveau 2

### Boîte blanche *\<brique 1>*

*\<template boîte blanche>*

### Boîte blanche *\<brique 2>*

*\<template boîte blanche>*

…

### Boîte blanche *\<brique n>*

*\<template boîte blanche>*

# Vue Exécution

## \<Scénario d’exécution 1>

-   *\<insérer un diagramme d’exécution ou une description textuelle du
    scénario>*

-   *\<insérer une description des aspects notables des interactions
    entre les instances des briques représentées dans ce diagramme.>*

## \<Scénario d’exécution 2>

## …

## \<Scénario d’exécution n>

# Vue Déploiement

## Infrastructure Niveau 1

***\<Schéma d’ensemble>***

Motivation  
*\<explication sous forme de texte>*

Caractéristiques de qualité et/ou de performance  
*\<explication sous forme de texte>*

Correspondance des briques vis à vis de l’infrastructure  
*\<description de la correspondance>*

## Infrastructure Niveau 2

### *\<Infrastructure Element 1>*

*\<schéma + explication>*

### *\<Infrastructure Element 2>*

*\<schéma + explication>*

…

### *\<Infrastructure Element n>*

*\<schéma + explication>*

# Concepts transversaux

## *\<Concept 1>*

*\<explication>*

## *\<Concept 2>*

*\<explication>*

…

## *\<Concept n>*

*\<explication>*

# Décisions d’architecture

# Critères de qualité

## Arbre de qualité

## Scénarios Qualité

# Risques et Dettes techniques

# Glossaire

| Terme        | Définition        |
|--------------|-------------------|
| *\<Terme-1>* | *\<Définition-1>* |
| *\<Terme-2>* | *\<Définition-2>* |
