# Introduction et Objectifs

## Vue d’ensemble des exigences

## Objectifs de Qualité

## Parties prenantes

| Rôle/Nom    | Contact        | Attentes       |
|-------------|----------------|----------------|
| *\<Role-1>* | *\<Contact-1>* | *\<Attente-1>* |
| *\<Role-2>* | *\<Contact-2>* | *\<Attente-2>* |
