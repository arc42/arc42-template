# Glossaire

| Terme        | Définition        |
|--------------|-------------------|
| *\<Terme-1>* | *\<Définition-1>* |
| *\<Terme-2>* | *\<Définition-2>* |
