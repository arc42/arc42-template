# Vue en Briques

## Niveau 1 : Système global Boîte blanche

***\<Schéma d’ensemble\>***

Motivation  
*\<texte explicatif\>*

Briques contenues  
*\<Description de la brique contenue (boîte noire)\>*

Interfaces Importantes  
*\<Description des interfaces importantes\>*

### \<Nom boîte noire 1\>

*\<Objectif/Responsabilité\>*

*\<Interface(s)\>*

*\<(Facultatif) Caractéristiques de qualité/performance\>*

*\<(Facultatif) Emplacement du répertoire/fichier\>*

*\<(Facultatif) Exigences respectées\>*

*\<(Facultatif) Questions ouvertes/problèmes/risques\>*

### \<Nom boîte noire 2\>

*\<template boîte noire\>*

### \<Nom boîte noire n\>

*\<template boîte noire\>*

### \<Nom interface 1\>

…​

### \<Nom interface m\>

## Niveau 2

### Boîte blanche *\<brique 1\>*

*\<template boîte blanche\>*

### Boîte blanche *\<brique 2\>*

*\<template boîte blanche\>*

…​

### Boîte blanche *\<brique n\>*

*\<template boîte blanche\>*
