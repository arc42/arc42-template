# Concepts transverses

## *\<Concept 1>*

*\<explication>*

## *\<Concept 2>*

*\<explication>*

…

## *\<Concept n>*

*\<explication>*
