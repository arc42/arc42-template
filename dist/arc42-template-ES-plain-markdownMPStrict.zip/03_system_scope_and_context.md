# Alcance y Contexto del Sistema

## Contexto de Negocio

**&lt;Diagrama o Tabla>**

**&lt;optionally: Explanation of external domain interfaces>**

## Contexto Técnico

**&lt;Diagrama o Tabla>**

**&lt;Opcional: Explicación de las interfases técnicas>**

**&lt;Mapeo de Entrada/Salida a canales>**
