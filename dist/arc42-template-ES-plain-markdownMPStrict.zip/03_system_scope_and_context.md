Alcance y Contexto del Sistema
==============================

Contexto de Negocio
-------------------

**&lt;Diagrama o Tabla&gt;**

**&lt;optionally: Explanation of external domain interfaces&gt;**

Contexto Técnico
----------------

**&lt;Diagrama o Tabla&gt;**

**&lt;Opcional: Explicación de las interfases técnicas&gt;**

**&lt;Mapeo de Entrada/Salida a canales&gt;**
