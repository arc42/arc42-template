Restricciones de la Arquitectura
================================
