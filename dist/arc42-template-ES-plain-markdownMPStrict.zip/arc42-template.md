# 

**Acerca de arc42**

arc42, La plantilla de documentación para arquitectura de sistemas y de
software.

Por Dr. Gernot Starke, Dr. Peter Hruschka y otros contribuyentes.

Revisión de la plantilla: 7.0 ES (basada en asciidoc), Enero 2017

© Reconocemos que este documento utiliza material de la plantilla de
arquitectura arc42, <https://www.arc42.org>. Creada por Dr. Peter
Hruschka y Dr. Gernot Starke.

# Introducción y Metas

## Vista de Requerimientos

## Metas de Calidad

## Partes interesadas (Stakeholders)

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Rol/Nombre</th>
<th style="text-align: left;">Contacto</th>
<th style="text-align: left;">Expectativas</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Role-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Contact-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Expectation-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Role-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Contact-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Expectation-2&gt;</em></p></td>
</tr>
</tbody>
</table>

# Restricciones de la Arquitectura

# Alcance y Contexto del Sistema

## Contexto de Negocio

**&lt;Diagrama o Tabla>**

**&lt;optionally: Explanation of external domain interfaces>**

## Contexto Técnico

**&lt;Diagrama o Tabla>**

**&lt;Opcional: Explicación de las interfases técnicas>**

**&lt;Mapeo de Entrada/Salida a canales>**

# Estrategia de solución

# Vista de Bloques

## Sistema General de Caja Blanca

***&lt;Diagrama general>***

Motivación  
*&lt;Explicación en texto>*

Bloques de construcción contenidos  
*&lt;Desripción de los bloques de construcción contenidos (Cajas
negras)>*

Interfases importantes  
*&lt;Descripción de las interfases importantes>*

### &lt;Caja Negra 1>

*&lt;Propósito/Responsabilidad>*

*&lt;Interfase(s)>*

*&lt;(Opcional) Características de Calidad/Performance>*

*&lt;(Opcional) Ubicación Archivo/Directorio>*

*&lt;(Opcional) Requerimientos Satisfechos>*

*&lt;(Opcional) Riesgos/Problemas/Incidentes Abiertos>*

### &lt;Caja Negra 2>

*&lt;plantilla de caja negra>*

### &lt;Caja Negra N>

*&lt;Plantilla de caja negra>*

### &lt;Interfase 1>

…

### &lt;Interfase m>

## Nivel 2

### Caja Blanca *&lt;bloque de construcción 1>*

*&lt;plantilla de caja blanca>*

### Caja Blanca *&lt;bloque de construcción 2>*

*&lt;plantilla de caja blanca>*

…

### Caja Blanca *&lt;bloque de construcción m>*

*&lt;plantilla de caja blanca>*

## Nivel 3

### Caja Blanca &lt;\_bloque de construcción x.1\_&gt;

*&lt;plantilla de caja blanca>*

### Caja Blanca &lt;\_bloque de construcción x.2\_&gt;

*&lt;plantilla de caja blanca>*

### Caja Blanca &lt;\_bloque de construcción y.1\_&gt;

*&lt;plantilla de caja blanca>*

# Vista de Ejecución

## &lt;Escenario de ejecución 1>

-   *&lt;Inserte un diagrama de ejecución o la descripción del
    escenario>*

-   *&lt;Inserte la descripción de aspectos notables de las
    interacciones entre los bloques de construcción mostrados en este
    diagrama.>*

## &lt;Escenario de ejecución 2>

## …

## &lt;Escenario de ejecución n>

# Vista de Despliegue

## Nivel de infraestructura 1

***&lt;Diagrama General>***

Motivación  
*&lt;Explicación en forma textual>*

Características de Calidad/Rendimiento  
*&lt;Explicación en forma textual>*

Mapeo de los Bloques de Construcción a Infraestructura  
*&lt;Descripción del mapeo>*

## Nivel de Infraestructura 2

### *&lt;Elemento de Infraestructura 1>*

*&lt;diagrama + explicación>*

### *&lt;Elemento de Infraestructura 2>*

*&lt;diagrama + explicación>*

…

### *&lt;Elemento de Infraestructura n>*

*&lt;diagrama + explicación>*

# Conceptos Transversales (Cross-cutting)

## *&lt;Concepto 1>*

*&lt;explicación>*

## *&lt;Concepto 2>*

*&lt;explicación>*

…

## *&lt;Concepto n>*

*&lt;explicación>*

# Decisiones de Diseño

# Requerimientos de Calidad

## Árbol de Calidad

## Escenarios de calidad

# Riesgos y deuda técnica

# Glosario

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Término</th>
<th style="text-align: left;">Definición</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Término-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definicion-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Término-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definicion-2&gt;</em></p></td>
</tr>
</tbody>
</table>
