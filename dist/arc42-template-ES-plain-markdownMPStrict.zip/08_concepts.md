# Conceptos Transversales (Cross-cutting)

## *&lt;Concepto 1>*

*&lt;explicación>*

## *&lt;Concepto 2>*

*&lt;explicación>*

…

## *&lt;Concepto n>*

*&lt;explicación>*
