Conceptos Transversales (Cross-cutting)
=======================================

*&lt;Concepto 1&gt;*
--------------------

*&lt;explicación&gt;*

*&lt;Concepto 2&gt;*
--------------------

*&lt;explicación&gt;*

…

*&lt;Concepto n&gt;*
--------------------

*&lt;explicación&gt;*
