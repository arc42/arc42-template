Decisiones de Diseño
====================
