# Glosario

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Término</th>
<th style="text-align: left;">Definición</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Término-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definicion-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Término-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definicion-2&gt;</em></p></td>
</tr>
</tbody>
</table>
