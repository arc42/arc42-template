Riesgos y deuda técnica
=======================
