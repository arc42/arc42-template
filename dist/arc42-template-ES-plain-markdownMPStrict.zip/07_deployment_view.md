# Vista de Despliegue

## Nivel de infraestructura 1

***&lt;Diagrama General&gt;***

Motivación  
*&lt;Explicación en forma textual&gt;*

Características de Calidad/Rendimiento  
*&lt;Explicación en forma textual&gt;*

Mapeo de los Bloques de Construcción a Infraestructura  
*&lt;Descripción del mapeo&gt;*

## Nivel de Infraestructura 2

### *&lt;Elemento de Infraestructura 1&gt;*

*&lt;diagrama + explicación&gt;*

### *&lt;Elemento de Infraestructura 2&gt;*

*&lt;diagrama + explicación&gt;*

…

### *&lt;Elemento de Infraestructura n&gt;*

*&lt;diagrama + explicación&gt;*
