# Vista de Despliegue

## Nivel de infraestructura 1

***&lt;Diagrama General>***

Motivación  
*&lt;Explicación en forma textual>*

Características de Calidad/Rendimiento  
*&lt;Explicación en forma textual>*

Mapeo de los Bloques de Construcción a Infraestructura  
*&lt;Descripción del mapeo>*

## Nivel de Infraestructura 2

### *&lt;Elemento de Infraestructura 1>*

*&lt;diagrama + explicación>*

### *&lt;Elemento de Infraestructura 2>*

*&lt;diagrama + explicación>*

…

### *&lt;Elemento de Infraestructura n>*

*&lt;diagrama + explicación>*
