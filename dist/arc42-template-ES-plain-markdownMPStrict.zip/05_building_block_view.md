Vista de Bloques
================

Sistema General de Caja Blanca
------------------------------

***&lt;Diagrama general&gt;***

Motivación  
*&lt;Explicación en texto&gt;*

Bloques de construcción contenidos  
*&lt;Desripción de los bloques de construcción contenidos (Cajas
negras)&gt;*

Interfases importantes  
*&lt;Descripción de las interfases importantes&gt;*

### &lt;Caja Negra 1&gt;

*&lt;Propósito/Responsabilidad&gt;*

*&lt;Interfase(s)&gt;*

*&lt;(Opcional) Características de Calidad/Performance&gt;*

*&lt;(Opcional) Ubicación Archivo/Directorio&gt;*

*&lt;(Opcional) Requerimientos Satisfechos&gt;*

*&lt;(Opcional) Riesgos/Problemas/Incidentes Abiertos&gt;*

### &lt;Caja Negra 2&gt;

*&lt;plantilla de caja negra&gt;*

### &lt;Caja Negra N&gt;

*&lt;Plantilla de caja negra&gt;*

### &lt;Interfase 1&gt;

…

### &lt;Interfase m&gt;

Nivel 2
-------

### Caja Blanca *&lt;bloque de construcción 1&gt;*

*&lt;plantilla de caja blanca&gt;*

### Caja Blanca *&lt;bloque de construcción 2&gt;*

*&lt;plantilla de caja blanca&gt;*

…

### Caja Blanca *&lt;bloque de construcción m&gt;*

*&lt;plantilla de caja blanca&gt;*

Nivel 3
-------

### Caja Blanca &lt;\_bloque de construcción x.1\_&gt;

*&lt;plantilla de caja blanca&gt;*

### Caja Blanca &lt;\_bloque de construcción x.2\_&gt;

*&lt;plantilla de caja blanca&gt;*

### Caja Blanca &lt;\_bloque de construcción y.1\_&gt;

*&lt;plantilla de caja blanca&gt;*
