# Vista de Ejecución

## &lt;Escenario de ejecución 1&gt;

-   *&lt;Inserte un diagrama de ejecución o la descripción del
    escenario&gt;*

-   *&lt;Inserte la descripción de aspectos notables de las
    interacciones entre los bloques de construcción mostrados en este
    diagrama.&gt;*

## &lt;Escenario de ejecución 2&gt;

## …

## &lt;Escenario de ejecución n&gt;
