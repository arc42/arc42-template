# Vista de Ejecución

## &lt;Escenario de ejecución 1>

-   *&lt;Inserte un diagrama de ejecución o la descripción del
    escenario>*

-   *&lt;Inserte la descripción de aspectos notables de las
    interacciones entre los bloques de construcción mostrados en este
    diagrama.>*

## &lt;Escenario de ejecución 2>

## …

## &lt;Escenario de ejecución n>
