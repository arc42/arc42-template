# Apéndice. Incidentes abiertos

La siguiente tabla contiene una lista de todos los incidentes abiertos
identificados relacionados con este doucmento

La lista de todas los incidentes cerrados se pueden ver directamente en
Jira.

<table>
<caption>Incidentes abiertos</caption>
<colgroup>
<col style="width: 16%" />
<col style="width: 8%" />
<col style="width: 8%" />
<col style="width: 16%" />
<col style="width: 51%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">ID</th>
<th style="text-align: left;">Prioridad</th>
<th style="text-align: left;">Creado</th>
<th style="text-align: left;">Asignado a</th>
<th style="text-align: left;">Resumen</th>
</tr>
</thead>
<tbody>
</tbody>
</table>

Incidentes abiertos
