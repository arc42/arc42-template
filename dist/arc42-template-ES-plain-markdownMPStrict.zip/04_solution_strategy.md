Estrategia de solución
======================
