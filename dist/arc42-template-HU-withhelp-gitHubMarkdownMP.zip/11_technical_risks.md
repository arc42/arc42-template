# Kockázatok és technikai adósságok

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Tartalom

</div>

Az azonosított technikai kockázatok vagy technikai adósságok listája,
prioritás szerint rendezve.

</div>

<div class="formalpara">

<div class="title">

Motiváció

</div>

„A kockázatkezelés felnőttek projektmenedzsmentje” (Tim Lister, Atlantic
Systems Guild.)

</div>

Ez legyen az irányelv a kockázatok és technikai adósságok szisztematikus
felderítéséhez és értékeléséhez az architektúrában, amelyre a vezetői
szintű érdekelt feleknek (pl. projektvezetők, terméktulajdonosok)
szükségük van az átfogó kockázatelemzés és méréstervezés részeként.

<div class="formalpara">

<div class="title">

Forma

</div>

Kockázatok és/vagy technikai adósságok listája, valószínűleg javasolt
intézkedésekkel a kockázatok minimalizálására, mérséklésére vagy
elkerülésére, illetve a technikai adósságok csökkentésére.

</div>

<div class="formalpara">

<div class="title">

További információ

</div>

Lásd [Kockázatok és technikai
adósság](https://docs.arc42.org/section-11/) az arc42 dokumentációban.

</div>

</div>
