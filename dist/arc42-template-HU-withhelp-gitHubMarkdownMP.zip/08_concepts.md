# Keresztmetszeti koncepciók

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Tartalom

</div>

Ez a fejezet a keresztmetszeti koncepciókat (gyakorlatok, minták,
szabályozások vagy megoldási ötletek) írja le. Az ilyen koncepciók
gyakran több építőelemhez kapcsolódnak. Számos különböző témát
tartalmazhatnak, mint például az alábbi ábrán bemutatottak:

</div>

<figure>
<img src="images/08-concepts-HU.drawio.png"
alt="A keresztmetszeti koncepciók lehetséges témái" />
</figure>

<div class="formalpara">

<div class="title">

Motiváció

</div>

A koncepciók alkotják az architektúra *fogalmi integritásának*
(konzisztencia, homogenitás) alapját. Ezáltal fontos hozzájárulást
jelentenek a rendszer belső minőségeinek eléréséhez.

</div>

Ez a sablon azon helye, amelyet az ilyen koncepciók egységes
specifikációjára biztosítottunk.

Ezek közül sok koncepció több építőelemhez kapcsolódik vagy hat rájuk.

<div class="formalpara">

<div class="title">

Forma

</div>

A forma változatos lehet:

</div>

- koncepciódokumentumok bármilyen struktúrával

- példamegvalósítások, különösen technikai koncepciókhoz

- keresztmetszeti modellrészletek vagy forgatókönyvek az architekturális
  nézetek jelöléseivel

<div class="formalpara">

<div class="title">

Struktúra

</div>

Válassza ki **csak** a rendszer számára leginkább szükséges témákat, és
rendeljen hozzájuk egy 2. szintű címsort ebben a fejezetben (pl. 8.1,
8.2 stb).

</div>

NE PRÓBÁLJA meg lefedni a fent említett diagram összes témáját.

<div class="formalpara">

<div class="title">

További információ

</div>

Egyes témák a rendszerekben gyakran több építőelemet, hardverelemet vagy
fejlesztési folyamatot érintenek. Könnyebb lehet az ilyen
*keresztmetszeti* témákat egy központi helyen kommunikálni vagy
dokumentálni, ahelyett hogy megismételnénk őket az érintett építőelemek,
hardverelemek vagy fejlesztési folyamatok leírásában.

</div>

Bizonyos koncepciók **minden** elemre vonatkozhatnak, mások csak
néhányra lehetnek relevánsak. A fenti ábrán a naplózás mindhárom
komponenst érinti, míg a biztonság csak két komponens számára releváns.

Lásd [Koncepciók](https://docs.arc42.org/section-8/) az arc42
dokumentációban.

</div>

## *\<1. koncepció\>*

*\<magyarázat\>*

## *\<2. koncepció\>*

*\<magyarázat\>*

…​

## *\<n. koncepció\>*

*\<magyarázat\>*
