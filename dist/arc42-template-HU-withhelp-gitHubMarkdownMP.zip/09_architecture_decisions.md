# Architektúra-döntések

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Tartalom

</div>

Fontos, költséges, nagy léptékű vagy kockázatos architekturális
döntések, beleértve az indoklásokat. A „döntések” alatt egy alternatíva
kiválasztását értjük adott kritériumok alapján.

</div>

Kérjük, használja a saját megítélését annak eldöntéséhez, hogy egy
architekturális döntést itt, ebben a központi fejezetben kell-e
dokumentálni, vagy inkább lokálisan (pl. egy építőelem fehér doboz
sablonján belül).

Kerülje a redundanciát. Hivatkozzon a 4. fejezetre, ahol már rögzítette
az architektúra legfontosabb döntéseit.

<div class="formalpara">

<div class="title">

Motiváció

</div>

Rendszere érdekelt feleinek képesnek kell lenniük megérteni és nyomon
követni az Ön döntéseit.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Különböző lehetőségek:

</div>

- ADR ([Architektúra-döntések
  dokumentálása](https://cognitect.com/blog/2011/11/15/documenting-architecture-decisions))
  minden fontos döntéshez

- Lista vagy táblázat, fontosság és következmények szerint rendezve,
  vagy:

- részletesebben, döntésenként külön fejezetben

<div class="formalpara">

<div class="title">

További információ

</div>

Lásd [Architektúra-döntések](https://docs.arc42.org/section-9/) az arc42
dokumentációban. Ott hivatkozásokat és példákat talál az ADR-ekről.

</div>

</div>
