# Bevezetés és célok

<div class="sidebar">

<div class="title">

</div>

Leírja azokat a követelményeket és hajtóerőket, amelyeket a
szoftverarchitekteknek és a fejlesztőcsapatnak figyelembe kell venniük.
Ezek a következők:

- alapvető üzleti célok,

- lényeges funkciók,

- lényeges funkcionális követelmények,

- az architektúra minőségi céljai és

- a releváns érdekelt felek és elvárásaik

</div>

## Követelmények áttekintése

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Tartalom

</div>

A funkcionális követelmények rövid leírása, hajtóerők, a követelmények
kivonata (vagy összefoglalása). Hivatkozás a (remélhetőleg létező)
követelmény-dokumentumokra (verziószámmal és az elérhetőség
megjelölésével).

</div>

<div class="formalpara">

<div class="title">

Motiváció

</div>

A végfelhasználók szemszögéből a rendszert egy üzleti tevékenység jobb
támogatása és/vagy a minőség javítása érdekében hozzák létre vagy
módosítják.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Rövid szöveges leírás, valószínűleg táblázatos használati eset
formátumban. Ha léteznek követelmény-dokumentumok, ez az áttekintés
hivatkozzon azokra.

</div>

Tartsa ezeket a kivonatokat a lehető legrövidebben. Egyensúlyozzon a
dokumentum olvashatósága és a követelmény-dokumentumokkal való esetleges
redundancia között.

<div class="formalpara">

<div class="title">

További információ

</div>

Lásd [Bevezetés és célok](https://docs.arc42.org/section-1/) az arc42
dokumentációban.

</div>

</div>

## Minőségi célok

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Tartalom

</div>

Az architektúra három (legfeljebb öt) legfontosabb minőségi célja,
amelyek teljesülése a legfontosabb érdekelt felek számára a legnagyobb
jelentőséggel bír. Valóban az architektúra minőségi céljairól van szó.
Ne keverje össze ezeket a projekt céljaival. Nem feltétlenül azonosak.

</div>

Tekintse át a lehetséges témák alábbi áttekintését (az ISO 25010
szabvány alapján):

<figure>
<img src="images/01_2_iso-25010-topics-HU-2023.drawio.png"
alt="Minőségi követelmények kategóriái" />
</figure>

<div class="formalpara">

<div class="title">

Motiváció

</div>

Ismernie kell a legfontosabb érdekelt felek minőségi céljait, mivel ezek
alapvető architekturális döntéseket befolyásolnak. Legyen nagyon konkrét
ezekkel a minőségi jellemzőkkel kapcsolatban, kerülje a divatos
szavakat. Ha architektként nem tudja, hogyan fogják munkája minőségét
megítélni…​

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Táblázat minőségi célokkal és konkrét forgatókönyvekkel, prioritás
szerint rendezve

</div>

</div>

## Érdekelt felek

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Tartalom

</div>

A rendszer érdekelt feleinek explicit áttekintése, azaz minden személy,
szerepkör vagy szervezet, amely

</div>

- ismernie kell az architektúrát

- meg kell győzni az architektúráról

- az architektúrával vagy a kóddal kell dolgoznia

- munkájához szüksége van az architektúra dokumentációjára

- a rendszerrel vagy annak fejlesztésével kapcsolatos döntéseket kell
  hoznia

<div class="formalpara">

<div class="title">

Motiváció

</div>

Ismernie kell minden, a rendszer fejlesztésében érintett vagy a rendszer
által érintett felet. Ellenkező esetben kellemetlen meglepetések érhetik
a fejlesztési folyamat során. Ezek az érdekelt felek határozzák meg
munkája és annak eredményei terjedelmét, valamint részletességi
szintjét.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Táblázat szerepkörökkel, személynevekkel és az architektúrával, illetve
annak dokumentációjával kapcsolatos elvárásaikkal.

</div>

</div>

| Szerepkör/Név     | Elérhetőség         | Elvárások       |
|-------------------|---------------------|-----------------|
| *\<Szerepkör-1\>* | *\<Elérhetőség-1\>* | *\<Elvárás-1\>* |
| *\<Szerepkör-2\>* | *\<Elérhetőség-2\>* | *\<Elvárás-2\>* |
