# Szójegyzék

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Tartalom

</div>

A legfontosabb szakterületi és technikai kifejezések, amelyeket az
érdekelt felek a rendszer megvitatásakor használnak.

</div>

A szójegyzék fordítási forrásként is szolgálhat, ha többnyelvű
csapatokban dolgozik.

<div class="formalpara">

<div class="title">

Motiváció

</div>

Egyértelműen meg kell határoznia a kifejezéseket, hogy minden érdekelt
fél

</div>

- azonos módon értse ezeket a kifejezéseket

- ne használjon szinonimákat és homonimákat

<div class="formalpara">

<div class="title">

Forma

</div>

Táblázat \<Kifejezés\> és \<Meghatározás\> oszlopokkal.

</div>

Szükség esetén további oszlopok fordításokhoz.

<div class="formalpara">

<div class="title">

További információ

</div>

Lásd [Szójegyzék](https://docs.arc42.org/section-12/) az arc42
dokumentációban.

</div>

</div>

| Kifejezés         | Meghatározás         |
|-------------------|----------------------|
| *\<Kifejezés-1\>* | *\<meghatározás-1\>* |
| *\<Kifejezés-2\>* | *\<meghatározás-2\>* |
