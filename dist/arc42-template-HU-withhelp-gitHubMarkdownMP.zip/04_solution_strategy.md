# Megoldási stratégia

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Tartalom

</div>

Az alapvető döntések és megoldási stratégiák rövid összefoglalása és
magyarázata, amelyek a rendszer architektúráját alakítják. Ezek a
következők:

</div>

- technológiai döntések

- a rendszer legfelső szintű dekompozíciójára vonatkozó döntések, pl.
  architekturális minta vagy tervezési minta alkalmazása

- a kulcsfontosságú minőségi célok elérésére vonatkozó döntések

- releváns szervezeti döntések, pl. fejlesztési folyamat kiválasztása
  vagy bizonyos feladatok harmadik félnek történő delegálása.

<div class="formalpara">

<div class="title">

Motiváció

</div>

Ezek a döntések képezik az architektúra sarokköveit. Számos más
részletes döntés vagy megvalósítási szabály alapjául szolgálnak.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Tartsa rövidre az ilyen kulcsfontosságú döntések magyarázatát.

</div>

Indokolja meg, hogy mit döntöttek és miért úgy döntöttek, a
probléma-meghatározás, a minőségi célok és a kulcsfontosságú megkötések
alapján. Hivatkozzon a következő fejezetek részleteire.

<div class="formalpara">

<div class="title">

További információ

</div>

Lásd [Megoldási stratégia](https://docs.arc42.org/section-4/) az arc42
dokumentációban.

</div>

</div>
