# Kontextus és hatókör

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Tartalom

</div>

A kontextus és hatókör – ahogy a neve is sugallja – elhatárolja a
rendszert (azaz a hatókört) az összes kommunikációs partnerétől
(szomszédos rendszerek és felhasználók, azaz a rendszer kontextusa).
Ezáltal meghatározza a külső interfészeket.

</div>

Szükség esetén különítse el az üzleti kontextust (szakterület-specifikus
bemenetek és kimenetek) a technikai kontextustól (csatornák,
protokollok, hardver).

<div class="formalpara">

<div class="title">

Motiváció

</div>

A kommunikációs partnerek felé mutató szakterületi és technikai
interfészek a rendszer legkritikusabb szempontjai közé tartoznak.
Győződjön meg róla, hogy teljesen megérti őket.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Különböző lehetőségek:

</div>

- Kontextus-diagramok

- Kommunikációs partnerek és interfészeik listája.

<div class="formalpara">

<div class="title">

További információ

</div>

Lásd [Kontextus és hatókör](https://docs.arc42.org/section-3/) az arc42
dokumentációban.

</div>

</div>

## Üzleti kontextus

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Tartalom

</div>

Az **összes** kommunikációs partner (felhasználók, IT-rendszerek, …​)
specifikációja a szakterület-specifikus bemenetek és kimenetek, illetve
interfészek magyarázatával. Opcionálisan hozzáadhatók
szakterület-specifikus formátumok vagy kommunikációs protokollok.

</div>

<div class="formalpara">

<div class="title">

Motiváció

</div>

Minden érdekelt félnek meg kell értenie, milyen adatok cserélődnek a
rendszer környezetével.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Bármilyen diagram, amely a rendszert fekete dobozként mutatja, és
meghatározza a szakterületi interfészeket a kommunikációs partnerek
felé.

</div>

Alternatívaként (vagy kiegészítésként) használhat táblázatot is. A
táblázat címe a rendszer neve, a három oszlop tartalmazza a
kommunikációs partner nevét, a bemeneteket és a kimeneteket.

</div>

**\<Diagram vagy táblázat\>**

**\<opcionális: Külső szakterületi interfészek magyarázata\>**

## Technikai kontextus

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Tartalom

</div>

Technikai interfészek (csatornák és átviteli közegek), amelyek a
rendszert a környezetéhez kapcsolják. Emellett a szakterület-specifikus
bemenet/kimenet leképezése a csatornákra, azaz annak magyarázata, hogy
melyik I/O melyik csatornát használja.

</div>

<div class="formalpara">

<div class="title">

Motiváció

</div>

Sok érdekelt fél a rendszer és kontextusa közötti technikai interfészek
alapján hoz architekturális döntéseket. Különösen az infrastruktúra-
vagy hardvertervezők döntik el ezeket a technikai interfészeket.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Pl. UML telepítési diagram, amely a szomszédos rendszerek felé mutató
csatornákat írja le, kiegészítve egy leképezési táblázattal, amely a
csatornák és a bemenet/kimenet közötti kapcsolatokat mutatja.

</div>

</div>

**\<Diagram vagy táblázat\>**

**\<opcionális: Technikai interfészek magyarázata\>**

**\<Bemenet/kimenet leképezése csatornákra\>**
