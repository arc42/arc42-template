# Futásidejű nézet

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Tartalom

</div>

A futásidejű nézet a rendszer építőelemeinek konkrét viselkedését és
interakcióit írja le forgatókönyvek formájában, az alábbi területekről:

</div>

- fontos használati esetek vagy funkciók: hogyan hajtják végre az
  építőelemek?

- interakciók kritikus külső interfészeken: hogyan működnek együtt az
  építőelemek a felhasználókkal és szomszédos rendszerekkel?

- üzemeltetés és adminisztráció: indítás, elindulás, leállás

- hiba- és kivételforgatókönyvek

Megjegyzés: A lehetséges forgatókönyvek (szekvenciák, munkafolyamatok)
kiválasztásának fő kritériuma az **architekturális relevancia**. **Nem**
fontos nagyszámú forgatókönyvet leírni. Inkább egy reprezentatív
válogatást dokumentáljon.

<div class="formalpara">

<div class="title">

Motiváció

</div>

Meg kell értenie, hogyan végzik el a rendszerét alkotó építőelemek
(illetve azok példányai) a feladataikat, és hogyan kommunikálnak
futásidőben. A forgatókönyveket elsősorban azért rögzíti a
dokumentációban, hogy az architektúrát kommunikálja azoknak az érdekelt
feleknek, akik kevésbé hajlandók vagy képesek elolvasni és megérteni a
statikus modelleket (építőelem-nézet, telepítési nézet).

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Számos jelölés létezik a forgatókönyvek leírására, pl.:

</div>

- lépések számozott listája (természetes nyelven)

- tevékenységdiagramok vagy folyamatábrák

- szekvenciadiagramok

- BPMN vagy EPC-k (eseményvezérelt folyamatláncok)

- állapotgépek

- …​

<div class="formalpara">

<div class="title">

További információ

</div>

Lásd [Futásidejű nézet](https://docs.arc42.org/section-6/) az arc42
dokumentációban.

</div>

</div>

## \<Futásidejű forgatókönyv 1\>

- *\<illesszen be futásidejű diagramot vagy a forgatókönyv szöveges
  leírását\>*

- *\<illesszen be leírást az ábrázolt építőelem-példányok közötti
  interakciók figyelemre méltó aspektusairól.\>*

## \<Futásidejű forgatókönyv 2\>

## …​

## \<Futásidejű forgatókönyv n\>
