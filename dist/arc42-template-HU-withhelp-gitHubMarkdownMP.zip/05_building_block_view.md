# Építőelem-nézet

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Tartalom

</div>

Az építőelem-nézet a rendszer statikus dekompozícióját mutatja
építőelemekre (modulok, komponensek, alrendszerek, osztályok,
interfészek, csomagok, könyvtárak, keretrendszerek, rétegek, partíciók,
szintek, függvények, makrók, műveletek, adatstruktúrák, …​), valamint
azok függőségeit (kapcsolatok, asszociációk, …​).

</div>

Ez a nézet minden architektúra-dokumentációban kötelező. Egy ház
analógiájával élve ez az *alaprajz*.

<div class="formalpara">

<div class="title">

Motiváció

</div>

Őrizze meg a forráskód áttekinthetőségét azáltal, hogy szerkezetét
absztrakcióval érthetővé teszi.

</div>

Ez lehetővé teszi, hogy absztrakt szinten kommunikáljon az érdekelt
felekkel, anélkül, hogy a megvalósítás részleteit felfedné.

<div class="formalpara">

<div class="title">

Forma

</div>

Az építőelem-nézet fekete dobozok és fehér dobozok hierarchikus
gyűjteménye (lásd az alábbi ábrát) és azok leírásai.

</div>

<figure>
<img src="images/05_building_blocks-HU.png"
alt="Építőelemek hierarchiája" />
</figure>

Az **1. szint** a teljes rendszer fehér doboz leírása a benne található
összes építőelem fekete doboz leírásával együtt.

A **2. szint** ráközelít az 1. szint néhány építőelemére. Így az 1.
szint kiválasztott építőelemeinek fehér doboz leírását tartalmazza, azok
belső építőelemeinek fekete doboz leírásával együtt.

A **3. szint** ráközelít a 2. szint kiválasztott építőelemeire, és így
tovább.

<div class="formalpara">

<div class="title">

További információ

</div>

Lásd [Építőelem-nézet](https://docs.arc42.org/section-5/) az arc42
dokumentációban.

</div>

</div>

## Fehér doboz Teljes rendszer

<div class="sidebar">

<div class="title">

</div>

Itt írja le a teljes rendszer dekompozícióját az alábbi fehér doboz
sablon segítségével. Ez tartalmazza:

- egy áttekintő diagramot

- a dekompozíció motivációját

- a tartalmazott építőelemek fekete doboz leírásait. Ehhez a következő
  alternatívákat kínáljuk:

  - használjon *egy* táblázatot az összes tartalmazott építőelem és
    interfészük rövid és pragmatikus áttekintéséhez

  - használja a fekete doboz sablon szerinti fekete doboz leírások
    listáját (lásd alább). Az eszközválasztástól függően ez a lista
    lehet alfejezet (szöveges fájlokban), aloldal (wikiben) vagy
    beágyazott elem (modellező eszközben).

- (opcionális:) olyan fontos interfészek, amelyeket nem a fekete doboz
  sablonok magyaráznak meg, de nagyon fontosak a fehér doboz
  megértéséhez. Mivel az interfészek megadásának oly sok módja létezik,
  nem adunk meg hozzájuk specifikus sablont. A legrosszabb esetben meg
  kell adnia és le kell írnia a szintaxist, szemantikát, protokollokat,
  hibakezelést, korlátozásokat, verziókat, minőségi jellemzőket,
  szükséges kompatibilitásokat és sok mást. A legjobb esetben elegendőek
  lesznek a példák vagy egyszerű szignatúrák.

</div>

***\<Áttekintő diagram\>***

Motiváció  
*\<szöveges magyarázat\>*

Tartalmazott építőelemek  
*\<A tartalmazott építőelemek (fekete dobozok) leírása\>*

Fontos interfészek  
*\<Fontos interfészek leírása\>*

<div class="sidebar">

<div class="title">

</div>

Illessze be az 1. szint fekete dobozainak magyarázatát:

Ha táblázatos formát használ, a fekete dobozokat csak név és felelősség
szerint írja le a következő séma szerint:

| **Név**              | **Felelősség** |
|----------------------|----------------|
| *\<fekete doboz 1\>* | *\<Szöveg\>*   |
| *\<fekete doboz 2\>* | *\<Szöveg\>*   |

Ha fekete doboz leírások listáját használja, minden fontos építőelemhez
külön fekete doboz sablont tölt ki. A címsora az adott fekete doboz
neve.

</div>

### \<Fekete doboz 1 neve\>

<div class="sidebar">

<div class="title">

</div>

Itt írja le a \<fekete doboz 1\>-et a következő fekete doboz sablon
szerint:

- Cél/Felelősség

- Interfész(ek), ha nem külön bekezdésbe vannak kiemelve. Ezek az
  interfészek tartalmazhatnak minőségi és teljesítményjellemzőket.

- (Opcionális) Minőségi/Teljesítményjellemzők a fekete dobozra
  vonatkozóan, pl. rendelkezésre állás, futásidejű viselkedés, …​.

- (Opcionális) Könyvtár/fájl elérési út

- (Opcionális) Teljesített követelmények (ha nyomon követhetőség
  szükséges a követelményekhez).

- (Opcionális) Nyitott kérdések/problémák/kockázatok

</div>

*\<Cél/Felelősség\>*

*\<Interfész(ek)\>*

*\<(Opcionális) Minőségi/Teljesítményjellemzők\>*

*\<(Opcionális) Könyvtár/Fájl elérési út\>*

*\<(Opcionális) Teljesített követelmények\>*

*\<(Opcionális) Nyitott kérdések/Problémák/Kockázatok\>*

### \<Fekete doboz 2 neve\>

*\<fekete doboz sablon\>*

### \<Fekete doboz n neve\>

*\<fekete doboz sablon\>*

### \<Interfész 1 neve\>

…​

### \<Interfész m neve\>

## 2. szint

<div class="sidebar">

<div class="title">

</div>

Itt adhatja meg az 1. szint (néhány) építőelemének belső szerkezetét
fehér dobozként.

El kell döntenie, hogy a rendszer mely építőelemei elég fontosak ahhoz,
hogy ilyen részletes leírást kapjanak. Részesítse előnyben a relevanciát
a teljességgel szemben. Írja le a fontos, meglepő, kockázatos, összetett
vagy instabil építőelemeket. Hagyja ki a rendszer normális, egyszerű,
unalmas vagy szabványos részeit.

</div>

### Fehér doboz *\<1. építőelem\>*

<div class="sidebar">

<div class="title">

</div>

…​az *1. építőelem* belső szerkezetét írja le.

</div>

*\<fehér doboz sablon\>*

### Fehér doboz *\<2. építőelem\>*

*\<fehér doboz sablon\>*

…​

### Fehér doboz *\<m. építőelem\>*

*\<fehér doboz sablon\>*

## 3. szint

<div class="sidebar">

<div class="title">

</div>

Itt adhatja meg a 2. szint (néhány) építőelemének belső szerkezetét
fehér dobozként.

Ha az architektúrában részletesebb szintekre van szükség, másolja le az
arc42 ezen részét a további szintekhez.

</div>

### Fehér doboz \<\_x.1 építőelem\_\>

<div class="sidebar">

<div class="title">

</div>

Az *x.1 építőelem* belső szerkezetét adja meg.

</div>

*\<fehér doboz sablon\>*

### Fehér doboz \<\_x.2 építőelem\_\>

*\<fehér doboz sablon\>*

### Fehér doboz \<\_y.1 építőelem\_\>

*\<fehér doboz sablon\>*
