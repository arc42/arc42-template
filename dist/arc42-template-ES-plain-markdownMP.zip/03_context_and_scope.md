# Alcance y Contexto del Sistema {#section-context-and-scope}

## Contexto de Negocio {#_contexto_de_negocio}

**\<Diagrama o Tabla>**

**\<optionally: Explanation of external domain interfaces>**

## Contexto Técnico {#_contexto_t_cnico}

**\<Diagrama o Tabla>**

**\<Opcional: Explicación de las interfases técnicas>**

**\<Mapeo de Entrada/Salida a canales>**
