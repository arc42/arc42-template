# Vista de Despliegue {#section-deployment-view}

## Nivel de infraestructura 1 {#_nivel_de_infraestructura_1}

***\<Diagrama General\>***

Motivación

:   *\<Explicación en forma textual\>*

Características de Calidad/Rendimiento

:   *\<Explicación en forma textual\>*

    Mapeo de los Bloques de Construcción a Infraestructura

    :   *\<Descripción del mapeo\>*

## Nivel de Infraestructura 2 {#_nivel_de_infraestructura_2}

### *\<Elemento de Infraestructura 1\>* {#__emphasis_elemento_de_infraestructura_1_emphasis}

*\<diagrama + explicación\>*

### *\<Elemento de Infraestructura 2\>* {#__emphasis_elemento_de_infraestructura_2_emphasis}

*\<diagrama + explicación\>*

...

### *\<Elemento de Infraestructura n\>* {#__emphasis_elemento_de_infraestructura_n_emphasis}

*\<diagrama + explicación\>*
