Alcance y Contexto del Sistema {#section-system-scope-and-context}
==============================

Contexto de Negocio {#_contexto_de_negocio}
-------------------

**&lt;Diagrama o Tabla&gt;**

**&lt;optionally: Explanation of external domain interfaces&gt;**

Contexto Técnico {#_contexto_t_cnico}
----------------

**&lt;Diagrama o Tabla&gt;**

**&lt;Opcional: Explicación de las interfases técnicas&gt;**

**&lt;Mapeo de Entrada/Salida a canales&gt;**
