Riesgos y deuda técnica {#section-technical-risks}
=======================
