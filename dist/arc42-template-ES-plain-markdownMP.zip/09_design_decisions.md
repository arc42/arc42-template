Decisiones de Diseño {#section-design-decisions}
====================
