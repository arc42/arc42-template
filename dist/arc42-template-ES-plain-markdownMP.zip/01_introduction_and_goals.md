Introducción y Metas {#section-introduction-and-goals}
====================

Vista de Requerimientos {#_vista_de_requerimientos}
-----------------------

Metas de Calidad {#_metas_de_calidad}
----------------

Partes interesadas (Stakeholders) {#_partes_interesadas_stakeholders}
---------------------------------

+-------------+---------------------------+---------------------------+
| Rol/Nombre  | Contacto                  | Expectativas              |
+=============+===========================+===========================+
| *\<Role-1\> | *\<Contact-1\>*           | *\<Expectation-1\>*       |
| *           |                           |                           |
+-------------+---------------------------+---------------------------+
| *\<Role-2\> | *\<Contact-2\>*           | *\<Expectation-2\>*       |
| *           |                           |                           |
+-------------+---------------------------+---------------------------+
