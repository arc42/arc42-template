Introducción y Metas {#section-introduction-and-goals}
====================

Vista de Requerimientos {#_vista_de_requerimientos}
-----------------------

Metas de Calidad {#_metas_de_calidad}
----------------

Partes interesadas (Stakeholders) {#_partes_interesadas_stakeholders}
---------------------------------

+-------------+---------------------------+---------------------------+
| Rol/Nombre  | Contacto                  | Expectativas              |
+=============+===========================+===========================+
| *&lt;Role-1 | *&lt;Contact-1&gt;*       | *&lt;Expectation-1&gt;*   |
| &gt;*       |                           |                           |
+-------------+---------------------------+---------------------------+
| *&lt;Role-2 | *&lt;Contact-2&gt;*       | *&lt;Expectation-2&gt;*   |
| &gt;*       |                           |                           |
+-------------+---------------------------+---------------------------+


