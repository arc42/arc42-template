Estrategia de solución {#section-solution-strategy}
======================
