# Restricciones de la Arquitectura {#section-architecture-constraints}
