Conceptos Transversales (Cross-cutting) {#section-concepts}
=======================================

*\<Concepto 1\>* {#_concepto_1}
----------------

*\<explicación\>*

*\<Concepto 2\>* {#_concepto_2}
----------------

*\<explicación\>*

...​

*\<Concepto n\>* {#_concepto_n}
----------------

*\<explicación\>*
