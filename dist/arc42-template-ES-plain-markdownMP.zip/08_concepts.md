Conceptos Transversales (Cross-cutting) {#section-concepts}
=======================================

*&lt;Concepto 1&gt;* {#__emphasis_concepto_1_emphasis}
--------------------

*&lt;explicación&gt;*

*&lt;Concepto 2&gt;* {#__emphasis_concepto_2_emphasis}
--------------------

*&lt;explicación&gt;*

…

*&lt;Concepto n&gt;* {#__emphasis_concepto_n_emphasis}
--------------------

*&lt;explicación&gt;*
