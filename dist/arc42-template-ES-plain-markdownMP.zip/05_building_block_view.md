Vista de Bloques {#section-building-block-view}
================

Sistema General de Caja Blanca {#_sistema_general_de_caja_blanca}
------------------------------

***&lt;Diagrama general&gt;***

Motivación

:   *&lt;Explicación en texto&gt;*

Bloques de construcción contenidos

:   *&lt;Desripción de los bloques de construcción contenidos (Cajas
    negras)&gt;*

Interfases importantes

:   *&lt;Descripción de las interfases importantes&gt;*

### &lt;Caja Negra 1&gt; {#__caja_negra_1}

*&lt;Propósito/Responsabilidad&gt;*

*&lt;Interfase(s)&gt;*

*&lt;(Opcional) Características de Calidad/Performance&gt;*

*&lt;(Opcional) Ubicación Archivo/Directorio&gt;*

*&lt;(Opcional) Requerimientos Satisfechos&gt;*

*&lt;(Opcional) Riesgos/Problemas/Incidentes Abiertos&gt;*

### &lt;Caja Negra 2&gt; {#__caja_negra_2}

*&lt;plantilla de caja negra&gt;*

### &lt;Caja Negra N&gt; {#__caja_negra_n}

*&lt;Plantilla de caja negra&gt;*

### &lt;Interfase 1&gt; {#__interfase_1}

…

### &lt;Interfase m&gt; {#__interfase_m}

Nivel 2 {#_nivel_2}
-------

### Caja Blanca *&lt;bloque de construcción 1&gt;* {#_caja_blanca_emphasis_bloque_de_construcci_n_1_emphasis}

*&lt;plantilla de caja blanca&gt;*

### Caja Blanca *&lt;bloque de construcción 2&gt;* {#_caja_blanca_emphasis_bloque_de_construcci_n_2_emphasis}

*&lt;plantilla de caja blanca&gt;*

…

### Caja Blanca *&lt;bloque de construcción m&gt;* {#_caja_blanca_emphasis_bloque_de_construcci_n_m_emphasis}

*&lt;plantilla de caja blanca&gt;*

Nivel 3 {#_nivel_3}
-------

### Caja Blanca &lt;\_bloque de construcción x.1\_&gt; {#_caja_blanca_bloque_de_construcci_n_x_1}

*&lt;plantilla de caja blanca&gt;*

### Caja Blanca &lt;\_bloque de construcción x.2\_&gt; {#_caja_blanca_bloque_de_construcci_n_x_2}

*&lt;plantilla de caja blanca&gt;*

### Caja Blanca &lt;\_bloque de construcción y.1\_&gt; {#_caja_blanca_bloque_de_construcci_n_y_1}

*&lt;plantilla de caja blanca&gt;*
