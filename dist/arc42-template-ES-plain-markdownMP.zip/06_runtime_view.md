Vista de Ejecución {#section-runtime-view}
==================

\<Escenario de ejecución 1\> {#__escenario_de_ejecuci_n_1}
----------------------------

-   *\<Inserte un diagrama de ejecución o la descripción del
    escenario\>*

-   *\<Inserte la descripción de aspectos notables de las interacciones
    entre los bloques de construcción mostrados en este diagrama.\>*

\<Escenario de ejecución 2\> {#__escenario_de_ejecuci_n_2}
----------------------------

... {#_}
---

\<Escenario de ejecución n\> {#__escenario_de_ejecuci_n_n}
----------------------------
