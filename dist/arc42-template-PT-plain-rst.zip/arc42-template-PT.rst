==============
Modelo |arc42|
==============

:Date: Setembro de 2024

**Sobre o arc42**

arc42, o template para documentação de software e arquitetura de
sistemas.

Versão do template 8.2-PT. (based upon AsciiDoc version), Setembro de
2024

Criado, mantido e © pelo Dr. Peter Hruschka, Dr. Gernot Starke e
colaboradores. Veja https://arc42.org.

.. _section-introduction-and-goals:

Introdução e Objetivos
======================

.. _`_visão_geral_dos_requisitos`:

Visão Geral dos Requisitos
--------------------------

.. _`_objetivos_de_qualidade`:

Objetivos de Qualidade
----------------------

.. _`_partes_interessadas`:

Partes Interessadas
-------------------

+-------------+---------------------------+---------------------------+
| Função/Nome | Contato                   | Expectativas              |
+=============+===========================+===========================+
| *           | *<Contato-1>*             | *<Expectativa-1>*         |
| <Função-1>* |                           |                           |
+-------------+---------------------------+---------------------------+
| *           | *<Contato-2>*             | *<Expectativa-2>*         |
| <Função-2>* |                           |                           |
+-------------+---------------------------+---------------------------+

.. _section-architecture-constraints:

Restrições Arquiteturais
========================

.. _section-context-and-scope:

Contexto e Escopo
=================

.. _`_contexto_negocial`:

Contexto Negocial
-----------------

**<Diagrama ou Tabela>**

**<opcionalmente: Explicação das interfaces de domínio externo>**

.. _`_contexto_técnico`:

Contexto Técnico
----------------

**<Diagrama ou Tabela>**

**<opcionalmente: Explicação das interfaces técnicas>**

**<Mapeamento de entrada/saída para canais>**

.. _section-solution-strategy:

Estratégia de Solução
=====================

.. _section-building-block-view:

Visão de Blocos de Construção
=============================

.. _`_visão_sistêmica_geral_de_caixa_branca`:

Visão Sistêmica Geral de Caixa Branca
-------------------------------------

**<Diagrama de Visão Geral>**

Motivação
   *<explicação textual>*

Blocos de Construção Contidos
   *<Descrição dos blocos de construção contidos (caixas pretas)>*

Interfaces Importantes
   *<Descrição de interfaces importantes>*

.. _`_nome_caixa_preta_1`:

<Nome Caixa Preta 1>
~~~~~~~~~~~~~~~~~~~~

*<Propósito/Responsabilidade>*

*<Interface(s)>*

*<(Opcional) Características de Qualidade/Desempenho>*

*<(Opcional) Local do Diretório/Arquivo>*

*<(Opcional) Requisitos Cumpridos>*

*<(opcional) Problemas/Riscos Abertos>*

.. _`_nome_caixa_preta_2`:

<Nome Caixa Preta 2>
~~~~~~~~~~~~~~~~~~~~

*<modelo de caixa preta>*

.. _`_nome_caixa_preta_n`:

<Nome Caixa Preta n>
~~~~~~~~~~~~~~~~~~~~

*<modelo de caixa preta>*

.. _`_nome_interface_1`:

<Nome Interface 1>
~~~~~~~~~~~~~~~~~~

…​

.. _`_nome_interface_m`:

<Nome Interface m>
~~~~~~~~~~~~~~~~~~

.. _`_nível_2`:

Nível 2
-------

.. _`_caixa_branca_bloco_de_construção_1`:

Caixa Branca *<Bloco de Construção 1>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<modelo de caixa branca>*

.. _`_caixa_branca_bloco_de_construção_2`:

Caixa Branca *<Bloco de Construção 2>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<modelo de caixa branca>*

…​

.. _`_caixa_branca_bloco_de_construção_m`:

Caixa Branca *<Bloco de Construção m>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<modelo de caixa branca>*

.. _`_nível_3`:

Nível 3
-------

.. _`_caixa_branca_bloco_de_construção_x_1`:

Caixa Branca <\_Bloco de Construção x.1\_>
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<modelo de caixa branca>*

.. _`_caixa_branca_bloco_de_construção_x_2`:

Caixa Branca <\_Bloco de Construção x.2\_>
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<modelo de caixa branca>*

.. _`_caixa_branca_bloco_de_construção_y_1`:

Caixa Branca <\_Bloco de Construção y.1\_>
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<modelo de caixa branca>*

.. _section-runtime-view:

Visão de Tempo de Execução
==========================

.. _`_cenário_de_tempo_de_execução_1`:

<Cenário de Tempo de Execução 1>
--------------------------------

-  *<inserir diagrama de tempo de execução ou descrição textual do
   cenário>*

-  *<inserir descrição dos aspectos notáveis ​​das interações entre as
   instâncias do bloco de construção descritas neste diagrama.>*

.. _`_cenário_de_tempo_de_execução_2`:

<Cenário de Tempo de Execução 2>
--------------------------------

…​
-

.. _`_cenário_de_tempo_de_execução_n`:

<Cenário de Tempo de Execução n>
--------------------------------

.. _section-deployment-view:

Visão de Implantação
====================

.. _`_nível_de_infraestrutura_1`:

Nível de Infraestrutura 1
-------------------------

**<Diagrama de Visão Geral>**

Motivação
   *<explicação em forma de texto>*

Características de Qualidade e/ou Desempenho
   *<explicação em forma de texto>*

Mapeamento de Blocos de Construção para Infraestrutura
   *<descrição do mapeamento>*

.. _`_nível_de_infraestrutura_2`:

Nível de Infraestrutura 2
-------------------------

.. _`_elemento_de_infraestrutura_1`:

*<Elemento de Infraestrutura 1>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<diagrama + explicação>*

.. _`_elemento_de_infraestrutura_2`:

*<Elemento de Infraestrutura 2>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<diagrama + explicação>*

…​

.. _`_elemento_de_infraestrutura_n`:

*<Elemento de Infraestrutura n>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<diagrama + explicação>*

.. _section-concepts:

Conceitos Transversais
======================

.. _`_conceito_1`:

*<Conceito 1>*
--------------

*<explicação>*

.. _`_conceito_2`:

*<Conceito 2>*
--------------

*<explicação>*

…​

.. _`_conceito_n`:

*<Conceito n>*
--------------

*<explicação>*

.. _section-design-decisions:

Decisões Arquiteturais
======================

.. _section-quality-scenarios:

Requisitos de qualidade
=======================

.. _`_árvore_de_qualidade`:

Árvore de qualidade
-------------------

.. _`_cenários_de_qualidade`:

Cenários de Qualidade
---------------------

.. _section-technical-risks:

Riscos e Débitos Técnicos
=========================

.. _section-glossary:

Glossário
=========

+----------------------+-----------------------------------------------+
| Termo                | Definição                                     |
+======================+===============================================+
| *<Termo-1>*          | *<definição-1>*                               |
+----------------------+-----------------------------------------------+
| *<Termo-2>*          | *<definição-2>*                               |
+----------------------+-----------------------------------------------+

.. |arc42| image:: images/arc42-logo.png
