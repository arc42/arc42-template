# 

**关于 arc42**

arc42，软件和系统架构文档模板。

模板版本 9.0-ZH。(基于 AsciiDoc 版本)，7月 2025

由 Dr. Peter Hruschka、Dr. Gernot Starke 及贡献者创建、维护和版权所有。
参见 <https://arc42.org> 。

# 引言与目标

## 需求概述

## 质量目标

## 干系人

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">角色/姓名</th>
<th style="text-align: left;">联系方式</th>
<th style="text-align: left;">期望</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;角色-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;联系方式-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;期望-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;角色-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;联系方式-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;期望-2&gt;</em></p></td>
</tr>
</tbody>
</table>

# 架构约束

# 上下文和边界

## 业务上下文

**&lt;图表或表格&gt;**

**&lt;可选：外部领域接口的解释&gt;**

## 技术上下文

**&lt;图表或表格&gt;**

**&lt;可选：技术接口的解释&gt;**

**&lt;输入、输出与信道之间的映射关系&gt;**

# 解决方案策略

# 构建块视图

## 整体系统

***&lt;概览图&gt;***

动机  
*&lt;文字说明&gt;*

包含的构建块  
*&lt;包含构建块（黑盒）的描述&gt;*

重要接口  
*&lt;对于重要接口的描述&gt;*

### &lt;黑盒 1&gt;

*&lt;目的/责任&gt;*

*&lt;接口列表&gt;*

*&lt;（可选）质量/性能特征&gt;*

*&lt;（可选）目录/文件路径&gt;*

*&lt;（可选）已满足的要求&gt;*

*&lt;（可选）未解决的问题/难题/风险&gt;*

### &lt;黑盒 2&gt;

*&lt;黑盒模板&gt;*

### &lt;黑盒 n&gt;

*&lt;黑盒模板&gt;*

### &lt;接口 1&gt;

…​

### &lt;接口 m&gt;

## 级别2

### 白盒 *&lt;构件块 1&gt;*

*&lt;白盒模板&gt;*

### 白盒 *&lt;构件块 2&gt;*

*&lt;白盒模板&gt;*

…​

### 白盒 *&lt;构件块 m&gt;*

*&lt;白盒模板&gt;*

## 级别3

### 白盒 &lt;\_构件块 x.1\_&gt;

*&lt;白盒模板&gt;*

### 白盒 &lt;\_构件块 x.2\_&gt;

*&lt;白盒模板&gt;*

### 白盒 &lt;\_构件块 y.1\_&gt;

*&lt;白盒模板&gt;*

# 运行时视图

## &lt;运行时场景 1&gt;

-   *&lt;插入场景的运行时图表或文本描述&gt;*

-   *&lt;插入此图中的构建模块实例之间交互关系的注意事项。&gt;*

## &lt;运行时场景 2&gt;

## …​

## &lt;运行时场景 n&gt;

# 部署视图

## 基础设施级别 1

***&lt;概览图&gt;***

动机  
*&lt;文本形式的解释&gt;*

质量和/或性能特征  
*&lt;文本形式的解释&gt;*

构建块到基础设施的映射  
*&lt;映射的描述&gt;*

## 基础设施级别 2

### *&lt;基础设施要素 1&gt;*

*&lt;图表 + 解释&gt;*

### *&lt;基础设施要素 2&gt;*

*&lt;图表 + 解释&gt;*

…​

### *&lt;基础设施要素 n&gt;*

*&lt;图表 + 解释&gt;*

# 跨领域概念

## *&lt;概念 1&gt;*

*&lt;解释&gt;*

## *&lt;概念 2&gt;*

*&lt;解释&gt;*

…​

## *&lt;概念 n&gt;*

*&lt;解释&gt;*

# 架构决策

# 质量需求

## 质量需求概述

## 质量场景

# 风险和技术债务

# 术语表

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">术语</th>
<th style="text-align: left;">英文</th>
<th style="text-align: left;">定义</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p>&lt;术语-1&gt;</p></td>
<td style="text-align: left;"><p>&lt;英文-1&gt;</p></td>
<td style="text-align: left;"><p>&lt;定义-1&gt;</p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p>&lt;术语-2&gt;</p></td>
<td style="text-align: left;"><p>&lt;英文-2&gt;</p></td>
<td style="text-align: left;"><p>&lt;定义-2&gt;</p></td>
</tr>
</tbody>
</table>
