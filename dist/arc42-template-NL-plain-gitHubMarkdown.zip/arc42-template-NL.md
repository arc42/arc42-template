# 

**Over arc42**

arc42, de Template voor documentatie van software en systeem
architectuur.

Gecreeerd en onderhouden door Dr. Peter Hruschka, Dr. Gernot Starke en
bijdragers.

Template Versie: 8. De NL versie is gebaseerd op EN template versie 8,
februari 2022

© We erkennen dat dit document materiaal gebruikt van de arc 42
architectuur template, <https://arc42.org>.

# Introductie en Doelen

## Requirements Overzicht

## Kwaliteits Doelen

## Belanghebbenden

| Rol/Naam   | Contact persoon | Verwachtingen      |
|------------|-----------------|--------------------|
| *\<Rol-1>* | *\<Contact-1>*  | *\<Verwachting-1>* |
| *\<Rol-2>* | *\<Contact-2>*  | *\<Verwachting-2>* |

# Architectuur Beperkingen

# Systeem Scope en Context

## Business Context

**\<Diagram of Tabel>**

**\<optioneel: Uitleg van de externe domein interfaces>**

## Technische Context

**\<Diagram of Tabel>**

**\<optioneel: Uitleg van technische interfaces>**

**\<Mapping Input/Output naar kanalen>**

# Oplossing Strategie

# Bouwstenen View

## Gehele whitebox Systeem

***\<Overzichts Diagram>***

Motivatie  
*\<tekstuele uitleg>*

Ingesloten bouwstenen  
*\<Beschrijving van ingesloten bouwstenen (*black boxes*)>*

Belangrijke Interfaces  
*\<Beschrijving van belangrijke interfaces>*

### \<Naam black box 1>

*\<Doel/Verantwoordelijkheid>*

*\<Interface(s)>*

*\<((Optioneel) Kwaliteits-/Prestatie karakteristieken>*

*\<(Optioneel) directories/bestand locaties>*

*\<(Optioneel) Vervulde requirements>*

*\<(Optioneel) Open issues/problemen/risico’s>*

## \<Naam black box 2>

*\<black box template>*

### \<Naam black box n>

*\<black box template>*

### \<Naam interface 1>

…

### \<Naam interface m>

## Niveau 2

### White Box *\<bouwsteen 1>*

*\<white box template>*

### White Box *\<bouwsteen 2>*

*\<white box template>*

…

### White Box *\<bouwsteen m>*

*\<white box template>*

## Niveau 3

### White Box *\<bouwsteen x.1>*

*\<white box template>*

### White Box *\<bouwsteen x.2>*

*\<white box template>*

### White Box *\<bouwsteen y.1>*

*\<white box template>*

# Runtime View

## \<Runtime Scenario 1>

-   *\<voeg een runtime diagram of een tekstuele beschrijving van het
    scenario toe>*

-   *\<voeg een beschrijving toe van bijzondere aspecten van de
    interactie tussen de instanties van de bouwstenen die in dit diagram
    worden weergegeven>*

## \<Runtime Scenario 2>

## …

## \<Runtime Scenario n>

# Deployment View

## Infrastructuur Niveau 1

***\<Overzichts Diagram>***

Motivatie  
*\<uitleg in tekstuele vorm>*

Kwaliteit en/of Performance Eigenschappen  
*\<uitleg in tekstuele vorm>*

Mapping van Bouwstenen naar Infrastructuur  
*\<beschrijving van de mapping>*

## Infrastructuur Niveau 2

### *\<Infrastructuur Element 1>*

*\<diagram + uitleg>*

### *\<Infrastructuur Element 2>*

*\<diagram + uitleg>*

…

### *\<Infrastructuur Element n>*

*\<diagram + uitleg>*

# Cross-cutting Concepten

## *\<Concept 1>*

*\<uitleg>*

## *\<Concept 2>*

*\<uitleg>*

…

## *\<Concept n>*

*\<uitleg>*

# Architectuur Beslissingen

# Kwaliteits Requirements

## Kwaliteits Boom

## Kwaliteits Scenarios

# Risico’s en Technical Debt

# Woordenlijst

| Term        | Definitie        |
|-------------|------------------|
| *\<Term-1>* | *\<definitie-1>* |
| *\<Term-2>* | *\<definitie-2>* |
