# Glossar

| Begriff         | Definition         |
| --------------- | ------------------ |
| *\<Begriff-1\>* | *\<Definition-1\>* |
| *\<Begriff-2*   | *\<Definition-2\>* |
