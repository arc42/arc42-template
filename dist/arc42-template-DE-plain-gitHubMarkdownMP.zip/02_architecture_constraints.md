# Randbedingungen
