# Querschnittliche Konzepte

<div class="formalpara-title">

**Weiterführende Informationen**

</div>

Siehe [Querschnittliche Konzepte](https://docs.arc42.org/section-8/) in
der online-Dokumentation (auf Englisch).

=== *\<Konzept 1\>*

*\<Erklärung\>*

=== *\<Konzept 2\>*

*\<Erklärung\>*

…

=== *\<Konzept n\>*

*\<Erklärung\>*
