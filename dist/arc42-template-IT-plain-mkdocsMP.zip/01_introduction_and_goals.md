# Introduzione e obiettivi {#section-introduction-and-goals}

## Panoramica dei requisiti {#_panoramica_dei_requisiti}

## Obiettivi di qualità {#_obiettivi_di_qualità}

## Stakeholders {#_stakeholders}

+---------------+---------------------------+---------------------------+
| Rouolo/Nome   | Contatto                  | Aspettative               |
+===============+===========================+===========================+
| *\<Ruolo-1\>* | *\<Contatto-1\>*          | *\<Aspettatiive-1\>*      |
+---------------+---------------------------+---------------------------+
| *\<Ruolo-2\>* | *\<Contatto-2\>*          | *\<Aspettatiive-2\>*      |
+---------------+---------------------------+---------------------------+
