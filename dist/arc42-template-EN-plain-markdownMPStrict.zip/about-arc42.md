**About arc42**

arc42, the Template for documentation of software and system
architecture.

Created and maintained by Dr. Peter Hruschka, Dr. Gernot Starke and
contributors.

Template Revision: 8.0 EN (based on asciidoc), February 2022

© We acknowledge that this document uses material from the arc 42
architecture template, <https://arc42.org>.
