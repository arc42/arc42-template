# Runtime View

## &lt;Runtime Scenario 1&gt;

-   *&lt;insert runtime diagram or textual description of the
    scenario&gt;*

-   *&lt;insert description of the notable aspects of the interactions
    between the building block instances depicted in this diagram.&gt;*

## &lt;Runtime Scenario 2&gt;

## …

## &lt;Runtime Scenario n&gt;
