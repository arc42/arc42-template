# Glossary

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Term</th>
<th style="text-align: left;">Definition</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Term-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definition-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Term-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definition-2&gt;</em></p></td>
</tr>
</tbody>
</table>
