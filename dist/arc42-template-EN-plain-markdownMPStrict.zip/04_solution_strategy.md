Solution Strategy
=================
