Architecture Constraints
========================
