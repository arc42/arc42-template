# Building Block View

## Whitebox Overall System

***&lt;Overview Diagram>***

Motivation  
*&lt;text explanation>*

Contained Building Blocks  
*&lt;Description of contained building block (black boxes)>*

Important Interfaces  
*&lt;Description of important interfaces>*

### &lt;Name black box 1>

*&lt;Purpose/Responsibility>*

*&lt;Interface(s)>*

*&lt;(Optional) Quality/Performance Characteristics>*

*&lt;(Optional) Directory/File Location>*

*&lt;(Optional) Fulfilled Requirements>*

*&lt;(optional) Open Issues/Problems/Risks>*

### &lt;Name black box 2>

*&lt;black box template>*

### &lt;Name black box n>

*&lt;black box template>*

### &lt;Name interface 1>

…

### &lt;Name interface m>

## Level 2

### White Box *&lt;building block 1>*

*&lt;white box template>*

### White Box *&lt;building block 2>*

*&lt;white box template>*

…

### White Box *&lt;building block m>*

*&lt;white box template>*

## Level 3

### White Box &lt;\_building block x.1\_&gt;

*&lt;white box template>*

### White Box &lt;\_building block x.2\_&gt;

*&lt;white box template>*

### White Box &lt;\_building block y.1\_&gt;

*&lt;white box template>*
