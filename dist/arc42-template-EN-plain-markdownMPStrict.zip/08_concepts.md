# Cross-cutting Concepts

## *&lt;Concept 1&gt;*

*&lt;explanation&gt;*

## *&lt;Concept 2&gt;*

*&lt;explanation&gt;*

…

## *&lt;Concept n&gt;*

*&lt;explanation&gt;*
