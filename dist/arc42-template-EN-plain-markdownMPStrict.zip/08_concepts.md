# Cross-cutting Concepts

## *&lt;Concept 1>*

*&lt;explanation>*

## *&lt;Concept 2>*

*&lt;explanation>*

…

## *&lt;Concept n>*

*&lt;explanation>*
