Design Decisions
================
