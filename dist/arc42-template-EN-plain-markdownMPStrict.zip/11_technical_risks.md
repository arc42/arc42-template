Risks and Technical Debts
=========================
