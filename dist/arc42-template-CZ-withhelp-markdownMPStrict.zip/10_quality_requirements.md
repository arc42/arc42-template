# Požadavky na kvalitu

Obsah

Tato kapitola shrnuje všechny relevantní požadavky na kvalitu.

Nejdůležitější z těchto požadavků již byly popsány v kapitole 1.2
(kvalitativní cíle), a proto by zde měly být pouze odkázány. V této
kapitole (10) je vhodné zaznamenat i méně důležité požadavky na kvalitu,
jejichž nesplnění nepředstavuje zásadní riziko, ale které mohou být
užitečné či žádoucí (*nice-to-have*).

Motivace

Požadavky na kvalitu mají výrazný vliv na architektonická rozhodnutí. Je
proto důležité znát kvalitativní očekávání zainteresovaných stran, a to
konkrétně a měřitelně.

Další informace

- Dokumentace arc42: [Quality
  Requirements](https://docs.arc42.org/section-10/)

- Model kvality Q42: [Q42 quality model na
  https://quality.arc42.org](https://quality.arc42.org).

## Přehled požadavků na kvalitu

Obsah

Stručný přehled požadavků na kvalitu.

Motivace

V praxi se často setkáváme s desítkami či stovkami požadavků na kvalitu.
Tento přehled by měl nabídnout jejich kategorizaci či shrnutí –
například dle standardu [ISO
25010:2023](https://www.iso.org/obp/ui/#iso:std:iso-iec:25010:ed-2:v1:en)
nebo podle [modelu Q42](https://quality.arc42.org).

Pokud je tento přehled dostatečně konkrétní, specifický a měřitelný,
může být část 10.2 vynechána.

Forma

Použijte jednoduchou tabulku, kde každý řádek reprezentuje kategorii
nebo typ požadavku na kvalitu spolu s krátkým popisem. Alternativně lze
využít mind map pro vizuální strukturování požadavků. V literatuře se
také vyskytuje pojem *strom kvalitativních atributů* (*Quality Attribute
Utility Tree*), který rozvíjí pojem „kvalita“ jako kořenový uzel stromu
s větvemi představujícími konkrétní požadavky.

## Scénáře kvality

Obsah

Scénáře kvality konkretizují požadavky na kvalitu a umožňují ověřit, zda
byly splněny (například pomocí akceptačních kritérií). Scénáře by měly
být jednoznačné a měřitelné.

Dva typy scénářů jsou obzvláště užitečné:

- *Scénáře použití* (též aplikační nebo provozní scénáře) popisují
  chování systému v reakci na určitý podnět v runtime – včetně
  výkonnosti, odezvy apod. Příklad: Systém odpoví na požadavek uživatele
  do jedné sekundy.

- *Scénáře změn* popisují chování systému při jeho úpravách nebo
  rozšiřování, případně změnách okolního prostředí. Příklad: Do systému
  je doplněna nová funkce, mění se požadavek na kvalitu a měří se
  náročnost změny.

Forma

Typická struktura scénáře může mít dvě podoby:

- **Krátká forma** (upřednostňuje ji model Q42):

- **Kontext**: O jaký systém nebo komponentu se jedná? Jaké je okolí
  nebo situace?

- **Zdroj/Podnět**: Kdo nebo co spouští chování nebo reakci systému?

- **Kritérium/Metoda ověření**: Jak poznáme, že je požadavek splněn?
  (metrika, měřitelný výstup)

- **Dlouhá forma** (používaná v SEI, např. \[Bass+21\]):

- **ID scénáře**

- **Název scénáře**

- **Zdroj** (uživatel, systém, událost)

- **Podnět**

- **Provozní prostředí**

- **Artefakt** (část systému, která je podnětem ovlivněna)

- **Odezva**

- **Metrika odezvy** (kritérium pro hodnocení odezvy systému)

Příklady

Viz [model kvality Q42](https://quality.arc42.org) pro detailní ukázky
scénářů.

Další informace

- Len Bass, Paul Clements, Rick Kazman: *Software Architecture in
  Practice*, 4. vydání, Addison-Wesley, 2021.
