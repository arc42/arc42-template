# Vymezení a rozsah systému

## Firemní kontext

**&lt;vložte diagram nebo tabulku>**

**&lt;(volitelně:) vložte vysvětlení externích doménových rozhraní>**

## Technický kontext

**&lt;vložte diagram nebo tabulku>**

**&lt;(volitelně:) vložte vysvětlení externích technických rozhraní>**

**&lt;mapování doménových vstupu/výstupu na technické kanály>**
