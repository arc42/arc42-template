# Perspektiva stavebních bloků

**Obsah**

Perspektiva stavebních bloků ukazuje statický rozklad systému na
stavební bloky (moduly, komponenty, subsystémy, třídy, rozhraní,
balíčky, knihovny, framework, oddíly, vrstvy, funkce, makra, operace,
datové struktury, …) stejně jako jejich vzájemné závislosti (vztahy,
asociace, …).

Toto perspektiva je povinná pro každou dokumentaci architektury, stejně
jako je to u domu jeho *půdorys*.

**Motivace**

Udržujte si přehled o zdrojovém kódu tím, že jeho strukturu učiníte
srozumitelnou prostřednictvím abstrakce.

To vám umožní komunikovat se zainteresovanými stranami na abstraktní
úrovni, aniž byste prozradili podrobnosti o implementaci.

**Forma**

Perspektiva stavebních bloků je hierarchický přehled "černých" a
"bílých" skříněk (black-box, white-box, viz obrázek níže) a jejich
popisů.

![Hierarchie stavebních bloků](images/05_building_blocks-EN.png)

**Úroveň 1** je popis celého systému jako white-box spolu s popisem
všech obsažených stavebních bloků ve formátu black-box.

**Úroveň 2** přibližuje některé stavební bloky úrovně 1. Obsahuje tedy
popis vybraných stavebních bloků úrovně 1 jako white-box spolu s popisy
jejich vnitřních stavebních bloků jako black-box.

**Úroveň 3** přiblíží vybrané stavební bloky úrovně 2 a tak dále.

Anglická dokumentace arc42: [Building Block
View](https://docs.arc42.org/section-5/).

## Celý systém jako white-box

Zde popisujete rozklad celého systému pomocí následující white-box
šablony. Obsahuje

-   přehledový diagram

-   motivaci k rozkladu

-   popis jednotlivých stavebních bloků jako black-box. K tomu jsou k
    dispozici různé alternativy:

    -   použijte *jednu* tabulku pro krátký a pragmatický přehled všech
        obsažených stavebních bloků a jejich rozhraní.

    -   použijte seznam stavebních bloků popsaných podle black-box
        šablony (viz níže). V závislosti na výběru konkrétního nástroje
        může tento seznam obsahovat podkapitoly (v textových souborech),
        podstránky (ve Wiki) nebo vnořené prvky (v modelovacím
        nástroji).

-   (Volitelně:) důležitá rozhraní, která nejsou vysvětlena v black-box
    šablonách stavebního bloku, ale jsou velmi důležitá pro pochopení
    popisovaného white-boxu. Protože existuje mnoho způsobů, jak
    specifikovat rozhraní, neposkytujeme žádnou konkrétní šablonu. V
    nejhorším případě musíte specifikovat a popsat syntax, sémantiku,
    protokoly, zpracování chyb, různá omezení, verze, nároky na kvalitu,
    potřebnou kompatibilitu a mnoho dalších věcí. V lepším případě vám
    stačí příklady nebo jednoduché podpisy.

***&lt;vložte přehledový diagram celého systému&gt;***

Motivace  
*&lt;popište motivaci&gt;*

Obsažené stavební bloky  
*&lt;popište obsažené stavební bloky (jako black-box)&gt;*

Důležitá rozhraní  
*&lt;popište důležitá rozhraní&gt;*

Vložte vysvětlení black-boxů z úrovně 1:

Pokud použijete tabulkovou formu, popište black-boxy pouze jménem a
odpovědností podle následujícího schématu:

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;"><strong>Jméno</strong></th>
<th style="text-align: left;"><strong>Odpovědnost</strong></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;black-box 1&gt;</em></p></td>
<td style="text-align: left;"><p> <em>&lt;Text&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;black-box 2&gt;</em></p></td>
<td style="text-align: left;"><p> <em>&lt;Text&gt;</em></p></td>
</tr>
</tbody>
</table>

Pokud použijete seznam popisů jednotlivých black-boxů, vyplňte
samostatnou black-box šablonu pro každý důležitý stavební blok. Její
titulek je název black-boxu.

### &lt;Jméno black-boxu 1&gt;

Popište &lt;black-box 1&gt; podle následující black-box šablony:

-   Účel/Odpovědnost

-   Rozhraní, pokud nejsou vyjmuta jako samostatné odstavce. Případně
    sem patří nároky na kvalitu a výkonnostní rozhraní.

-   (Volitelně) Popis požadavků na kvalitu/výkon black-boxu, např.
    dostupnost, runtime vlastnosti, ….

-   (Volitelně) Umístění/složky a soubory

-   (Volitelně) Splněné požadavky (pokud potřebujete dohledat vztah k
    požadavkům).

-   (Volitelně) Nevyřešené body/problémy/rizika

*&lt;Účel/Odpovědnost&gt;*

*&lt;Rozhraní&gt;*

*&lt;(Volitelně) Požadavky na kvalitu/výkon&gt;*

*&lt;(Volitelně) Umístění/složky a soubory&gt;*

*&lt;(Volitelně) Splněné požadavky&gt;*

*&lt;(Volitelně) Nevyřešené body/problémy/rizika&gt;*

### &lt;Jméno black-boxu 2&gt;

*&lt;šablona black-box&gt;*

### &lt;Jméno black-boxu n&gt;

*&lt;šablona black-box&gt;*

### &lt;Jméno rozhraní 1&gt;

…

### &lt;Jméno rozhraní m&gt;

## Úroveň 2

Zde popište vnitřní strukturu (některých) stavebních bloků z úrovně 1
jako white-box.

Musíte rozhodnout, které stavební bloky systému jsou natolik důležité,
aby ospravedlnily tak podrobný popis. Upřednostněte relevanci před
úplností. Uveďte důležité, překvapivé, riskantní, komplexní nebo
volatilní stavební bloky. Vynechejte normální, jednoduché nebo
standardizované části systému.

### white-box *&lt;stavební blok 1&gt;*

…popisuje vnitřní strukturu *stavebního bloku 1*.

*&lt;šablona white-box&gt;*

### white-box *&lt;stavební blok 2&gt;*

*&lt;šablona white-box&gt;*

…

### white-box *&lt;stavební blok m&gt;*

*&lt;šablona white-box&gt;*

## Úroveň 3

Zde můžete popsat vnitřní strukturu (některých) stavebních bloků z
úrovně 2 jako white-box.

Pokud potřebujete podrobnější úrovně architektury, zkopírujte si pro ně
tuto část arc42.

### white-box &lt;\_stavební blok x.1\_&gt;

…popisuje vnitřní strukturu *stavebního bloku x.1*.

*&lt;šablona white-box&gt;*

### white-box &lt;\_stavební blok x.2\_&gt;

*&lt;šablona white-box&gt;*

### white-box &lt;\_stavební blok y.1\_&gt;

*&lt;šablona white-box&gt;*
