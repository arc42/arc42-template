# Úvod a cíle

Shrnuje klíčové požadavky a omezení, se kterými musí softwaroví
architekti i vývojový tým počítat. Patří sem zejména:

- hlavní obchodní cíle,

- základní vlastnosti systému,

- funkční požadavky,

- kvalitativní cíle architektury,

- zainteresované strany systému (stakeholder) a jejich potřeby.

## Přehled požadavků

Obsah

Stručný popis (shrnutí či abstrakt) funkčních i kvalitativních
požadavků. Odkaz na (doufejme existující) dokumentaci požadavků (s
číslem verze a informacemi, kde ji najít).

Motivace

Z hlediska koncových uživatelů je cílem vývoje nebo změny systému
zlepšení jeho funkcí k plnění obchodních cílů a/nebo zlepšení jeho
kvality.

Forma

Stručný popis, pravděpodobně ve formátu tabulkového přehledu funkcí
(use-case). Pokud existují dokumenty požadavků, měl by na ně tento
přehled odkazovat.

Udržujte tento popis co nejkratší (z hlediska čitelnosti), ale tak aby
nebyly zbytečně opakovány informace z dokumentace požadavků.

Další informace

Anglická dokumentace arc42: [Introduction and
Goals](https://docs.arc42.org/section-1/).

## Kvalitativní cíle

Obsah

Tři (maximálně pět) nejdůležitějších kvalitativních cílů pro
architekturu, jejichž splnění je pro hlavní zainteresované strany
nejdůležitější. Jedná se skutečně o kvalitativní cíle pro architekturu.
Nepleťte si je s cíli projektu, ty nemusí být nutně totožné.

Norma ISO 25010 poskytuje přehled jednotlivých oblastí:

<figure>
<img src="images/01_2_iso-25010-topics-EN-2023.drawio.png"
alt="Kategorie kvalitativních cílů" />
</figure>

Motivace

Je vhodné znát kvalitativní cíle klíčových zainteresovaných stran
systému, protože ty ovlivní zásadní architektonická rozhodnutí. Ujistěte
se, že jsou tyto požadavky na systém jednoznačné či měřitelné, vyvarujte
se vágních formulací.

Forma

Tabulka s nejdůležitějšími kvalitativními cíli a praktickými scénáři,
seřazená podle priorit.

## Strany zainteresované na systému (stakeholder)

Obsah

Jasný přehled všech stran zainteresovaných na systému, tedy všech osob,
rolí nebo organizací, které

- by měli architekturu znát,

- by měli s architekturou souhlasit,

- budou s architekturou nebo s kódem pracovat,

- ke své práci potřebují dokumentaci architektury,

- rozhodují o vývoji a designu systému.

Motivace

Je vhodné znát všechny strany zapojené do vývoje systému (nebo systémem
ovlivněné). Jinak se může stát, že se později v procesu vývoje objeví
nepříjemná překvapení. Zainteresované strany ovlivňují rozsah a úroveň
detailu vaší práce a jejích výsledků.

Forma

Tabulka s názvy rolí, jmény osob a jejich očekáváním na architekturu a
její dokumentaci.

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">Role/Jméno</th>
<th style="text-align: left;">Kontakt</th>
<th style="text-align: left;">Očekávání</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p><em>&lt;Role-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Kontakt-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Očekávání-1&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"><p><em>&lt;Role-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Kontakt-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Očekávání-2&gt;</em></p></td>
</tr>
</tbody>
</table>
