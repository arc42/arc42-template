# Slovník pojmů

**Obsah**

Nejdůležitější doménové a technické termíny, které zainteresované strany
používají při diskuzi o systému.

Pokud pracujete ve vícejazyčných týmech, můžete glosář používat jako
zdroj překladů.

**Motivace**

Měli byste jasně definovat důležité pojmy, aby všechny zainteresované
strany

-   chápaly tyto pojmy stejně

-   a aby neexistovalo pro jednu a stejnou věc více variant

<!-- -->

-   Tabulka se sloupci &lt;Termín&gt; a &lt;Definice&gt;.

-   Potenciálně více sloupců v případě, že potřebujete překlady.

Anglická dokumentace arc42:
[Glossary](https://docs.arc42.org/section-12/).

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Termín</th>
<th style="text-align: left;">Definice</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;termín-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definice-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;termín-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definice-2&gt;</em></p></td>
</tr>
</tbody>
</table>
