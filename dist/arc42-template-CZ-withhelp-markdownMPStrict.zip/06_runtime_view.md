# Perspektiva chování za běhu (runtime)

## &lt;Scénář runtime 1>

-   *&lt;vložte runtime diagram nebo textový popis scénáře>*

-   *&lt;vložte popis důležitých interakcí mezi instancemi stavebních
    bloků zobrazených v tomto diagramu>*

## &lt;Scénář runtime 2>

## …

## &lt;Scénář runtime n>
