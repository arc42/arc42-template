# Průřezové (cross-cutting) koncepty

## *&lt;Koncept 1>*

*&lt;vysvětlení>*

## *&lt;Koncept 2>*

*&lt;vysvětlení>*

…

## *&lt;Koncept n>*

*&lt;vysvětlení>*
