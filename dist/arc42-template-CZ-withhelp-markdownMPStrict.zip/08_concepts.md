# Průřezové (cross-cutting) koncepty

## *&lt;Koncept 1&gt;*

*&lt;vysvětlení&gt;*

## *&lt;Koncept 2&gt;*

*&lt;vysvětlení&gt;*

…​

## *&lt;Koncept n&gt;*

*&lt;vysvětlení&gt;*
