# Průřezové (cross-cutting) koncepty

Obsah

Tato část dokumentace popisuje přesahující principy, předpisy a řešení,
které jsou relevantní pro více částí systému (= průřezové). Takové
koncepty se často týkají více stavebních bloků.

Může zahrnovat mnoho různých témat, jako například

- modely, zejména doménové modely

- architekturu nebo designové vzory

- pravidla pro použití konkrétních technologií

- zásadní, často technická rozhodnutí zastřešujícího (= průřezového)
  charakteru

- pravidla implementace

Motivace

Koncepty tvoří základ *konceptuální integrity* (konzistence, homogenity)
softwarové architektury. Jsou tedy důležitým příspěvkem k dosažení
vnitřní kvality vyvíjeného systému.

Některé z těchto konceptů nelze přiřadit k jednotlivým stavebním blokům,
například zabezpečení.

Forma

Forma může být různá:

- koncepční dokumenty s jakoukoliv strukturou

- průřezové modely nebo scénáře, které jsou již využity v jednotlivých
  perspektivách architektury

- vzorové implementace, zejména pro technické koncepty

- odkaz na "typické" používání standardních frameworků (například
  používání Hibernate pro objektové/relační mapování)

Struktura

Potenciální (nikoli však povinná) struktura pro tento oddíl dokumentace
může být:

- Koncepty domén

- Koncepty uživatelské zkušenosti (UX)

- Koncepty bezpečnosti a zabezpečení

- Architektura a designové vzory

- "pod kapotou"

- Vývojové koncepty

- Provozní koncepty

Poznámka: Může být obtížné přiřadit jednotlivé koncepty k jednomu
konkrétnímu tématu z tohoto seznamu.

<figure>
<img src="images/08-concepts-EN.drawio.png"
alt="Témata pro průřezové koncepty" />
</figure>

Další informace

Anglická dokumentace arc42:
[Concepts](https://docs.arc42.org/section-8/).

## *&lt;Koncept 1&gt;*

*&lt;vysvětlení&gt;*

## *&lt;Koncept 2&gt;*

*&lt;vysvětlení&gt;*

…​

## *&lt;Koncept n&gt;*

*&lt;vysvětlení&gt;*
