# Glosario

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenido

</div>

Los términos técnicos y de dominio más importantes que serán utilizados
por las partes relacionadas al discutir el sistema.

</div>

También se puede usar el glosario como fuente para traducciones si se
trabaja en equipos multi-lenguaje.

<div class="formalpara">

<div class="title">

Motivación

</div>

Deberían definirse claramente los términos, para que todas las partes
relacionadas:

</div>

- Tengan un entendimiento idéntico de dichos términos

- No usen sinónimos y homónimos

<div>

<div class="title">

Forma

</div>

- Crear una tabla con las columnas \<Término\> y \<Definición\>.

- Se pueden agregar más columnas en caso de que se requieran
  traducciones.

</div>

</div>

| Término         | Definición         |
|-----------------|--------------------|
| *\<Término-1\>* | *\<definicion-1\>* |
| *\<Término-2\>* | *\<definicion-2\>* |
