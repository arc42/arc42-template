# Conceptos Transversales (Cross-cutting)

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenido

</div>

Esta sección describe de manera general, las principales ideas de
solución y regulación que son relevantes en multiples partes (→
cross-cutting/transversales) del sistema. Dichos conceptos están
relacionados usualmente a múltiples bloques de construcción. Pueden
incluir diversos temas, tales como:

</div>

- Modelos de dominio

- Patrones de arquitectura o patrones de diseño

- Reglas de uso para alguna tecnología específica.

- Decisiones técnicas principales o generales

- Reglas de implementación

<div class="formalpara">

<div class="title">

Motivación

</div>

Conceptos que forman la base para la *integridad conceptual*
(consistencia, homogeneidad) de la arquitectura. Entonces, son una
contribución importante para alcanzar la calidad interna del sistema.

</div>

Algunos de estos conceptos no pueden ser asignados a bloques de
construcción individuales (por ejemplo seguridad). Este es el lugar en
la plantilla provisto para una especificación cohesiva de dichos
conceptos.

<div class="formalpara">

<div class="title">

Forma

</div>

La forma puede ser variada:

</div>

- Papeles conceptuales con cualquier tipo de estructura

- Modelo transversal (cross-cutting) de fragmentos o escenarios usando
  notación de las vistas arquitectónicas

- Implementaciones de muestra, especialmente para conceptos técnicos.

- Referencias a uso típico en frameworks estándar (por ejemplo, el uso
  de Hibernate para mapeo Objeto/Relacional) The form can be varied:

<div class="formalpara">

<div class="title">

Estructura

</div>

La estructura potencial (pero no obligatoria) para esta sección podría
ser:

</div>

- Conceptos de dominio

- Conceptos de experiencia de usuario (UX)

- Conceptos de seguridad

- Patrones de diseño y arquitectura \* A potential (but not mandatory)
  structure for this section could be:

- Domain concepts

- User Experience concepts (UX)

- Safety and security concepts

- Architecture and design patterns

- "Bajo el capó"

- Conceptos de desarrollo

- Conceptos de operación

Nota: Puede ser difícil asignar conceptos individuales a un tema
específico de la lista

![Posibles temas para conceptos
transversales](images/08-concepts-EN.drawio.png)

</div>

## *\<Concepto 1\>*

*\<explicación\>*

## *\<Concepto 2\>*

*\<explicación\>*

…​

## *\<Concepto n\>*

*\<explicación\>*
