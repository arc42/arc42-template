# Vista de Despliegue

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenido

</div>

La vista de despliegue describe:

</div>

1.  La infraestructura técnica usada para ejecutar el sistema, con
    elementos de infraestructura como locaciones geográficas, ambientes,
    computadoras, procesadores, canales y topologías de red así como
    otros elementos de infraestructura.

2.  El mapeo de los bloques de construcción (software) en dichos
    elementos de infraestructura.

Comúnmente los sistemas son ejecutados en diferentes ambientes, por
ejemplo, ambiente de desarrollo, de pruebas, de producción. En dichos
casos deberían documentarse todos los ambientes relevantes.

Deberá documentarse la vista de despliegue de manera especial cuando el
software se ejecute como un sistema distribuido con mas de una
computadora, procesador, servidor o contenedor o cuando se diseñen los
procesadores y chips de hardware propios.

Desde una perspectiva de software es suficiente con capturar los
elementos de la infraestructura necesarios para mostrar el despliegue de
los bloques de construcción. Los arquitectos de hardware pueden ir más
alla y describir la infraestructura a cualquier nivel de detalle que
requieran.

<div class="formalpara">

<div class="title">

Motivación

</div>

El software no corre sin haardware. El hardware subyacente puede
influenciar el sistema o algunos conceptos entrecruzados. Por ende, es
necesario conocer la infraestructura.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Quizá el más alto nivel de diagrama de despliegue esté contenido en la
sección 3.2. como contexto técnico con la propia infraestructura como
UNA caja negra. En esta sección se deberá realizar un acercamiento a
ésta caja negra utilizando diagramas de despliegue adicionales:

</div>

- UML provee diagramas de despliegue para expresar la vista. Uselos,
  probablemente con diagramas anidados.

- Cuando las partes relacionadas de Hardware prefieran otro tipo de
  diagramas además de los diagramas de despliegue, permítales usar
  cualquier tipo que permita mostrar los nodos y canales de la
  infraestructura.

</div>

## Nivel de infraestructura 1

<div class="sidebar">

<div class="title">

</div>

Describa (Usualmente en una combinación de diagramas, tablas y texto):

- La distribución del sistema en múltiples ubicaciones, ambientes,
  computadoras, procesadores, …​ así como las conexiones físicas entre
  ellos

- La motivación o justificación de importancia para la estructura de
  despliegue

- Características de Calidad y/o rendimiento de la infraestructura

- El mapeo de los artefactos de software a los elementos de la
  infraestructura.

Para múltiples ambientes o despliegues alternativos copie esta sección
para todos los ambientes relevantes.

</div>

***\<Diagrama General\>***

Motivación  
*\<Explicación en forma textual\>*

Características de Calidad/Rendimiento  
*\<Explicación en forma textual\>*

Mapeo de los Bloques de Construcción a Infraestructura  
*\<Descripción del mapeo\>*

## Nivel de Infraestructura 2

<div class="sidebar">

<div class="title">

</div>

Aquí puede incluir la estructura interna de (algunos) elementos de
infraestructura del nivel 1.

Copie la estructura del nivel 1 para cada elemento elegido.

</div>

### *\<Elemento de Infraestructura 1\>*

*\<diagrama + explicación\>*

### *\<Elemento de Infraestructura 2\>*

*\<diagrama + explicación\>*

…​

### *\<Elemento de Infraestructura n\>*

*\<diagrama + explicación\>*
