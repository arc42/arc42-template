# Bausteinsicht

## Whitebox Gesamtsystem

***&lt;Übersichtsdiagramm&gt;***

Begründung  
*&lt;Erläuternder Text&gt;*

Enthaltene Bausteine  
*&lt;Beschreibung der enthaltenen Bausteine (Blackboxen)&gt;*

Wichtige Schnittstellen  
*&lt;Beschreibung wichtiger Schnittstellen&gt;*

### &lt;Name Blackbox 1&gt;

*&lt;Zweck/Verantwortung&gt;*

*&lt;Schnittstelle(n)&gt;*

*&lt;(Optional) Qualitäts-/Leistungsmerkmale&gt;*

*&lt;(Optional) Ablageort/Datei(en)&gt;*

*&lt;(Optional) Erfüllte Anforderungen&gt;*

*&lt;(optional) Offene Punkte/Probleme/Risiken&gt;*

### &lt;Name Blackbox 2&gt;

*&lt;Blackbox-Template&gt;*

### &lt;Name Blackbox n&gt;

*&lt;Blackbox-Template&gt;*

### &lt;Name Schnittstelle 1&gt;

…​

### &lt;Name Schnittstelle m&gt;

## Ebene 2

### Whitebox *&lt;Baustein 1&gt;*

*&lt;Whitebox-Template&gt;*

### Whitebox *&lt;Baustein 2&gt;*

*&lt;Whitebox-Template&gt;*

…​

### Whitebox *&lt;Baustein m&gt;*

*&lt;Whitebox-Template&gt;*

## Ebene 3

### Whitebox &lt;\_Baustein x.1\_&gt;

*&lt;Whitebox-Template&gt;*

### Whitebox &lt;\_Baustein x.2\_&gt;

*&lt;Whitebox-Template&gt;*

### Whitebox &lt;\_Baustein y.1\_&gt;

*&lt;Whitebox-Template&gt;*
