================
|arc42| Template
================

:Date: March 2023

**About arc42**

arc42, the Template for documentation of software and system
architecture.

By Dr. Gernot Starke, Dr. Peter Hruschka and contributors.

Template Revision: 7.0 IT (based on asciidoc), April 2021

© We acknowledge that this document uses material from the arc 42
architecture template, https://www.arc42.org. Created by Dr. Peter
Hruschka & Dr. Gernot Starke.

.. container:: sidebar

   .. note::

      This version of the template contains some help and explanations.
      It is used for familiarization with arc42 and the understanding of
      the concepts. For documentation of your own system you use better
      the *plain* version.

.. _section-introduction-and-goals:

Introduzione e obiettivi
========================

.. container:: sidebar

   Descrive i requisiti rilevanti e le forze trainanti che gli
   architetti del software e il team di sviluppo devono considerare.
   Questi includono

   - obiettivi di business sottostanti, caratteristiche essenziali e
     requisiti funzionali per il sistema

   - obiettivi di qualità per l’architettura

   - stakeholder rilevanti e le loro aspettative

.. _`_panoramica_dei_requisiti`:

Panoramica dei requisiti
------------------------

.. container:: sidebar

   .. container:: formalpara

      Breve descrizione dei requisiti funzionali, forze trainanti,
      estratto (o abstract) dei requisiti. Collegamento ai documenti dei
      requisiti (si spera esistenti) (con il numero di versione e le
      informazioni su dove trovarlo).

   .. container:: formalpara

      Dal punto di vista degli utenti finali un sistema viene creato o
      modificato per migliorare il supporto di un’attività di business
      e/o migliorare la qualità.

   .. container:: formalpara

      Breve descrizione testuale, casi d’uso in forma tabellare. Se
      esistono documenti sui requisiti, questa panoramica dovrebbe fare
      riferimento a questi documenti.

   Mantieni questi estratti il ​​più brevi possibile. Bilancia la
   leggibilità di questo documento con la potenziale ridondanza rispetto
   ai documenti dei requisiti.

.. _`_obiettivi_di_qualità`:

Obiettivi di qualità
--------------------

.. container:: sidebar

   .. container:: formalpara

      I principali tre (massimo cinque) obiettivi di qualità per
      l’architettura la cui realizzazione è della massima importanza per
      i principali stakeholder, Intendiamo davvero obiettivi di qualità
      per l’architettura. Non confonderli con gli obiettivi del
      progetto. Non sono necessariamente identici.

   .. container:: formalpara

      Dovresti conoscere gli obiettivi di qualità dei tuoi stakeholder
      più importanti, poiché influenzeranno le decisioni architettoniche
      fondamentali. Assicurati di essere molto concreto su queste
      qualità, evita le parole d’ordine. Se tu come architetto non sai
      come verrà giudicata la qualità del tuo lavoro

   .. container:: formalpara

      Una tabella con obiettivi di qualità e scenari concreti, ordinati
      per priorità

.. _`_stakeholders`:

Stakeholders
------------

.. container:: sidebar

   .. container:: formalpara

      Panoramica esplicita degli stakeholder del sistema, ovvero tutte
      le persone, i ruoli o le organizzazioni che

   - dovrebbero conoscere l’architettura

   - devono essere convinti dell’architettura

   - devono lavorare con l’architettura o con il codice

   - necessitano della documentazione dell’architettura per il loro
     lavoro

   - devono prendere decisioni sul sistema o sul suo sviluppo

   .. container:: formalpara

      È necessario conoscere tutte le parti coinvolte nello sviluppo del
      sistema o interessate dal sistema. Altrimenti, potresti ricevere
      brutte sorprese più avanti nel processo di sviluppo. Questi
      stakeholder determinano la portata e il livello di dettaglio del
      tuo lavoro e dei suoi risultati.

   .. container:: formalpara

      Tabella con i nomi dei ruoli, i nomi delle persone e le loro
      aspettative rispetto all’architettura e alla sua documentazione

+-------------+---------------------------+---------------------------+
| Rouolo/Nome | Contatto                  | Aspettative               |
+=============+===========================+===========================+
| *<Ruolo-1>* | *<Contatto-1>*            | *<Aspettatiive-1>*        |
+-------------+---------------------------+---------------------------+
| *<Ruolo-2>* | *<Contatto-2>*            | *<Aspettatiive-2>*        |
+-------------+---------------------------+---------------------------+

.. _section-architecture-constraints:

Vincoli di architettura
=======================

.. container:: sidebar

   .. container:: formalpara

      Qualsiasi requisito che limiti gli architetti del software nella
      loro libertà di decisioni di progettazione e implementazione o
      decisione sul processo di sviluppo. Questi vincoli a volte vanno
      oltre i singoli sistemi e sono validi per intere organizzazioni e
      aziende.

   .. container:: formalpara

      Gli architetti dovrebbero sapere esattamente dove sono liberi
      nelle loro decisioni di progettazione e dove devono aderire ai
      vincoli. I vincoli devono essere sempre affrontati; possono essere
      negoziabili però.

   .. container:: formalpara

      Semplici tabelle di vincoli con spiegazioni. Se necessario puoi
      suddividerli in file vincoli tecnici, vincoli organizzativi e
      politici e convenzioni (ad es. linee guida di programmazione o di
      controllo delle versioni, documentazione o convenzioni di
      denominazione)

.. _section-context-and-scope:

Ambito e contesto del sistema
=============================

.. container:: sidebar

   .. container:: formalpara

      L’ambito e il contesto del sistema, come suggerisce il nome,
      delimitano il sistema (ovvero l’ambito) da tutti i suoi partner di
      comunicazione (sistemi e utenti vicini, ovvero il contesto del tuo
      sistema). In tal modo specifica le interfacce esterne.

   Se necessario, differenziare il contesto di business (input e output
   specifici del dominio) dal contesto tecnico (canali, protocolli,
   hardware).

   .. container:: formalpara

      Le interfacce di dominio e le interfacce tecniche per i partner di
      comunicazione sono tra gli aspetti più critici del sistema.
      Assicurati di capirli completamente.

   .. container:: formalpara

      Diverse opzioni:

   - Diagrammi di contesto

   - Elenchi di partner di comunicazione e loro interfacce.

.. _`_contesto_di_business`:

Contesto di Business
--------------------

.. container:: sidebar

   .. container:: formalpara

      Specifica di **tutti** i partner di comunicazione (utenti, sistemi
      IT, …​) con spiegazioni di input e output specifici del dominio o
      interfacce. Facoltativamente è possibile aggiungere formati
      specifici del dominio o protocolli di comunicazione.

   .. container:: formalpara

      Tutti gli stakeholder dovrebbero capire quali dati vengono
      scambiati con l’ambiente del sistema.

   .. container:: formalpara

      Tutti i tipi di diagrammi che mostrano il sistema come una scatola
      nera e specificano le interfacce di dominio per i partner di
      comunicazione.

   In alternativa (o in aggiunta) puoi usare una tabella. Il titolo
   della tabella è il nome del sistema, le tre colonne contengono il
   nome del partner di comunicazione, gli ingressi e le uscite.

**<Diagramma o Tabella>**

**<opzionale: spiegazione delle interfacce del dominio esterno>**

.. _`_contesto_tecnico`:

Contesto Tecnico
----------------

.. container:: sidebar

   .. container:: formalpara

      Interfacce tecniche (canali e mezzi di trasmissione) che collegano
      il sistema al suo ambiente. Oltre alla mappatura dell’input/output
      specifico del dominio sui canali di comunicazione, ad es. una
      spiegazione con I/O dell’utilizza del canale di comunicazione.

   .. container:: formalpara

      Spesso, gli stakeholders prendono decisioni architetturali in base
      alle interfacce tecniche tra il sistema e il suo contesto. Sono,
      principalmente i progettisti di infrastrutture o hardware che
      decidono queste interfacce tecniche.

   .. container:: formalpara

      Esempio: un deployment diagram UML che descrive i canali di
      comunicazione dei sistemi vicini, insieme a una tabella di
      mappatura che mostra le relazioni tra canali e input/output.

**<Diagramma o Tabella>**

**<opzionale: Spiegazione delle interfacce tecniche>**

**<Mappatura Input/Output sui canali di comunicazione>**

.. _section-solution-strategy:

Strategia della soluzione
=========================

.. container:: sidebar

   .. container:: formalpara

      Un breve riassunto e spiegazione delle decisioni fondamentali e
      delle strategie di soluzione che modellano l’architettura del
      sistema. Questi includono

   - decisioni tecnologiche

   - decisioni sulla scomposizione di primo livello del sistema, ad es.
     utilizzo di un modello architetturale o di un modello di
     progettazione

   - decisioni su come raggiungere gli obiettivi chiave di qualità

   - decisioni organizzative rilevanti, ad es. selezionare un processo
     di sviluppo o delegare determinati compiti a terzi.

   .. container:: formalpara

      Queste decisioni costituiscono le pietre angolari della tua
      architettura. Sono la base per molte altre decisioni dettagliate o
      regole di attuazione.

   .. container:: formalpara

      Mantieni breve la spiegazione di queste decisioni chiave.

   Motiva ciò che hai deciso e perché lo hai deciso in questo modo, in
   base alla dichiarazione del problema, agli obiettivi di qualità e ai
   vincoli chiave. Fare riferimento ai dettagli nelle sezioni seguenti.

.. _section-building-block-view:

Building Block View
===================

.. container:: sidebar

   .. container:: formalpara

      La visualizzazione building block mostra la scomposizione statica
      del sistema in building block (moduli, componenti, sottosistemi,
      classi, interfacce, pacchetti, librerie, framework, livelli,
      partizioni, livelli, funzioni, macro, operazioni, strutture dei
      dati, …​) così come le loro dipendenze (relazioni, associazioni, …​)

   Questa vista dovrebbe essere obbligatoria per ogni documentazione
   sull’architettura. In analogia con una casa, questa è la *pianta dei
   piani*.

   .. container:: formalpara

      Mantieni una panoramica del tuo codice sorgente rendendone
      comprensibile la struttura tramite astrazioni di essa.

   Ciò consente di comunicare con gli stakeholder a livello astratto
   senza rivelare i dettagli di implementazione.

   .. container:: formalpara

      è una raccolta gerarchica di black box e white box (vedi figura
      sotto) e le loro descrizioni.

   .. figure:: images/05_building_blocks-IT.png
      :alt: Gerarchia dei building blocks

   **Livello 1** è la descrizione della white box del sistema
   complessivo insieme alle descrizioni delle black box di tutti i
   building block contenuti.

   **Livello 2** entra nel dettaglio dei building block di livello 1.
   Quindi contiene la descrizione della white box dei building block
   selezionati del livello 1, insieme alle descrizioni della black box
   dei building block interni.

   **Livello 3** entra nel dettaglio dei building block di livello 2, e
   cosi via..

.. _`_whitebox_overall_system`:

Whitebox Overall System
-----------------------

.. container:: sidebar

   Qui descrivi la scomposizione dell’intero sistema utilizzando il
   seguente template white box. Contiene

   - un diagramma generico

   - una motivazione per la decomposizione

   - descrizioni in black box dei building blocks contenuti. Per questi
     ti offriamo alternative:

     - usa la tabella *one* per una panoramica breve e pragmatica di
       tutti gli elementi costitutivi contenuti e delle loro interfacce

     - utilizzare un elenco di descrizioni delle black box dei building
       box secondo il template black box (vedi sotto). A seconda dello
       strumento scelto, questo elenco potrebbe essere sottocapitoli (in
       file di testo), sottopagine (in un Wiki) o elementi nidificati
       (in uno strumento di modellazione).

   - (opzionale) interfacce importanti, che non sono spiegate nelle
     black box di un building block, ma sono molto importanti per
     comprendere la white box. Poiché ci sono così tanti modi per
     specificare le interfacce, non forniamo un template specifico per
     loro. Nel peggiore dei casi devi specificare e descrivere sintassi,
     semantica, protocolli, gestione degli errori, restrizioni,
     versioni, qualità, compatibilità necessarie e molte altre cose. Nel
     migliore dei casi te la caverai con esempi o semplici firme.

**<Overview Diagram>**

Motivazione
   *<spiegazione testuale>*

Contenuto dei Building Blocks
   *<Descrizione del contenuto del building block (black boxes)>*

Important Interfaces
   *<Descrizione delle interfacce importanti>*

.. container:: sidebar

   Inserisci le spiegazioni delle black box dal livello 1:

   Se usi la forma tabulare descriveresti solo le black box con nome e
   responsabilità secondo il seguente schema:

   +----------------------+-----------------------------------------------+
   | **Nome**             | **Responsibilità**                            |
   +======================+===============================================+
   | *<black box 1>*      |  *<Text>*                                     |
   +----------------------+-----------------------------------------------+
   | *<black box 2>*      |  *<Text>*                                     |
   +----------------------+-----------------------------------------------+

   Se si utilizza un elenco di descrizioni delle black box, si compila
   un template di black box separato per ogni building block importante.
   Il titolo è il nome della black box.

.. _`_nome_black_box_1`:

<Nome black box 1>
~~~~~~~~~~~~~~~~~~

.. container:: sidebar

   Qui descrivi la <black box 1> secondo il seguente template di scatola
   nera:

   - Scopo/responsabilità

   - Interfacce, quando non vengono estratte come paragrafi separati.
     Queste interfacce possono includere caratteristiche di qualità e
     prestazionali.

   - (Facoltativo) Caratteristiche di qualità/prestazionali della black
     box, ad esempio disponibilità, comportamento in fase di esecuzione,
     …​.

   - (Facoltativo) percorso file/directory

   - (Facoltativo) Requisiti soddisfatti (se è necessaria la
     tracciabilità dei requisiti).

   - (Facoltativo) Bug noti/Rischi/problemi

*<Scopo/responsabilità>*

*<Interfacce>*

*<(Facoltativo) Caratteristiche di qualità/prestazionali>*

*<(Facoltativo) percorso file/directory>*

*<(Facoltativo) Requisiti soddisfatti>*

*<(Facoltativo) Bug noti/Rischi/problemi>*

.. _`_nome_black_box_2`:

<Nome black box 2>
~~~~~~~~~~~~~~~~~~

*<black box template>*

.. _`_nome_black_box_n`:

<Nome black box n>
~~~~~~~~~~~~~~~~~~

*<black box template>*

.. _`_nome_interface_1`:

<Nome interface 1>
~~~~~~~~~~~~~~~~~~

…​

.. _`_nome_interface_m`:

<Nome interface m>
~~~~~~~~~~~~~~~~~~

.. _`_livello_2`:

Livello 2
---------

.. container:: sidebar

   Qui puoi specificare la struttura interna di (alcuni) building block
   dal livello 1 come white box.

   Devi decidere quali building block del tuo sistema sono abbastanza
   importanti da giustificare una descrizione così dettagliata. Si prega
   di preferire la pertinenza alla completezza. Specifica i building
   blocks importanti, sorprendenti, rischiosi, complessi o volatili.
   Tralascia le parti normali, semplici, noiose o standardizzate del tuo
   sistema

.. _`_white_box_building_block_1`:

White Box *<building block 1>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. container:: sidebar

   …​descrive la struttura interna del *building block 1*.

*<white box template>*

.. _`_white_box_building_block_2`:

White Box *<building block 2>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<white box template>*

…​

.. _`_white_box_building_block_m`:

White Box *<building block m>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<white box template>*

.. _`_livello_3`:

Livello 3
---------

.. container:: sidebar

   Qui puoi specificare la struttura interna di (alcuni) building block
   dal livello 2 come white box.

   Quando hai bisogno di livelli più dettagliati della tua architettura,
   copia questa parte di arc42 per livelli aggiuntivi.

.. _`_white_box_building_block_x_1`:

White Box <\_building block x.1\_>
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. container:: sidebar

   Specifica la struttura interna del *building block x.1*.

*<white box template>*

.. _`_white_box_building_block_x_2`:

White Box <\_building block x.2\_>
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<white box template>*

.. _`_white_box_building_block_y_1`:

White Box <\_building block y.1\_>
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<white box template>*

.. _section-runtime-view:

Runtime View
============

.. container:: sidebar

   .. container:: formalpara

      La runtime view descrive il comportamento concreto e le
      interazioni dei building block del sistema sotto forma di scenari
      dalle seguenti aree:

   - importanti casi d’uso o funzionalità: come vengono eseguiti dai
     building block?

   - interazioni alle interfacce esterne critiche: in che modo i
     building block cooperano con gli utenti e i sistemi vicini?

   - funzionamento e amministrazione: lancio, avvio, arresto

   - errori e scenari di eccezione

   Nota: il criterio principale per la scelta dei possibili scenari
   (sequenze, flussi di lavoro) è la loro **rilevanza architettonica**.
   **Non** è importante descrivere un gran numero di scenari. Dovresti
   piuttosto documentare una selezione rappresentativa.

   .. container:: formalpara

      È necessario comprendere in che modo (istanze di) building block
      del sistema eseguono il proprio lavoro e comunicano in fase di
      esecuzione. Acquisirai principalmente scenari nella tua
      documentazione per comunicare la tua architettura alle parti
      interessate che sono meno disposte o in grado di leggere e
      comprendere i modelli statici (building block view, deployment
      view).

   .. container:: formalpara

      Ci sono molte notazioni per descrivere gli scenari, ad es.

   - elenco numerato di passaggi (in linguaggio naturale)

   - activity diagram o diagrammi di flusso

   - sequence diagram

   - BPMN o EPC (catene di processi di eventi)

   - state diagram

   - …​

.. _`_runtime_scenario_1`:

<Runtime Scenario 1>
--------------------

- *<inserire un runtime diagram o una descrizione testuale dello
  scenario>*

- *<inserire la descrizione degli aspetti degni di nota delle
  interazioni tra i istanze di building block illustrate in questo
  diagramma.>*

.. _`_runtime_scenario_2`:

<Runtime Scenario 2>
--------------------

…​
-

.. _`_runtime_scenario_n`:

<Runtime Scenario n>
--------------------

.. _section-deployment-view:

Deployment View
===============

.. container:: sidebar

   .. container:: formalpara

      La Deployment View descrive:

   1. l’infrastruttura tecnica utilizzata per eseguire il sistema, con
      elementi dell’infrastruttura come posizioni geografiche, ambienti,
      computer, processori, canali e topologie di rete, nonché altri
      elementi dell’infrastruttura e

   2. la mappatura dei building block (software) di tali elementi
      dell’infrastruttura.

   Spesso i sistemi vengono eseguiti in ambienti diversi, ad es.
   ambiente di sviluppo, ambiente di test, ambiente di produzione. In
   questi casi è necessario documentare tutti gli ambienti rilevanti.

   Documentare in particolare la Deployment View quando il software
   viene eseguito come sistema distribuito con più di un computer,
   processore, server o container o quando si progettano e si
   costruiscono processori e chip hardware personalizzati.

   Dal punto di vista del software è sufficiente acquisire quegli
   elementi dell’infrastruttura necessari per mostrare la distribuzione
   dei building block. Gli architetti hardware possono andare oltre e
   descrivere l’infrastruttura con qualsiasi livello di dettaglio di cui
   hanno bisogno per acquisire.

   .. container:: formalpara

      Il software non funziona senza hardware. Questa infrastruttura
      sottostante può e influenzerà il tuo sistema e/o alcuni concetti
      trasversali. Pertanto, è necessario conoscere l’infrastruttura.

   .. container:: formalpara

      Può essere che il Deployment View di livello più alto sia già
      contenuto nella sezione 3.2. come contesto tecnico con la propria
      infrastruttura come UNA scatola nera. In questa sezione lo farai
      ingrandire questa scatola nera utilizzando Deployment View
      aggiuntivi:

   - UML offre diagrammi di distribuzione per esprimere quella vista.
     Usalo, probabilmente con diagrammi annidati, quando la tua
     infrastruttura è più complessa.

   - Quando i tuoi stakeholder (hardware) preferiscono altri tipi di
     diagrammi piuttosto che il Deployment View, lascia che utilizzino
     qualsiasi tipo che sia in grado di mostrare nodi e canali
     dell’infrastruttura.

.. _`_livello_infrastruttura_1`:

Livello infrastruttura 1
------------------------

.. container:: sidebar

   Descrivi (di solito in una combinazione di diagrammi, tabelle e
   testo):

   - la distribuzione del sistema in più posizioni, ambienti, computer,
     processori, .. così come le connessioni fisiche tra di loro

   - una giustificazione o motivazione importante per questa struttura
     di distribuzione

   - Caratteristiche di qualità e/o prestazioni dell’infrastruttura

   - la mappatura degli artefatti software agli elementi
     dell’infrastruttura

   Per più ambienti o distribuzioni alternative, copia quella sezione di
   arc42 per tutti gli ambienti pertinenti.

**<Overview Diagram>**

Motivatione
   *<spiegazione in forma di testo>*

Requsiti di qualità e/o di prestazioni
   *<spiegazione in forma di testo>*

Mappatura dei Building Blocks nella Architettura
   *<descrizione della mappatura>*

.. _`_livello_infrastruttura_2`:

Livello infrastruttura 2
------------------------

.. container:: sidebar

   Qui puoi includere la struttura interna di (alcuni) elementi
   dell’infrastruttura dal livello 1.

   Si prega di copiare la struttura dal livello 1 per ogni elemento
   selezionato.

.. _`_elemento_infrastruttura_1`:

*<Elemento infrastruttura 1>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<diagramma + spiegazione>*

.. _`_elemento_infrastruttura_2`:

*<Elemento infrastruttura 2>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<diagramma + spiegazione>*

…​

.. _`_elemento_infrastruttura_n`:

*<Elemento infrastruttura n>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<diagramma + spiegazione>*

.. _section-concepts:

Concetti trasversali
====================

.. container:: sidebar

   .. container:: formalpara

      Questa sezione descrive le normative generali e principali e le
      idee di soluzione che sono rilevante in più parti (= trasversali)
      del sistema. Tali concetti sono spesso correlati a più building
      blocks. Possono includere molti argomenti diversi, come

   - modello di domonio

   - modelli di architettura o modelli di design

   - regole per l’utilizzo di una tecnologia specifica

   - decisioni principali, spesso tecniche, di decisioni generali

   - regole di implementazione

   .. container:: formalpara

      I concetti costituiscono la base per l '\_ integrità concettuale\_
      (coerenza, omogeneità) dell’architettura. Pertanto, sono un
      contributo importante per raggiungere le qualità interne del tuo
      sistema.

   Alcuni di questi concetti non possono essere assegnati a singoli
   building blocks (ad es. sicurezza o protezione). Questo è il posto
   nel template che abbiamo fornito per una specifica coerente di tali
   concetti.

   .. container:: formalpara

      Le forme possono eessere varie:

   - documenti concettuali con qualsiasi tipo di struttura

   - estratti di modelli trasversali o scenari che utilizzano le
     notazioni delle viste dell’architettura

   - implementazioni di esempio, soprattutto per concetti tecnici

   - riferimento all’uso tipico di framework standard (es. utilizzo di
     Hibernate per object/relational mapping)

   .. container:: formalpara

      Una struttura potenziale (ma non obbligatoria) per questa sezione
      potrebbe essere:

   - Concetti di dominio

   - Concetti sull’esperienza utente (UX)

   - Concetti di sicurezza e protezione

   - Architettura e modelli di design

   - "Sotto il cappuccio"

   - concetti di sviluppo

   - concetti operativi

   Nota: potrebbe essere difficile assegnare concetti individuali a un
   argomento specifico in questo elenco.

   .. figure:: images/08-concepts-EN.drawio.png
      :alt: Possibili argomenti per concetti trasversali

.. _`_concetto_1`:

*<Concetto 1>*
--------------

*<spiegazione>*

.. _`_concetto_2`:

*<Concetto 2>*
--------------

*<spiegazione>*

…​

.. _`_concetto_n`:

*<Concetto n>*
--------------

*<spiegazione>*

.. _section-design-decisions:

Decisioni di progettazione
==========================

.. container:: sidebar

   .. container:: formalpara

      Decisioni di architettura importanti, costose, su larga scala o
      rischiose, inclusi i razionali. Con "decisioni" si intende
      selezionare un’alternativa in base a determinati criteri.

   Si prega di utilizzare il proprio giudizio per decidere se una
   decisione architetturale debba essere documentata qui in questa
   sezione centrale o se è meglio documentarlo localmente (ad es.
   all’interno del whitebox di un building block).

   Evita la ridondanza. Fare riferimento alla sezione 4, dove sono già
   state acquisite le decisioni più importanti della propria
   architettura.

   .. container:: formalpara

      Gli stakeholder del tuo sistema dovrebbero essere in grado di
      comprendere e ripercorrere le tue decisioni.

   .. container:: formalpara

      Diverse opzioni:

   - Elenco o tabella, ordinati per importanza e conseguenze oppure:

   - più dettagliato sotto forma di sezioni separate per le decisioni

   - ADR (architecture decision record) per ogni decisione importante

.. _section-quality-scenarios:

Requisiti di Qualità
====================

.. container:: sidebar

   .. container:: formalpara

      Questa sezione contiene tutti i requisiti di qualità come albero
      di qualità con scenari. I più importanti sono già stati descritti
      nella sezione 1.2. (obiettivi di qualità)

   Qui puoi anche acquisire i requisiti di qualità con una priorità
   minore, il che non creerà rischi elevati quando non sono pienamente
   raggiunti.

   .. container:: formalpara

      Poiché i requisiti di qualità avranno molta influenza sulle
      decisioni architetturali, dovresti sapere per ogni stakeholder
      cosa è veramente importante per loro, concreto e misurabile.

.. _`_albero_di_qualità`:

Albero di qualità
-----------------

.. container:: sidebar

   .. container:: formalpara

      L’albero della qualità (come definito in ATAM – Architecture
      Tradeoff Analysis Method) con scenari di qualità/valutazione come
      foglie.

   .. container:: formalpara

      La struttura ad albero con le priorità fornisce una panoramica per
      un numero talvolta elevato di requisiti di qualità.

   .. container:: formalpara

      L’albero della qualità è una panoramica di alto livello degli
      obiettivi e dei requisiti di qualità:

   - espande il termine "qualità" con la forma di un’albero. Usa
     "qualità" o "utilità" come radice

   - una mappa mentale con categorie di qualità come rami principali

   In ogni caso l’albero dovrebbe includere collegamenti agli scenari
   della sezione successiva.

.. _`_scenari_di_qualità`:

Scenari di qualità
------------------

.. container:: sidebar

   .. container:: formalpara

      Concretizzazione dei requisiti di qualità (a volte vaghi o
      impliciti) utilizzando scenari (di qualità).

   Questi scenari descrivono cosa dovrebbe accadere quando uno stimolo
   arriva al sistema.

   Per gli architetti, due tipi di scenari sono importanti:

   - Gli scenari di utilizzo (chiamati anche scenari di applicazione o
     scenari di casi d’uso) descrivono la reazione di runtime del
     sistema a un determinato stimolo. Ciò include anche scenari che
     descrivono l’efficienza o le prestazioni del sistema. Esempio: il
     sistema risponde alla richiesta di un utente entro un secondo.

   - Gli scenari di cambiamento descrivono una modifica del sistema o
     dell’ambiente circostante. Esempio: sono implementate funzionalità
     aggiuntive o requisiti per una modifica dell’attributo di qualità.

   .. container:: formalpara

      Gli scenari rendono concreti i requisiti di qualità e consentono
      di misurare o decidere più facilmente se sono soddisfatti.

   Soprattutto quando vuoi valutare la tua architettura usando metodi
   come ATAM devi descrivere i tuoi obiettivi di qualità (dalla sezione
   1.2) più precisamente fino a un livello di scenari che possono essere
   discussi e valutati.

   .. container:: formalpara

      Testo tabulare o testo in formato libero.

.. _section-technical-risks:

Rischi e debiti tecnici
=======================

.. container:: sidebar

   .. container:: formalpara

      Un elenco di rischi tecnici o debiti tecnici identificati,
      ordinati per priorità

   .. container:: formalpara

      “La gestione del rischio è la gestione del progetto per adulti”
      (Tim Lister, Atlantic Systems Guild.)

   Questo dovrebbe essere il tuo motto per il rilevamento e la
   valutazione sistematica dei rischi e dei debiti tecnici
   nell’architettura, che saranno necessari agli stakeholder del
   management (ad esempio i project manager, i proprietari dei prodotti)
   come parte dell’analisi complessiva dei rischi e della pianificazione
   delle misurazioni.

   .. container:: formalpara

      Elenco dei rischi e/o dei debiti tecnici, possibilmente
      comprendendo le misure suggerite per minimizzare, mitigare o
      evitare i rischi o ridurre i debiti tecnici.

.. _section-glossary:

Glossario
=========

.. container:: sidebar

   .. container:: formalpara

      Il dominio più importante e i termini tecnici utilizzati dagli
      stakeholder quando discutono del sistema.

   Puoi anche vedere il glossario come fonte per le traduzioni se lavori
   in team multilingue.

   .. container:: formalpara

      Dovresti definire chiaramente i tuoi termini, in modo che tutte le
      parti interessate

   - abbiano una comprensione identica di questi termini

   - non utilizzino sinonimi e omonimi

   .. container::

      - Una tabella con colonne <Termine> e <Definizione>.

      - Potenzialmente più colonne nel caso tu abbia bisogno di
        traduzioni.

+----------------------+-----------------------------------------------+
| Termine              | Definizione                                   |
+======================+===============================================+
| *<Termine-1>*        | *<definizione-1>*                             |
+----------------------+-----------------------------------------------+
| *<Termine-2>*        | *<definizione-2>*                             |
+----------------------+-----------------------------------------------+

.. |arc42| image:: images/arc42-logo.png
