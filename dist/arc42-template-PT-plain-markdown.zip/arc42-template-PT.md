# 

**Sobre o arc42**

arc42, o template para documentação de software e arquitetura de
sistemas.

Versão do template 8.2 PT. (baseado na versão AsciiDoc), Setembro de
2024

Criado, mantido e © pelo Dr. Peter Hruschka, Dr. Gernot Starke e
colaboradores. Veja <https://arc42.org>.

# Introdução e Objetivos {#section-introduction-and-goals}

## Visão Geral dos Requisitos {#_vis_o_geral_dos_requisitos}

## Objetivos de Qualidade {#_objetivos_de_qualidade}

## Partes Interessadas {#_partes_interessadas}

+-------------+---------------------------+---------------------------+
| Função/Nome | Contato                   | Expectativas              |
+=============+===========================+===========================+
| *\          | *\<Contato-1>*            | *\<Expectativa-1>*        |
| <Função-1>* |                           |                           |
+-------------+---------------------------+---------------------------+
| *\          | *\<Contato-2>*            | *\<Expectativa-2>*        |
| <Função-2>* |                           |                           |
+-------------+---------------------------+---------------------------+

# Restrições Arquiteturais {#section-architecture-constraints}

# Contexto e Escopo {#section-context-and-scope}

## Contexto Negocial {#_contexto_negocial}

**\<Diagrama ou Tabela>**

**\<opcionalmente: Explicação das interfaces de domínio externo>**

## Contexto Técnico {#_contexto_t_cnico}

**\<Diagrama ou Tabela>**

**\<opcionalmente: Explicação das interfaces técnicas>**

**\<Mapeamento de entrada/saída para canais>**

# Estratégia de Solução {#section-solution-strategy}

# Visão de Blocos de Construção {#section-building-block-view}

## Visão Sistêmica Geral de Caixa Branca {#_vis_o_sist_mica_geral_de_caixa_branca}

***\<Diagrama de Visão Geral>***

Motivação

:   *\<explicação textual>*

Blocos de Construção Contidos

:   *\<Descrição dos blocos de construção contidos (caixas pretas)>*

Interfaces Importantes

:   *\<Descrição de interfaces importantes>*

### \<Nome Caixa Preta 1> {#__nome_caixa_preta_1}

*\<Propósito/Responsabilidade>*

*\<Interface(s)>*

*\<(Opcional) Características de Qualidade/Desempenho>*

*\<(Opcional) Local do Diretório/Arquivo>*

*\<(Opcional) Requisitos Cumpridos>*

*\<(opcional) Problemas/Riscos Abertos>*

### \<Nome Caixa Preta 2> {#__nome_caixa_preta_2}

*\<modelo de caixa preta>*

### \<Nome Caixa Preta n> {#__nome_caixa_preta_n}

*\<modelo de caixa preta>*

### \<Nome Interface 1> {#__nome_interface_1}

...

### \<Nome Interface m> {#__nome_interface_m}

## Nível 2 {#_n_vel_2}

### Caixa Branca *\<Bloco de Construção 1>* {#_caixa_branca_emphasis_bloco_de_constru_o_1_emphasis}

*\<modelo de caixa branca>*

### Caixa Branca *\<Bloco de Construção 2>* {#_caixa_branca_emphasis_bloco_de_constru_o_2_emphasis}

*\<modelo de caixa branca>*

...

### Caixa Branca *\<Bloco de Construção m>* {#_caixa_branca_emphasis_bloco_de_constru_o_m_emphasis}

*\<modelo de caixa branca>*

## Nível 3 {#_n_vel_3}

### Caixa Branca \<\_Bloco de Construção x.1\_\> {#_caixa_branca_bloco_de_constru_o_x_1}

*\<modelo de caixa branca>*

### Caixa Branca \<\_Bloco de Construção x.2\_\> {#_caixa_branca_bloco_de_constru_o_x_2}

*\<modelo de caixa branca>*

### Caixa Branca \<\_Bloco de Construção y.1\_\> {#_caixa_branca_bloco_de_constru_o_y_1}

*\<modelo de caixa branca>*

# Visão de Tempo de Execução {#section-runtime-view}

## \<Cenário de Tempo de Execução 1> {#__cen_rio_de_tempo_de_execu_o_1}

-   *\<inserir diagrama de tempo de execução ou descrição textual do
    cenário>*

-   *\<inserir descrição dos aspectos notáveis ​​das interações entre as
    instâncias do bloco de construção descritas neste diagrama.\>*

## \<Cenário de Tempo de Execução 2> {#__cen_rio_de_tempo_de_execu_o_2}

## ... {#_}

## \<Cenário de Tempo de Execução n> {#__cen_rio_de_tempo_de_execu_o_n}

# Visão de Implantação {#section-deployment-view}

## Nível de Infraestrutura 1 {#_n_vel_de_infraestrutura_1}

***\<Diagrama de Visão Geral>***

Motivação

:   *\<explicação em forma de texto>*

Características de Qualidade e/ou Desempenho

:   *\<explicação em forma de texto>*

Mapeamento de Blocos de Construção para Infraestrutura

:   *\<descrição do mapeamento>*

## Nível de Infraestrutura 2 {#_n_vel_de_infraestrutura_2}

### *\<Elemento de Infraestrutura 1>* {#__emphasis_elemento_de_infraestrutura_1_emphasis}

*\<diagrama + explicação>*

### *\<Elemento de Infraestrutura 2>* {#__emphasis_elemento_de_infraestrutura_2_emphasis}

*\<diagrama + explicação>*

...

### *\<Elemento de Infraestrutura n>* {#__emphasis_elemento_de_infraestrutura_n_emphasis}

*\<diagrama + explicação>*

# Conceitos Transversais {#section-concepts}

## *\<Conceito 1>* {#__emphasis_conceito_1_emphasis}

*\<explicação>*

## *\<Conceito 2>* {#__emphasis_conceito_2_emphasis}

*\<explicação>*

...

## *\<Conceito n>* {#__emphasis_conceito_n_emphasis}

*\<explicação>*

# Decisões Arquiteturais {#section-design-decisions}

# Requisitos de qualidade {#section-quality-scenarios}

## Árvore de qualidade {#__rvore_de_qualidade}

## Cenários de Qualidade {#_cen_rios_de_qualidade}

# Riscos e Débitos Técnicos {#section-technical-risks}

# Glossário {#section-glossary}

+-----------------------+-----------------------------------------------+
| Termo                 | Definição                                     |
+=======================+===============================================+
| *\<Termo-1>*          | *\<definição-1>*                              |
+-----------------------+-----------------------------------------------+
| *\<Termo-2>*          | *\<definição-2>*                              |
+-----------------------+-----------------------------------------------+
