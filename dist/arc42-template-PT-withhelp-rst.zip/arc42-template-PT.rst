==============
Modelo |arc42|
==============

:Date: Setembro de 2024

**Sobre o arc42**

arc42, o template para documentação de software e arquitetura de
sistemas.

Versão do template 8.2-PT. (based upon AsciiDoc version), Setembro de
2024

Criado, mantido e © pelo Dr. Peter Hruschka, Dr. Gernot Starke e
colaboradores. Veja https://arc42.org.

.. container:: sidebar

   .. note::

      Esta versão do modelo contém algumas ajudas e explicações. É usada
      para familiarização com arc42 e compreensão dos conceitos. Para a
      documentação do seu próprio sistema, é melhor usar a versão
      *plain*.

.. _section-introduction-and-goals:

Introdução e Objetivos
======================

.. container:: sidebar

   Descreve os requisitos relevantes e as forças motrizes que os
   arquitetos de software e a equipe de desenvolvimento devem
   considerar. Isso inclui

   - objetivos de negócios subjacentes,

   - recursos essenciais,

   - requisitos funcionais essenciais,

   - objetivos de qualidade para a arquitetura e

   - partes interessadas relevantes e suas expectativas

.. _`_visão_geral_dos_requisitos`:

Visão Geral dos Requisitos
--------------------------

.. container:: sidebar

   .. container:: formalpara

      Descrição curta dos requisitos funcionais, forças motrizes,
      excerto (ou resumo) dos requisitos. Link para (esperançosamente
      existentes) documentos de requisitos (com número da versão e
      informações sobre onde encontrá-lo).

   .. container:: formalpara

      Do ponto de vista dos usuários finais, um sistema é criado ou
      modificado para melhorar o suporte e/ou melhorar a qualidade de
      uma atividade negocial.

   .. container:: formalpara

      Descrição textual curta, provavelmente em formato tabular de casos
      de uso. Se existirem documentos de requisitos, esta visão geral
      deve se referir a esses documentos.

   Mantenha esses trechos o mais curtos possível. Equilibre a
   legibilidade deste documento com a redundância potencial em relação
   aos documentos de requisitos.

   .. container:: formalpara

      Consulte `Introduction and
      Goals <https://docs.arc42.org/section-1/>`__ na documentação do
      arc42.

.. _`_objetivos_de_qualidade`:

Objetivos de Qualidade
----------------------

.. container:: sidebar

   .. container:: formalpara

      Os três principais (máx. cinco) objetivos de qualidade para a
      arquitetura cujo cumprimento é de maior importância para as
      principais partes interessadas. Nós realmente queremos dizer
      objetivos de qualidade para a arquitetura. Não os confunda com
      objetivos de projeto. Eles não são necessariamente idênticos.

   Considere esta visão geral de tópicos potenciais (com base no padrão
   ISO 25010):

   .. figure:: images/01_2_iso-25010-topics-EN-2023.drawio.png
      :alt: Categorias de Requisitos de Qualidade

   .. container:: formalpara

      Você deve saber os objetivos de qualidade de suas partes
      interessadas mais importantes, pois elas influenciarão decisões
      arquiteturais fundamentais. Certifique-se de ser muito concreto
      sobre essas qualidades, evite chavões. Se você, como arquiteto,
      não sabe como a qualidade do seu trabalho será julgada…​

   .. container:: formalpara

      Uma tabela com objetivos de qualidade e cenários concretos,
      ordenados por prioridades

.. _`_partes_interessadas`:

Partes Interessadas
-------------------

.. container:: sidebar

   .. container:: formalpara

      Visão geral explícita das partes interessadas do sistema, ou seja,
      todas as pessoas, funções ou organizações que

   - devem conhecer a arquitetura

   - precisam ser convencidas da arquitetura

   - precisam trabalhar com a arquitetura ou com código

   - precisam da documentação da arquitetura para seu trabalho

   - precisam tomar decisões sobre o sistema ou seu desenvolvimento

   .. container:: formalpara

      Você deve conhecer todas as partes envolvidas no desenvolvimento
      do sistema ou afetadas pelo sistema. Caso contrário, você pode ter
      surpresas desagradáveis ​​mais tarde no processo de desenvolvimento.
      Essas partes interessadas determinam a extensão e o nível de
      detalhes do seu trabalho e seus resultados.

   .. container:: formalpara

      Tabela com nomes de funções, nomes de pessoas e suas expectativas
      com relação à arquitetura e sua documentação.

+--------------+---------------------------+---------------------------+
| Função/Nome  | Contato                   | Expectativas              |
+==============+===========================+===========================+
| *<Função-1>* | *<Contato-1>*             | *<Expectativa-1>*         |
+--------------+---------------------------+---------------------------+
| *<Função-2>* | *<Contato-2>*             | *<Expectativa-2>*         |
+--------------+---------------------------+---------------------------+

.. _section-architecture-constraints:

Restrições Arquiteturais
========================

.. container:: sidebar

   .. container:: formalpara

      Qualquer requisito que restrinja arquitetos de software em sua
      liberdade de decisões de design e implementação ou decisão sobre o
      processo de desenvolvimento. Essas restrições às vezes vão além de
      sistemas individuais e são válidas para organizações e empresas
      inteiras.

   .. container:: formalpara

      Arquitetos devem saber exatamente onde são livres em suas decisões
      de design e onde devem aderir às restrições. Restrições devem
      sempre ser tratadas; elas podem ser negociáveis, no entanto.

   .. container:: formalpara

      Tabelas simples de restrições com explicações. Se necessário, você
      pode subdividi-las em restrições técnicas, restrições
      organizacionais e políticas e convenções (por exemplo, diretrizes
      de programação ou controle de versão, convenções de documentação
      ou nomenclatura)

   .. container:: formalpara

      Consulte `Architecture
      Constraints <https://docs.arc42.org/section-2/>`__ na documentação
      do arc42.

.. _section-context-and-scope:

Contexto e Escopo
=================

.. container:: sidebar

   .. container:: formalpara

      Contexto e escopo - como o nome sugere - delimita seu sistema (ou
      seja, seu escopo) de todos os seus parceiros de comunicação
      (sistemas e usuários vizinhos, ou seja, o contexto do seu
      sistema). Ele especifica, portanto, as interfaces externas.

   Se necessário, diferencie o contexto de negócios (entradas e saídas
   específicas do domínio) do contexto técnico (canais, protocolos,
   hardware).

   .. container:: formalpara

      As interfaces de domínio e as interfaces técnicas para componentes
      externos estão entre os aspectos mais críticos do seu sistema.
      Certifique-se de entendê-las completamente.

   .. container:: formalpara

      Várias opções:

   - Diagramas de contexto

   - Listas de componentes externos e suas interfaces.

   .. container:: formalpara

      Consulte `Context and Scope <https://docs.arc42.org/section-3/>`__
      na documentação do arc42.

.. _`_contexto_negocial`:

Contexto Negocial
-----------------

.. container:: sidebar

   .. container:: formalpara

      Especificação de **todos** os componentes externos (usuários,
      sistemas de TI, …​) com explicações de entradas e saídas ou
      interfaces específicas do domínio. Opcionalmente, você pode
      adicionar formatos específicos do domínio ou protocolos de
      comunicação.

   .. container:: formalpara

      Todas as partes interessadas devem entender quais dados são
      trocados com o ambiente do sistema.

   .. container:: formalpara

      Todos os tipos de diagramas que mostram o sistema como uma caixa
      preta e especificam as interfaces de domínio para os componentes
      externos.

   Como alternativa (ou adicionalmente), você pode usar uma tabela. O
   título da tabela é o nome do seu sistema, as três colunas contêm o
   nome do componente externo, as entradas e as saídas.

**<Diagrama ou Tabela>**

**<opcionalmente: Explicação das interfaces de domínio externo>**

.. _`_contexto_técnico`:

Contexto Técnico
----------------

.. container:: sidebar

   .. container:: formalpara

      Interfaces técnicas (canais e mídias de transmissão) que vinculam
      seu sistema ao seu ambiente. Além disso, um mapeamento de
      entrada/saída específica de domínio para os canais, ou seja, uma
      explicação de qual E/S usa qual canal.

   .. container:: formalpara

      Muitas partes interessadas tomam decisões arquiteturais com base
      nas interfaces técnicas entre o sistema e seu contexto.
      Especialmente os designers de infraestrutura ou hardware decidem
      essas interfaces técnicas.

   .. container:: formalpara

      Por exemplo, diagrama de implantação UML descrevendo canais para
      sistemas vizinhos, junto com uma tabela de mapeamento mostrando os
      relacionamentos entre canais e entrada/saída.

**<Diagrama ou Tabela>**

**<opcionalmente: Explicação das interfaces técnicas>**

**<Mapeamento de entrada/saída para canais>**

.. _section-solution-strategy:

Estratégia de Solução
=====================

.. container:: sidebar

   .. container:: formalpara

      Um breve resumo e explicação das decisões fundamentais e
      estratégias de solução que moldam a arquitetura do sistema. Inclui

   - decisões de tecnologia

   - decisões sobre a decomposição de nível superior do sistema, por
     exemplo, uso de um padrão arquitetural ou *design pattern*

   - decisões sobre como atingir as principais metas de qualidade

   - decisões organizacionais relevantes, por exemplo, selecionar um
     processo de desenvolvimento ou delegar certas tarefas a terceiros.

   .. container:: formalpara

      Essas decisões formam os pilares da sua arquitetura. Elas são a
      base para muitas outras decisões detalhadas ou regras de
      implementação.

   .. container:: formalpara

      Mantenha as explicações dessas decisões-chave curtas.

   Motive o que foi decidido e por que foi decidido dessa forma, com
   base na declaração do problema, metas de qualidade e principais
   restrições. Consulte os detalhes nas seções a seguir.

   .. container:: formalpara

      Consulte `Solution Strategy <https://docs.arc42.org/section-4/>`__
      na documentação do arc42.

.. _section-building-block-view:

Visão de Blocos de Construção
=============================

.. container:: sidebar

   .. container:: formalpara

      A visão de blocos de construção mostra a decomposição estática do
      sistema em blocos (módulos, componentes, subsistemas, classes,
      interfaces, pacotes, bibliotecas, frameworks, camadas, partições,
      níveis, funções, macros, operações, estruturas de dados, …​) bem
      como suas dependências (relacionamentos, associações, …​)

   Esta visão é obrigatória para toda documentação de arquitetura. Em
   analogia a uma casa, esta é a *planta baixa*.

   .. container:: formalpara

      Mantenha uma visão geral do seu código-fonte tornando sua
      estrutura compreensível por meio de abstração.

   Isso permite que você se comunique com suas partes interessadas em um
   nível abstrato sem revelar detalhes de implementação.

   .. container:: formalpara

      A visão de blocos de construção é uma coleção hierárquica de
      caixas pretas e caixas brancas (veja a figura abaixo) e suas
      descrições.

   .. figure:: images/05_building_blocks-EN.png
      :alt: Hierarquia de blocos de construção

   **Nível 1** é a descrição da caixa branca do sistema geral,
   juntamente com descrições de caixa preta de todos os blocos de
   construção contidos.

   **Nível 2** amplia alguns blocos de construção do nível 1. Portanto,
   ele contém a descrição da caixa branca dos blocos de construção
   selecionados do nível 1, juntamente com descrições de caixa preta de
   seus blocos de construção internos.

   **Nível 3** amplia os blocos de construção selecionados do nível 2, e
   assim por diante.

   .. container:: formalpara

      Consulte `Building Block
      View <https://docs.arc42.org/section-5/>`__ na documentação do
      arc42.

.. _`_visão_sistêmica_geral_de_caixa_branca`:

Visão Sistêmica Geral de Caixa Branca
-------------------------------------

.. container:: sidebar

   Aqui você descreve a decomposição geral do sistema usando o seguinte
   modelo de caixa branca. Ele contém

   - um diagrama de visão geral

   - uma motivação para a decomposição

   - descrições de caixa preta dos blocos de construção contidos. Para
     isso, oferecemos alternativas:

     - use *uma* tabela para uma visão geral curta e pragmática de todos
       os blocos de construção contidos e suas interfaces

     - use uma lista de descrições de caixa preta dos blocos de
       construção de acordo com o modelo de caixa preta (veja abaixo).
       Dependendo da sua escolha de ferramenta, esta lista pode ser
       subcapítulos (em arquivos de texto), subpáginas (em uma Wiki) ou
       elementos aninhados (em uma ferramenta de modelagem).

   - (opcional:) interfaces importantes, que não são explicadas nos
     modelos de caixa preta de um bloco de construção, mas são muito
     importantes para entender a caixa branca. Já que há tantas maneiras
     de especificar interfaces, por que não fornecer um modelo
     específico para elas? No pior caso, você tem que especificar e
     descrever sintaxe, semântica, protocolos, tratamento de erros,
     restrições, versões, qualidades, compatibilidades necessárias e
     muito mais. Na melhor das hipóteses, você conseguirá usar exemplos
     ou descrições simples.

**<Diagrama de Visão Geral>**

Motivação
   *<explicação textual>*

Blocos de Construção Contidos
   *<Descrição dos blocos de construção contidos (caixas pretas)>*

Interfaces Importantes
   *<Descrição de interfaces importantes>*

.. container:: sidebar

   Insira suas explicações de caixas pretas do nível 1:

   Se você usar a forma tabular, você descreverá apenas suas caixas
   pretas com nome e responsabilidade de acordo com o seguinte esquema:

   +----------------------+-----------------------------------------------+
   | **Nome**             | **Responsabilidade**                          |
   +======================+===============================================+
   | *<caixa preta 1>*    | *<Texto>*                                     |
   +----------------------+-----------------------------------------------+
   | *<caixa preta 2>*    | *<Texto>*                                     |
   +----------------------+-----------------------------------------------+

   Se você usar uma lista de descrições de caixa preta, então você
   preenche um modelo de caixa preta separado para cada bloco de
   construção importante. Seu título é o nome da caixa preta.

.. _`_nome_caixa_preta_1`:

<Nome Caixa Preta 1>
~~~~~~~~~~~~~~~~~~~~

.. container:: sidebar

   Aqui você descreve <caixa preta 1> de acordo com o seguinte modelo de
   caixa preta:

   - Propósito/Responsabilidade

   - Interface(s), quando não são extraídas como parágrafos separados.
     Essas interfaces podem incluir qualidades e características de
     desempenho.

   - (Opcional) Características de qualidade/desempenho da caixa preta,
     por exemplo, disponibilidade, comportamento de tempo de execução,
     …​.

   - (Opcional) Local do diretório/arquivo

   - (Opcional) Requisitos atendidos (se você precisar de
     rastreabilidade para requisitos).

   - (Opcional) Problemas/questões/riscos abertos

*<Propósito/Responsabilidade>*

*<Interface(s)>*

*<(Opcional) Características de Qualidade/Desempenho>*

*<(Opcional) Local do Diretório/Arquivo>*

*<(Opcional) Requisitos Cumpridos>*

*<(opcional) Problemas/Riscos Abertos>*

.. _`_nome_caixa_preta_2`:

<Nome Caixa Preta 2>
~~~~~~~~~~~~~~~~~~~~

*<modelo de caixa preta>*

.. _`_nome_caixa_preta_n`:

<Nome Caixa Preta n>
~~~~~~~~~~~~~~~~~~~~

*<modelo de caixa preta>*

.. _`_nome_interface_1`:

<Nome Interface 1>
~~~~~~~~~~~~~~~~~~

…​

.. _`_nome_interface_m`:

<Nome Interface m>
~~~~~~~~~~~~~~~~~~

.. _`_nível_2`:

Nível 2
-------

.. container:: sidebar

   Aqui você pode especificar a estrutura interna de (alguns) blocos de
   construção do nível 1 como caixas brancas.

   Você tem que decidir quais blocos de construção do seu sistema são
   importantes o suficiente para justificar uma descrição tão detalhada.
   Por favor, prefira relevância à completude. Especifique blocos de
   construção importantes, surpreendentes, arriscados, complexos ou
   voláteis. Deixe de fora partes normais, simples, chatas ou
   padronizadas do seu sistema

.. _`_caixa_branca_bloco_de_construção_1`:

Caixa Branca *<Bloco de Construção 1>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. container:: sidebar

   …​descreve a estrutura interna do *bloco de construção 1*.

*<modelo de caixa branca>*

.. _`_caixa_branca_bloco_de_construção_2`:

Caixa Branca *<Bloco de Construção 2>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<modelo de caixa branca>*

…​

.. _`_caixa_branca_bloco_de_construção_m`:

Caixa Branca *<Bloco de Construção m>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<modelo de caixa branca>*

.. _`_nível_3`:

Nível 3
-------

.. container:: sidebar

   Aqui você pode especificar a estrutura interna de (alguns) blocos de
   construção do nível 2 como caixas brancas.

   Quando precisar de níveis mais detalhados de sua arquitetura, copie
   esta parte do arc42 para níveis adicionais.

.. _`_caixa_branca_bloco_de_construção_x_1`:

Caixa Branca <\_Bloco de Construção x.1\_>
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. container:: sidebar

   Especifica a estrutura interna do *bloco de construção x.1*.

*<modelo de caixa branca>*

.. _`_caixa_branca_bloco_de_construção_x_2`:

Caixa Branca <\_Bloco de Construção x.2\_>
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<modelo de caixa branca>*

.. _`_caixa_branca_bloco_de_construção_y_1`:

Caixa Branca <\_Bloco de Construção y.1\_>
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<modelo de caixa branca>*

.. _section-runtime-view:

Visão de Tempo de Execução
==========================

.. container:: sidebar

   .. container:: formalpara

      A visão de tempo de execução descreve o comportamento concreto e
      as interações dos blocos de construção do sistema na forma de
      cenários das seguintes áreas:

   - casos de uso ou recursos importantes: como os blocos de construção
     os executam?

   - interações em interfaces externas críticas: como os blocos de
     construção cooperam com os usuários e sistemas vizinhos?

   - operação e administração: lançamento, inicialização, parada

   - cenários de erro e exceção

   Observação: O principal critério para a escolha de cenários possíveis
   (sequências, fluxos de trabalho) é sua **relevância arquitetural**.
   **Não** é importante descrever um grande número de cenários. Você
   deve documentar uma seleção representativa.

   .. container:: formalpara

      Você deve entender como (instâncias de) blocos de construção do
      seu sistema realizam seu trabalho e se comunicam em tempo de
      execução. Você capturará principalmente cenários em sua
      documentação para comunicar sua arquitetura às partes interessadas
      que estão menos dispostas ou capazes de ler e entender os modelos
      estáticos (visão de bloco de construção, visão de implantação).

   .. container:: formalpara

      Há muitas notações para descrever cenários, por exemplo,

   - lista numerada de etapas (em linguagem natural)

   - diagramas de atividade ou fluxogramas

   - diagramas de sequência

   - BPMN ou EPCs (cadeias de processos de eventos)

   - máquinas de estado

   - …​

   .. container:: formalpara

      Consulte `Runtime View <https://docs.arc42.org/section-6/>`__ na
      documentação do arc42.

.. _`_cenário_de_tempo_de_execução_1`:

<Cenário de Tempo de Execução 1>
--------------------------------

- *<inserir diagrama de tempo de execução ou descrição textual do
  cenário>*

- *<inserir descrição dos aspectos notáveis ​​das interações entre as
  instâncias do bloco de construção descritas neste diagrama.>*

.. _`_cenário_de_tempo_de_execução_2`:

<Cenário de Tempo de Execução 2>
--------------------------------

…​
-

.. _`_cenário_de_tempo_de_execução_n`:

<Cenário de Tempo de Execução n>
--------------------------------

.. _section-deployment-view:

Visão de Implantação
====================

.. container:: sidebar

   .. container:: formalpara

      A visão de implantação descreve:

   1. infraestrutura técnica usada para executar seu sistema, com
      elementos de infraestrutura como localizações geográficas,
      ambientes, computadores, processadores, canais e topologias de
      rede, bem como outros elementos de infraestrutura e

   2. mapeamento de blocos de construção (de software) para esses
      elementos de infraestrutura.

   Frequentemente, os sistemas são executados em ambientes diferentes,
   por exemplo, ambiente de desenvolvimento, ambiente de teste, ambiente
   de produção. Nesses casos, você deve documentar todos os ambientes
   relevantes.

   Documente especialmente uma visão de implantação se seu software for
   executado como um sistema distribuído com mais de um computador,
   processador, servidor ou contêiner ou quando você projeta e constrói
   seus próprios processadores e chips de hardware.

   De uma perspectiva de software, é suficiente capturar apenas os
   elementos de uma infraestrutura que são necessários para mostrar uma
   implantação de seus blocos de construção. Arquitetos de hardware
   podem ir além disso e descrever uma infraestrutura em qualquer nível
   de detalhe que precisem capturar.

   .. container:: formalpara

      O software não roda sem hardware. Essa infraestrutura subjacente
      pode e influenciará um sistema e/ou alguns conceitos transversais.
      Portanto, é necessário conhecer a infraestrutura.

   .. container:: formalpara

      Talvez um diagrama de implantação de nível mais alto já esteja
      contido na seção 3.2. como contexto técnico com sua própria
      infraestrutura como UMA caixa preta. Nesta seção, pode-se ampliar
      esta caixa preta usando diagramas de implantação adicionais:

   - UML oferece diagramas de implantação para expressar essa visão.
     Use-o, provavelmente com diagramas aninhados, quando sua
     infraestrutura for mais complexa.

   - Quando suas partes interessadas (de hardware) preferirem outros
     tipos de diagramas em vez de um diagrama de implantação, deixe-os
     usar qualquer tipo que seja capaz de mostrar nós e canais da
     infraestrutura.

   .. container:: formalpara

      Consulte `Deployment View <https://docs.arc42.org/section-7/>`__
      na documentação do arc42.

.. _`_nível_de_infraestrutura_1`:

Nível de Infraestrutura 1
-------------------------

.. container:: sidebar

   Descreva (geralmente em uma combinação de diagramas, tabelas e
   texto):

   - distribuição de um sistema para vários locais, ambientes,
     computadores, processadores, .., bem como conexões físicas entre
     eles

   - justificativas ou motivações importantes para esta estrutura de
     implantação

   - recursos de qualidade e/ou desempenho desta infraestrutura

   - mapeamento de artefatos de software para elementos desta
     infraestrutura

   Para vários ambientes ou implantações alternativas, copie e adapte
   esta seção do arc42 para todos os ambientes relevantes.

**<Diagrama de Visão Geral>**

Motivação
   *<explicação em forma de texto>*

Características de Qualidade e/ou Desempenho
   *<explicação em forma de texto>*

Mapeamento de Blocos de Construção para Infraestrutura
   *<descrição do mapeamento>*

.. _`_nível_de_infraestrutura_2`:

Nível de Infraestrutura 2
-------------------------

.. container:: sidebar

   Aqui você pode incluir a estrutura interna de (alguns) elementos de
   infraestrutura do nível 1.

   Copie a estrutura do nível 1 para cada elemento selecionado.

.. _`_elemento_de_infraestrutura_1`:

*<Elemento de Infraestrutura 1>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<diagrama + explicação>*

.. _`_elemento_de_infraestrutura_2`:

*<Elemento de Infraestrutura 2>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<diagrama + explicação>*

…​

.. _`_elemento_de_infraestrutura_n`:

*<Elemento de Infraestrutura n>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<diagrama + explicação>*

.. _section-concepts:

Conceitos Transversais
======================

.. container:: sidebar

   .. container:: formalpara

      Esta seção descreve globalmente, as principais regulamentações e
      ideias de soluções que são relevantes em várias partes (=
      transversais) do seu sistema. Esses conceitos geralmente estão
      relacionados a vários blocos de construção. Eles podem incluir
      muitos tópicos diferentes, como

   - modelos, especialmente modelos de domínio

   - padrões de arquitetura ou *design patterns*

   - regras para usar tecnologia específica

   - principais decisões, geralmente técnicas, de natureza abrangente (=
     transversais)

   - regras de implementação

   .. container:: formalpara

      Os conceitos formam a base para a *integridade conceitual*
      (consistência, homogeneidade) da arquitetura. Portanto, eles são
      uma contribuição importante para atingir as qualidades internas do
      seu sistema.

   Alguns desses conceitos não podem ser atribuídos a blocos de
   construção individuais, por exemplo segurança ou proteção.

   .. container:: formalpara

      A forma pode ser variada:

   - documentos conceituais com qualquer tipo de estrutura

   - trechos ou cenários de modelos transversais usando notações das
     visualizações de arquitetura

   - amostra de implementações, especialmente para conceitos técnicos

   - referência ao uso típico de *frameworks* padrão (por exemplo,
     usando Hibernate para mapeamento de objeto/relacional)

   .. container:: formalpara

      Uma estrutura potencial (mas não obrigatória) para esta seção
      poderia ser:

   - Conceitos de domínio

   - Conceitos de Experiência do Usuário (UX)

   - Conceitos de proteção e segurança

   - Padrões de arquitetura e *design patterns*

   - Estruturas internas

   - Conceitos de desenvolvimento

   - Conceitos operacionais

   Observação: pode ser difícil atribuir conceitos individuais a um
   tópico específico nesta lista.

   .. figure:: images/08-concepts-EN.drawio.png
      :alt: Tópicos possíveis para conceitos transversais

   .. container:: formalpara

      Veja `Concepts <https://docs.arc42.org/section-8/>`__ na
      documentação do arc42.

.. _`_conceito_1`:

*<Conceito 1>*
--------------

*<explicação>*

.. _`_conceito_2`:

*<Conceito 2>*
--------------

*<explicação>*

…​

.. _`_conceito_n`:

*<Conceito n>*
--------------

*<explicação>*

.. _section-design-decisions:

Decisões Arquiteturais
======================

.. container:: sidebar

   .. container:: formalpara

      Decisões arquiteturais importantes, caras, de grande escala ou
      arriscadas, incluindo justificativas. Com "decisões", queremos
      dizer selecionar uma alternativa com base em critérios fornecidos.

   Use seu julgamento para decidir se uma decisão de arquitetura deve
   ser documentada aqui nesta seção central ou se é melhor documentá-la
   localmente (por exemplo, dentro do modelo de caixa branca de um bloco
   de construção).

   Evite redundância. Consulte a seção 4, onde você já capturou as
   decisões mais importantes da sua arquitetura.

   .. container:: formalpara

      As partes interessadas do seu sistema devem ser capazes de
      compreender e refazer suas decisões.

   .. container:: formalpara

      Várias opções:

   - ADR (Architecture Decision Record) (`Documentando Decisões de
     Arquitetura <https://cognitect.com/blog/2011/11/15/documenting-architecture-decisions>`__)
     para cada decisão importante

   - Lista ou tabela, ordenada por importância e consequências ou:

   - mais detalhada em forma de seções separadas por decisão

   .. container:: formalpara

      Veja `Architecture
      Decisions <https://docs.arc42.org/section-9/>`__ na documentação
      do arc42. Lá você encontrará links e exemplos sobre ADR.

.. _section-quality-scenarios:

Requisitos de qualidade
=======================

.. container:: sidebar

   .. container:: formalpara

      Esta seção contém todos os requisitos de qualidade como árvore de
      qualidade com cenários. Os mais importantes já foram descritos na
      seção 1.2. (objetivos de qualidade)

   Aqui você também pode capturar requisitos de qualidade com menor
   prioridade, que não criarão altos riscos quando não forem totalmente
   alcançados.

   .. container:: formalpara

      Como os requisitos de qualidade terão muita influência nas
      decisões arquiteturais, você deve saber para cada parte
      interessada o que é realmente importante para eles, concreto e
      mensurável.

   .. container:: formalpara

      Veja `Quality Requirements <https://docs.arc42.org/section-10/>`__
      na documentação do arc42.

.. _`_árvore_de_qualidade`:

Árvore de qualidade
-------------------

.. container:: sidebar

   .. container:: formalpara

      A árvore de qualidade (conforme definido no ATAM – Architecture
      Tradeoff Analysis Method) com cenários de qualidade/avaliação como
      folhas.

   .. container:: formalpara

      A estrutura de árvore com prioridades fornece uma visão geral para
      um número às vezes grande de requisitos de qualidade.

   .. container:: formalpara

      A árvore de qualidade é uma visão geral de alto nível das metas e
      requisitos de qualidade:

   - refinamento em forma de árvore do termo "qualidade". Use
     "qualidade" ou "utilidade" como raiz

   - um mapa mental com categorias de qualidade como ramos principais

   Em qualquer caso, a árvore deve incluir links para os cenários da
   seção a seguir.

.. _`_cenários_de_qualidade`:

Cenários de Qualidade
---------------------

.. container:: sidebar

   .. container:: formalpara

      Concretização de requisitos de qualidade (às vezes vagos ou
      implícitos) usando cenários (de qualidade).

   Esses cenários descrevem o que deve acontecer quando um estímulo
   chega ao sistema.

   Para arquitetos, dois tipos de cenários são importantes:

   - Cenários de uso (também chamados de cenários de aplicação ou
     cenários de caso de uso) descrevem a reação do tempo de execução do
     sistema a um determinado estímulo. Isso também inclui cenários que
     descrevem a eficiência ou o desempenho do sistema. Exemplo: O
     sistema reage à solicitação de um usuário em um segundo.

   - Cenários de mudança descrevem uma modificação do sistema ou de seu
     ambiente imediato. Exemplo: Funcionalidade adicional é implementada
     ou requisitos para um atributo de qualidade mudam.

   .. container:: formalpara

      Os cenários tornam os requisitos de qualidade concretos e permitem
      medir ou decidir mais facilmente se eles são atendidos.

   Especialmente quando você quer avaliar sua arquitetura usando métodos
   como ATAM você precisa descrever suas metas de qualidade (da seção
   1.2) mais precisamente até um nível de cenários que podem ser
   discutidos e avaliados.

   .. container:: formalpara

      Tabular ou texto livre.

.. _section-technical-risks:

Riscos e Débitos Técnicos
=========================

.. container:: sidebar

   .. container:: formalpara

      Uma lista de riscos técnicos identificados ou débitos técnicos,
      ordenadas por prioridade

   .. container:: formalpara

      “Gerenciamento de riscos é gerenciamento de projetos para adultos”
      (Tim Lister, Atlantic Systems Guild.)

   Este deve ser seu lema para detecção e avaliação sistemáticas de
   riscos e débitos técnicos na arquitetura, que serão necessárias para
   as partes interessadas da gerência (por exemplo, gerentes de projeto,
   proprietários de produtos) como parte da análise geral de riscos e
   planejamento de medição.

   .. container:: formalpara

      Lista de riscos e/ou débitos técnicos, provavelmente incluindo
      medidas sugeridas para minimizar, mitigar ou evitar riscos ou
      reduzir débitos técnicos.

   .. container:: formalpara

      Veja `Risks and Technical
      Debt <https://docs.arc42.org/section-11/>`__ na documentação do
      arc42.

.. _section-glossary:

Glossário
=========

.. container:: sidebar

   .. container:: formalpara

      Os termos técnicos e de domínio mais importantes que suas partes
      interessadas usam ao discutir o sistema.

   Você também pode ver o glossário como fonte para traduções se
   trabalhar em equipes multilíngues.

   .. container:: formalpara

      Você deve definir claramente seus termos, para que todas as partes
      interessadas

   - tenham um entendimento idêntico desses termos

   - não usem sinônimos e homônimos

   .. container:: formalpara

      Uma tabela com colunas <Termo> e <Definição>.

   Possivelmente mais colunas, caso precise de traduções.

   .. container:: formalpara

      Veja `Glossary <https://docs.arc42.org/section-12/>`__ na
      documentação do arc42.

+----------------------+-----------------------------------------------+
| Termo                | Definição                                     |
+======================+===============================================+
| *<Termo-1>*          | *<definição-1>*                               |
+----------------------+-----------------------------------------------+
| *<Termo-2>*          | *<definição-2>*                               |
+----------------------+-----------------------------------------------+

.. |arc42| image:: images/arc42-logo.png
