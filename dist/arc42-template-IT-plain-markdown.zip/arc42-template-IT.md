# 

**About arc42**

arc42, the Template for documentation of software and system
architecture.

By Dr. Gernot Starke, Dr. Peter Hruschka and contributors.

Template Revision: 7.0 IT (based on asciidoc), April 2021

© We acknowledge that this document uses material from the arc 42
architecture template, <https://www.arc42.org>. Created by Dr. Peter
Hruschka & Dr. Gernot Starke.

# Introduzione e obiettivi {#section-introduction-and-goals}

## Panoramica dei requisiti {#_panoramica_dei_requisiti}

## Obiettivi di qualità {#_obiettivi_di_qualit}

## Stakeholders {#_stakeholders}

+-------------+---------------------------+---------------------------+
| Rouolo/Nome | Contatto                  | Aspettative               |
+=============+===========================+===========================+
| *\          | *\<Contatto-1\>*          | *\<Aspettatiive-1\>*      |
| <Ruolo-1\>* |                           |                           |
+-------------+---------------------------+---------------------------+
| *\          | *\<Contatto-2\>*          | *\<Aspettatiive-2\>*      |
| <Ruolo-2\>* |                           |                           |
+-------------+---------------------------+---------------------------+

# Vincoli di architettura {#section-architecture-constraints}

# Ambito e contesto del sistema {#section-system-scope-and-context}

## Contesto di Business {#_contesto_di_business}

**\<Diagramma o Tabella\>**

**\<opzionale: spiegazione delle interfacce del dominio esterno\>**

## Contesto Tecnico {#_contesto_tecnico}

**\<Diagramma o Tabella\>**

**\<opzionale: Spiegazione delle interfacce tecniche\>**

**\<Mappatura Input/Output sui canali di comunicazione\>**

# Strategia della soluzione {#section-solution-strategy}

# Building Block View {#section-building-block-view}

## Whitebox Overall System {#_whitebox_overall_system}

***\<Overview Diagram\>***

Motivazione

:   *\<spiegazione testuale\>*

Contenuto dei Building Blocks

:   *\<Descrizione del contenuto del building block (black boxes)\>*

Important Interfaces

:   *\<Descrizione delle interfacce importanti\>*

### \<Nome black box 1\> {#__nome_black_box_1}

*\<Scopo/responsabilità\>*

*\<Interfacce\>*

*\<(Facoltativo) Caratteristiche di qualità/prestazionali\>*

*\<(Facoltativo) percorso file/directory\>*

*\<(Facoltativo) Requisiti soddisfatti\>*

*\<(Facoltativo) Bug noti/Rischi/problemi\>*

### \<Nome black box 2\> {#__nome_black_box_2}

*\<black box template\>*

### \<Nome black box n\> {#__nome_black_box_n}

*\<black box template\>*

### \<Nome interface 1\> {#__nome_interface_1}

...

### \<Nome interface m\> {#__nome_interface_m}

## Livello 2 {#_livello_2}

### White Box *\<building block 1\>* {#_white_box_emphasis_building_block_1_emphasis}

*\<white box template\>*

### White Box *\<building block 2\>* {#_white_box_emphasis_building_block_2_emphasis}

*\<white box template\>*

...

### White Box *\<building block m\>* {#_white_box_emphasis_building_block_m_emphasis}

*\<white box template\>*

## Livello 3 {#_livello_3}

### White Box \<\_building block x.1\_\> {#_white_box_building_block_x_1}

*\<white box template\>*

### White Box \<\_building block x.2\_\> {#_white_box_building_block_x_2}

*\<white box template\>*

### White Box \<\_building block y.1\_\> {#_white_box_building_block_y_1}

*\<white box template\>*

# Runtime View {#section-runtime-view}

## \<Runtime Scenario 1\> {#__runtime_scenario_1}

-   *\<inserire un runtime diagram o una descrizione testuale dello
    scenario\>*

-   *\<inserire la descrizione degli aspetti degni di nota delle
    interazioni tra i istanze di building block illustrate in questo
    diagramma.\>*

## \<Runtime Scenario 2\> {#__runtime_scenario_2}

## ... {#_}

## \<Runtime Scenario n\> {#__runtime_scenario_n}

# Deployment View {#section-deployment-view}

## Livello infrastruttura 1 {#_livello_infrastruttura_1}

***\<Overview Diagram\>***

Motivatione

:   *\<spiegazione in forma di testo\>*

Requsiti di qualità e/o di prestazioni

:   *\<spiegazione in forma di testo\>*

Mappatura dei Building Blocks nella Architettura

:   *\<descrizione della mappatura\>*

## Livello infrastruttura 2 {#_livello_infrastruttura_2}

### *\<Elemento infrastruttura 1\>* {#__emphasis_elemento_infrastruttura_1_emphasis}

*\<diagramma + spiegazione\>*

### *\<Elemento infrastruttura 2\>* {#__emphasis_elemento_infrastruttura_2_emphasis}

*\<diagramma + spiegazione\>*

...

### *\<Elemento infrastruttura n\>* {#__emphasis_elemento_infrastruttura_n_emphasis}

*\<diagramma + spiegazione\>*

# Concetti trasversali {#section-concepts}

## *\<Concetto 1\>* {#__emphasis_concetto_1_emphasis}

*\<spiegazione\>*

## *\<Concetto 2\>* {#__emphasis_concetto_2_emphasis}

*\<spiegazione\>*

...

## *\<Concetto n\>* {#__emphasis_concetto_n_emphasis}

*\<spiegazione\>*

# Decisioni di progettazione {#section-design-decisions}

# Requisiti di Qualità {#section-quality-scenarios}

## Albero di qualità {#_albero_di_qualit}

## Scenari di qualità {#_scenari_di_qualit}

# Rischi e debiti tecnici {#section-technical-risks}

# Glossario {#section-glossary}

+-----------------------+-----------------------------------------------+
| Termine               | Definizione                                   |
+=======================+===============================================+
| *\<Termine-1\>*       | *\<definizione-1\>*                           |
+-----------------------+-----------------------------------------------+
| *\<Termine-2\>*       | *\<definizione-2\>*                           |
+-----------------------+-----------------------------------------------+
