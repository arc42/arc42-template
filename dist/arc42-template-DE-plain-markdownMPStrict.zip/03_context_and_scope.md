# Kontextabgrenzung

## Fachlicher Kontext

**&lt;Diagramm und/oder Tabelle>**

**&lt;optional: Erläuterung der externen fachlichen Schnittstellen>**

## Technischer Kontext

**&lt;Diagramm oder Tabelle>**

**&lt;optional: Erläuterung der externen technischen Schnittstellen>**

**&lt;Mapping fachliche auf technische Schnittstellen>**
