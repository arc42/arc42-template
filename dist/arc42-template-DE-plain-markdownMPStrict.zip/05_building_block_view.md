# Bausteinsicht

## Whitebox Gesamtsystem

***&lt;Übersichtsdiagramm>***

Begründung  
*&lt;Erläuternder Text>*

Enthaltene Bausteine  
*&lt;Beschreibung der enthaltenen Bausteine (Blackboxen)>*

Wichtige Schnittstellen  
*&lt;Beschreibung wichtiger Schnittstellen>*

### &lt;Name Blackbox 1>

*&lt;Zweck/Verantwortung>*

*&lt;Schnittstelle(n)>*

*&lt;(Optional) Qualitäts-/Leistungsmerkmale>*

*&lt;(Optional) Ablageort/Datei(en)>*

*&lt;(Optional) Erfüllte Anforderungen>*

*&lt;(optional) Offene Punkte/Probleme/Risiken>*

### &lt;Name Blackbox 2>

*&lt;Blackbox-Template>*

### &lt;Name Blackbox n>

*&lt;Blackbox-Template>*

### &lt;Name Schnittstelle 1>

…

### &lt;Name Schnittstelle m>

## Ebene 2

### Whitebox *&lt;Baustein 1>*

*&lt;Whitebox-Template>*

### Whitebox *&lt;Baustein 2>*

*&lt;Whitebox-Template>*

…

### Whitebox *&lt;Baustein m>*

*&lt;Whitebox-Template>*

## Ebene 3

### Whitebox &lt;\_Baustein x.1\_&gt;

*&lt;Whitebox-Template>*

### Whitebox &lt;\_Baustein x.2\_&gt;

*&lt;Whitebox-Template>*

### Whitebox &lt;\_Baustein y.1\_&gt;

*&lt;Whitebox-Template>*
