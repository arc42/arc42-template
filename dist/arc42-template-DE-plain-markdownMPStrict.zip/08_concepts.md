# Querschnittliche Konzepte

## *&lt;Konzept 1>*

*&lt;Erklärung>*

## *&lt;Konzept 2>*

*&lt;Erklärung>*

…

## *&lt;Konzept n>*

*&lt;Erklärung>*
