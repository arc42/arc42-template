# Querschnittliche Konzepte

**Weiterführende Informationen**

Siehe [Querschnittliche Konzepte](https://docs.arc42.org/section-8/) in
der online-Dokumentation (auf Englisch).

=== *&lt;Konzept 1&gt;*

*&lt;Erklärung&gt;*

=== *&lt;Konzept 2&gt;*

*&lt;Erklärung&gt;*

…

=== *&lt;Konzept n&gt;*

*&lt;Erklärung&gt;*
