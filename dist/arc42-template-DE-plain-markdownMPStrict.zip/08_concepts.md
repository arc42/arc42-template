# Querschnittliche Konzepte

## *&lt;Konzept 1&gt;*

*&lt;Erklärung&gt;*

## *&lt;Konzept 2&gt;*

*&lt;Erklärung&gt;*

…​

## *&lt;Konzept n&gt;*

*&lt;Erklärung&gt;*
