Verteilungssicht
================

Infrastruktur Ebene 1
---------------------

***&lt;Übersichtsdiagramm&gt;***

Begründung  
*&lt;Erläuternder Text&gt;*

Qualitäts- und/oder Leistungsmerkmale  
*&lt;Erläuternder Text&gt;*

Zuordnung von Bausteinen zu Infrastruktur  
*&lt;Beschreibung der Zuordnung&gt;*

Infrastruktur Ebene 2
---------------------

### *&lt;Infrastrukturelement 1&gt;*

*&lt;Diagramm + Erläuterungen&gt;*

### *&lt;Infrastrukturelement 2&gt;*

*&lt;Diagramm + Erläuterungen&gt;*

…

### *&lt;Infrastrukturelement n&gt;*

*&lt;Diagramm + Erläuterungen&gt;*
