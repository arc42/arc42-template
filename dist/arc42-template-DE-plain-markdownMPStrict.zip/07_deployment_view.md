# Verteilungssicht

## Infrastruktur Ebene 1

***&lt;Übersichtsdiagramm>***

Begründung  
*&lt;Erläuternder Text>*

Qualitäts- und/oder Leistungsmerkmale  
*&lt;Erläuternder Text>*

Zuordnung von Bausteinen zu Infrastruktur  
*&lt;Beschreibung der Zuordnung>*

## Infrastruktur Ebene 2

### *&lt;Infrastrukturelement 1>*

*&lt;Diagramm + Erläuterungen>*

### *&lt;Infrastrukturelement 2>*

*&lt;Diagramm + Erläuterungen>*

…

### *&lt;Infrastrukturelement n>*

*&lt;Diagramm + Erläuterungen>*
