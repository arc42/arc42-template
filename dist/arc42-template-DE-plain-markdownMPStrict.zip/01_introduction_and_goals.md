Einführung und Ziele
====================

Aufgabenstellung
----------------

Qualitätsziele
--------------

Stakeholder
-----------

<table>
<colgroup>
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th>Rolle</th>
<th>Kontakt</th>
<th>Erwartungshaltung</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><p><em>&lt;Rolle-1&gt;</em></p></td>
<td><p><em>&lt;Kontakt-1&gt;</em></p></td>
<td><p><em>&lt;Erwartung-1&gt;</em></p></td>
</tr>
<tr class="even">
<td><p><em>&lt;Rolle-2&gt;</em></p></td>
<td><p><em>&lt;Kontakt-2&gt;</em></p></td>
<td><p><em>&lt;Erwartung-2&gt;</em></p></td>
</tr>
</tbody>
</table>
