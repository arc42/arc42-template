# Einführung und Ziele

## Aufgabenstellung

## Qualitätsziele

## Stakeholder

<table>
<colgroup>
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">Rolle</th>
<th style="text-align: left;">Kontakt</th>
<th style="text-align: left;">Erwartungshaltung</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p><em>&lt;Rolle-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Kontakt-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Erwartung-1&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"><p><em>&lt;Rolle-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Kontakt-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Erwartung-2&gt;</em></p></td>
</tr>
</tbody>
</table>
