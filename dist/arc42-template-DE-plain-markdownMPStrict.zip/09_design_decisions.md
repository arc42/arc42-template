Entwurfsentscheidungen
======================
