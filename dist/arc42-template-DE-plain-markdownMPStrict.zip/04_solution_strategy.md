Lösungsstrategie
================
