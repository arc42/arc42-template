# Lösungsstrategie
