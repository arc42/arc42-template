Glossar
=======

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th>Begriff</th>
<th>Definition</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><p><em>&lt;Begriff-1&gt;</em></p></td>
<td><p><em>&lt;Definition-1&gt;</em></p></td>
</tr>
<tr class="even">
<td><p><em>&lt;Begriff-2</em></p></td>
<td><p><em>&lt;Definition-2&gt;</em></p></td>
</tr>
</tbody>
</table>
