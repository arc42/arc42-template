# Randbedingungen
