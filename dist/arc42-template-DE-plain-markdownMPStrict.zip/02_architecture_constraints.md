Randbedingungen
===============
