**O arc42**

arc42, šablona pro dokumentaci softwaru a architekturu systému.

Verze šablony 9.0-CZ. (na základě AsciiDoc verze), Leden 2025

Created, maintained and © by Dr. Peter Hruschka, Dr. Gernot Starke and
contributors. Viz https://arc42.org.

.. _section-introduction-and-goals:

Úvod a cíle
===========

.. _`_přehled_požadavků`:

Přehled požadavků
-----------------

.. _`_kvalitativní_cíle`:

Kvalitativní cíle
-----------------

.. _`_strany_zainteresované_na_systému_stakeholder`:

Strany zainteresované na systému (stakeholder)
----------------------------------------------

+-------------+---------------------------+---------------------------+
| Role/Jméno  | Kontakt                   | Očekávání                 |
+=============+===========================+===========================+
| *<Role-1>*  | *<Kontakt-1>*             | *<Očekávání-1>*           |
+-------------+---------------------------+---------------------------+
| *<Role-2>*  | *<Kontakt-2>*             | *<Očekávání-2>*           |
+-------------+---------------------------+---------------------------+

.. _section-architecture-constraints:

Omezení na realizaci systému
============================

.. _section-context-and-scope:

Vymezení a rozsah systému
=========================

.. _`_firemní_kontext`:

Firemní kontext
---------------

**<vložte diagram nebo tabulku>**

**<(volitelně:) vložte vysvětlení externích doménových rozhraní>**

.. _`_technický_kontext`:

Technický kontext
-----------------

**<vložte diagram nebo tabulku>**

**<(volitelně:) vložte vysvětlení externích technických rozhraní>**

**<mapování doménových vstupu/výstupu na technické kanály>**

.. _section-solution-strategy:

Strategie řešení
================

.. _section-building-block-view:

Perspektiva stavebních bloků
============================

.. _`_celý_systém_jako_white_box`:

Celý systém jako white-box
--------------------------

**<vložte přehledový diagram celého systému>**

Motivace
   *<popište motivaci>*

Obsažené stavební bloky
   *<popište obsažené stavební bloky (jako black-box)>*

Důležitá rozhraní
   *<popište důležitá rozhraní>*

.. _`_jméno_black_boxu_1`:

<Jméno black-boxu 1>
~~~~~~~~~~~~~~~~~~~~

*<Účel/Odpovědnost>*

*<Rozhraní>*

*<(Volitelně) Požadavky na kvalitu/výkon>*

*<(Volitelně) Umístění/složky a soubory>*

*<(Volitelně) Splněné požadavky>*

*<(Volitelně) Nevyřešené body/problémy/rizika>*

.. _`_jméno_black_boxu_2`:

<Jméno black-boxu 2>
~~~~~~~~~~~~~~~~~~~~

*<šablona black-box>*

.. _`_jméno_black_boxu_n`:

<Jméno black-boxu n>
~~~~~~~~~~~~~~~~~~~~

*<šablona black-box>*

.. _`_jméno_rozhraní_1`:

<Jméno rozhraní 1>
~~~~~~~~~~~~~~~~~~

…​

.. _`_jméno_rozhraní_m`:

<Jméno rozhraní m>
~~~~~~~~~~~~~~~~~~

.. _`_úroveň_2`:

Úroveň 2
--------

.. _`_white_box_stavební_blok_1`:

white-box *<stavební blok 1>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<šablona white-box>*

.. _`_white_box_stavební_blok_2`:

white-box *<stavební blok 2>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<šablona white-box>*

…​

.. _`_white_box_stavební_blok_m`:

white-box *<stavební blok m>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<šablona white-box>*

.. _`_úroveň_3`:

Úroveň 3
--------

.. _`_white_box_stavební_blok_x_1`:

white-box <\_stavební blok x.1\_>
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<šablona white-box>*

.. _`_white_box_stavební_blok_x_2`:

white-box <\_stavební blok x.2\_>
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<šablona white-box>*

.. _`_white_box_stavební_blok_y_1`:

white-box <\_stavební blok y.1\_>
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<šablona white-box>*

.. _section-runtime-view:

Perspektiva chování za běhu (runtime)
=====================================

.. _`_scénář_runtime_1`:

<Scénář runtime 1>
------------------

- *<vložte runtime diagram nebo textový popis scénáře>*

- *<vložte popis důležitých interakcí mezi instancemi stavebních bloků
  zobrazených v tomto diagramu>*

.. _`_scénář_runtime_2`:

<Scénář runtime 2>
------------------

…​
-

.. _`_scénář_runtime_n`:

<Scénář runtime n>
------------------

.. _section-deployment-view:

Perspektiva nasazení softwaru (deployment)
==========================================

.. _`_úroveň_infrastruktury_1`:

Úroveň infrastruktury 1
-----------------------

**<Přehledový diagram>**

Motivace
   *<vysvětlení v textové podobě>*

Kvalitativní a/nebo výkonnostní vlastnosti
   *<vysvětlení v textové podobě>*

Mapování softwarových artefaktů na prvky infrastruktury
   *<popis mapování>*

.. _`_úroveň_infrastruktury_2`:

Úroveň infrastruktury 2
-----------------------

.. _`_prvek_infrastruktury_1`:

*<prvek infrastruktury 1>*
~~~~~~~~~~~~~~~~~~~~~~~~~~

*<diagram + vysvětlení>*

.. _`_prvek_infrastruktury_2`:

*<prvek infrastruktury 2>*
~~~~~~~~~~~~~~~~~~~~~~~~~~

*<diagram + vysvětlení>*

…​

.. _`_prvek_infrastruktury_n`:

*<prvek infrastruktury n>*
~~~~~~~~~~~~~~~~~~~~~~~~~~

*<diagram + vysvětlení>*

.. _section-concepts:

Průřezové (cross-cutting) koncepty
==================================

.. _`_koncept_1`:

*<Koncept 1>*
-------------

*<vysvětlení>*

.. _`_koncept_2`:

*<Koncept 2>*
-------------

*<vysvětlení>*

…​

.. _`_koncept_n`:

*<Koncept n>*
-------------

*<vysvětlení>*

.. _section-design-decisions:

Rozhodnutí o architektuře
=========================

.. _section-quality-scenarios:

Požadavky na kvalitu
====================

.. _`_přehled_požadavků_na_kvalitu`:

Přehled požadavků na kvalitu
----------------------------

.. _`_scénáře_kvality`:

Scénáře kvality
---------------

.. _section-technical-risks:

Rizika a technické dluhy
========================

.. _section-glossary:

Slovník pojmů
=============

+----------------------+-----------------------------------------------+
| Termín               | Definice                                      |
+======================+===============================================+
| *<termín-1>*         | *<definice-1>*                                |
+----------------------+-----------------------------------------------+
| *<termín-2>*         | *<definice-2>*                                |
+----------------------+-----------------------------------------------+

.. |arc42| image:: images/arc42-logo.png
