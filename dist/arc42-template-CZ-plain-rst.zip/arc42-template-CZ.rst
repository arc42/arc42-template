**O arc42**

arc42, šablona pro dokumentaci softwaru a architekturu systému.

Verze šablony 8.1 CZ. (na základě AsciiDoc verze), říjen 2022

Created, maintained and © by Dr. Peter Hruschka, Dr. Gernot Starke and
contributors. Viz https://arc42.org.

.. _section-introduction-and-goals:

Úvod a cíle
===========

.. _`_p_ehled_po_adavk`:

Přehled požadavků
-----------------

.. _`_kvalitativn_c_le`:

Kvalitativní cíle
-----------------

.. _`_strany_zainteresovan_na_syst_mu_stakeholder`:

Strany zainteresované na systému (Stakeholder)
----------------------------------------------

+-------------+---------------------------+---------------------------+
| Role/Jméno  | Kontakt                   | Očekávání                 |
+=============+===========================+===========================+
| *<Role-1>*  | *<Kontakt-1>*             | *<Očekávání-1>*           |
+-------------+---------------------------+---------------------------+
| *<Role-2>*  | *<Kontakt-2>*             | *<Očekávání-2>*           |
+-------------+---------------------------+---------------------------+

.. _section-architecture-constraints:

Omezení na realizaci systému
============================

.. _section-system-scope-and-context:

Vymezení a rozsah systému
=========================

.. _`_firemn_kontext`:

Firemní kontext
---------------

**<vložte diagram nebo tabulku>**

**<(volitelně:) vložte vysvětlení externích doménových rozhraní>**

.. _`_technick_kontext`:

Technický kontext
-----------------

**<vložte diagram nebo tabulku>**

**<(volitelně:) vložte vysvětlení externích technických rozhraní>**

**<mapování doménových vstupu/výstupu na technické kanály>**

.. _section-solution-strategy:

Strategie řešení
================

.. _section-building-block-view:

Perspektiva stavebních bloků
============================

.. _`_cel_syst_m_jako_white_box`:

Celý systém jako white-box
--------------------------

**<vložte přehledový diagram celého systému>**

Motivace
   *<popište motivaci>*

Obsažené stavební bloky
   *<popište obsažené stavební bloky (jako black-box)>*

Důležitá rozhraní
   *<popište důležitá rozhraní>*

.. _`__jm_no_black_boxu_1`:

<Jméno black-boxu 1>
~~~~~~~~~~~~~~~~~~~~

*<Účel/Odpovědnost>*

*<Rozhraní>*

*<(Volitelně) Požadavky na kvalitu/výkon>*

*<(Volitelně) Umístění/složky a soubory>*

*<(Volitelně) Splněné požadavky>*

*<(Volitelně) Nevyřešené body/problémy/rizika>*

.. _`__jm_no_black_boxu_2`:

<Jméno black-boxu 2>
~~~~~~~~~~~~~~~~~~~~

*<šablona black-box>*

.. _`__jm_no_black_boxu_n`:

<Jméno black-boxu n>
~~~~~~~~~~~~~~~~~~~~

*<šablona black-box>*

.. _`__jm_no_rozhran_1`:

<Jméno rozhraní 1>
~~~~~~~~~~~~~~~~~~

…

.. _`__jm_no_rozhran_m`:

<Jméno rozhraní m>
~~~~~~~~~~~~~~~~~~

.. _`__rove_2`:

Úroveň 2
--------

.. _`_white_box_emphasis_stavebn_blok_1_emphasis`:

white-box *<stavební blok 1>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<šablona white-box>*

.. _`_white_box_emphasis_stavebn_blok_2_emphasis`:

white-box *<stavební blok 2>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<šablona white-box>*

…

.. _`_white_box_emphasis_stavebn_blok_m_emphasis`:

white-box *<stavební blok m>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<šablona white-box>*

.. _`__rove_3`:

Úroveň 3
--------

.. _`_white_box_stavebn_blok_x_1`:

white-box <_stavební blok x.1_>
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<šablona white-box>*

.. _`_white_box_stavebn_blok_x_2`:

white-box <_stavební blok x.2_>
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<šablona white-box>*

.. _`_white_box_stavebn_blok_y_1`:

white-box <_stavební blok y.1_>
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<šablona white-box>*

.. _section-runtime-view:

Perspektiva chování za běhu (runtime)
=====================================

.. _`__sc_n_runtime_1`:

<Scénář runtime 1>
------------------

-  *<vložte runtime diagram nebo textový popis scénáře>*

-  *<vložte popis důležitých interakcí mezi instancemi stavebních bloků
   zobrazených v tomto diagramu>*

.. _`__sc_n_runtime_2`:

<Scénář runtime 2>
------------------

.. _`_`:

…
-

.. _`__sc_n_runtime_n`:

<Scénář runtime n>
------------------

.. _section-deployment-view:

Perspektiva nasazení softwaru (deployment)
==========================================

.. _`__rove_infrastruktury_1`:

Úroveň infrastruktury 1
-----------------------

**<Přehledový diagram>**

Motivace
   *<vysvětlení v textové podobě>*

Kvalitativní a/nebo výkonnostní vlastnosti
   *<vysvětlení v textové podobě>*

Mapování softwarových artefaktů na prvky infrastruktury
   *<popis mapování>*

.. _`__rove_infrastruktury_2`:

Úroveň infrastruktury 2
-----------------------

.. _`__emphasis_prvek_infrastruktury_1_emphasis`:

*<prvek infrastruktury 1>*
~~~~~~~~~~~~~~~~~~~~~~~~~~

*<diagram + vysvětlení>*

.. _`__emphasis_prvek_infrastruktury_2_emphasis`:

*<prvek infrastruktury 2>*
~~~~~~~~~~~~~~~~~~~~~~~~~~

*<diagram + vysvětlení>*

…

.. _`__emphasis_prvek_infrastruktury_n_emphasis`:

*<prvek infrastruktury n>*
~~~~~~~~~~~~~~~~~~~~~~~~~~

*<diagram + vysvětlení>*

.. _section-concepts:

Průřezové (cross-cutting) koncepty
==================================

.. _`__emphasis_koncept_1_emphasis`:

*<Koncept 1>*
-------------

*<vysvětlení>*

.. _`__emphasis_koncept_2_emphasis`:

*<Koncept 2>*
-------------

*<vysvětlení>*

…

.. _`__emphasis_koncept_n_emphasis`:

*<Koncept n>*
-------------

*<vysvětlení>*

.. _section-design-decisions:

Rozhodnutí o architektuře
=========================

.. _section-quality-scenarios:

Požadavky na kvalitu
====================

.. _`_strom_kvality`:

Strom kvality
-------------

.. _`_sc_n_e_kvality`:

Scénáře kvality
---------------

.. _section-technical-risks:

Rizika a technické dluhy
========================

.. _section-glossary:

Slovník pojmů
=============

+-----------------------+-----------------------------------------------+
| Termín                | Definice                                      |
+=======================+===============================================+
| *<termín-1>*          | *<definice-1>*                                |
+-----------------------+-----------------------------------------------+
| *<termín-2>*          | *<definice-2>*                                |
+-----------------------+-----------------------------------------------+

.. |arc42| image:: images/arc42-logo.png
