# Decisões Arquiteturais

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Conteúdo

</div>

Decisões arquiteturais importantes, caras, de grande escala ou
arriscadas, incluindo justificativas. Com "decisões", queremos dizer
selecionar uma alternativa com base em critérios fornecidos.

</div>

Use seu julgamento para decidir se uma decisão de arquitetura deve ser
documentada aqui nesta seção central ou se é melhor documentá-la
localmente (por exemplo, dentro do modelo de caixa branca de um bloco de
construção).

Evite redundância. Consulte a seção 4, onde você já capturou as decisões
mais importantes da sua arquitetura.

<div class="formalpara">

<div class="title">

Motivação

</div>

As partes interessadas do seu sistema devem ser capazes de compreender e
refazer suas decisões.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Várias opções:

</div>

- ADR (Architecture Decision Record) ([Documentando Decisões de
  Arquitetura](https://cognitect.com/blog/2011/11/15/documenting-architecture-decisions))
  para cada decisão importante

- Lista ou tabela, ordenada por importância e consequências ou:

- mais detalhada em forma de seções separadas por decisão

<div class="formalpara">

<div class="title">

Mais informações

</div>

Veja [Architecture Decisions](https://docs.arc42.org/section-9/) na
documentação do arc42. Lá você encontrará links e exemplos sobre ADR.

</div>

</div>
