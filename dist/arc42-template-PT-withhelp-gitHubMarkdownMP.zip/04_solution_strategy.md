# Estratégia de Solução

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Conteúdo

</div>

Um breve resumo e explicação das decisões fundamentais e estratégias de
solução que moldam a arquitetura do sistema. Inclui

</div>

- decisões de tecnologia

- decisões sobre a decomposição de nível superior do sistema, por
  exemplo, uso de um padrão arquitetural ou *design pattern*

- decisões sobre como atingir as principais metas de qualidade

- decisões organizacionais relevantes, por exemplo, selecionar um
  processo de desenvolvimento ou delegar certas tarefas a terceiros.

<div class="formalpara">

<div class="title">

Motivação

</div>

Essas decisões formam os pilares da sua arquitetura. Elas são a base
para muitas outras decisões detalhadas ou regras de implementação.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Mantenha as explicações dessas decisões-chave curtas.

</div>

Motive o que foi decidido e por que foi decidido dessa forma, com base
na declaração do problema, metas de qualidade e principais restrições.
Consulte os detalhes nas seções a seguir.

<div class="formalpara">

<div class="title">

Mais informações

</div>

Consulte [Solution Strategy](https://docs.arc42.org/section-4/) na
documentação do arc42.

</div>

</div>
