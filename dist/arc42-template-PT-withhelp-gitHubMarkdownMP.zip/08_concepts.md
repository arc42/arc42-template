# Conceitos Transversais

## *\<Conceito 1>*

*\<explicação>*

## *\<Conceito 2>*

*\<explicação>*

…

## *\<Conceito n>*

*\<explicação>*
