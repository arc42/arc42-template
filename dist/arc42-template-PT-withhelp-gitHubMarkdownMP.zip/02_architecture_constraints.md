# Restrições Arquiteturais

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Conteúdo

</div>

Qualquer requisito que restrinja arquitetos de software em sua liberdade
de decisões de design e implementação ou decisão sobre o processo de
desenvolvimento. Essas restrições às vezes vão além de sistemas
individuais e são válidas para organizações e empresas inteiras.

</div>

<div class="formalpara">

<div class="title">

Motivação

</div>

Arquitetos devem saber exatamente onde são livres em suas decisões de
design e onde devem aderir às restrições. Restrições devem sempre ser
tratadas; elas podem ser negociáveis, no entanto.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Tabelas simples de restrições com explicações. Se necessário, você pode
subdividi-las em restrições técnicas, restrições organizacionais e
políticas e convenções (por exemplo, diretrizes de programação ou
controle de versão, convenções de documentação ou nomenclatura)

</div>

<div class="formalpara">

<div class="title">

Mais informações

</div>

Consulte [Architecture Constraints](https://docs.arc42.org/section-2/)
na documentação do arc42.

</div>

</div>
