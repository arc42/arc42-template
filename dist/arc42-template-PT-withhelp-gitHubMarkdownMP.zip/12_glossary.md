# Glossário

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Conteúdo

</div>

Os termos técnicos e de domínio mais importantes que suas partes
interessadas usam ao discutir o sistema.

</div>

Você também pode ver o glossário como fonte para traduções se trabalhar
em equipes multilíngues.

<div class="formalpara">

<div class="title">

Motivação

</div>

Você deve definir claramente seus termos, para que todas as partes
interessadas

</div>

- tenham um entendimento idêntico desses termos

- não usem sinônimos e homônimos

<div class="formalpara">

<div class="title">

Forma

</div>

Uma tabela com colunas \<Termo\> e \<Definição\>.

</div>

Possivelmente mais colunas, caso precise de traduções.

<div class="formalpara">

<div class="title">

Mais informações

</div>

Veja [Glossary](https://docs.arc42.org/section-12/) na documentação do
arc42.

</div>

</div>

| Termo         | Definição         |
|---------------|-------------------|
| *\<Termo-1\>* | *\<definição-1\>* |
| *\<Termo-2\>* | *\<definição-2\>* |
