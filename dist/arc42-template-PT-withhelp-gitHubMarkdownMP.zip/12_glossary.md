# Glossário

| Termo        | Definição        |
|--------------|------------------|
| *\<Termo-1>* | *\<definição-1>* |
| *\<Termo-2>* | *\<definição-2>* |
