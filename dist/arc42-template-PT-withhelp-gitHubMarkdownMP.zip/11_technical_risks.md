# Riscos e Débitos Técnicos

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Conteúdo

</div>

Uma lista de riscos técnicos identificados ou débitos técnicos,
ordenadas por prioridade

</div>

<div class="formalpara">

<div class="title">

Motivação

</div>

“Gerenciamento de riscos é gerenciamento de projetos para adultos” (Tim
Lister, Atlantic Systems Guild.)

</div>

Este deve ser seu lema para detecção e avaliação sistemáticas de riscos
e débitos técnicos na arquitetura, que serão necessárias para as partes
interessadas da gerência (por exemplo, gerentes de projeto,
proprietários de produtos) como parte da análise geral de riscos e
planejamento de medição.

<div class="formalpara">

<div class="title">

Forma

</div>

Lista de riscos e/ou débitos técnicos, provavelmente incluindo medidas
sugeridas para minimizar, mitigar ou evitar riscos ou reduzir débitos
técnicos.

</div>

<div class="formalpara">

<div class="title">

Mais informações

</div>

Veja [Risks and Technical Debt](https://docs.arc42.org/section-11/) na
documentação do arc42.

</div>

</div>
