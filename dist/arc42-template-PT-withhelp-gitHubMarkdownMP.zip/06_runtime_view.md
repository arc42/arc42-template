# Visão de Tempo de Execução

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Conteúdo

</div>

A visão de tempo de execução descreve o comportamento concreto e as
interações dos blocos de construção do sistema na forma de cenários das
seguintes áreas:

</div>

- casos de uso ou recursos importantes: como os blocos de construção os
  executam?

- interações em interfaces externas críticas: como os blocos de
  construção cooperam com os usuários e sistemas vizinhos?

- operação e administração: lançamento, inicialização, parada

- cenários de erro e exceção

Observação: O principal critério para a escolha de cenários possíveis
(sequências, fluxos de trabalho) é sua **relevância arquitetural**.
**Não** é importante descrever um grande número de cenários. Você deve
documentar uma seleção representativa.

<div class="formalpara">

<div class="title">

Motivação

</div>

Você deve entender como (instâncias de) blocos de construção do seu
sistema realizam seu trabalho e se comunicam em tempo de execução. Você
capturará principalmente cenários em sua documentação para comunicar sua
arquitetura às partes interessadas que estão menos dispostas ou capazes
de ler e entender os modelos estáticos (visão de bloco de construção,
visão de implantação).

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Há muitas notações para descrever cenários, por exemplo,

</div>

- lista numerada de etapas (em linguagem natural)

- diagramas de atividade ou fluxogramas

- diagramas de sequência

- BPMN ou EPCs (cadeias de processos de eventos)

- máquinas de estado

- …​

<div class="formalpara">

<div class="title">

Mais informações

</div>

Consulte [Runtime View](https://docs.arc42.org/section-6/) na
documentação do arc42.

</div>

</div>

## \<Cenário de Tempo de Execução 1\>

- *\<inserir diagrama de tempo de execução ou descrição textual do
  cenário\>*

- *\<inserir descrição dos aspectos notáveis ​​das interações entre as
  instâncias do bloco de construção descritas neste diagrama.\>*

## \<Cenário de Tempo de Execução 2\>

## …​

## \<Cenário de Tempo de Execução n\>
