# Visão de Tempo de Execução

## \<Cenário de Tempo de Execução 1>

-   *\<inserir diagrama de tempo de execução ou descrição textual do
    cenário>*

-   *\<inserir descrição dos aspectos notáveis ​​das interações entre as
    instâncias do bloco de construção descritas neste diagrama.>*

## \<Cenário de Tempo de Execução 2>

## …

## \<Cenário de Tempo de Execução n>
