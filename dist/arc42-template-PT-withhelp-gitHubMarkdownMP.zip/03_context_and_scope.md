# Contexto e Escopo

## Contexto Negocial

**\<Diagrama ou Tabela>**

**\<opcionalmente: Explicação das interfaces de domínio externo>**

## Contexto Técnico

**\<Diagrama ou Tabela>**

**\<opcionalmente: Explicação das interfaces técnicas>**

**\<Mapeamento de entrada/saída para canais>**
