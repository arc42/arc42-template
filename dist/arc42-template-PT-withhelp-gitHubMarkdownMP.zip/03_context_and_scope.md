# Contexto e Escopo

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Conteúdo

</div>

Contexto e escopo - como o nome sugere - delimita seu sistema (ou seja,
seu escopo) de todos os seus parceiros de comunicação (sistemas e
usuários vizinhos, ou seja, o contexto do seu sistema). Ele especifica,
portanto, as interfaces externas.

</div>

Se necessário, diferencie o contexto de negócios (entradas e saídas
específicas do domínio) do contexto técnico (canais, protocolos,
hardware).

<div class="formalpara">

<div class="title">

Motivação

</div>

As interfaces de domínio e as interfaces técnicas para componentes
externos estão entre os aspectos mais críticos do seu sistema.
Certifique-se de entendê-las completamente.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Várias opções:

</div>

- Diagramas de contexto

- Listas de componentes externos e suas interfaces.

<div class="formalpara">

<div class="title">

Mais informações

</div>

Consulte [Context and Scope](https://docs.arc42.org/section-3/) na
documentação do arc42.

</div>

</div>

## Contexto Negocial

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Conteúdo

</div>

Especificação de **todos** os componentes externos (usuários, sistemas
de TI, …​) com explicações de entradas e saídas ou interfaces específicas
do domínio. Opcionalmente, você pode adicionar formatos específicos do
domínio ou protocolos de comunicação.

</div>

<div class="formalpara">

<div class="title">

Motivação

</div>

Todas as partes interessadas devem entender quais dados são trocados com
o ambiente do sistema.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Todos os tipos de diagramas que mostram o sistema como uma caixa preta e
especificam as interfaces de domínio para os componentes externos.

</div>

Como alternativa (ou adicionalmente), você pode usar uma tabela. O
título da tabela é o nome do seu sistema, as três colunas contêm o nome
do componente externo, as entradas e as saídas.

</div>

**\<Diagrama ou Tabela\>**

**\<opcionalmente: Explicação das interfaces de domínio externo\>**

## Contexto Técnico

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Conteúdo

</div>

Interfaces técnicas (canais e mídias de transmissão) que vinculam seu
sistema ao seu ambiente. Além disso, um mapeamento de entrada/saída
específica de domínio para os canais, ou seja, uma explicação de qual
E/S usa qual canal.

</div>

<div class="formalpara">

<div class="title">

Motivação

</div>

Muitas partes interessadas tomam decisões arquiteturais com base nas
interfaces técnicas entre o sistema e seu contexto. Especialmente os
designers de infraestrutura ou hardware decidem essas interfaces
técnicas.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Por exemplo, diagrama de implantação UML descrevendo canais para
sistemas vizinhos, junto com uma tabela de mapeamento mostrando os
relacionamentos entre canais e entrada/saída.

</div>

</div>

**\<Diagrama ou Tabela\>**

**\<opcionalmente: Explicação das interfaces técnicas\>**

**\<Mapeamento de entrada/saída para canais\>**
