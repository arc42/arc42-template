# Visão de Blocos de Construção

## Visão Sistêmica Geral de Caixa Branca

***\<Diagrama de Visão Geral>***

Motivação  
*\<explicação textual>*

Blocos de Construção Contidos  
*\<Descrição dos blocos de construção contidos (caixas pretas)>*

Interfaces Importantes  
*\<Descrição de interfaces importantes>*

### \<Nome Caixa Preta 1>

*\<Propósito/Responsabilidade>*

*\<Interface(s)>*

*\<(Opcional) Características de Qualidade/Desempenho>*

*\<(Opcional) Local do Diretório/Arquivo>*

*\<(Opcional) Requisitos Cumpridos>*

*\<(opcional) Problemas/Riscos Abertos>*

### \<Nome Caixa Preta 2>

*\<modelo de caixa preta>*

### \<Nome Caixa Preta n>

*\<modelo de caixa preta>*

### \<Nome Interface 1>

…

### \<Nome Interface m>

## Nível 2

### Caixa Branca *\<Bloco de Construção 1>*

*\<modelo de caixa branca>*

### Caixa Branca *\<Bloco de Construção 2>*

*\<modelo de caixa branca>*

…

### Caixa Branca *\<Bloco de Construção m>*

*\<modelo de caixa branca>*

## Nível 3

### Caixa Branca \<\_Bloco de Construção x.1\_\>

*\<modelo de caixa branca>*

### Caixa Branca \<\_Bloco de Construção x.2\_\>

*\<modelo de caixa branca>*

### Caixa Branca \<\_Bloco de Construção y.1\_\>

*\<modelo de caixa branca>*
