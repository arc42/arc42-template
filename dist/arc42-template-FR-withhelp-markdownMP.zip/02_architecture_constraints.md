# Contraintes d'Architecture {#section-architecture-constraints}
