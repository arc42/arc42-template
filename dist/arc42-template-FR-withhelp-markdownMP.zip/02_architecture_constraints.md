# Constraintes d'Architecture {#section-architecture-constraints}

::: formalpara-title
**Contenu**
:::

Toute exigence qui limite la liberté des architectes logiciels dans
leurs décisions de conception et de mise en œuvre ou dans leurs
décisions concernant le processus de développement. Ces contraintes vont
parfois au-delà des systèmes individuels et sont valables pour
l'ensemble des organisations et des entreprises.

::: formalpara-title
**Motivation**
:::

Les architectes doivent savoir exactement où ils sont libres dans leurs
décisions de conception et où ils doivent respecter des contraintes. Les
contraintes doivent toujours être prises en compte ; elles peuvent
toutefois être négociables.

::: formalpara-title
**Représentation**
:::

Tableaux simples de contraintes avec explications. Si nécessaire, vous
pouvez les subdiviser en contraintes techniques, contraintes
organisationnelles, politiques et conventions (par exemple, règles de
développement ou de version, conventions de documentation ou de
dénomination).

Voir [Architecture Constraints](https://docs.arc42.org/section-2/) dans
la documentation arc42.
