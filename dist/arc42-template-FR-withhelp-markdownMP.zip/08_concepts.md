# Concepts transversaux {#section-concepts}

## *\<Concept 1>* {#__emphasis_concept_1_emphasis}

*\<explication>*

## *\<Concept 2>* {#__emphasis_concept_2_emphasis}

*\<explication>*

...

## *\<Concept n>* {#__emphasis_concept_n_emphasis}

*\<explication>*
