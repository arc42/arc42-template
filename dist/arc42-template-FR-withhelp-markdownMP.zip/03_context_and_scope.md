# Contexte et périmètre {#section-context-and-scope}

## Contexte métier {#_contexte_métier}

**\<Schéma ou tableau\>**

**\<éventuellement : Explication des interfaces de domaines externes\>**

## Contexte Technique {#_contexte_technique}

**\<Schéma ou tableau\>**

**\<en option : Explication des interfaces techniques\>**

**\<Correspondance des entrées/sorties aux canaux\>**
