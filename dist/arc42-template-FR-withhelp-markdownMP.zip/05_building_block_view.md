# Vue en Briques {#section-building-block-view}

## Niveau 1 : Système global Boîte blanche {#_niveau_1_système_global_boîte_blanche}

***\<Schéma d'ensemble\>***

Motivation

:   *\<texte explicatif\>*

Briques contenues

:   *\<Description de la brique contenue (boîte noire)\>*

Interfaces Importantes

:   *\<Description des interfaces importantes\>*

### \<Nom boîte noire 1\> {#_nom_boîte_noire_1}

*\<Objectif/Responsabilité\>*

*\<Interface(s)\>*

*\<(Facultatif) Caractéristiques de qualité/performance\>*

*\<(Facultatif) Emplacement du répertoire/fichier\>*

*\<(Facultatif) Exigences respectées\>*

*\<(Facultatif) Questions ouvertes/problèmes/risques\>*

### \<Nom boîte noire 2\> {#_nom_boîte_noire_2}

*\<template boîte noire\>*

### \<Nom boîte noire n\> {#_nom_boîte_noire_n}

*\<template boîte noire\>*

### \<Nom interface 1\> {#_nom_interface_1}

...​

### \<Nom interface m\> {#_nom_interface_m}

## Niveau 2 {#_niveau_2}

### Boîte blanche *\<brique 1\>* {#_boîte_blanche_brique_1}

*\<template boîte blanche\>*

### Boîte blanche *\<brique 2\>* {#_boîte_blanche_brique_2}

*\<template boîte blanche\>*

...​

### Boîte blanche *\<brique n\>* {#_boîte_blanche_brique_n}

*\<template boîte blanche\>*
