# Vue Exécution {#section-runtime-view}

::: formalpara-title
**Contenu**
:::

La vue d'exécution décrit le comportement concret et les interactions
des briques du système sous la forme de scénarios dans les domaines
suivants :

-   cas d'utilisation ou caractéristiques importants : comment les
    briques les exécutent-ils ?

-   interactions aux interfaces externes critiques : comment les briques
    coopèrent-ils avec les utilisateurs et les systèmes voisins ?

-   fonctionnement et administration : lancement, démarrage, arrêt

-   scénarios d'erreur et d'exception

Remarque : Le critère principal pour le choix des scénarios possibles
(séquences, flux de travail) est leur **pertinence architecturale**. Il
n'est **pas** important de décrire un grand nombre de scénarios. Vous
devez plutôt documenter une sélection représentative.

::: formalpara-title
**Motivation**
:::

Vous devez comprendre comment les (instances des) briques de votre
système effectuent leur travail et communiquent au moment de
l'exécution. Vous capturerez principalement des scénarios dans votre
documentation afin de communiquer votre architecture aux parties
prenantes qui sont moins disposées ou capables de lire et de comprendre
les modèles statiques (vue en briques, vue déploiement).

::: formalpara-title
**Représentation**
:::

Il existe de nombreuses notations pour décrire les scénarios, par
exemple

-   liste numérotée d\'étapes (en langage naturel)

-   diagrammes d'activités ou de flux

-   diagrammes de séquence

-   BPMN ou EPC (chaînes de processus d\'événements)

-   machines à états

-   ...

Voir [Runtime View](https://docs.arc42.org/section-6/) dans la
documentation arc42.

## \<Scénario d'exécution 1> {#__sc_nario_d_ex_cution_1}

-   *\<insérer un diagramme d'exécution ou une description textuelle du
    scénario>*

-   *\<insérer une description des aspects notables des interactions
    entre les instances des briques représentées dans ce diagramme.\>*

## \<Scénario d'exécution 2> {#__sc_nario_d_ex_cution_2}

## ... {#_}

## \<Scénario d'exécution n> {#__sc_nario_d_ex_cution_n}
