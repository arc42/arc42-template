# Risques et Dettes techniques {#section-technical-risks}

::: formalpara-title
**Contenu**
:::

Une liste des risques ou des dettes techniques identifiés, classés par
ordre de priorité

::: formalpara-title
**Motivation**
:::

"Risk management is project management for grown-ups" (Tim Lister,
Atlantic Systems Guild.)

C'est la devise pour la détection et l\'évaluation systématiques des
risques et des dettes techniques dans l'architecture, dont auront besoin
les acteurs de la gestion de projet (par exemple, les chefs de projet,
les propriétaires de produits) dans le cadre de l'analyse globale des
risques et de la planification de la mesure.

::: formalpara-title
**Représentation**
:::

Liste des risques et/ou des dettes techniques, comprenant probablement
des mesures suggérées pour minimiser, atténuer ou éviter les risques ou
réduire les dettes techniques.

Voir [Risks and Technical Debt](https://docs.arc42.org/section-11/) dans
la documentation arc42.
