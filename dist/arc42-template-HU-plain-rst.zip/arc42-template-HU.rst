==============
|arc42| Sablon
==============

:Date: 2026. május

**Az arc42-ről**

arc42, a szoftver- és rendszerarchitektúra dokumentálásának sablonja.

Sablonverzió 9.0-HU. (az AsciiDoc verzió alapján), 2026. május

Készítették és karbantartják Dr. Peter Hruschka, Dr. Gernot Starke és a
közreműködők (©). Lásd https://arc42.org.

.. _section-introduction-and-goals:

Bevezetés és célok
==================

.. _`_követelmények_áttekintése`:

Követelmények áttekintése
-------------------------

.. _`_minőségi_célok`:

Minőségi célok
--------------

.. _`_érdekelt_felek`:

Érdekelt felek
--------------

+-------------+---------------------------+---------------------------+
| Sz          | Elérhetőség               | Elvárások                 |
| erepkör/Név |                           |                           |
+=============+===========================+===========================+
| *<Sz        | *<Elérhetőség-1>*         | *<Elvárás-1>*             |
| erepkör-1>* |                           |                           |
+-------------+---------------------------+---------------------------+
| *<Sz        | *<Elérhetőség-2>*         | *<Elvárás-2>*             |
| erepkör-2>* |                           |                           |
+-------------+---------------------------+---------------------------+

.. _section-architecture-constraints:

Architekturális megkötések
==========================

.. _section-context-and-scope:

Kontextus és hatókör
====================

.. _`_üzleti_kontextus`:

Üzleti kontextus
----------------

**<Diagram vagy táblázat>**

**<opcionális: Külső szakterületi interfészek magyarázata>**

.. _`_technikai_kontextus`:

Technikai kontextus
-------------------

**<Diagram vagy táblázat>**

**<opcionális: Technikai interfészek magyarázata>**

**<Bemenet/kimenet leképezése csatornákra>**

.. _section-solution-strategy:

Megoldási stratégia
===================

.. _section-building-block-view:

Építőelem-nézet
===============

.. _`_fehér_doboz_teljes_rendszer`:

Fehér doboz Teljes rendszer
---------------------------

**<Áttekintő diagram>**

Motiváció
   *<szöveges magyarázat>*

Tartalmazott építőelemek
   *<A tartalmazott építőelemek (fekete dobozok) leírása>*

Fontos interfészek
   *<Fontos interfészek leírása>*

.. _`_fekete_doboz_1_neve`:

<Fekete doboz 1 neve>
~~~~~~~~~~~~~~~~~~~~~

*<Cél/Felelősség>*

*<Interfész(ek)>*

*<(Opcionális) Minőségi/Teljesítményjellemzők>*

*<(Opcionális) Könyvtár/Fájl elérési út>*

*<(Opcionális) Teljesített követelmények>*

*<(Opcionális) Nyitott kérdések/Problémák/Kockázatok>*

.. _`_fekete_doboz_2_neve`:

<Fekete doboz 2 neve>
~~~~~~~~~~~~~~~~~~~~~

*<fekete doboz sablon>*

.. _`_fekete_doboz_n_neve`:

<Fekete doboz n neve>
~~~~~~~~~~~~~~~~~~~~~

*<fekete doboz sablon>*

.. _`_interfész_1_neve`:

<Interfész 1 neve>
~~~~~~~~~~~~~~~~~~

…​

.. _`_interfész_m_neve`:

<Interfész m neve>
~~~~~~~~~~~~~~~~~~

.. _`_2_szint`:

2. szint
--------

.. _`_fehér_doboz_1_építőelem`:

Fehér doboz *<1. építőelem>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<fehér doboz sablon>*

.. _`_fehér_doboz_2_építőelem`:

Fehér doboz *<2. építőelem>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<fehér doboz sablon>*

…​

.. _`_fehér_doboz_m_építőelem`:

Fehér doboz *<m. építőelem>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<fehér doboz sablon>*

.. _`_3_szint`:

3. szint
--------

.. _`_fehér_doboz_x_1_építőelem`:

Fehér doboz <\_x.1 építőelem\_>
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<fehér doboz sablon>*

.. _`_fehér_doboz_x_2_építőelem`:

Fehér doboz <\_x.2 építőelem\_>
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<fehér doboz sablon>*

.. _`_fehér_doboz_y_1_építőelem`:

Fehér doboz <\_y.1 építőelem\_>
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<fehér doboz sablon>*

.. _section-runtime-view:

Futásidejű nézet
================

.. _`_futásidejű_forgatókönyv_1`:

<Futásidejű forgatókönyv 1>
---------------------------

-  *<illesszen be futásidejű diagramot vagy a forgatókönyv szöveges
   leírását>*

-  *<illesszen be leírást az ábrázolt építőelem-példányok közötti
   interakciók figyelemre méltó aspektusairól.>*

.. _`_futásidejű_forgatókönyv_2`:

<Futásidejű forgatókönyv 2>
---------------------------

…​
-

.. _`_futásidejű_forgatókönyv_n`:

<Futásidejű forgatókönyv n>
---------------------------

.. _section-deployment-view:

Telepítési nézet
================

.. _`_1_infrastruktúra_szint`:

1. infrastruktúra-szint
-----------------------

**<Áttekintő diagram>**

Motiváció
   *<szöveges magyarázat>*

Minőségi és/vagy teljesítményjellemzők
   *<szöveges magyarázat>*

Építőelemek leképezése az infrastruktúrára
   *<a leképezés leírása>*

.. _`_2_infrastruktúra_szint`:

2. infrastruktúra-szint
-----------------------

.. _`_1_infrastruktúra_elem`:

*<1. infrastruktúra-elem>*
~~~~~~~~~~~~~~~~~~~~~~~~~~

*<diagram + magyarázat>*

.. _`_2_infrastruktúra_elem`:

*<2. infrastruktúra-elem>*
~~~~~~~~~~~~~~~~~~~~~~~~~~

*<diagram + magyarázat>*

…​

.. _`_n_infrastruktúra_elem`:

*<n. infrastruktúra-elem>*
~~~~~~~~~~~~~~~~~~~~~~~~~~

*<diagram + magyarázat>*

.. _section-concepts:

Keresztmetszeti koncepciók
==========================

.. _`_1_koncepció`:

*<1. koncepció>*
----------------

*<magyarázat>*

.. _`_2_koncepció`:

*<2. koncepció>*
----------------

*<magyarázat>*

…​

.. _`_n_koncepció`:

*<n. koncepció>*
----------------

*<magyarázat>*

.. _section-design-decisions:

Architektúra-döntések
=====================

.. _section-quality-scenarios:

Minőségi követelmények
======================

.. _`_minőségi_követelmények_áttekintése`:

Minőségi követelmények áttekintése
----------------------------------

.. _`_minőségi_forgatókönyvek`:

Minőségi forgatókönyvek
-----------------------

.. _section-technical-risks:

Kockázatok és technikai adósságok
=================================

.. _section-glossary:

Szójegyzék
==========

+----------------------+-----------------------------------------------+
| Kifejezés            | Meghatározás                                  |
+======================+===============================================+
| *<Kifejezés-1>*      | *<meghatározás-1>*                            |
+----------------------+-----------------------------------------------+
| *<Kifejezés-2>*      | *<meghatározás-2>*                            |
+----------------------+-----------------------------------------------+

.. |arc42| image:: images/arc42-logo.png
