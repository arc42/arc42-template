# 架构约束 {#section-architecture-constraints}

  [架构约束]: #section-architecture-constraints {#toc-section-architecture-constraints}
