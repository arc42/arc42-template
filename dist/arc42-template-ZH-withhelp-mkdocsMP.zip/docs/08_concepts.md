# 跨领域概念 {#section-concepts}

## *&lt;概念 1&gt;* {#_概念_1}

*&lt;解释&gt;*

## *&lt;概念 2&gt;* {#_概念_2}

*&lt;解释&gt;*

…​

## *&lt;概念 n&gt;* {#_概念_n}

*&lt;解释&gt;*

  [跨领域概念]: #section-concepts {#toc-section-concepts}
  [*&lt;概念 1&gt;*]: #_概念_1 {#toc-_概念_1}
  [*&lt;概念 2&gt;*]: #_概念_2 {#toc-_概念_2}
  [*&lt;概念 n&gt;*]: #_概念_n {#toc-_概念_n}
