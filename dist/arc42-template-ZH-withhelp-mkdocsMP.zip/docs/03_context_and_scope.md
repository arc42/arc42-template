# 上下文和边界 {#section-context-and-scope}

## 业务上下文 {#_业务上下文}

**&lt;图表或表格&gt;**

**&lt;可选：外部领域接口的解释&gt;**

## 技术上下文 {#_技术上下文}

**&lt;图表或表格&gt;**

**&lt;可选：技术接口的解释&gt;**

**&lt;输入、输出与信道之间的映射关系&gt;**

  [上下文和边界]: #section-context-and-scope {#toc-section-context-and-scope}
  [业务上下文]: #_业务上下文 {#toc-_业务上下文}
  [技术上下文]: #_技术上下文 {#toc-_技术上下文}
