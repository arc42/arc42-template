**关于 arc42**

arc42，软件和系统架构文档模板。

模板版本 9.0-ZH。(基于 AsciiDoc 版本)，7月 2025

由 Dr. Peter Hruschka、Dr. Gernot Starke 及贡献者创建、维护和版权所有。 参见 <https://arc42.org>.


0. [运行时视图](06_runtime_view.md)

0. [构建块视图](05_building_block_view.md)

0. [引言与目标](01_introduction_and_goals.md)

0. [部署视图](07_deployment_view.md)

0. [架构约束](02_architecture_constraints.md)

0. [风险和技术债务](11_technical_risks.md)

0. [跨领域概念](08_concepts.md)

0. [架构决策](09_architecture_decisions.md)

0. [术语表](12_glossary.md)

0. [质量需求](10_quality_requirements.md)

0. [上下文和边界](03_context_and_scope.md)

0. [解决方案策略](04_solution_strategy.md)
