# 术语表 {#section-glossary}

| 术语           | 英文           | 定义           |
|----------------|----------------|----------------|
| &lt;术语-1&gt; | &lt;英文-1&gt; | &lt;定义-1&gt; |
| &lt;术语-2&gt; | &lt;英文-2&gt; | &lt;定义-2&gt; |

  [术语表]: #section-glossary {#toc-section-glossary}
