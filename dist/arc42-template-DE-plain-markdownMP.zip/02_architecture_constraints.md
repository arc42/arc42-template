Randbedingungen {#section-architecture-constraints}
===============
