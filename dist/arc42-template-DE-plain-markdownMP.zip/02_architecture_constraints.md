Randbedingungen {#section-architecture-constraints}
===============
