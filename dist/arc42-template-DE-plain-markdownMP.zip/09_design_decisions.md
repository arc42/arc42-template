Entwurfsentscheidungen {#section-design-decisions}
======================
