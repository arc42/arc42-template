Querschnittliche Konzepte {#section-concepts}
=========================

*&lt;Konzept 1&gt;* {#__emphasis_konzept_1_emphasis}
-------------------

*&lt;Erklärung&gt;*

*&lt;Konzept 2&gt;* {#__emphasis_konzept_2_emphasis}
-------------------

*&lt;Erklärung&gt;*

…

*&lt;Konzept n&gt;* {#__emphasis_konzept_n_emphasis}
-------------------

*&lt;Erklärung&gt;*
