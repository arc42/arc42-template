Querschnittliche Konzepte {#section-concepts}
=========================

*\<Konzept 1\>* {#_konzept_1}
---------------

*\<Erklärung\>*

*\<Konzept 2\>* {#_konzept_2}
---------------

*\<Erklärung\>*

...​

*\<Konzept n\>* {#_konzept_n}
---------------

*\<Erklärung\>*
