Lösungsstrategie {#section-solution-strategy}
================
