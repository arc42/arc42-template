Lösungsstrategie {#section-solution-strategy}
================
