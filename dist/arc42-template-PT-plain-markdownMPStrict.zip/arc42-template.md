# 

**Sobre o arc42**

arc42, o template para documentação de software e arquitetura de
sistemas.

Versão do template 8.2 PT. (baseado na versão AsciiDoc), Setembro de
2024

Criado, mantido e © pelo Dr. Peter Hruschka, Dr. Gernot Starke e
colaboradores. Veja <https://arc42.org>.

# Introdução e Objetivos

## Visão Geral dos Requisitos

## Objetivos de Qualidade

## Partes Interessadas

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Função/Nome</th>
<th style="text-align: left;">Contato</th>
<th style="text-align: left;">Expectativas</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Função-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Contato-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Expectativa-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Função-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Contato-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Expectativa-2&gt;</em></p></td>
</tr>
</tbody>
</table>

# Restrições Arquiteturais

# Contexto e Escopo

## Contexto Negocial

**&lt;Diagrama ou Tabela>**

**&lt;opcionalmente: Explicação das interfaces de domínio externo>**

## Contexto Técnico

**&lt;Diagrama ou Tabela>**

**&lt;opcionalmente: Explicação das interfaces técnicas>**

**&lt;Mapeamento de entrada/saída para canais>**

# Estratégia de Solução

# Visão de Blocos de Construção

## Visão Sistêmica Geral de Caixa Branca

***&lt;Diagrama de Visão Geral>***

Motivação  
*&lt;explicação textual>*

Blocos de Construção Contidos  
*&lt;Descrição dos blocos de construção contidos (caixas pretas)>*

Interfaces Importantes  
*&lt;Descrição de interfaces importantes>*

### &lt;Nome Caixa Preta 1>

*&lt;Propósito/Responsabilidade>*

*&lt;Interface(s)>*

*&lt;(Opcional) Características de Qualidade/Desempenho>*

*&lt;(Opcional) Local do Diretório/Arquivo>*

*&lt;(Opcional) Requisitos Cumpridos>*

*&lt;(opcional) Problemas/Riscos Abertos>*

### &lt;Nome Caixa Preta 2>

*&lt;modelo de caixa preta>*

### &lt;Nome Caixa Preta n>

*&lt;modelo de caixa preta>*

### &lt;Nome Interface 1>

…

### &lt;Nome Interface m>

## Nível 2

### Caixa Branca *&lt;Bloco de Construção 1>*

*&lt;modelo de caixa branca>*

### Caixa Branca *&lt;Bloco de Construção 2>*

*&lt;modelo de caixa branca>*

…

### Caixa Branca *&lt;Bloco de Construção m>*

*&lt;modelo de caixa branca>*

## Nível 3

### Caixa Branca &lt;\_Bloco de Construção x.1\_&gt;

*&lt;modelo de caixa branca>*

### Caixa Branca &lt;\_Bloco de Construção x.2\_&gt;

*&lt;modelo de caixa branca>*

### Caixa Branca &lt;\_Bloco de Construção y.1\_&gt;

*&lt;modelo de caixa branca>*

# Visão de Tempo de Execução

## &lt;Cenário de Tempo de Execução 1>

-   *&lt;inserir diagrama de tempo de execução ou descrição textual do
    cenário>*

-   *&lt;inserir descrição dos aspectos notáveis ​​das interações entre
    as instâncias do bloco de construção descritas neste diagrama.>*

## &lt;Cenário de Tempo de Execução 2>

## …

## &lt;Cenário de Tempo de Execução n>

# Visão de Implantação

## Nível de Infraestrutura 1

***&lt;Diagrama de Visão Geral>***

Motivação  
*&lt;explicação em forma de texto>*

Características de Qualidade e/ou Desempenho  
*&lt;explicação em forma de texto>*

Mapeamento de Blocos de Construção para Infraestrutura  
*&lt;descrição do mapeamento>*

## Nível de Infraestrutura 2

### *&lt;Elemento de Infraestrutura 1>*

*&lt;diagrama + explicação>*

### *&lt;Elemento de Infraestrutura 2>*

*&lt;diagrama + explicação>*

…

### *&lt;Elemento de Infraestrutura n>*

*&lt;diagrama + explicação>*

# Conceitos Transversais

## *&lt;Conceito 1>*

*&lt;explicação>*

## *&lt;Conceito 2>*

*&lt;explicação>*

…

## *&lt;Conceito n>*

*&lt;explicação>*

# Decisões Arquiteturais

# Requisitos de qualidade

## Árvore de qualidade

## Cenários de Qualidade

# Riscos e Débitos Técnicos

# Glossário

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Termo</th>
<th style="text-align: left;">Definição</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Termo-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definição-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Termo-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definição-2&gt;</em></p></td>
</tr>
</tbody>
</table>
