# Glossário

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Termo</th>
<th style="text-align: left;">Definição</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Termo-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definição-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Termo-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definição-2&gt;</em></p></td>
</tr>
</tbody>
</table>
