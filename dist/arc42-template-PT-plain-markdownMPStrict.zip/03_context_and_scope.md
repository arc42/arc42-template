# Contexto e Escopo

## Contexto Negocial

**&lt;Diagrama ou Tabela>**

**&lt;opcionalmente: Explicação das interfaces de domínio externo>**

## Contexto Técnico

**&lt;Diagrama ou Tabela>**

**&lt;opcionalmente: Explicação das interfaces técnicas>**

**&lt;Mapeamento de entrada/saída para canais>**
