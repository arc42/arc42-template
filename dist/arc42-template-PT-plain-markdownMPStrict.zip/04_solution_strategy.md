# Estratégia de Solução
