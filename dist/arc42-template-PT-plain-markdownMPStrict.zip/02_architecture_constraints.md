# Restrições Arquiteturais
