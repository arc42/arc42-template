---
date: March 2023
title: "![arc42](images/arc42-logo.png) Template"
---

# 

**About arc42**

arc42, the Template for documentation of software and system
architecture.

By Dr. Gernot Starke, Dr. Peter Hruschka and contributors.

Template Revision: 7.0 IT (based on asciidoc), April 2021

© We acknowledge that this document uses material from the arc 42
architecture template, <https://www.arc42.org>. Created by Dr. Peter
Hruschka & Dr. Gernot Starke.

# Introduzione e obiettivi

## Panoramica dei requisiti

## Obiettivi di qualità

## Stakeholders

| Rouolo/Nome   | Contatto         | Aspettative          |
|---------------|------------------|----------------------|
| *\<Ruolo-1\>* | *\<Contatto-1\>* | *\<Aspettatiive-1\>* |
| *\<Ruolo-2\>* | *\<Contatto-2\>* | *\<Aspettatiive-2\>* |

# Vincoli di architettura

# Ambito e contesto del sistema

## Contesto di Business

**\<Diagramma o Tabella\>**

**\<opzionale: spiegazione delle interfacce del dominio esterno\>**

## Contesto Tecnico

**\<Diagramma o Tabella\>**

**\<opzionale: Spiegazione delle interfacce tecniche\>**

**\<Mappatura Input/Output sui canali di comunicazione\>**

# Strategia della soluzione

# Building Block View

## Whitebox Overall System

***\<Overview Diagram\>***

Motivazione  
*\<spiegazione testuale\>*

Contenuto dei Building Blocks  
*\<Descrizione del contenuto del building block (black boxes)\>*

Important Interfaces  
*\<Descrizione delle interfacce importanti\>*

### \<Nome black box 1\>

*\<Scopo/responsabilità\>*

*\<Interfacce\>*

*\<(Facoltativo) Caratteristiche di qualità/prestazionali\>*

*\<(Facoltativo) percorso file/directory\>*

*\<(Facoltativo) Requisiti soddisfatti\>*

*\<(Facoltativo) Bug noti/Rischi/problemi\>*

### \<Nome black box 2\>

*\<black box template\>*

### \<Nome black box n\>

*\<black box template\>*

### \<Nome interface 1\>

…​

### \<Nome interface m\>

## Livello 2

### White Box *\<building block 1\>*

*\<white box template\>*

### White Box *\<building block 2\>*

*\<white box template\>*

…​

### White Box *\<building block m\>*

*\<white box template\>*

## Livello 3

### White Box \<\_building block x.1\_\>

*\<white box template\>*

### White Box \<\_building block x.2\_\>

*\<white box template\>*

### White Box \<\_building block y.1\_\>

*\<white box template\>*

# Runtime View

## \<Runtime Scenario 1\>

- *\<inserire un runtime diagram o una descrizione testuale dello
  scenario\>*

- *\<inserire la descrizione degli aspetti degni di nota delle
  interazioni tra i istanze di building block illustrate in questo
  diagramma.\>*

## \<Runtime Scenario 2\>

## …​

## \<Runtime Scenario n\>

# Deployment View

## Livello infrastruttura 1

***\<Overview Diagram\>***

Motivatione  
*\<spiegazione in forma di testo\>*

Requsiti di qualità e/o di prestazioni  
*\<spiegazione in forma di testo\>*

Mappatura dei Building Blocks nella Architettura  
*\<descrizione della mappatura\>*

## Livello infrastruttura 2

### *\<Elemento infrastruttura 1\>*

*\<diagramma + spiegazione\>*

### *\<Elemento infrastruttura 2\>*

*\<diagramma + spiegazione\>*

…​

### *\<Elemento infrastruttura n\>*

*\<diagramma + spiegazione\>*

# Concetti trasversali

## *\<Concetto 1\>*

*\<spiegazione\>*

## *\<Concetto 2\>*

*\<spiegazione\>*

…​

## *\<Concetto n\>*

*\<spiegazione\>*

# Decisioni di progettazione

# Requisiti di Qualità

## Albero di qualità

## Scenari di qualità

# Rischi e debiti tecnici

# Glossario

| Termine         | Definizione         |
|-----------------|---------------------|
| *\<Termine-1\>* | *\<definizione-1\>* |
| *\<Termine-2\>* | *\<definizione-2\>* |
