# Deployment View

## Infrastructuur Niveau 1

***\<Overzichts Diagram\>***

Motivatie  
*\<uitleg in tekstuele vorm\>*

Kwaliteit en/of Performance Eigenschappen  
*\<uitleg in tekstuele vorm\>*

Mapping van Bouwstenen naar Infrastructuur  
*\<beschrijving van de mapping\>*

## Infrastructuur Niveau 2

### *\<Infrastructuur Element 1\>*

*\<diagram + uitleg\>*

### *\<Infrastructuur Element 2\>*

*\<diagram + uitleg\>*

…

### *\<Infrastructuur Element n\>*

*\<diagram + uitleg\>*
