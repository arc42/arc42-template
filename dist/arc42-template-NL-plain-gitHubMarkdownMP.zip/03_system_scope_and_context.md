# Systeem Scope en Context

## Business Context

**\<Diagram of Tabel\>**

**\<optioneel: Uitleg van de externe domein interfaces\>**

## Technische Context

**\<Diagram of Tabel\>**

**\<optioneel: Uitleg van technische interfaces\>**

**\<Mapping Input/Output naar kanalen\>**
