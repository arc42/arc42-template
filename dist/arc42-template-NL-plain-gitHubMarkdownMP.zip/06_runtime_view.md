# Runtime View

## \<Runtime Scenario 1>

-   *\<voeg een runtime diagram of een tekstuele beschrijving van het
    scenario toe>*

-   *\<voeg een beschrijving toe van bijzondere aspecten van de
    interactie tussen de instanties van de bouwstenen die in dit diagram
    worden weergegeven>*

## \<Runtime Scenario 2>

## …

## \<Runtime Scenario n>
