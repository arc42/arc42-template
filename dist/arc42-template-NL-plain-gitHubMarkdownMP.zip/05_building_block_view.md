# Bouwstenen View

## Gehele whitebox Systeem

***\<Overzichts Diagram\>***

Motivatie  
*\<tekstuele uitleg\>*

Ingesloten bouwstenen  
*\<Beschrijving van ingesloten bouwstenen (*black boxes*)\>*

Belangrijke Interfaces  
*\<Beschrijving van belangrijke interfaces\>*

### \<Naam black box 1\>

*\<Doel/Verantwoordelijkheid\>*

*\<Interface(s)\>*

*\<((Optioneel) Kwaliteits-/Prestatie karakteristieken\>*

*\<(Optioneel) directories/bestand locaties\>*

*\<(Optioneel) Vervulde requirements\>*

*\<(Optioneel) Open issues/problemen/risico’s\>*

## \<Naam black box 2\>

*\<black box template\>*

### \<Naam black box n\>

*\<black box template\>*

### \<Naam interface 1\>

…

### \<Naam interface m\>

## Niveau 2

### White Box *\<bouwsteen 1\>*

*\<white box template\>*

### White Box *\<bouwsteen 2\>*

*\<white box template\>*

…

### White Box *\<bouwsteen m\>*

*\<white box template\>*

## Niveau 3

### White Box *\<bouwsteen x.1\>*

*\<white box template\>*

### White Box *\<bouwsteen x.2\>*

*\<white box template\>*

### White Box *\<bouwsteen y.1\>*

*\<white box template\>*
