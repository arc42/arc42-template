# Cross-cutting Concepten

## *\<Concept 1\>*

*\<uitleg\>*

## *\<Concept 2\>*

*\<uitleg\>*

…

## *\<Concept n\>*

*\<uitleg\>*
