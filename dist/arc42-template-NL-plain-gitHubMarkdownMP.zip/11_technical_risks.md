# Risico’s en Technical Debt
