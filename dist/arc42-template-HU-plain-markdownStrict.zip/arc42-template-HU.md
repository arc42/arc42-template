# 

**Az arc42-ről**

arc42, a szoftver- és rendszerarchitektúra dokumentálásának sablonja.

Sablonverzió 9.0-HU. (az AsciiDoc verzió alapján), 2026. május

Készítették és karbantartják Dr. Peter Hruschka, Dr. Gernot Starke és a
közreműködők (©). Lásd <https://arc42.org>.

# Bevezetés és célok

## Követelmények áttekintése

## Minőségi célok

## Érdekelt felek

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Szerepkör/Név</th>
<th style="text-align: left;">Elérhetőség</th>
<th style="text-align: left;">Elvárások</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Szerepkör-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Elérhetőség-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Elvárás-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Szerepkör-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Elérhetőség-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Elvárás-2&gt;</em></p></td>
</tr>
</tbody>
</table>

# Architekturális megkötések

# Kontextus és hatókör

## Üzleti kontextus

**&lt;Diagram vagy táblázat&gt;**

**&lt;opcionális: Külső szakterületi interfészek magyarázata&gt;**

## Technikai kontextus

**&lt;Diagram vagy táblázat&gt;**

**&lt;opcionális: Technikai interfészek magyarázata&gt;**

**&lt;Bemenet/kimenet leképezése csatornákra&gt;**

# Megoldási stratégia

# Építőelem-nézet

## Fehér doboz Teljes rendszer

***&lt;Áttekintő diagram&gt;***

Motiváció  
*&lt;szöveges magyarázat&gt;*

Tartalmazott építőelemek  
*&lt;A tartalmazott építőelemek (fekete dobozok) leírása&gt;*

Fontos interfészek  
*&lt;Fontos interfészek leírása&gt;*

### &lt;Fekete doboz 1 neve&gt;

*&lt;Cél/Felelősség&gt;*

*&lt;Interfész(ek)&gt;*

*&lt;(Opcionális) Minőségi/Teljesítményjellemzők&gt;*

*&lt;(Opcionális) Könyvtár/Fájl elérési út&gt;*

*&lt;(Opcionális) Teljesített követelmények&gt;*

*&lt;(Opcionális) Nyitott kérdések/Problémák/Kockázatok&gt;*

### &lt;Fekete doboz 2 neve&gt;

*&lt;fekete doboz sablon&gt;*

### &lt;Fekete doboz n neve&gt;

*&lt;fekete doboz sablon&gt;*

### &lt;Interfész 1 neve&gt;

…​

### &lt;Interfész m neve&gt;

## 2. szint

### Fehér doboz *&lt;1. építőelem&gt;*

*&lt;fehér doboz sablon&gt;*

### Fehér doboz *&lt;2. építőelem&gt;*

*&lt;fehér doboz sablon&gt;*

…​

### Fehér doboz *&lt;m. építőelem&gt;*

*&lt;fehér doboz sablon&gt;*

## 3. szint

### Fehér doboz &lt;\_x.1 építőelem\_&gt;

*&lt;fehér doboz sablon&gt;*

### Fehér doboz &lt;\_x.2 építőelem\_&gt;

*&lt;fehér doboz sablon&gt;*

### Fehér doboz &lt;\_y.1 építőelem\_&gt;

*&lt;fehér doboz sablon&gt;*

# Futásidejű nézet

## &lt;Futásidejű forgatókönyv 1&gt;

-   *&lt;illesszen be futásidejű diagramot vagy a forgatókönyv szöveges
    leírását&gt;*

-   *&lt;illesszen be leírást az ábrázolt építőelem-példányok közötti
    interakciók figyelemre méltó aspektusairól.&gt;*

## &lt;Futásidejű forgatókönyv 2&gt;

## …​

## &lt;Futásidejű forgatókönyv n&gt;

# Telepítési nézet

## 1. infrastruktúra-szint

***&lt;Áttekintő diagram&gt;***

Motiváció  
*&lt;szöveges magyarázat&gt;*

Minőségi és/vagy teljesítményjellemzők  
*&lt;szöveges magyarázat&gt;*

Építőelemek leképezése az infrastruktúrára  
*&lt;a leképezés leírása&gt;*

## 2. infrastruktúra-szint

### *&lt;1. infrastruktúra-elem&gt;*

*&lt;diagram + magyarázat&gt;*

### *&lt;2. infrastruktúra-elem&gt;*

*&lt;diagram + magyarázat&gt;*

…​

### *&lt;n. infrastruktúra-elem&gt;*

*&lt;diagram + magyarázat&gt;*

# Keresztmetszeti koncepciók

## *&lt;1. koncepció&gt;*

*&lt;magyarázat&gt;*

## *&lt;2. koncepció&gt;*

*&lt;magyarázat&gt;*

…​

## *&lt;n. koncepció&gt;*

*&lt;magyarázat&gt;*

# Architektúra-döntések

# Minőségi követelmények

## Minőségi követelmények áttekintése

## Minőségi forgatókönyvek

# Kockázatok és technikai adósságok

# Szójegyzék

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Kifejezés</th>
<th style="text-align: left;">Meghatározás</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Kifejezés-1&gt;</em></p></td>
<td
style="text-align: left;"><p><em>&lt;meghatározás-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Kifejezés-2&gt;</em></p></td>
<td
style="text-align: left;"><p><em>&lt;meghatározás-2&gt;</em></p></td>
</tr>
</tbody>
</table>
