**O arc42**

arc42, šablona pro dokumentaci softwaru a architekturu systému.

Verze šablony {revnumber}. {revremark}, {revdate}

Created, maintained and © by Dr. Peter Hruschka, Dr. Gernot Starke and
contributors. Viz <https://arc42.org>.
