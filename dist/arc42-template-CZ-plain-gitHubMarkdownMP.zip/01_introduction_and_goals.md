# Úvod a cíle

## Přehled požadavků

## Kvalitativní cíle

## Strany zainteresované na systému (Stakeholder)

| Role/Jméno  | Kontakt        | Očekávání        |
|-------------|----------------|------------------|
| *\<Role-1>* | *\<Kontakt-1>* | *\<Očekávání-1>* |
| *\<Role-2>* | *\<Kontakt-2>* | *\<Očekávání-2>* |
