# Perspektiva chování za běhu (runtime)

## \<Scénář runtime 1>

-   *\<vložte runtime diagram nebo textový popis scénáře>*

-   *\<vložte popis důležitých interakcí mezi instancemi stavebních
    bloků zobrazených v tomto diagramu>*

## \<Scénář runtime 2>

## …

## \<Scénář runtime n>
