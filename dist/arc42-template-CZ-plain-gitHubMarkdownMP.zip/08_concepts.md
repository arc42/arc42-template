# Průřezové (cross-cutting) koncepty

## *\<Koncept 1\>*

*\<vysvětlení\>*

## *\<Koncept 2\>*

*\<vysvětlení\>*

…

## *\<Koncept n\>*

*\<vysvětlení\>*
