# Perspektiva nasazení softwaru (deployment)

## Úroveň infrastruktury 1

***\<Přehledový diagram\>***

Motivace  
*\<vysvětlení v textové podobě\>*

Kvalitativní a/nebo výkonnostní vlastnosti  
*\<vysvětlení v textové podobě\>*

Mapování softwarových artefaktů na prvky infrastruktury  
*\<popis mapování\>*

## Úroveň infrastruktury 2

### *\<prvek infrastruktury 1\>*

*\<diagram + vysvětlení\>*

### *\<prvek infrastruktury 2\>*

*\<diagram + vysvětlení\>*

…

### *\<prvek infrastruktury n\>*

*\<diagram + vysvětlení\>*
