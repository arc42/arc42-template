# Rozhodnutí o architektuře
