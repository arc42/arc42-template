---
hide:
   - navigation
---

# Arc42 Template


**Über arc42**

arc42, das Template zur Dokumentation von Software- und Systemarchitekturen.

Template Version 9.0-DE. (basiert auf der AsciiDoc Version), Juli 2025

Created, maintained and © by Dr. Peter Hruschka, Dr. Gernot Starke and contributors. Siehe <https://arc42.org>.

## Einführung und Ziele {#section-introduction-and-goals}

### Aufgabenstellung {#_aufgabenstellung}

### Qualitätsziele {#_qualitätsziele}

### Stakeholder {#_stakeholder}

 Rolle             | Kontakt             | Erwartungshaltung     |
-------------------|---------------------|-----------------------|
 *&lt;Rolle-1&gt;* | *&lt;Kontakt-1&gt;* | *&lt;Erwartung-1&gt;* |
 *&lt;Rolle-2&gt;* | *&lt;Kontakt-2&gt;* | *&lt;Erwartung-2&gt;* |

## Randbedingungen {#section-architecture-constraints}

## Kontextabgrenzung {#section-context-and-scope}

### Fachlicher Kontext {#_fachlicher_kontext}

**&lt;Diagramm und/oder Tabelle&gt;**

**&lt;optional: Erläuterung der externen fachlichen Schnittstellen&gt;**

### Technischer Kontext {#_technischer_kontext}

**&lt;Diagramm oder Tabelle&gt;**

**&lt;optional: Erläuterung der externen technischen Schnittstellen&gt;**

**&lt;Mapping fachliche auf technische Schnittstellen&gt;**

## Lösungsstrategie {#section-solution-strategy}

## Bausteinsicht {#section-building-block-view}

### Whitebox Gesamtsystem {#_whitebox_gesamtsystem}

***&lt;Übersichtsdiagramm&gt;***

Begründung

:   *&lt;Erläuternder Text&gt;*

Enthaltene Bausteine

:   *&lt;Beschreibung der enthaltenen Bausteine (Blackboxen)&gt;*

Wichtige Schnittstellen

:   *&lt;Beschreibung wichtiger Schnittstellen&gt;*

#### &lt;Name Blackbox 1&gt; {#_name_blackbox_1}

*&lt;Zweck/Verantwortung&gt;*

*&lt;Schnittstelle(n)&gt;*

*&lt;(Optional) Qualitäts-/Leistungsmerkmale&gt;*

*&lt;(Optional) Ablageort/Datei(en)&gt;*

*&lt;(Optional) Erfüllte Anforderungen&gt;*

*&lt;(optional) Offene Punkte/Probleme/Risiken&gt;*

#### &lt;Name Blackbox 2&gt; {#_name_blackbox_2}

*&lt;Blackbox-Template&gt;*

#### &lt;Name Blackbox n&gt; {#_name_blackbox_n}

*&lt;Blackbox-Template&gt;*

#### &lt;Name Schnittstelle 1&gt; {#_name_schnittstelle_1}

…​

#### &lt;Name Schnittstelle m&gt; {#_name_schnittstelle_m}

### Ebene 2 {#_ebene_2}

#### Whitebox *&lt;Baustein 1&gt;* {#_whitebox_baustein_1}

*&lt;Whitebox-Template&gt;*

#### Whitebox *&lt;Baustein 2&gt;* {#_whitebox_baustein_2}

*&lt;Whitebox-Template&gt;*

…​

#### Whitebox *&lt;Baustein m&gt;* {#_whitebox_baustein_m}

*&lt;Whitebox-Template&gt;*

### Ebene 3 {#_ebene_3}

#### Whitebox &lt;\_Baustein x.1\_&gt; {#_whitebox_baustein_x_1}

*&lt;Whitebox-Template&gt;*

#### Whitebox &lt;\_Baustein x.2\_&gt; {#_whitebox_baustein_x_2}

*&lt;Whitebox-Template&gt;*

#### Whitebox &lt;\_Baustein y.1\_&gt; {#_whitebox_baustein_y_1}

*&lt;Whitebox-Template&gt;*

## Laufzeitsicht {#section-runtime-view}

### *&lt;Bezeichnung Laufzeitszenario 1&gt;* {#_bezeichnung_laufzeitszenario_1}

- &lt;hier Laufzeitdiagramm oder Ablaufbeschreibung einfügen&gt;

- &lt;hier Besonderheiten bei dem Zusammenspiel der Bausteine in diesem Szenario erläutern&gt;

### *&lt;Bezeichnung Laufzeitszenario 2&gt;* {#_bezeichnung_laufzeitszenario_2}

…​

### *&lt;Bezeichnung Laufzeitszenario n&gt;* {#_bezeichnung_laufzeitszenario_n}

…​

## Verteilungssicht {#section-deployment-view}

### Infrastruktur Ebene 1 {#_infrastruktur_ebene_1}

***&lt;Übersichtsdiagramm&gt;***

Begründung

:   *&lt;Erläuternder Text&gt;*

Qualitäts- und/oder Leistungsmerkmale

:   *&lt;Erläuternder Text&gt;*

Zuordnung von Bausteinen zu Infrastruktur

:   *&lt;Beschreibung der Zuordnung&gt;*

### Infrastruktur Ebene 2 {#_infrastruktur_ebene_2}

#### *&lt;Infrastrukturelement 1&gt;* {#_infrastrukturelement_1}

*&lt;Diagramm + Erläuterungen&gt;*

#### *&lt;Infrastrukturelement 2&gt;* {#_infrastrukturelement_2}

*&lt;Diagramm + Erläuterungen&gt;*

…​

#### *&lt;Infrastrukturelement n&gt;* {#_infrastrukturelement_n}

*&lt;Diagramm + Erläuterungen&gt;*

## Querschnittliche Konzepte {#section-concepts}

### *&lt;Konzept 1&gt;* {#_konzept_1}

*&lt;Erklärung&gt;*

### *&lt;Konzept 2&gt;* {#_konzept_2}

*&lt;Erklärung&gt;*

…​

### *&lt;Konzept n&gt;* {#_konzept_n}

*&lt;Erklärung&gt;*

## Architekturentscheidungen {#section-design-decisions}

## Qualitätsanforderungen {#section-quality-scenarios}

### Übersicht der Qualitätsanforderungen {#_übersicht_der_qualitätsanforderungen}

### Qualitätsszenarien {#_qualitätsszenarien}

## Risiken und technische Schulden {#section-technical-risks}

## Glossar {#section-glossary}

 Begriff             | Definition             |
---------------------|------------------------|
 *&lt;Begriff-1&gt;* | *&lt;Definition-1&gt;* |
 *&lt;Begriff-2*     | *&lt;Definition-2&gt;* |

  [arc42]: images/arc42-logo.png
  [Einführung und Ziele]: #section-introduction-and-goals {#toc-section-introduction-and-goals}
  [Aufgabenstellung]: #_aufgabenstellung {#toc-_aufgabenstellung}
  [Qualitätsziele]: #_qualitätsziele {#toc-_qualitätsziele}
  [Stakeholder]: #_stakeholder {#toc-_stakeholder}
  [Randbedingungen]: #section-architecture-constraints {#toc-section-architecture-constraints}
  [Kontextabgrenzung]: #section-context-and-scope {#toc-section-context-and-scope}
  [Fachlicher Kontext]: #_fachlicher_kontext {#toc-_fachlicher_kontext}
  [Technischer Kontext]: #_technischer_kontext {#toc-_technischer_kontext}
  [Lösungsstrategie]: #section-solution-strategy {#toc-section-solution-strategy}
  [Bausteinsicht]: #section-building-block-view {#toc-section-building-block-view}
  [Whitebox Gesamtsystem]: #_whitebox_gesamtsystem {#toc-_whitebox_gesamtsystem}
  [&lt;Name Blackbox 1&gt;]: #_name_blackbox_1 {#toc-_name_blackbox_1}
  [&lt;Name Blackbox 2&gt;]: #_name_blackbox_2 {#toc-_name_blackbox_2}
  [&lt;Name Blackbox n&gt;]: #_name_blackbox_n {#toc-_name_blackbox_n}
  [&lt;Name Schnittstelle 1&gt;]: #_name_schnittstelle_1 {#toc-_name_schnittstelle_1}
  [&lt;Name Schnittstelle m&gt;]: #_name_schnittstelle_m {#toc-_name_schnittstelle_m}
  [Ebene 2]: #_ebene_2 {#toc-_ebene_2}
  [Whitebox *&lt;Baustein 1&gt;*]: #_whitebox_baustein_1 {#toc-_whitebox_baustein_1}
  [Whitebox *&lt;Baustein 2&gt;*]: #_whitebox_baustein_2 {#toc-_whitebox_baustein_2}
  [Whitebox *&lt;Baustein m&gt;*]: #_whitebox_baustein_m {#toc-_whitebox_baustein_m}
  [Ebene 3]: #_ebene_3 {#toc-_ebene_3}
  [Whitebox &lt;\_Baustein x.1\_&gt;]: #_whitebox_baustein_x_1 {#toc-_whitebox_baustein_x_1}
  [Whitebox &lt;\_Baustein x.2\_&gt;]: #_whitebox_baustein_x_2 {#toc-_whitebox_baustein_x_2}
  [Whitebox &lt;\_Baustein y.1\_&gt;]: #_whitebox_baustein_y_1 {#toc-_whitebox_baustein_y_1}
  [Laufzeitsicht]: #section-runtime-view {#toc-section-runtime-view}
  [*&lt;Bezeichnung Laufzeitszenario 1&gt;*]: #_bezeichnung_laufzeitszenario_1 {#toc-_bezeichnung_laufzeitszenario_1}
  [*&lt;Bezeichnung Laufzeitszenario 2&gt;*]: #_bezeichnung_laufzeitszenario_2 {#toc-_bezeichnung_laufzeitszenario_2}
  [*&lt;Bezeichnung Laufzeitszenario n&gt;*]: #_bezeichnung_laufzeitszenario_n {#toc-_bezeichnung_laufzeitszenario_n}
  [Verteilungssicht]: #section-deployment-view {#toc-section-deployment-view}
  [Infrastruktur Ebene 1]: #_infrastruktur_ebene_1 {#toc-_infrastruktur_ebene_1}
  [Infrastruktur Ebene 2]: #_infrastruktur_ebene_2 {#toc-_infrastruktur_ebene_2}
  [*&lt;Infrastrukturelement 1&gt;*]: #_infrastrukturelement_1 {#toc-_infrastrukturelement_1}
  [*&lt;Infrastrukturelement 2&gt;*]: #_infrastrukturelement_2 {#toc-_infrastrukturelement_2}
  [*&lt;Infrastrukturelement n&gt;*]: #_infrastrukturelement_n {#toc-_infrastrukturelement_n}
  [Querschnittliche Konzepte]: #section-concepts {#toc-section-concepts}
  [*&lt;Konzept 1&gt;*]: #_konzept_1 {#toc-_konzept_1}
  [*&lt;Konzept 2&gt;*]: #_konzept_2 {#toc-_konzept_2}
  [*&lt;Konzept n&gt;*]: #_konzept_n {#toc-_konzept_n}
  [Architekturentscheidungen]: #section-design-decisions {#toc-section-design-decisions}
  [Qualitätsanforderungen]: #section-quality-scenarios {#toc-section-quality-scenarios}
  [Übersicht der Qualitätsanforderungen]: #_übersicht_der_qualitätsanforderungen {#toc-_übersicht_der_qualitätsanforderungen}
  [Qualitätsszenarien]: #_qualitätsszenarien {#toc-_qualitätsszenarien}
  [Risiken und technische Schulden]: #section-technical-risks {#toc-section-technical-risks}
  [Glossar]: #section-glossary {#toc-section-glossary}