# Risiken und technische Schulden {#section-technical-risks}

  [Risiken und technische Schulden]: #section-technical-risks {#toc-section-technical-risks}
