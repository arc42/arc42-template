# Glossar {#section-glossary}

| Begriff             | Definition             |
|---------------------|------------------------|
| *&lt;Begriff-1&gt;* | *&lt;Definition-1&gt;* |
| *&lt;Begriff-2*     | *&lt;Definition-2&gt;* |

  [Glossar]: #section-glossary {#toc-section-glossary}
