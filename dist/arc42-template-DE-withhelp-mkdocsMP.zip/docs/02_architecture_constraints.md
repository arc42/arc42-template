# Randbedingungen {#section-architecture-constraints}

  [Randbedingungen]: #section-architecture-constraints {#toc-section-architecture-constraints}
