# Architekturentscheidungen {#section-design-decisions}

  [Architekturentscheidungen]: #section-design-decisions {#toc-section-design-decisions}
