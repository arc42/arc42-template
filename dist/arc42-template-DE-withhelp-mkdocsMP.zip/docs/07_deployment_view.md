# Verteilungssicht {#section-deployment-view}

## Infrastruktur Ebene 1 {#_infrastruktur_ebene_1}

***&lt;Übersichtsdiagramm&gt;***

Begründung

:   *&lt;Erläuternder Text&gt;*

Qualitäts- und/oder Leistungsmerkmale

:   *&lt;Erläuternder Text&gt;*

Zuordnung von Bausteinen zu Infrastruktur

:   *&lt;Beschreibung der Zuordnung&gt;*

## Infrastruktur Ebene 2 {#_infrastruktur_ebene_2}

### *&lt;Infrastrukturelement 1&gt;* {#_infrastrukturelement_1}

*&lt;Diagramm + Erläuterungen&gt;*

### *&lt;Infrastrukturelement 2&gt;* {#_infrastrukturelement_2}

*&lt;Diagramm + Erläuterungen&gt;*

…​

### *&lt;Infrastrukturelement n&gt;* {#_infrastrukturelement_n}

*&lt;Diagramm + Erläuterungen&gt;*

  [Verteilungssicht]: #section-deployment-view {#toc-section-deployment-view}
  [Infrastruktur Ebene 1]: #_infrastruktur_ebene_1 {#toc-_infrastruktur_ebene_1}
  [Infrastruktur Ebene 2]: #_infrastruktur_ebene_2 {#toc-_infrastruktur_ebene_2}
  [*&lt;Infrastrukturelement 1&gt;*]: #_infrastrukturelement_1 {#toc-_infrastrukturelement_1}
  [*&lt;Infrastrukturelement 2&gt;*]: #_infrastrukturelement_2 {#toc-_infrastrukturelement_2}
  [*&lt;Infrastrukturelement n&gt;*]: #_infrastrukturelement_n {#toc-_infrastrukturelement_n}
