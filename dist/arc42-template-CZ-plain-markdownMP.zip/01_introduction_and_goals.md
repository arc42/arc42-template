# Úvod a cíle {#section-introduction-and-goals}

## Přehled požadavků {#_p_ehled_po_adavk}

## Kvalitativní cíle {#_kvalitativn_c_le}

## Strany zainteresované na systému (Stakeholder) {#_strany_zainteresovan_na_syst_mu_stakeholder}

+-------------+---------------------------+---------------------------+
| Role/Jméno  | Kontakt                   | Očekávání                 |
+=============+===========================+===========================+
| *\<Role-1>* | *\<Kontakt-1>*            | *\<Očekávání-1>*          |
+-------------+---------------------------+---------------------------+
| *\<Role-2>* | *\<Kontakt-2>*            | *\<Očekávání-2>*          |
+-------------+---------------------------+---------------------------+
