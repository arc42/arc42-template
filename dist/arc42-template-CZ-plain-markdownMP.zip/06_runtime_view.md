# Perspektiva chování za běhu (runtime) {#section-runtime-view}

## \<Scénář runtime 1\> {#_scénář_runtime_1}

- *\<vložte runtime diagram nebo textový popis scénáře\>*

- *\<vložte popis důležitých interakcí mezi instancemi stavebních bloků
  zobrazených v tomto diagramu\>*

## \<Scénář runtime 2\> {#_scénář_runtime_2}

## ...​

## \<Scénář runtime n\> {#_scénář_runtime_n}
