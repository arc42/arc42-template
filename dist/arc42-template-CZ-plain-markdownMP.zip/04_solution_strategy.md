# Strategie řešení {#section-solution-strategy}
