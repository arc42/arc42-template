# Perspektiva stavebních bloků {#section-building-block-view}

## Celý systém jako white-box {#_celý_systém_jako_white_box}

***\<vložte přehledový diagram celého systému\>***

Motivace

:   *\<popište motivaci\>*

Obsažené stavební bloky

:   *\<popište obsažené stavební bloky (jako black-box)\>*

Důležitá rozhraní

:   *\<popište důležitá rozhraní\>*

### \<Jméno black-boxu 1\> {#_jméno_black_boxu_1}

*\<Účel/Odpovědnost\>*

*\<Rozhraní\>*

*\<(Volitelně) Požadavky na kvalitu/výkon\>*

*\<(Volitelně) Umístění/složky a soubory\>*

*\<(Volitelně) Splněné požadavky\>*

*\<(Volitelně) Nevyřešené body/problémy/rizika\>*

### \<Jméno black-boxu 2\> {#_jméno_black_boxu_2}

*\<šablona black-box\>*

### \<Jméno black-boxu n\> {#_jméno_black_boxu_n}

*\<šablona black-box\>*

### \<Jméno rozhraní 1\> {#_jméno_rozhraní_1}

...​

### \<Jméno rozhraní m\> {#_jméno_rozhraní_m}

## Úroveň 2 {#_úroveň_2}

### white-box *\<stavební blok 1\>* {#_white_box_stavební_blok_1}

*\<šablona white-box\>*

### white-box *\<stavební blok 2\>* {#_white_box_stavební_blok_2}

*\<šablona white-box\>*

...​

### white-box *\<stavební blok m\>* {#_white_box_stavební_blok_m}

*\<šablona white-box\>*

## Úroveň 3 {#_úroveň_3}

### white-box \<\_stavební blok x.1\_\> {#_white_box_stavební_blok_x_1}

*\<šablona white-box\>*

### white-box \<\_stavební blok x.2\_\> {#_white_box_stavební_blok_x_2}

*\<šablona white-box\>*

### white-box \<\_stavební blok y.1\_\> {#_white_box_stavební_blok_y_1}

*\<šablona white-box\>*
