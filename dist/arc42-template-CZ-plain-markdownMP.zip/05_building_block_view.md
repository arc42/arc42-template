# Perspektiva stavebních bloků {#section-building-block-view}

## Celý systém jako white-box {#_cel_syst_m_jako_white_box}

***\<vložte přehledový diagram celého systému>***

Motivace

:   *\<popište motivaci>*

Obsažené stavební bloky

:   *\<popište obsažené stavební bloky (jako black-box)>*

Důležitá rozhraní

:   *\<popište důležitá rozhraní>*

### \<Jméno black-boxu 1> {#__jm_no_black_boxu_1}

*\<Účel/Odpovědnost>*

*\<Rozhraní>*

*\<(Volitelně) Požadavky na kvalitu/výkon>*

*\<(Volitelně) Umístění/složky a soubory>*

*\<(Volitelně) Splněné požadavky>*

*\<(Volitelně) Nevyřešené body/problémy/rizika>*

### \<Jméno black-boxu 2> {#__jm_no_black_boxu_2}

*\<šablona black-box>*

### \<Jméno black-boxu n> {#__jm_no_black_boxu_n}

*\<šablona black-box>*

### \<Jméno rozhraní 1> {#__jm_no_rozhran_1}

...

### \<Jméno rozhraní m> {#__jm_no_rozhran_m}

## Úroveň 2 {#__rove_2}

### white-box *\<stavební blok 1>* {#_white_box_emphasis_stavebn_blok_1_emphasis}

*\<šablona white-box>*

### white-box *\<stavební blok 2>* {#_white_box_emphasis_stavebn_blok_2_emphasis}

*\<šablona white-box>*

...

### white-box *\<stavební blok m>* {#_white_box_emphasis_stavebn_blok_m_emphasis}

*\<šablona white-box>*

## Úroveň 3 {#__rove_3}

### white-box \<\_stavební blok x.1\_\> {#_white_box_stavebn_blok_x_1}

*\<šablona white-box>*

### white-box \<\_stavební blok x.2\_\> {#_white_box_stavebn_blok_x_2}

*\<šablona white-box>*

### white-box \<\_stavební blok y.1\_\> {#_white_box_stavebn_blok_y_1}

*\<šablona white-box>*
