# Omezení na realizaci systému {#section-architecture-constraints}
