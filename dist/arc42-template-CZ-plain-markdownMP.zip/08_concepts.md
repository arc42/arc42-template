# Průřezové (cross-cutting) koncepty {#section-concepts}

## *\<Koncept 1\>* {#__emphasis_koncept_1_emphasis}

*\<vysvětlení\>*

## *\<Koncept 2\>* {#__emphasis_koncept_2_emphasis}

*\<vysvětlení\>*

...

## *\<Koncept n\>* {#__emphasis_koncept_n_emphasis}

*\<vysvětlení\>*
