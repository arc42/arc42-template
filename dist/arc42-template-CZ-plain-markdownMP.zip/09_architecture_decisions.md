# Rozhodnutí o architektuře {#section-design-decisions}
