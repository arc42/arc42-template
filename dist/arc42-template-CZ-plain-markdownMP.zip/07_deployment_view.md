# Perspektiva nasazení softwaru (deployment) {#section-deployment-view}

## Úroveň infrastruktury 1 {#_úroveň_infrastruktury_1}

***\<Přehledový diagram\>***

Motivace

:   *\<vysvětlení v textové podobě\>*

Kvalitativní a/nebo výkonnostní vlastnosti

:   *\<vysvětlení v textové podobě\>*

Mapování softwarových artefaktů na prvky infrastruktury

:   *\<popis mapování\>*

## Úroveň infrastruktury 2 {#_úroveň_infrastruktury_2}

### *\<prvek infrastruktury 1\>* {#_prvek_infrastruktury_1}

*\<diagram + vysvětlení\>*

### *\<prvek infrastruktury 2\>* {#_prvek_infrastruktury_2}

*\<diagram + vysvětlení\>*

...​

### *\<prvek infrastruktury n\>* {#_prvek_infrastruktury_n}

*\<diagram + vysvětlení\>*
