# Perspektiva nasazení softwaru (deployment) {#section-deployment-view}

## Úroveň infrastruktury 1 {#__rove_infrastruktury_1}

***\<Přehledový diagram\>***

Motivace

:   *\<vysvětlení v textové podobě\>*

Kvalitativní a/nebo výkonnostní vlastnosti

:   *\<vysvětlení v textové podobě\>*

Mapování softwarových artefaktů na prvky infrastruktury

:   *\<popis mapování\>*

## Úroveň infrastruktury 2 {#__rove_infrastruktury_2}

### *\<prvek infrastruktury 1\>* {#__emphasis_prvek_infrastruktury_1_emphasis}

*\<diagram + vysvětlení\>*

### *\<prvek infrastruktury 2\>* {#__emphasis_prvek_infrastruktury_2_emphasis}

*\<diagram + vysvětlení\>*

...

### *\<prvek infrastruktury n\>* {#__emphasis_prvek_infrastruktury_n_emphasis}

*\<diagram + vysvětlení\>*
