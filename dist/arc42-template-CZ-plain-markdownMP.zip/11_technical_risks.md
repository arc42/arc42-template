# Rizika a technické dluhy {#section-technical-risks}
