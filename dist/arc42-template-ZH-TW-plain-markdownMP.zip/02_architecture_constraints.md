# 架構限制 {#section-architecture-constraints}
