# 風險與技術負債 {#section-technical-risks}
