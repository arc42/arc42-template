# Perspektiva stavebních bloků

## Celý systém jako white-box

***&lt;vložte přehledový diagram celého systému>***

Motivace  
*&lt;popište motivaci>*

Obsažené stavební bloky  
*&lt;popište obsažené stavební bloky (jako black-box)>*

Důležitá rozhraní  
*&lt;popište důležitá rozhraní>*

### &lt;Jméno black-boxu 1>

*&lt;Účel/Odpovědnost>*

*&lt;Rozhraní>*

*&lt;(Volitelně) Požadavky na kvalitu/výkon>*

*&lt;(Volitelně) Umístění/složky a soubory>*

*&lt;(Volitelně) Splněné požadavky>*

*&lt;(Volitelně) Nevyřešené body/problémy/rizika>*

### &lt;Jméno black-boxu 2>

*&lt;šablona black-box>*

### &lt;Jméno black-boxu n>

*&lt;šablona black-box>*

### &lt;Jméno rozhraní 1>

…

### &lt;Jméno rozhraní m>

## Úroveň 2

### white-box *&lt;stavební blok 1>*

*&lt;šablona white-box>*

### white-box *&lt;stavební blok 2>*

*&lt;šablona white-box>*

…

### white-box *&lt;stavební blok m>*

*&lt;šablona white-box>*

## Úroveň 3

### white-box &lt;\_stavební blok x.1\_&gt;

*&lt;šablona white-box>*

### white-box &lt;\_stavební blok x.2\_&gt;

*&lt;šablona white-box>*

### white-box &lt;\_stavební blok y.1\_&gt;

*&lt;šablona white-box>*
