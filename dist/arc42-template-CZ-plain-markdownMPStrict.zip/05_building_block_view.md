# Perspektiva stavebních bloků

## Celý systém jako white-box

***&lt;vložte přehledový diagram celého systému&gt;***

Motivace  
*&lt;popište motivaci&gt;*

Obsažené stavební bloky  
*&lt;popište obsažené stavební bloky (jako black-box)&gt;*

Důležitá rozhraní  
*&lt;popište důležitá rozhraní&gt;*

### &lt;Jméno black-boxu 1&gt;

*&lt;Účel/Odpovědnost&gt;*

*&lt;Rozhraní&gt;*

*&lt;(Volitelně) Požadavky na kvalitu/výkon&gt;*

*&lt;(Volitelně) Umístění/složky a soubory&gt;*

*&lt;(Volitelně) Splněné požadavky&gt;*

*&lt;(Volitelně) Nevyřešené body/problémy/rizika&gt;*

### &lt;Jméno black-boxu 2&gt;

*&lt;šablona black-box&gt;*

### &lt;Jméno black-boxu n&gt;

*&lt;šablona black-box&gt;*

### &lt;Jméno rozhraní 1&gt;

…​

### &lt;Jméno rozhraní m&gt;

## Úroveň 2

### white-box *&lt;stavební blok 1&gt;*

*&lt;šablona white-box&gt;*

### white-box *&lt;stavební blok 2&gt;*

*&lt;šablona white-box&gt;*

…​

### white-box *&lt;stavební blok m&gt;*

*&lt;šablona white-box&gt;*

## Úroveň 3

### white-box &lt;\_stavební blok x.1\_&gt;

*&lt;šablona white-box&gt;*

### white-box &lt;\_stavební blok x.2\_&gt;

*&lt;šablona white-box&gt;*

### white-box &lt;\_stavební blok y.1\_&gt;

*&lt;šablona white-box&gt;*
