# Slovník pojmů

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">Termín</th>
<th style="text-align: left;">Definice</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p><em>&lt;termín-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definice-1&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"><p><em>&lt;termín-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definice-2&gt;</em></p></td>
</tr>
</tbody>
</table>
