# Perspektiva chování za běhu (runtime)

## &lt;Scénář runtime 1&gt;

- *&lt;vložte runtime diagram nebo textový popis scénáře&gt;*

- *&lt;vložte popis důležitých interakcí mezi instancemi stavebních
  bloků zobrazených v tomto diagramu&gt;*

## &lt;Scénář runtime 2&gt;

## …​

## &lt;Scénář runtime n&gt;
