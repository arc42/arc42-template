# Perspektiva nasazení softwaru (deployment)

## Úroveň infrastruktury 1

***&lt;Přehledový diagram>***

Motivace  
*&lt;vysvětlení v textové podobě>*

Kvalitativní a/nebo výkonnostní vlastnosti  
*&lt;vysvětlení v textové podobě>*

Mapování softwarových artefaktů na prvky infrastruktury  
*&lt;popis mapování>*

## Úroveň infrastruktury 2

### *&lt;prvek infrastruktury 1>*

*&lt;diagram + vysvětlení>*

### *&lt;prvek infrastruktury 2>*

*&lt;diagram + vysvětlení>*

…

### *&lt;prvek infrastruktury n>*

*&lt;diagram + vysvětlení>*
