# Perspektiva nasazení softwaru (deployment)

## Úroveň infrastruktury 1

***&lt;Přehledový diagram&gt;***

Motivace  
*&lt;vysvětlení v textové podobě&gt;*

Kvalitativní a/nebo výkonnostní vlastnosti  
*&lt;vysvětlení v textové podobě&gt;*

Mapování softwarových artefaktů na prvky infrastruktury  
*&lt;popis mapování&gt;*

## Úroveň infrastruktury 2

### *&lt;prvek infrastruktury 1&gt;*

*&lt;diagram + vysvětlení&gt;*

### *&lt;prvek infrastruktury 2&gt;*

*&lt;diagram + vysvětlení&gt;*

…​

### *&lt;prvek infrastruktury n&gt;*

*&lt;diagram + vysvětlení&gt;*
