# Úvod a cíle

## Přehled požadavků

## Kvalitativní cíle

## Strany zainteresované na systému (Stakeholder)

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Role/Jméno</th>
<th style="text-align: left;">Kontakt</th>
<th style="text-align: left;">Očekávání</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Role-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Kontakt-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Očekávání-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Role-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Kontakt-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Očekávání-2&gt;</em></p></td>
</tr>
</tbody>
</table>
