# 

**O arc42**

arc42, šablona pro dokumentaci softwaru a architekturu systému.

Verze šablony 9.0-CZ. (na základě AsciiDoc verze), Leden 2025

Created, maintained and © by Dr. Peter Hruschka, Dr. Gernot Starke and
contributors. Viz <https://arc42.org>.

# Úvod a cíle

## Přehled požadavků

## Kvalitativní cíle

## Strany zainteresované na systému (stakeholder)

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Role/Jméno</th>
<th style="text-align: left;">Kontakt</th>
<th style="text-align: left;">Očekávání</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Role-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Kontakt-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Očekávání-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Role-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Kontakt-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Očekávání-2&gt;</em></p></td>
</tr>
</tbody>
</table>

# Omezení na realizaci systému

# Vymezení a rozsah systému

## Firemní kontext

**&lt;vložte diagram nebo tabulku&gt;**

**&lt;(volitelně:) vložte vysvětlení externích doménových rozhraní&gt;**

## Technický kontext

**&lt;vložte diagram nebo tabulku&gt;**

**&lt;(volitelně:) vložte vysvětlení externích technických
rozhraní&gt;**

**&lt;mapování doménových vstupu/výstupu na technické kanály&gt;**

# Strategie řešení

# Perspektiva stavebních bloků

## Celý systém jako white-box

***&lt;vložte přehledový diagram celého systému&gt;***

Motivace  
*&lt;popište motivaci&gt;*

Obsažené stavební bloky  
*&lt;popište obsažené stavební bloky (jako black-box)&gt;*

Důležitá rozhraní  
*&lt;popište důležitá rozhraní&gt;*

### &lt;Jméno black-boxu 1&gt;

*&lt;Účel/Odpovědnost&gt;*

*&lt;Rozhraní&gt;*

*&lt;(Volitelně) Požadavky na kvalitu/výkon&gt;*

*&lt;(Volitelně) Umístění/složky a soubory&gt;*

*&lt;(Volitelně) Splněné požadavky&gt;*

*&lt;(Volitelně) Nevyřešené body/problémy/rizika&gt;*

### &lt;Jméno black-boxu 2&gt;

*&lt;šablona black-box&gt;*

### &lt;Jméno black-boxu n&gt;

*&lt;šablona black-box&gt;*

### &lt;Jméno rozhraní 1&gt;

…​

### &lt;Jméno rozhraní m&gt;

## Úroveň 2

### white-box *&lt;stavební blok 1&gt;*

*&lt;šablona white-box&gt;*

### white-box *&lt;stavební blok 2&gt;*

*&lt;šablona white-box&gt;*

…​

### white-box *&lt;stavební blok m&gt;*

*&lt;šablona white-box&gt;*

## Úroveň 3

### white-box &lt;\_stavební blok x.1\_&gt;

*&lt;šablona white-box&gt;*

### white-box &lt;\_stavební blok x.2\_&gt;

*&lt;šablona white-box&gt;*

### white-box &lt;\_stavební blok y.1\_&gt;

*&lt;šablona white-box&gt;*

# Perspektiva chování za běhu (runtime)

## &lt;Scénář runtime 1&gt;

-   *&lt;vložte runtime diagram nebo textový popis scénáře&gt;*

-   *&lt;vložte popis důležitých interakcí mezi instancemi stavebních
    bloků zobrazených v tomto diagramu&gt;*

## &lt;Scénář runtime 2&gt;

## …​

## &lt;Scénář runtime n&gt;

# Perspektiva nasazení softwaru (deployment)

## Úroveň infrastruktury 1

***&lt;Přehledový diagram&gt;***

Motivace  
*&lt;vysvětlení v textové podobě&gt;*

Kvalitativní a/nebo výkonnostní vlastnosti  
*&lt;vysvětlení v textové podobě&gt;*

Mapování softwarových artefaktů na prvky infrastruktury  
*&lt;popis mapování&gt;*

## Úroveň infrastruktury 2

### *&lt;prvek infrastruktury 1&gt;*

*&lt;diagram + vysvětlení&gt;*

### *&lt;prvek infrastruktury 2&gt;*

*&lt;diagram + vysvětlení&gt;*

…​

### *&lt;prvek infrastruktury n&gt;*

*&lt;diagram + vysvětlení&gt;*

# Průřezové (cross-cutting) koncepty

## *&lt;Koncept 1&gt;*

*&lt;vysvětlení&gt;*

## *&lt;Koncept 2&gt;*

*&lt;vysvětlení&gt;*

…​

## *&lt;Koncept n&gt;*

*&lt;vysvětlení&gt;*

# Rozhodnutí o architektuře

# Požadavky na kvalitu

## Přehled požadavků na kvalitu

## Scénáře kvality

# Rizika a technické dluhy

# Slovník pojmů

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Termín</th>
<th style="text-align: left;">Definice</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;termín-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definice-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;termín-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definice-2&gt;</em></p></td>
</tr>
</tbody>
</table>
