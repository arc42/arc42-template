# Vymezení a rozsah systému

## Firemní kontext

**&lt;vložte diagram nebo tabulku&gt;**

**&lt;(volitelně:) vložte vysvětlení externích doménových rozhraní&gt;**

## Technický kontext

**&lt;vložte diagram nebo tabulku&gt;**

**&lt;(volitelně:) vložte vysvětlení externích technických
rozhraní&gt;**

**&lt;mapování doménových vstupu/výstupu na technické kanály&gt;**
