# Telepítési nézet

## 1. infrastruktúra-szint

***\<Áttekintő diagram\>***

Motiváció  
*\<szöveges magyarázat\>*

Minőségi és/vagy teljesítményjellemzők  
*\<szöveges magyarázat\>*

Építőelemek leképezése az infrastruktúrára  
*\<a leképezés leírása\>*

## 2. infrastruktúra-szint

### *\<1. infrastruktúra-elem\>*

*\<diagram + magyarázat\>*

### *\<2. infrastruktúra-elem\>*

*\<diagram + magyarázat\>*

…​

### *\<n. infrastruktúra-elem\>*

*\<diagram + magyarázat\>*
