# Megoldási stratégia
