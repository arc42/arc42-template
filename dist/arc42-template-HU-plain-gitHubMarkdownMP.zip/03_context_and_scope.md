# Kontextus és hatókör

## Üzleti kontextus

**\<Diagram vagy táblázat\>**

**\<opcionális: Külső szakterületi interfészek magyarázata\>**

## Technikai kontextus

**\<Diagram vagy táblázat\>**

**\<opcionális: Technikai interfészek magyarázata\>**

**\<Bemenet/kimenet leképezése csatornákra\>**
