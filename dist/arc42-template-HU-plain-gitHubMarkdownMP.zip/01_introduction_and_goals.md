# Bevezetés és célok

## Követelmények áttekintése

## Minőségi célok

## Érdekelt felek

| Szerepkör/Név     | Elérhetőség         | Elvárások       |
|-------------------|---------------------|-----------------|
| *\<Szerepkör-1\>* | *\<Elérhetőség-1\>* | *\<Elvárás-1\>* |
| *\<Szerepkör-2\>* | *\<Elérhetőség-2\>* | *\<Elvárás-2\>* |
