# Építőelem-nézet

## Fehér doboz Teljes rendszer

***\<Áttekintő diagram\>***

Motiváció  
*\<szöveges magyarázat\>*

Tartalmazott építőelemek  
*\<A tartalmazott építőelemek (fekete dobozok) leírása\>*

Fontos interfészek  
*\<Fontos interfészek leírása\>*

### \<Fekete doboz 1 neve\>

*\<Cél/Felelősség\>*

*\<Interfész(ek)\>*

*\<(Opcionális) Minőségi/Teljesítményjellemzők\>*

*\<(Opcionális) Könyvtár/Fájl elérési út\>*

*\<(Opcionális) Teljesített követelmények\>*

*\<(Opcionális) Nyitott kérdések/Problémák/Kockázatok\>*

### \<Fekete doboz 2 neve\>

*\<fekete doboz sablon\>*

### \<Fekete doboz n neve\>

*\<fekete doboz sablon\>*

### \<Interfész 1 neve\>

…​

### \<Interfész m neve\>

## 2. szint

### Fehér doboz *\<1. építőelem\>*

*\<fehér doboz sablon\>*

### Fehér doboz *\<2. építőelem\>*

*\<fehér doboz sablon\>*

…​

### Fehér doboz *\<m. építőelem\>*

*\<fehér doboz sablon\>*

## 3. szint

### Fehér doboz \<\_x.1 építőelem\_\>

*\<fehér doboz sablon\>*

### Fehér doboz \<\_x.2 építőelem\_\>

*\<fehér doboz sablon\>*

### Fehér doboz \<\_y.1 építőelem\_\>

*\<fehér doboz sablon\>*
