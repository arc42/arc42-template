# Keresztmetszeti koncepciók

## *\<1. koncepció\>*

*\<magyarázat\>*

## *\<2. koncepció\>*

*\<magyarázat\>*

…​

## *\<n. koncepció\>*

*\<magyarázat\>*
