# Futásidejű nézet

## \<Futásidejű forgatókönyv 1\>

- *\<illesszen be futásidejű diagramot vagy a forgatókönyv szöveges
  leírását\>*

- *\<illesszen be leírást az ábrázolt építőelem-példányok közötti
  interakciók figyelemre méltó aspektusairól.\>*

## \<Futásidejű forgatókönyv 2\>

## …​

## \<Futásidejű forgatókönyv n\>
