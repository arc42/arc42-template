# Szójegyzék

| Kifejezés         | Meghatározás         |
|-------------------|----------------------|
| *\<Kifejezés-1\>* | *\<meghatározás-1\>* |
| *\<Kifejezés-2\>* | *\<meghatározás-2\>* |
