# Cross-cutting Concepten

## *&lt;Concept 1>*

*&lt;uitleg>*

## *&lt;Concept 2>*

*&lt;uitleg>*

…

## *&lt;Concept n>*

*&lt;uitleg>*
