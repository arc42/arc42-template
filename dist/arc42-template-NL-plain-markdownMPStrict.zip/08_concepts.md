# Cross-cutting Concepten

## *&lt;Concept 1&gt;*

*&lt;uitleg&gt;*

## *&lt;Concept 2&gt;*

*&lt;uitleg&gt;*

…

## *&lt;Concept n&gt;*

*&lt;uitleg&gt;*
