**Over arc42**

arc42, de Template voor documentatie van software en systeem
architectuur.

Gecreeerd en onderhouden door Dr. Peter Hruschka, Dr. Gernot Starke en
bijdragers.

Template Revisie: 8.0 NL (based on asciidoc), February 2022

© We erkennen dat dit document materiaal gebruikt van de arc 42
architectuur template, <https://arc42.org>.
