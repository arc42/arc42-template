# Runtime View

## &lt;Runtime Scenario 1>

-   *&lt;voeg een runtime diagram of een tekstuele beschrijving van het
    scenario toe>*

-   *&lt;voeg een beschrijving toe van bijzondere aspecten van de
    interactie tussen de instanties van de bouwstenen die in dit diagram
    worden weergegeven>*

## &lt;Runtime Scenario 2>

## …

## &lt;Runtime Scenario n>
