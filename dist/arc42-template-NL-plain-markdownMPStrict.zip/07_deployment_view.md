# Deployment View

## Infrastructuur Niveau 1

***&lt;Overzichts Diagram>***

Motivatie  
*&lt;uitleg in tekstuele vorm>*

Kwaliteit en/of Performance Eigenschappen  
*&lt;uitleg in tekstuele vorm>*

Mapping van Bouwstenen naar Infrastructuur  
*&lt;beschrijving van de mapping>*

## Infrastructuur Niveau 2

### *&lt;Infrastructuur Element 1>*

*&lt;diagram + uitleg>*

### *&lt;Infrastructuur Element 2>*

*&lt;diagram + uitleg>*

…

### *&lt;Infrastructuur Element n>*

*&lt;diagram + uitleg>*
