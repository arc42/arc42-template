# Deployment View

## Infrastructuur Niveau 1

***&lt;Overzichts Diagram&gt;***

Motivatie  
*&lt;uitleg in tekstuele vorm&gt;*

Kwaliteit en/of Performance Eigenschappen  
*&lt;uitleg in tekstuele vorm&gt;*

Mapping van Bouwstenen naar Infrastructuur  
*&lt;beschrijving van de mapping&gt;*

## Infrastructuur Niveau 2

### *&lt;Infrastructuur Element 1&gt;*

*&lt;diagram + uitleg&gt;*

### *&lt;Infrastructuur Element 2&gt;*

*&lt;diagram + uitleg&gt;*

…

### *&lt;Infrastructuur Element n&gt;*

*&lt;diagram + uitleg&gt;*
