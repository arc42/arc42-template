# Oplossing Strategie
