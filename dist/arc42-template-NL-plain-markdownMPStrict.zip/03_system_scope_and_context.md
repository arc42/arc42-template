# Systeem Scope en Context

## Business Context

**&lt;Diagram of Tabel&gt;**

**&lt;optioneel: Uitleg van de externe domein interfaces&gt;**

## Technische Context

**&lt;Diagram of Tabel&gt;**

**&lt;optioneel: Uitleg van technische interfaces&gt;**

**&lt;Mapping Input/Output naar kanalen&gt;**
