# 

**Over arc42**

arc42, de Template voor documentatie van software en systeem
architectuur.

Gecreeerd en onderhouden door Dr. Peter Hruschka, Dr. Gernot Starke en
bijdragers.

Template Revisie: 8.0 NL (based on asciidoc), February 2022

© We erkennen dat dit document materiaal gebruikt van de arc 42
architectuur template, <https://arc42.org>.

# Introductie en Doelen

## Requirements Overzicht

## Kwaliteits Doelen

## Belanghebbenden

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Rol/Naam</th>
<th style="text-align: left;">Contact persoon</th>
<th style="text-align: left;">Verwachtingen</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Rol-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Contact-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Verwachting-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Rol-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Contact-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Verwachting-2&gt;</em></p></td>
</tr>
</tbody>
</table>

# Architectuur Beperkingen

# Systeem Scope en Context

## Business Context

**&lt;Diagram of Tabel>**

**&lt;optioneel: Uitleg van de externe domein interfaces>**

## Technische Context

**&lt;Diagram of Tabel>**

**&lt;optioneel: Uitleg van technische interfaces>**

**&lt;Mapping Input/Output naar kanalen>**

# Oplossing Strategie

# Bouwstenen View

## Gehele whitebox Systeem

***&lt;Overzichts Diagram>***

Motivatie  
*&lt;tekstuele uitleg>*

Ingesloten bouwstenen  
*&lt;Beschrijving van ingesloten bouwstenen (*black boxes*)>*

Belangrijke Interfaces  
*&lt;Beschrijving van belangrijke interfaces>*

### &lt;Naam black box 1>

*&lt;Doel/Verantwoordelijkheid>*

*&lt;Interface(s)>*

*&lt;((Optioneel) Kwaliteits-/Prestatie karakteristieken>*

*&lt;(Optioneel) directories/bestand locaties>*

*&lt;(Optioneel) Vervulde requirements>*

*&lt;(Optioneel) Open issues/problemen/risico’s>*

## &lt;Naam black box 2>

*&lt;black box template>*

### &lt;Naam black box n>

*&lt;black box template>*

### &lt;Naam interface 1>

…

### &lt;Naam interface m>

## Niveau 2

### White Box *&lt;bouwsteen 1>*

*&lt;white box template>*

### White Box *&lt;bouwsteen 2>*

*&lt;white box template>*

…

### White Box *&lt;bouwsteen m>*

*&lt;white box template>*

## Niveau 3

### White Box *&lt;bouwsteen x.1>*

*&lt;white box template>*

### White Box *&lt;bouwsteen x.2>*

*&lt;white box template>*

### White Box *&lt;bouwsteen y.1>*

*&lt;white box template>*

# Runtime View

## &lt;Runtime Scenario 1>

-   *&lt;voeg een runtime diagram of een tekstuele beschrijving van het
    scenario toe>*

-   *&lt;voeg een beschrijving toe van bijzondere aspecten van de
    interactie tussen de instanties van de bouwstenen die in dit diagram
    worden weergegeven>*

## &lt;Runtime Scenario 2>

## …

## &lt;Runtime Scenario n>

# Deployment View

## Infrastructuur Niveau 1

***&lt;Overzichts Diagram>***

Motivatie  
*&lt;uitleg in tekstuele vorm>*

Kwaliteit en/of Performance Eigenschappen  
*&lt;uitleg in tekstuele vorm>*

Mapping van Bouwstenen naar Infrastructuur  
*&lt;beschrijving van de mapping>*

## Infrastructuur Niveau 2

### *&lt;Infrastructuur Element 1>*

*&lt;diagram + uitleg>*

### *&lt;Infrastructuur Element 2>*

*&lt;diagram + uitleg>*

…

### *&lt;Infrastructuur Element n>*

*&lt;diagram + uitleg>*

# Cross-cutting Concepten

## *&lt;Concept 1>*

*&lt;uitleg>*

## *&lt;Concept 2>*

*&lt;uitleg>*

…

## *&lt;Concept n>*

*&lt;uitleg>*

# Architectuur Beslissingen

# Kwaliteits Requirements

## Kwaliteits Boom

## Kwaliteits Scenarios

# Risico’s en Technical Debt

# Woordenlijst

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Term</th>
<th style="text-align: left;">Definitie</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Term-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definitie-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Term-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definitie-2&gt;</em></p></td>
</tr>
</tbody>
</table>
