# 

**Over arc42**

arc42, de Template voor documentatie van software en systeem
architectuur.

Gecreeerd en onderhouden door Dr. Peter Hruschka, Dr. Gernot Starke en
bijdragers.

Template Versie: 8.2-NL. De NL versie is gebaseerd op EN asciidoc
template , March 2023

© We erkennen dat dit document materiaal gebruikt van de arc 42
architectuur template, <https://arc42.org>.

# Introductie en Doelen

## Requirements Overzicht

## Kwaliteits Doelen

## Belanghebbenden

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Rol/Naam</th>
<th style="text-align: left;">Contact persoon</th>
<th style="text-align: left;">Verwachtingen</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Rol-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Contact-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Verwachting-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Rol-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Contact-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Verwachting-2&gt;</em></p></td>
</tr>
</tbody>
</table>

# Architectuur Beperkingen

# Context en Systeem Scope

## Business Context

**&lt;Diagram of Tabel&gt;**

**&lt;optioneel: Uitleg van de externe domein interfaces&gt;**

## Technische Context

**&lt;Diagram of Tabel&gt;**

**&lt;optioneel: Uitleg van technische interfaces&gt;**

**&lt;Mapping Input/Output naar kanalen&gt;**

# Oplossing Strategie

# Bouwstenen View

## Gehele whitebox Systeem

***&lt;Overzichts Diagram&gt;***

Motivatie  
*&lt;tekstuele uitleg&gt;*

Ingesloten bouwstenen  
*&lt;Beschrijving van ingesloten bouwstenen ('black boxes')&gt;*

Belangrijke Interfaces  
*&lt;Beschrijving van belangrijke interfaces&gt;*

### &lt;Naam black box 1&gt;

*&lt;Doel/Verantwoordelijkheid&gt;*

*&lt;Interface(s)&gt;*

*&lt;((Optioneel) Kwaliteits-/Prestatie karakteristieken&gt;*

*&lt;(Optioneel) directories/bestand locaties&gt;*

*&lt;(Optioneel) Vervulde requirements&gt;*

*&lt;(Optioneel) Open issues/problemen/risico’s&gt;*

## &lt;Naam black box 2&gt;

*&lt;black box template&gt;*

### &lt;Naam black box n&gt;

*&lt;black box template&gt;*

### &lt;Naam interface 1&gt;

…​

### &lt;Naam interface m&gt;

## Niveau 2

### White Box *&lt;bouwsteen 1&gt;*

*&lt;white box template&gt;*

### White Box *&lt;bouwsteen 2&gt;*

*&lt;white box template&gt;*

…​

### White Box *&lt;bouwsteen m&gt;*

*&lt;white box template&gt;*

## Niveau 3

### White Box *&lt;bouwsteen x.1&gt;*

*&lt;white box template&gt;*

### White Box *&lt;bouwsteen x.2&gt;*

*&lt;white box template&gt;*

### White Box *&lt;bouwsteen y.1&gt;*

*&lt;white box template&gt;*

# Runtime View

## &lt;Runtime Scenario 1&gt;

-   *&lt;voeg een runtime diagram of een tekstuele beschrijving van het
    scenario toe&gt;*

-   *&lt;voeg een beschrijving toe van bijzondere aspecten van de
    interactie tussen de instanties van de bouwstenen die in dit diagram
    worden weergegeven&gt;*

## &lt;Runtime Scenario 2&gt;

## …​

## &lt;Runtime Scenario n&gt;

# Deployment View

## Infrastructuur Niveau 1

***&lt;Overzichts Diagram&gt;***

Motivatie  
*&lt;uitleg in tekstuele vorm&gt;*

Kwaliteit en/of Performance Eigenschappen  
*&lt;uitleg in tekstuele vorm&gt;*

Mapping van Bouwstenen naar Infrastructuur  
*&lt;beschrijving van de mapping&gt;*

## Infrastructuur Niveau 2

### *&lt;Infrastructuur Element 1&gt;*

*&lt;diagram + uitleg&gt;*

### *&lt;Infrastructuur Element 2&gt;*

*&lt;diagram + uitleg&gt;*

…​

### *&lt;Infrastructuur Element n&gt;*

*&lt;diagram + uitleg&gt;*

# Cross-cutting Concepten

## *&lt;Concept 1&gt;*

*&lt;uitleg&gt;*

## *&lt;Concept 2&gt;*

*&lt;uitleg&gt;*

…​

## *&lt;Concept n&gt;*

*&lt;uitleg&gt;*

# Architectuur Beslissingen

# Kwaliteits Requirements

## Kwaliteits Boom

## Kwaliteits Scenarios

# Risico’s en Technical Debt

# Woordenlijst

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Term</th>
<th style="text-align: left;">Definitie</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Term-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definitie-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Term-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definitie-2&gt;</em></p></td>
</tr>
</tbody>
</table>
