# Bouwstenen View

## Gehele whitebox Systeem

***&lt;Overzichts Diagram>***

Motivatie  
*&lt;tekstuele uitleg>*

Ingesloten bouwstenen  
*&lt;Beschrijving van ingesloten bouwstenen (*black boxes*)>*

Belangrijke Interfaces  
*&lt;Beschrijving van belangrijke interfaces>*

### &lt;Naam black box 1>

*&lt;Doel/Verantwoordelijkheid>*

*&lt;Interface(s)>*

*&lt;((Optioneel) Kwaliteits-/Prestatie karakteristieken>*

*&lt;(Optioneel) directories/bestand locaties>*

*&lt;(Optioneel) Vervulde requirements>*

*&lt;(Optioneel) Open issues/problemen/risico’s>*

## &lt;Naam black box 2>

*&lt;black box template>*

### &lt;Naam black box n>

*&lt;black box template>*

### &lt;Naam interface 1>

…

### &lt;Naam interface m>

## Niveau 2

### White Box *&lt;bouwsteen 1>*

*&lt;white box template>*

### White Box *&lt;bouwsteen 2>*

*&lt;white box template>*

…

### White Box *&lt;bouwsteen m>*

*&lt;white box template>*

## Niveau 3

### White Box *&lt;bouwsteen x.1>*

*&lt;white box template>*

### White Box *&lt;bouwsteen x.2>*

*&lt;white box template>*

### White Box *&lt;bouwsteen y.1>*

*&lt;white box template>*
