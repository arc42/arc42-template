# Bouwstenen View

## Gehele whitebox Systeem

***&lt;Overzichts Diagram&gt;***

Motivatie  
*&lt;tekstuele uitleg&gt;*

Ingesloten bouwstenen  
*&lt;Beschrijving van ingesloten bouwstenen (*black boxes*)&gt;*

Belangrijke Interfaces  
*&lt;Beschrijving van belangrijke interfaces&gt;*

### &lt;Naam black box 1&gt;

*&lt;Doel/Verantwoordelijkheid&gt;*

*&lt;Interface(s)&gt;*

*&lt;((Optioneel) Kwaliteits-/Prestatie karakteristieken&gt;*

*&lt;(Optioneel) directories/bestand locaties&gt;*

*&lt;(Optioneel) Vervulde requirements&gt;*

*&lt;(Optioneel) Open issues/problemen/risico’s&gt;*

## &lt;Naam black box 2&gt;

*&lt;black box template&gt;*

### &lt;Naam black box n&gt;

*&lt;black box template&gt;*

### &lt;Naam interface 1&gt;

…

### &lt;Naam interface m&gt;

## Niveau 2

### White Box *&lt;bouwsteen 1&gt;*

*&lt;white box template&gt;*

### White Box *&lt;bouwsteen 2&gt;*

*&lt;white box template&gt;*

…

### White Box *&lt;bouwsteen m&gt;*

*&lt;white box template&gt;*

## Niveau 3

### White Box *&lt;bouwsteen x.1&gt;*

*&lt;white box template&gt;*

### White Box *&lt;bouwsteen x.2&gt;*

*&lt;white box template&gt;*

### White Box *&lt;bouwsteen y.1&gt;*

*&lt;white box template&gt;*
