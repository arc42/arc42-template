# Архитектурные ограничения {#section-architecture-constraints}
