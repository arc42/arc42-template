# Перекрёстные концепции {#section-concepts}

## *\<Концепция 1>* {#__emphasis_1_emphasis}

*\<Пояснения>*

## *\<Концепция 2>* {#__emphasis_2_emphasis}

*\<Пояснения>*

...

## *\<Концепция n>* {#__emphasis_n_emphasis}

*\<Пояснения>*
