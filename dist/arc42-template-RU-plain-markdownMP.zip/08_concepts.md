# Сквозные концепции {#section-concepts}

## *\<Концепция 1>* {#__emphasis_1_emphasis}

*\<объяснение>*

## *\<Концепция 2>* {#__emphasis_2_emphasis}

*\<объяснение>*

...

## *\<Концепция n>* {#__emphasis_n_emphasis}

*\<объяснение>*
