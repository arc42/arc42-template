Стратегия решения {#section-solution-strategy}
=================
