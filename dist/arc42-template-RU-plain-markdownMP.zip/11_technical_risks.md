# Риски и технический долг {#section-technical-risks}
