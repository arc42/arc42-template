# Decisioni di progettazione {#section-design-decisions}
