# Runtime View {#section-runtime-view}

## \<Runtime Scenario 1> {#__runtime_scenario_1}

-   *\<inserire un runtime diagram o una descrizione testuale dello
    scenario>*

-   *\<inserire la descrizione degli aspetti degni di nota delle
    interazioni tra i istanze di building block illustrate in questo
    diagramma.\>*

## \<Runtime Scenario 2> {#__runtime_scenario_2}

## ... {#_}

## \<Runtime Scenario n> {#__runtime_scenario_n}
