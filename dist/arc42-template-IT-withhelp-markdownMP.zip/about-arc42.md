**About arc42**

arc42, the Template for documentation of software and system
architecture.

By Dr. Gernot Starke, Dr. Peter Hruschka and contributors.

Template Revision: 7.0 IT (based on asciidoc), April 2021

© We acknowledge that this document uses material from the arc 42
architecture template, <https://www.arc42.org>. Created by Dr. Peter
Hruschka & Dr. Gernot Starke.
