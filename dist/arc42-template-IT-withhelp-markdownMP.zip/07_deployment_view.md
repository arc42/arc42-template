# Deployment View {#section-deployment-view}

## Livello infrastruttura 1 {#_livello_infrastruttura_1}

***\<Overview Diagram>***

Motivatione

:   *\<spiegazione in forma di testo>*

Requsiti di qualità e/o di prestazioni

:   *\<spiegazione in forma di testo>*

Mappatura dei Building Blocks nella Architettura

:   *\<descrizione della mappatura>*

## Livello infrastruttura 2 {#_livello_infrastruttura_2}

### *\<Elemento infrastruttura 1>* {#__emphasis_elemento_infrastruttura_1_emphasis}

*\<diagramma + spiegazione>*

### *\<Elemento infrastruttura 2>* {#__emphasis_elemento_infrastruttura_2_emphasis}

*\<diagramma + spiegazione>*

...

### *\<Elemento infrastruttura n>* {#__emphasis_elemento_infrastruttura_n_emphasis}

*\<diagramma + spiegazione>*
