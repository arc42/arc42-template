# Concetti trasversali {#section-concepts}

## *\<Concetto 1>* {#__emphasis_concetto_1_emphasis}

*\<spiegazione>*

## *\<Concetto 2>* {#__emphasis_concetto_2_emphasis}

*\<spiegazione>*

...

## *\<Concetto n>* {#__emphasis_concetto_n_emphasis}

*\<spiegazione>*
