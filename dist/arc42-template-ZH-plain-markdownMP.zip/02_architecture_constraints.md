# 架构约束 {#section-architecture-constraints}
