# 

**关于 arc42**

arc42，软件和系统架构文档模板。

模板版本 9.0-ZH。(基于 AsciiDoc 版本)，7月 2025

由 Dr. Peter Hruschka、Dr. Gernot Starke 及贡献者创建、维护和版权所有。
参见 <https://arc42.org> 。
