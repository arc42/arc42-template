================
|arc42| Template
================

:Date: March 2023

**About arc42**

arc42, the Template for documentation of software and system
architecture.

By Dr. Gernot Starke, Dr. Peter Hruschka and contributors.

Template Revision: 7.0 IT (based on asciidoc), April 2021

© We acknowledge that this document uses material from the arc 42
architecture template, https://www.arc42.org. Created by Dr. Peter
Hruschka & Dr. Gernot Starke.

.. _section-introduction-and-goals:

Introduzione e obiettivi
========================

.. _`_panoramica_dei_requisiti`:

Panoramica dei requisiti
------------------------

.. _`_obiettivi_di_qualità`:

Obiettivi di qualità
--------------------

.. _`_stakeholders`:

Stakeholders
------------

+-------------+---------------------------+---------------------------+
| Rouolo/Nome | Contatto                  | Aspettative               |
+=============+===========================+===========================+
| *<Ruolo-1>* | *<Contatto-1>*            | *<Aspettatiive-1>*        |
+-------------+---------------------------+---------------------------+
| *<Ruolo-2>* | *<Contatto-2>*            | *<Aspettatiive-2>*        |
+-------------+---------------------------+---------------------------+

.. _section-architecture-constraints:

Vincoli di architettura
=======================

.. _section-context-and-scope:

Ambito e contesto del sistema
=============================

.. _`_contesto_di_business`:

Contesto di Business
--------------------

**<Diagramma o Tabella>**

**<opzionale: spiegazione delle interfacce del dominio esterno>**

.. _`_contesto_tecnico`:

Contesto Tecnico
----------------

**<Diagramma o Tabella>**

**<opzionale: Spiegazione delle interfacce tecniche>**

**<Mappatura Input/Output sui canali di comunicazione>**

.. _section-solution-strategy:

Strategia della soluzione
=========================

.. _section-building-block-view:

Building Block View
===================

.. _`_whitebox_overall_system`:

Whitebox Overall System
-----------------------

**<Overview Diagram>**

Motivazione
   *<spiegazione testuale>*

Contenuto dei Building Blocks
   *<Descrizione del contenuto del building block (black boxes)>*

Important Interfaces
   *<Descrizione delle interfacce importanti>*

.. _`_nome_black_box_1`:

<Nome black box 1>
~~~~~~~~~~~~~~~~~~

*<Scopo/responsabilità>*

*<Interfacce>*

*<(Facoltativo) Caratteristiche di qualità/prestazionali>*

*<(Facoltativo) percorso file/directory>*

*<(Facoltativo) Requisiti soddisfatti>*

*<(Facoltativo) Bug noti/Rischi/problemi>*

.. _`_nome_black_box_2`:

<Nome black box 2>
~~~~~~~~~~~~~~~~~~

*<black box template>*

.. _`_nome_black_box_n`:

<Nome black box n>
~~~~~~~~~~~~~~~~~~

*<black box template>*

.. _`_nome_interface_1`:

<Nome interface 1>
~~~~~~~~~~~~~~~~~~

…​

.. _`_nome_interface_m`:

<Nome interface m>
~~~~~~~~~~~~~~~~~~

.. _`_livello_2`:

Livello 2
---------

.. _`_white_box_building_block_1`:

White Box *<building block 1>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<white box template>*

.. _`_white_box_building_block_2`:

White Box *<building block 2>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<white box template>*

…​

.. _`_white_box_building_block_m`:

White Box *<building block m>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<white box template>*

.. _`_livello_3`:

Livello 3
---------

.. _`_white_box_building_block_x_1`:

White Box <\_building block x.1\_>
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<white box template>*

.. _`_white_box_building_block_x_2`:

White Box <\_building block x.2\_>
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<white box template>*

.. _`_white_box_building_block_y_1`:

White Box <\_building block y.1\_>
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<white box template>*

.. _section-runtime-view:

Runtime View
============

.. _`_runtime_scenario_1`:

<Runtime Scenario 1>
--------------------

-  *<inserire un runtime diagram o una descrizione testuale dello
   scenario>*

-  *<inserire la descrizione degli aspetti degni di nota delle
   interazioni tra i istanze di building block illustrate in questo
   diagramma.>*

.. _`_runtime_scenario_2`:

<Runtime Scenario 2>
--------------------

…​
-

.. _`_runtime_scenario_n`:

<Runtime Scenario n>
--------------------

.. _section-deployment-view:

Deployment View
===============

.. _`_livello_infrastruttura_1`:

Livello infrastruttura 1
------------------------

**<Overview Diagram>**

Motivatione
   *<spiegazione in forma di testo>*

Requsiti di qualità e/o di prestazioni
   *<spiegazione in forma di testo>*

Mappatura dei Building Blocks nella Architettura
   *<descrizione della mappatura>*

.. _`_livello_infrastruttura_2`:

Livello infrastruttura 2
------------------------

.. _`_elemento_infrastruttura_1`:

*<Elemento infrastruttura 1>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<diagramma + spiegazione>*

.. _`_elemento_infrastruttura_2`:

*<Elemento infrastruttura 2>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<diagramma + spiegazione>*

…​

.. _`_elemento_infrastruttura_n`:

*<Elemento infrastruttura n>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<diagramma + spiegazione>*

.. _section-concepts:

Concetti trasversali
====================

.. _`_concetto_1`:

*<Concetto 1>*
--------------

*<spiegazione>*

.. _`_concetto_2`:

*<Concetto 2>*
--------------

*<spiegazione>*

…​

.. _`_concetto_n`:

*<Concetto n>*
--------------

*<spiegazione>*

.. _section-design-decisions:

Decisioni di progettazione
==========================

.. _section-quality-scenarios:

Requisiti di Qualità
====================

.. _`_albero_di_qualità`:

Albero di qualità
-----------------

.. _`_scenari_di_qualità`:

Scenari di qualità
------------------

.. _section-technical-risks:

Rischi e debiti tecnici
=======================

.. _section-glossary:

Glossario
=========

+----------------------+-----------------------------------------------+
| Termine              | Definizione                                   |
+======================+===============================================+
| *<Termine-1>*        | *<definizione-1>*                             |
+----------------------+-----------------------------------------------+
| *<Termine-2>*        | *<definizione-2>*                             |
+----------------------+-----------------------------------------------+

.. |arc42| image:: images/arc42-logo.png
