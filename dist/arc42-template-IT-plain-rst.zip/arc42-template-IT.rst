**About arc42**

arc42, the Template for documentation of software and system
architecture.

By Dr. Gernot Starke, Dr. Peter Hruschka and contributors.

Template Revision: 7.0 IT (based on asciidoc), April 2021

© We acknowledge that this document uses material from the arc 42
architecture template, http://www.arc42.de. Created by Dr. Peter
Hruschka & Dr. Gernot Starke.

.. _section-introduction-and-goals:

Introduzione e obiettivi
========================

.. __panoramica_dei_requisiti:

Panoramica dei requisiti
------------------------

.. __obiettivi_di_qualit:

Obiettivi di qualità
--------------------

.. __stakeholders:

Stakeholders
------------

+-------------+---------------------------+---------------------------+
| Rouolo/Nome | Contatto                  | Aspettative               |
+=============+===========================+===========================+
| *<Ruolo-1>* | *<Contatto-1>*            | *<Aspettatiive-1>*        |
+-------------+---------------------------+---------------------------+
| *<Ruolo-2>* | *<Contatto-2>*            | *<Aspettatiive-2>*        |
+-------------+---------------------------+---------------------------+

.. _section-architecture-constraints:

Vincoli di architettura
=======================

.. _section-system-scope-and-context:

Ambito e contesto del sistema
=============================

.. __contesto_di_business:

Contesto di Business
--------------------

**<Diagramma o Tabella>**

**<opzionale: spiegazione delle interfacce del dominio esterno>**

.. __contesto_tecnico:

Contesto Tecnico
----------------

**<Diagramma o Tabella>**

**<opzionale: Spiegazione delle interfacce tecniche>**

**<Mappatura Input/Output sui canali di comunicazione>**

.. _section-solution-strategy:

Strategia della soluzione
=========================

.. _section-building-block-view:

Building Block View
===================

.. __whitebox_overall_system:

Whitebox Overall System
-----------------------

**<Overview Diagram>**

Motivazione
   *<spiegazione testuale>*

Contenuto dei Building Blocks
   *<Descrizione del contenuto del building block (black boxes)>*

Important Interfaces
   *<Descrizione delle interfacce importanti>*

.. ___nome_black_box_1:

<Nome black box 1>
~~~~~~~~~~~~~~~~~~

*<Scopo/responsabilità>*

*<Interfacce>*

*<(Facoltativo) Caratteristiche di qualità/prestazionali>*

*<(Facoltativo) percorso file/directory>*

*<(Facoltativo) Requisiti soddisfatti>*

*<(Facoltativo) Bug noti/Rischi/problemi>*

.. ___nome_black_box_2:

<Nome black box 2>
~~~~~~~~~~~~~~~~~~

*<black box template>*

.. ___nome_black_box_n:

<Nome black box n>
~~~~~~~~~~~~~~~~~~

*<black box template>*

.. ___nome_interface_1:

<Nome interface 1>
~~~~~~~~~~~~~~~~~~

…

.. ___nome_interface_m:

<Nome interface m>
~~~~~~~~~~~~~~~~~~

.. __livello_2:

Livello 2
---------

.. __white_box_emphasis_building_block_1_emphasis:

White Box *<building block 1>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<white box template>*

.. __white_box_emphasis_building_block_2_emphasis:

White Box *<building block 2>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<white box template>*

…

.. __white_box_emphasis_building_block_m_emphasis:

White Box *<building block m>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<white box template>*

.. __livello_3:

Livello 3
---------

.. __white_box_building_block_x_1:

White Box <_building block x.1_>
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<white box template>*

.. __white_box_building_block_x_2:

White Box <_building block x.2_>
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<white box template>*

.. __white_box_building_block_y_1:

White Box <_building block y.1_>
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<white box template>*

.. _section-runtime-view:

Runtime View
============

.. ___runtime_scenario_1:

<Runtime Scenario 1>
--------------------

-  *<inserire un runtime diagram o una descrizione testuale dello
   scenario>*

-  *<inserire la descrizione degli aspetti degni di nota delle
   interazioni tra i istanze di building block illustrate in questo
   diagramma.>*

.. ___runtime_scenario_2:

<Runtime Scenario 2>
--------------------

.. __:

…
-

.. ___runtime_scenario_n:

<Runtime Scenario n>
--------------------

.. _section-deployment-view:

Deployment View
===============

.. __livello_infrastruttura_1:

Livello infrastruttura 1
------------------------

**<Overview Diagram>**

Motivatione
   *<spiegazione in forma di testo>*

Requsiti di qualità e/o di prestazioni
   *<spiegazione in forma di testo>*

Mappatura dei Building Blocks nella Architettura
   *<descrizione della mappatura>*

.. __livello_infrastruttura_2:

Livello infrastruttura 2
------------------------

.. ___emphasis_elemento_infrastruttura_1_emphasis:

*<Elemento infrastruttura 1>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<diagramma + spiegazione>*

.. ___emphasis_elemento_infrastruttura_2_emphasis:

*<Elemento infrastruttura 2>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<diagramma + spiegazione>*

…

.. ___emphasis_elemento_infrastruttura_n_emphasis:

*<Elemento infrastruttura n>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<diagramma + spiegazione>*

.. _section-concepts:

Concetti trasversali
====================

.. ___emphasis_concetto_1_emphasis:

*<Concetto 1>*
--------------

*<spiegazione>*

.. ___emphasis_concetto_2_emphasis:

*<Concetto 2>*
--------------

*<spiegazione>*

…

.. ___emphasis_concetto_n_emphasis:

*<Concetto n>*
--------------

*<spiegazione>*

.. _section-design-decisions:

Decisioni di progettazione
==========================

.. _section-quality-scenarios:

Requisiti di Qualità
====================

.. __albero_di_qualit:

Albero di qualità
-----------------

.. __scenari_di_qualit:

Scenari di qualità
------------------

.. _section-technical-risks:

Rischi e debiti tecnici
=======================

.. _section-glossary:

Glossario
=========

+-----------------------+-----------------------------------------------+
| Termine               | Definizione                                   |
+=======================+===============================================+
| *<Termine-1>*         | *<definizione-1>*                             |
+-----------------------+-----------------------------------------------+
| *<Termine-2>*         | *<definizione-2>*                             |
+-----------------------+-----------------------------------------------+

.. |arc42| image:: images/arc42-logo.png
