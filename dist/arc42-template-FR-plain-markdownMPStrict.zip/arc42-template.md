# 

**A propos d’arc42**

arc42, le modèle de documentation de l’architecture des logiciels et des
systèmes.

Version du modèle 8.2 FR. (basé sur la version AsciiDoc), January 2023

Créé, maintenu et © par Dr. Peter Hruschka, Dr. Gernot Starke et les
contributeurs. Voir <https://arc42.org>.

# Introduction et Objectifs

## Aperçu des spécifications

## Objectifs de Qualité

## Parties prenantes

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Rôle/Nom</th>
<th style="text-align: left;">Contact</th>
<th style="text-align: left;">Attentes</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Role-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Contact-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Attente-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Role-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Contact-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Attente-2&gt;</em></p></td>
</tr>
</tbody>
</table>

# Contraintes d’Architecture

# Contexte et périmètre

## Contexte métier

**&lt;Schéma ou tableau>**

**&lt;éventuellement : Explication des interfaces de domaines
externes>**

## Contexte Technique

**&lt;Schéma ou tableau>**

**&lt;en option : Explication des interfaces techniques>**

**&lt;Correspondance des entrées/sorties aux canaux>**

# Stratégie de solution

# Vue en Briques

## Niveau 1 : Système global Boîte blanche

***&lt;Schéma d’ensemble>***

Motivation  
*&lt;texte explicatif>*

Briques contenues  
*&lt;Description de la brique contenue (boîte noire)>*

Interfaces Importantes  
*&lt;Description des interfaces importantes>*

### &lt;Nom boîte noire 1>

*&lt;Objectif/Responsabilité>*

*&lt;Interface(s)>*

*&lt;(Facultatif) Caractéristiques de qualité/performance>*

*&lt;(Facultatif) Emplacement du répertoire/fichier>*

*&lt;(Facultatif) Exigences respectées>*

*&lt;(Facultatif) Questions ouvertes/problèmes/risques>*

### &lt;Nom boîte noire 2>

*&lt;template boîte noire>*

### &lt;Nom boîte noire n>

*&lt;template boîte noire>*

### &lt;Nom interface 1>

…

### &lt;Nom interface m>

## Niveau 2

### Boîte blanche *&lt;brique 1>*

*&lt;template boîte blanche>*

### Boîte blanche *&lt;brique 2>*

*&lt;template boîte blanche>*

…

### Boîte blanche *&lt;brique n>*

*&lt;template boîte blanche>*

# Vue Exécution

## &lt;Scénario d’exécution 1>

-   *&lt;insérer un diagramme d’exécution ou une description textuelle
    du scénario>*

-   *&lt;insérer une description des aspects notables des interactions
    entre les instances des briques représentées dans ce diagramme.>*

## &lt;Scénario d’exécution 2>

## …

## &lt;Scénario d’exécution n>

# Vue Déploiement

## Infrastructure Niveau 1

***&lt;Schéma d’ensemble>***

Motivation  
*&lt;explication sous forme de texte>*

Caractéristiques de qualité et/ou de performance  
*&lt;explication sous forme de texte>*

Correspondance des briques vis à vis de l’infrastructure  
*&lt;description de la correspondance>*

## Infrastructure Niveau 2

### *&lt;Infrastructure Element 1>*

*&lt;schéma + explication>*

### *&lt;Infrastructure Element 2>*

*&lt;schéma + explication>*

…

### *&lt;Infrastructure Element n>*

*&lt;schéma + explication>*

# Concepts transversaux

## *&lt;Concept 1>*

*&lt;explication>*

## *&lt;Concept 2>*

*&lt;explication>*

…

## *&lt;Concept n>*

*&lt;explication>*

# Décisions d’architecture

# Critères de qualité

## Arbre de qualité

## Scénarios Qualité

# Risques et Dettes techniques

# Glossaire

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Terme</th>
<th style="text-align: left;">Définition</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Terme-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Définition-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Terme-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Définition-2&gt;</em></p></td>
</tr>
</tbody>
</table>
