# Vue Exécution

## &lt;Scénario d’exécution 1>

-   *&lt;insérer un diagramme d’exécution ou une description textuelle
    du scénario>*

-   *&lt;insérer une description des aspects notables des interactions
    entre les instances des briques représentées dans ce diagramme.>*

## &lt;Scénario d’exécution 2>

## …

## &lt;Scénario d’exécution n>
