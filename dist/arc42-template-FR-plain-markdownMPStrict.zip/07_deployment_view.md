# Vue Déploiement

## Infrastructure Niveau 1

***&lt;Schéma d’ensemble>***

Motivation  
*&lt;explication sous forme de texte>*

Caractéristiques de qualité et/ou de performance  
*&lt;explication sous forme de texte>*

Correspondance des briques vis à vis de l’infrastructure  
*&lt;description de la correspondance>*

## Infrastructure Niveau 2

### *&lt;Infrastructure Element 1>*

*&lt;schéma + explication>*

### *&lt;Infrastructure Element 2>*

*&lt;schéma + explication>*

…

### *&lt;Infrastructure Element n>*

*&lt;schéma + explication>*
