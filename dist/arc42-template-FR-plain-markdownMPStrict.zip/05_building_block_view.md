# Vue en Briques

## Niveau 1 : Système global Boîte blanche

***&lt;Schéma d’ensemble>***

Motivation  
*&lt;texte explicatif>*

Briques contenues  
*&lt;Description de la brique contenue (boîte noire)>*

Interfaces Importantes  
*&lt;Description des interfaces importantes>*

### &lt;Nom boîte noire 1>

*&lt;Objectif/Responsabilité>*

*&lt;Interface(s)>*

*&lt;(Facultatif) Caractéristiques de qualité/performance>*

*&lt;(Facultatif) Emplacement du répertoire/fichier>*

*&lt;(Facultatif) Exigences respectées>*

*&lt;(Facultatif) Questions ouvertes/problèmes/risques>*

### &lt;Nom boîte noire 2>

*&lt;template boîte noire>*

### &lt;Nom boîte noire n>

*&lt;template boîte noire>*

### &lt;Nom interface 1>

…

### &lt;Nom interface m>

## Niveau 2

### Boîte blanche *&lt;brique 1>*

*&lt;template boîte blanche>*

### Boîte blanche *&lt;brique 2>*

*&lt;template boîte blanche>*

…

### Boîte blanche *&lt;brique n>*

*&lt;template boîte blanche>*
