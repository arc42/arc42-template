# Perspektiva chování za běhu (runtime) {#section-runtime-view}

## \<Scénář runtime 1> {#__sc_n_runtime_1}

-   *\<vložte runtime diagram nebo textový popis scénáře>*

-   *\<vložte popis důležitých interakcí mezi instancemi stavebních
    bloků zobrazených v tomto diagramu>*

## \<Scénář runtime 2> {#__sc_n_runtime_2}

## ... {#_}

## \<Scénář runtime n> {#__sc_n_runtime_n}
