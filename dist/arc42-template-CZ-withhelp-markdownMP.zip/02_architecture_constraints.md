# Omezení na realizaci systému {#section-architecture-constraints}

::: formalpara-title
**Obsah**
:::

Jakýkoli požadavek, který softwarové architekty omezuje v jejich svobodě
rozhodování o návrhu a implementaci nebo v rozhodování o procesu vývoje.
Tato omezení někdy přesahují jednotlivé systémy a platí pro celé
organizace a společnosti.

::: formalpara-title
**Motivace**
:::

Softwarový Architekt by měl přesně vědět, které části systému může
určovat a kde musí dodržovat vnější omezení. S omezeními je třeba se
vždy vypořádat; mohou být ale předmětem vyjednávaní.

::: formalpara-title
**Forma**
:::

Tabulka se (všemi) omezeními, včetně jejich vysvětlení. V případě
potřeby rozdělená na technická, organizační nebo politická omezení či
konvence (např. co se týče programovaní, verzí systému, dokumentace nebo
pojmenování)

Anglická dokumentace arc42: [Architecture
Constraints](https://docs.arc42.org/section-2/).
