# Úvod a cíle {#section-introduction-and-goals}

## Přehled požadavků {#_přehled_požadavků}

## Kvalitativní cíle {#_kvalitativní_cíle}

## Strany zainteresované na systému (stakeholder) {#_strany_zainteresované_na_systému_stakeholder}

+--------------+---------------------------+---------------------------+
| Role/Jméno   | Kontakt                   | Očekávání                 |
+==============+===========================+===========================+
| *\<Role-1\>* | *\<Kontakt-1\>*           | *\<Očekávání-1\>*         |
+--------------+---------------------------+---------------------------+
| *\<Role-2\>* | *\<Kontakt-2\>*           | *\<Očekávání-2\>*         |
+--------------+---------------------------+---------------------------+
