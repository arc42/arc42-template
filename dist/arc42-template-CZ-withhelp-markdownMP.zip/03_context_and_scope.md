# Vymezení a rozsah systému {#section-context-and-scope}

## Firemní kontext {#_firemní_kontext}

**\<vložte diagram nebo tabulku\>**

**\<(volitelně:) vložte vysvětlení externích doménových rozhraní\>**

## Technický kontext {#_technický_kontext}

**\<vložte diagram nebo tabulku\>**

**\<(volitelně:) vložte vysvětlení externích technických rozhraní\>**

**\<mapování doménových vstupu/výstupu na technické kanály\>**
