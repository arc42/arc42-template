# Rizika a technické dluhy {#section-technical-risks}

:::::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Obsah
:::

Seznam známých technických rizik nebo technických dluhů seřazený podle
jejich priority.
::::

:::: formalpara
::: title
Motivace
:::

„Řízení rizik je řízení projektu pro dospělé." --- Tim Lister, Atlantic
Systems Guild
::::

Tak by mělo znít motto pro systematické zjišťování a hodnocení rizik a
technických dluhů v architektuře, které potřebují znát zainteresované
strany z oblasti managementu (například projektoví manažeři, vlastníci
produktu - (Product Owner)) jako součást celkové analýzy rizik.

:::: formalpara
::: title
Forma
:::

Seznam rizik a/nebo technických dluhů, pravděpodobně včetně navrhovaných
opatření k jejich minimalizaci, zmírnění nebo vyloučení.
::::

:::: formalpara
::: title
Další informace
:::

Anglická dokumentace arc42: [Risks and Technical
Debt](https://docs.arc42.org/section-11/).
::::
::::::::::::
