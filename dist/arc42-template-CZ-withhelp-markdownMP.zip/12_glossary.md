# Slovník pojmů {#section-glossary}

:::::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Obsah
:::

Nejdůležitější doménové a technické termíny, které zainteresované strany
používají při diskuzi o systému.
::::

Pokud pracujete ve vícejazyčných týmech, můžete glosář používat jako
zdroj překladů.

:::: formalpara
::: title
Motivace
:::

Je důležité jasně definovat klíčové pojmy, aby všechny zainteresované
strany
::::

- chápaly tyto pojmy stejně

- a aby neexistovalo pro jednu a stejnou věc více variant

<div>

::: title
Forma
:::

- Tabulka se sloupci \<Termín\> a \<Definice\>.

- Potenciálně více sloupců v případě, že potřebujete překlady.

</div>

:::: formalpara
::: title
Další informace
:::

Anglická dokumentace arc42:
[Glossary](https://docs.arc42.org/section-12/).
::::
::::::::::::

+----------------------+-----------------------------------------------+
| Termín               | Definice                                      |
+======================+===============================================+
| *\<termín-1\>*       | *\<definice-1\>*                              |
+----------------------+-----------------------------------------------+
| *\<termín-2\>*       | *\<definice-2\>*                              |
+----------------------+-----------------------------------------------+
