# Průřezové (cross-cutting) koncepty {#section-concepts}

## *\<Koncept 1\>* {#_koncept_1}

*\<vysvětlení\>*

## *\<Koncept 2\>* {#_koncept_2}

*\<vysvětlení\>*

...​

## *\<Koncept n\>* {#_koncept_n}

*\<vysvětlení\>*
