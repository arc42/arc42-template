# Průřezové (cross-cutting) koncepty {#section-concepts}

::: formalpara-title
**Obsah**
:::

Tato část dokumentace popisuje přesahující principy, předpisy a řešení,
které jsou relevantní pro více částí systému (= průřezové). Takové
koncepty se často týkají více stavebních bloků.

Může zahrnovat mnoho různých témat, jako např.

-   modely, zejména doménové modely

-   architekturu nebo designové vzory

-   pravidla pro použití konkrétních technologií

-   zásadní, často technická rozhodnutí zastřešujícího (= průřezového)
    charakteru

-   pravidla implementace

::: formalpara-title
**Motivace**
:::

Koncepty tvoří základ *konceptuální integrity* (konzistence, homogenity)
softwarové architektury. Jsou tedy důležitým příspěvkem k dosažení
vnitřní kvality vyvíjeného systému.

Některé z těchto konceptů nelze přiřadit k jednotlivým stavebním blokům,
např. zabezpečení.

::: formalpara-title
**Forma**
:::

Forma může být různá:

-   koncepční dokumenty s jakoukoliv strukturou

-   průřezové modely nebo scénáře, které jsou již využity v jednotlivých
    perspektivách architektury

-   vzorové implementace, zejména pro technické koncepty

-   odkaz na \"typické\" používání standardních frameworků (např.
    používání Hibernate pro objektové/relační mapování)

::: formalpara-title
**Struktura**
:::

Potenciální (nikoli však povinná) struktura pro tento oddíl dokumentace
může být:

-   Koncepty domén

-   Koncepty uživatelské zkušenosti (UX)

-   Koncepty bezpečnosti a zabezpečení

-   Architektura a designové vzory

-   \"pod kapotou\"

-   Vývojové koncepty

-   Provozní koncepty

Poznámka: Může být obtížné přiřadit jednotlivé koncepty k jednomu
konkrétnímu tématu z tohoto seznamu.

![Témata pro průřezové
koncepty](images/08-Crosscutting-Concepts-Structure-EN.png)

Anglická dokumentace arc42:
[Concepts](https://docs.arc42.org/section-8/).

## *\<Koncept 1>* {#__emphasis_koncept_1_emphasis}

*\<vysvětlení>*

## *\<Koncept 2>* {#__emphasis_koncept_2_emphasis}

*\<vysvětlení>*

...

## *\<Koncept n>* {#__emphasis_koncept_n_emphasis}

*\<vysvětlení>*
