# Perspektiva stavebních bloků {#section-building-block-view}

::: formalpara-title
**Obsah**
:::

Perspektiva stavebních bloků ukazuje statický rozklad systému na
stavební bloky (moduly, komponenty, subsystémy, třídy, rozhraní,
balíčky, knihovny, framework, oddíly, vrstvy, funkce, makra, operace,
datové struktury, ...) stejně jako jejich vzájemné závislosti (vztahy,
asociace, ...).

Toto perspektiva je povinná pro každou dokumentaci architektury, stejně
jako je to u domu jeho *půdorys*.

::: formalpara-title
**Motivace**
:::

Udržujte si přehled o zdrojovém kódu tím, že jeho strukturu učiníte
srozumitelnou prostřednictvím abstrakce.

To vám umožní komunikovat se zainteresovanými stranami na abstraktní
úrovni, aniž byste prozradili podrobnosti o implementaci.

::: formalpara-title
**Forma**
:::

Perspektiva stavebních bloků je hierarchický přehled \"černých\" a
\"bílých\" skříněk (black-box, white-box, viz obrázek níže) a jejich
popisů.

![Hierarchie stavebních bloků](images/05_building_blocks-EN.png)

**Úroveň 1** je popis celého systému jako white-box spolu s popisem
všech obsažených stavebních bloků ve formátu black-box.

**Úroveň 2** přibližuje některé stavební bloky úrovně 1. Obsahuje tedy
popis vybraných stavebních bloků úrovně 1 jako white-box spolu s popisy
jejich vnitřních stavebních bloků jako black-box.

**Úroveň 3** přiblíží vybrané stavební bloky úrovně 2 a tak dále.

Anglická dokumentace arc42: [Building Block
View](https://docs.arc42.org/section-5/).

## Celý systém jako white-box {#_cel_syst_m_jako_white_box}

Zde popisujete rozklad celého systému pomocí následující white-box
šablony. Obsahuje

-   přehledový diagram

-   motivaci k rozkladu

-   popis jednotlivých stavebních bloků jako black-box. K tomu jsou k
    dispozici různé alternativy:

    -   použijte *jednu* tabulku pro krátký a pragmatický přehled všech
        obsažených stavebních bloků a jejich rozhraní.

    -   použijte seznam stavebních bloků popsaných podle black-box
        šablony (viz níže). V závislosti na výběru konkrétního nástroje
        může tento seznam obsahovat podkapitoly (v textových souborech),
        podstránky (ve Wiki) nebo vnořené prvky (v modelovacím
        nástroji).

-   (Volitelně:) důležitá rozhraní, která nejsou vysvětlena v black-box
    šablonách stavebního bloku, ale jsou velmi důležitá pro pochopení
    popisovaného white-boxu. Protože existuje mnoho způsobů, jak
    specifikovat rozhraní, neposkytujeme žádnou konkrétní šablonu. V
    nejhorším případě musíte specifikovat a popsat syntax, sémantiku,
    protokoly, zpracování chyb, různá omezení, verze, nároky na kvalitu,
    potřebnou kompatibilitu a mnoho dalších věcí. V lepším případě vám
    stačí příklady nebo jednoduché podpisy.

***\<vložte přehledový diagram celého systému>***

Motivace

:   *\<popište motivaci>*

Obsažené stavební bloky

:   *\<popište obsažené stavební bloky (jako black-box)>*

Důležitá rozhraní

:   *\<popište důležitá rozhraní>*

Vložte vysvětlení black-boxů z úrovně 1:

Pokud použijete tabulkovou formu, popište black-boxy pouze jménem a
odpovědností podle následujícího schématu:

+-----------------------+-----------------------------------------------+
| **Jméno**             | **Odpovědnost**                               |
+=======================+===============================================+
| *\<black-box 1>*      |  *\<Text>*                                    |
+-----------------------+-----------------------------------------------+
| *\<black-box 2>*      |  *\<Text>*                                    |
+-----------------------+-----------------------------------------------+

Pokud použijete seznam popisů jednotlivých black-boxů, vyplňte
samostatnou black-box šablonu pro každý důležitý stavební blok. Její
titulek je název black-boxu.

### \<Jméno black-boxu 1> {#__jm_no_black_boxu_1}

Popište \<black-box 1> podle následující black-box šablony:

-   Účel/Odpovědnost

-   Rozhraní, pokud nejsou vyjmuta jako samostatné odstavce. Případně
    sem patří nároky na kvalitu a výkonnostní rozhraní.

-   (Volitelně) Popis požadavků na kvalitu/výkon black-boxu, např.
    dostupnost, runtime vlastnosti, ....

-   (Volitelně) Umístění/složky a soubory

-   (Volitelně) Splněné požadavky (pokud potřebujete dohledat vztah k
    požadavkům).

-   (Volitelně) Nevyřešené body/problémy/rizika

*\<Účel/Odpovědnost>*

*\<Rozhraní>*

*\<(Volitelně) Požadavky na kvalitu/výkon>*

*\<(Volitelně) Umístění/složky a soubory>*

*\<(Volitelně) Splněné požadavky>*

*\<(Volitelně) Nevyřešené body/problémy/rizika>*

### \<Jméno black-boxu 2> {#__jm_no_black_boxu_2}

*\<šablona black-box>*

### \<Jméno black-boxu n> {#__jm_no_black_boxu_n}

*\<šablona black-box>*

### \<Jméno rozhraní 1> {#__jm_no_rozhran_1}

...

### \<Jméno rozhraní m> {#__jm_no_rozhran_m}

## Úroveň 2 {#__rove_2}

Zde popište vnitřní strukturu (některých) stavebních bloků z úrovně 1
jako white-box.

Musíte rozhodnout, které stavební bloky systému jsou natolik důležité,
aby ospravedlnily tak podrobný popis. Upřednostněte relevanci před
úplností. Uveďte důležité, překvapivé, riskantní, komplexní nebo
volatilní stavební bloky. Vynechejte normální, jednoduché nebo
standardizované části systému.

### white-box *\<stavební blok 1>* {#_white_box_emphasis_stavebn_blok_1_emphasis}

...popisuje vnitřní strukturu *stavebního bloku 1*.

*\<šablona white-box>*

### white-box *\<stavební blok 2>* {#_white_box_emphasis_stavebn_blok_2_emphasis}

*\<šablona white-box>*

...

### white-box *\<stavební blok m>* {#_white_box_emphasis_stavebn_blok_m_emphasis}

*\<šablona white-box>*

## Úroveň 3 {#__rove_3}

Zde můžete popsat vnitřní strukturu (některých) stavebních bloků z
úrovně 2 jako white-box.

Pokud potřebujete podrobnější úrovně architektury, zkopírujte si pro ně
tuto část arc42.

### white-box \<\_stavební blok x.1\_\> {#_white_box_stavebn_blok_x_1}

...popisuje vnitřní strukturu *stavebního bloku x.1*.

*\<šablona white-box>*

### white-box \<\_stavební blok x.2\_\> {#_white_box_stavebn_blok_x_2}

*\<šablona white-box>*

### white-box \<\_stavební blok y.1\_\> {#_white_box_stavebn_blok_y_1}

*\<šablona white-box>*
