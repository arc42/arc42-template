# 

**O arc42**

arc42, šablona pro dokumentaci softwaru a architekturu systému.

Verze šablony 9.0-CZ. (na základě AsciiDoc verze), Leden 2025

Created, maintained and © by Dr. Peter Hruschka, Dr. Gernot Starke and
contributors. Viz <https://arc42.org>.

Tato verze arc42 šablony obsahuje nápovědu a vysvětlivky a slouží proto
k seznámení s arc42 a pochopení pojmů. Pro dokumentaci vašeho vlastního
systému použijte raději *plain* verzi.

# Úvod a cíle

Shrnuje klíčové požadavky a omezení, se kterými musí softwaroví
architekti i vývojový tým počítat. Patří sem zejména:

-   hlavní obchodní cíle,

-   základní vlastnosti systému,

-   funkční požadavky,

-   kvalitativní cíle architektury,

-   zainteresované strany systému (stakeholder) a jejich potřeby.

## Přehled požadavků

**Obsah**

Stručný popis (shrnutí či abstrakt) funkčních i kvalitativních
požadavků. Odkaz na (doufejme existující) dokumentaci požadavků (s
číslem verze a informacemi, kde ji najít).

**Motivace**

Z hlediska koncových uživatelů je cílem vývoje nebo změny systému
zlepšení jeho funkcí k plnění obchodních cílů a/nebo zlepšení jeho
kvality.

**Forma**

Stručný popis, pravděpodobně ve formátu tabulkového přehledu funkcí
(use-case). Pokud existují dokumenty požadavků, měl by na ně tento
přehled odkazovat.

Udržujte tento popis co nejkratší (z hlediska čitelnosti), ale tak aby
nebyly zbytečně opakovány informace z dokumentace požadavků.

**Další informace**

Anglická dokumentace arc42: [Introduction and
Goals](https://docs.arc42.org/section-1/).

## Kvalitativní cíle

**Obsah**

Tři (maximálně pět) nejdůležitějších kvalitativních cílů pro
architekturu, jejichž splnění je pro hlavní zainteresované strany
nejdůležitější. Jedná se skutečně o kvalitativní cíle pro architekturu.
Nepleťte si je s cíli projektu, ty nemusí být nutně totožné.

Norma ISO 25010 poskytuje přehled jednotlivých oblastí:

<figure>
<img src="images/01_2_iso-25010-topics-EN-2023.drawio.png"
alt="Kategorie kvalitativních cílů" />
</figure>

**Motivace**

Je vhodné znát kvalitativní cíle klíčových zainteresovaných stran
systému, protože ty ovlivní zásadní architektonická rozhodnutí. Ujistěte
se, že jsou tyto požadavky na systém jednoznačné či měřitelné, vyvarujte
se vágních formulací.

**Forma**

Tabulka s nejdůležitějšími kvalitativními cíli a praktickými scénáři,
seřazená podle priorit.

## Strany zainteresované na systému (stakeholder)

**Obsah**

Jasný přehled všech stran zainteresovaných na systému, tedy všech osob,
rolí nebo organizací, které

-   by měli architekturu znát,

-   by měli s architekturou souhlasit,

-   budou s architekturou nebo s kódem pracovat,

-   ke své práci potřebují dokumentaci architektury,

-   rozhodují o vývoji a designu systému.

**Motivace**

Je vhodné znát všechny strany zapojené do vývoje systému (nebo systémem
ovlivněné). Jinak se může stát, že se později v procesu vývoje objeví
nepříjemná překvapení. Zainteresované strany ovlivňují rozsah a úroveň
detailu vaší práce a jejích výsledků.

**Forma**

Tabulka s názvy rolí, jmény osob a jejich očekáváním na architekturu a
její dokumentaci.

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Role/Jméno</th>
<th style="text-align: left;">Kontakt</th>
<th style="text-align: left;">Očekávání</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Role-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Kontakt-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Očekávání-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Role-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Kontakt-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Očekávání-2&gt;</em></p></td>
</tr>
</tbody>
</table>

# Omezení na realizaci systému

**Obsah**

Jakýkoli požadavek, který software-architektům omezuje prostor pro
rozhodování o návrhu a implementaci nebo pro rozhodování o procesu
vývoje. Tato omezení někdy přesahují jednotlivé systémy a platí pro celé
organizace a společnosti.

**Motivace**

Softwarový Architekt by měl přesně vědět, které části systému může
určovat a kde musí dodržovat vnější omezení. S omezeními je třeba se
vždy vypořádat; mohou být ale předmětem vyjednávaní.

**Forma**

Tabulka se (všemi) omezeními, včetně jejich vysvětlení. V případě
potřeby rozdělená na technická, organizační nebo politická omezení či
konvence (například co se týče programovaní, verzí systému, dokumentace
nebo pojmenování)

**Další informace**

Anglická dokumentace arc42: [Architecture
Constraints](https://docs.arc42.org/section-2/).

# Vymezení a rozsah systému

**Obsah**

Rozsah a kontext systému vymezují – jak název napovídá – systém od všech
jeho komunikačních partnerů (sousední systémy a uživatelé). Tím se
specifikují externí rozhraní (interface) systému a určí zodpovědnost:
Které funkce patří do našeho systému a které do systémů sousedních.

V případě potřeby odlište firemní kontext (doménově specifické vstupy a
výstupy) od technického kontextu (kanály, protokoly, hardware).

**Motivace**

Doménová a technická komunikační rozhraní patří mezi nejdůležitější
aspekty systému. Ujistěte se, že jim zcela rozumíte.

**Forma**

Různé možnosti:

-   Kontextové diagramy

-   Seznam komunikačních partnerů a příslušné rozhraní

**Další informace**

Anglická dokumentace arc42: [Context and
Scope](https://docs.arc42.org/section-3/).

## Firemní kontext

**Obsah**

Specifikace **všech** komunikačních partnerů systému (uživatelů, IT
systémů, …) s vysvětlením doménově specifických vstupů a výstupů nebo
rozhraní. Podle potřeby můžete přidat doménově specifické datové formáty
nebo komunikační protokoly.

**Motivace**

Všechny zainteresované strany by měly rozumět tomu, jaké doménové
informace si systém vyměňuje s okolím.

**Forma**

Různé druhy diagramů, které ukazují systém jako černou skříňku (black
box) a popisují doménová rozhraní pro komunikaci s partnery.

Alternativně (nebo jako doplnění) můžete použít tabulku. Titulek tabulky
je název systému, tři sloupce obsahují: jméno komunikačního partnera,
vstupy a výstupy.

**&lt;vložte diagram nebo tabulku&gt;**

**&lt;(volitelně:) vložte vysvětlení externích doménových rozhraní&gt;**

## Technický kontext

**Obsah**

Technická rozhraní (kanály a přenosová média) propojující váš systém s
jeho okolím. Navíc mapování doménově specifického vstupu/výstupu na tyto
kanály, tj. vysvětlení, která doménová data používají který kanál.

**Motivace**

Mnoho zainteresovaných stran činí architektonická rozhodnutí na základě
technických rozhraní mezi systémem a jeho okolím. Zejména při výběru
infrastruktury nebo hardwaru jsou tato technická rozhraní rozhodující.

**Forma**

Např. UML Diagram popisující technické napojení sousedních systémů spolu
s tabulkou ukazující vztahy mezi technickými kanály a doménovým
vstupem/výstupem.

**&lt;vložte diagram nebo tabulku&gt;**

**&lt;(volitelně:) vložte vysvětlení externích technických
rozhraní&gt;**

**&lt;mapování doménových vstupu/výstupu na technické kanály&gt;**

# Strategie řešení

**Obsah**

Krátké shrnutí a vysvětlení zásadních rozhodnutí a strategií řešení,
které utvářejí architekturu systému. Tyto zahrnují

-   technologická rozhodnutí

-   rozhodnutí o dekompozici systému na nejvyšší úrovni (top-level),
    například o použití vzoru (pattern) pro architekturu nebo návrh

-   rozhodnutí o tom, jak dosáhnout klíčových kvalitativních cílů

-   příslušná organizační rozhodnutí, například výběr procesu vývoje
    nebo delegování určitých úkolů na třetí strany.

**Motivace**

Tato rozhodnutí tvoří pilíře softwarové architektury. Jsou základem pro
mnoho dalších detailních rozhodnutí nebo pravidel implementace.

**Forma**

Vysvětlení těchto klíčových rozhodnutí ponechte **krátké**.

Popište, jak jste se rozhodli a proč jste se tak rozhodli, s ohledem na
řešení problému, cíle kvality a klíčová omezení. Pro podrobnosti odkažte
na následující části.

**Další informace**

Anglická dokumentace arc42: [Solution
Strategy](https://docs.arc42.org/section-4/).

# Perspektiva stavebních bloků

**Obsah**

Perspektiva stavebních bloků ukazuje statický rozklad systému na
stavební bloky (moduly, komponenty, subsystémy, třídy, rozhraní,
balíčky, knihovny, framework, oddíly, vrstvy, funkce, makra, operace,
datové struktury, …) stejně jako jejich vzájemné závislosti (vztahy,
asociace, …).

Toto perspektiva je povinná pro každou dokumentaci architektury, stejně
jako je to u domu jeho *půdorys*.

**Motivace**

Udržujte si přehled o zdrojovém kódu tím, že jeho strukturu učiníte
srozumitelnou prostřednictvím abstrakce.

To vám umožní komunikovat se zainteresovanými stranami na abstraktní
úrovni, aniž byste prozradili podrobnosti o implementaci.

**Forma**

Perspektiva stavebních bloků je hierarchický přehled "černých" a
"bílých" skříněk (black-box, white-box, viz obrázek níže) a jejich
popisů.

<figure>
<img src="images/05_building_blocks-EN.png"
alt="Hierarchie stavebních bloků" />
</figure>

**Úroveň 1** je popis celého systému jako white-box spolu s popisem
všech obsažených stavebních bloků ve formátu black-box.

**Úroveň 2** přibližuje některé stavební bloky úrovně 1. Obsahuje tedy
popis vybraných stavebních bloků úrovně 1 jako white-box spolu s popisy
jejich vnitřních stavebních bloků jako black-box.

**Úroveň 3** přiblíží vybrané stavební bloky úrovně 2 a tak dále.

**Další informace**

Anglická dokumentace arc42: [Building Block
View](https://docs.arc42.org/section-5/).

## Celý systém jako white-box

Zde popisujete rozklad celého systému pomocí následující white-box
šablony. Obsahuje

-   přehledový diagram

-   motivaci k rozkladu

-   popis jednotlivých stavebních bloků jako black-box. K tomu jsou k
    dispozici různé alternativy:

    -   použijte *jednu* tabulku pro krátký a pragmatický přehled všech
        obsažených stavebních bloků a jejich rozhraní.

    -   použijte seznam stavebních bloků popsaných podle black-box
        šablony (viz níže). V závislosti na výběru konkrétního nástroje
        může tento seznam obsahovat podkapitoly (v textových souborech),
        podstránky (ve Wiki) nebo vnořené prvky (v modelovacím
        nástroji).

-   (Volitelně:) důležitá rozhraní, která nejsou vysvětlena v black-box
    šablonách stavebního bloku, ale jsou velmi důležitá pro pochopení
    popisovaného white-boxu. Protože existuje mnoho způsobů, jak
    specifikovat rozhraní, neposkytujeme žádnou konkrétní šablonu. V
    nejhorším případě musíte specifikovat a popsat syntax, sémantiku,
    protokoly, zpracování chyb, různá omezení, verze, nároky na kvalitu,
    potřebnou kompatibilitu a mnoho dalších věcí. V lepším případě vám
    stačí příklady nebo jednoduché podpisy.

***&lt;vložte přehledový diagram celého systému&gt;***

Motivace  
*&lt;popište motivaci&gt;*

Obsažené stavební bloky  
*&lt;popište obsažené stavební bloky (jako black-box)&gt;*

Důležitá rozhraní  
*&lt;popište důležitá rozhraní&gt;*

Vložte vysvětlení black-boxů z úrovně 1:

Pokud použijete tabulkovou formu, popište black-boxy pouze jménem a
odpovědností podle následujícího schématu:

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;"><strong>Jméno</strong></th>
<th style="text-align: left;"><strong>Odpovědnost</strong></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;black-box 1&gt;</em></p></td>
<td style="text-align: left;"><p> <em>&lt;Text&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;black-box 2&gt;</em></p></td>
<td style="text-align: left;"><p> <em>&lt;Text&gt;</em></p></td>
</tr>
</tbody>
</table>

Pokud použijete seznam popisů jednotlivých black-boxů, vyplňte
samostatnou black-box šablonu pro každý důležitý stavební blok. Její
titulek je název black-boxu.

### &lt;Jméno black-boxu 1&gt;

Popište &lt;black-box 1&gt; podle následující black-box šablony:

-   Účel/Odpovědnost

-   Rozhraní, pokud nejsou vyjmuta jako samostatné odstavce. Případně
    sem patří nároky na kvalitu a výkonnostní rozhraní.

-   (Volitelně) Popis požadavků na kvalitu/výkon black-boxu, například
    dostupnost, runtime vlastnosti, ….

-   (Volitelně) Umístění/složky a soubory

-   (Volitelně) Splněné požadavky (pokud potřebujete dohledat vztah k
    požadavkům).

-   (Volitelně) Nevyřešené body/problémy/rizika

*&lt;Účel/Odpovědnost&gt;*

*&lt;Rozhraní&gt;*

*&lt;(Volitelně) Požadavky na kvalitu/výkon&gt;*

*&lt;(Volitelně) Umístění/složky a soubory&gt;*

*&lt;(Volitelně) Splněné požadavky&gt;*

*&lt;(Volitelně) Nevyřešené body/problémy/rizika&gt;*

### &lt;Jméno black-boxu 2&gt;

*&lt;šablona black-box&gt;*

### &lt;Jméno black-boxu n&gt;

*&lt;šablona black-box&gt;*

### &lt;Jméno rozhraní 1&gt;

…​

### &lt;Jméno rozhraní m&gt;

## Úroveň 2

Zde popište vnitřní strukturu (některých) stavebních bloků z úrovně 1
jako white-box.

Musíte rozhodnout, které stavební bloky systému jsou natolik důležité,
aby ospravedlnily tak podrobný popis. Upřednostněte relevanci před
úplností. Uveďte důležité, překvapivé, riskantní, komplexní nebo
volatilní stavební bloky. Vynechejte normální, jednoduché nebo
standardizované části systému.

### white-box *&lt;stavební blok 1&gt;*

…​popisuje vnitřní strukturu *stavebního bloku 1*.

*&lt;šablona white-box&gt;*

### white-box *&lt;stavební blok 2&gt;*

*&lt;šablona white-box&gt;*

…​

### white-box *&lt;stavební blok m&gt;*

*&lt;šablona white-box&gt;*

## Úroveň 3

Zde můžete popsat vnitřní strukturu (některých) stavebních bloků z
úrovně 2 jako white-box.

Pokud potřebujete podrobnější úrovně architektury, zkopírujte si pro ně
tuto část arc42.

### white-box &lt;\_stavební blok x.1\_&gt;

…​popisuje vnitřní strukturu *stavebního bloku x.1*.

*&lt;šablona white-box&gt;*

### white-box &lt;\_stavební blok x.2\_&gt;

*&lt;šablona white-box&gt;*

### white-box &lt;\_stavební blok y.1\_&gt;

*&lt;šablona white-box&gt;*

# Perspektiva chování za běhu (runtime)

**Obsah**

Perspektiva runtime popisuje konkrétní chování a interakce stavebních
bloků systému ve formě scénářů v následujících oblastech:

-   důležité procesy nebo funkce: jak je stavební bloky systému
    provádějí?

-   interakce na kritických externích rozhraních: jak spolupracují
    stavební bloky s uživateli a sousedními systémy?

-   provoz a administrace: prvotní konfigurace, spuštění, zastavení

-   scénáře pro chyby a výjimky

Poznámka: Hlavním kritériem pro výběr dokumentovaných scénářů (sekvencí,
pracovních postupů) je jejich **význam pro architekturu**. Není cílem
popisovat velké množství scénářů, ale raději **reprezentativní** výběr.

**Motivace**

Je důležité rozumět tomu, jak stavební bloky systému (nebo jejich
instance) vykonávají svoji práci a jak spolu komunikují za běhu. Ve této
části dokumentace popište především scénáře, kterými architekturu
vysvětlíte těm stranám zainteresovaným na systému, které jsou méně
ochotné nebo schopné číst a chápat statické modely (perspektivu
stavebních bloků, perspektivu nasazení softwaru).

**Forma**

Existuje mnoho notací pro popis scénářů, například

-   očíslovaný seznam jednotlivých kroků (jako text)

-   diagramy aktivit nebo vývojové diagramy (flow chart)

-   sekvenční diagramy

-   Business Process Model and Notation (BPMN) nebo Event-driven Process
    Chain (EPC)

-   konečné automaty nebo přechodové systémy

-   …​

**Další informace**

Anglická dokumentace arc42: [Runtime
View](https://docs.arc42.org/section-6/).

## &lt;Scénář runtime 1&gt;

-   *&lt;vložte runtime diagram nebo textový popis scénáře&gt;*

-   *&lt;vložte popis důležitých interakcí mezi instancemi stavebních
    bloků zobrazených v tomto diagramu&gt;*

## &lt;Scénář runtime 2&gt;

## …​

## &lt;Scénář runtime n&gt;

# Perspektiva nasazení softwaru (deployment)

**Obsah**

Perspektiva nasazení softwaru popisuje:

1.  technickou infrastrukturu, na které systém poběží, s jednotlivými
    prvky infrastruktury, jako jsou například geografická poloha,
    prostředí, počítače, procesory, kanály a topologie sítí a další,
    jakož i

2.  mapování (softwarových) stavebních bloků na jednotlivé prvky této
    infrastruktury.

Systémy bývají často spouštěny v různých prostředích, například
vývojovém prostředí, testovacím prostředí, produkčním prostředí. V
takových případech by měla být zdokumentována všechna relevantní
prostředí.

Zejména dokumentujte perspektivu nasazení softwaru, pokud je software
provozován jako distribuovaný systém s více než jedním počítačem,
procesorem, serverem nebo kontejnerem nebo když jsou navrhovány a
konstruovány vlastní hardwarové procesory a čipy.

Z hlediska softwaru stačí zachytit pouze ty prvky infrastruktury, které
jsou potřebné k ukázce nasazení jednotlivých stavebních bloků.
Hardwaroví architekti mohou jít dále a popsat infrastrukturu do té
úrovně detailů, kterou je potřeba zachytit.

**Motivace**

Software neběží bez hardwaru. Tato infrastruktura může a bude ovlivňovat
systém a/nebo některé průřezové koncepty. Proto je potřeba ji znát.

**Forma**

Možná je diagram nasazení softwaru na nejvyšší úrovni již obsažen v
části 3.2. jako technický kontext s vlastní infrastrukturou jako JEDEN
black-box. V této sekci lze tento black-box přiblížit pomocí dalších
diagramů nasazení:

-   UML nabízí diagramy nasazení k vyjádření této perspektivy. Použijte
    je, pravděpodobně s vnořenými diagramy, když je infrastruktura
    složitější.

-   Když strany zainteresované na hardwaru preferují jiné druhy diagramů
    než diagram nasazení, nechte je použít jakýkoli druh, který je
    schopen zobrazit uzly a kanály infrastruktury.

**Další informace**

Anglická dokumentace arc42: [Deployment
View](https://docs.arc42.org/section-7/).

## Úroveň infrastruktury 1

Popište (obvykle kombinací diagramů, tabulek a textu):

-   distribuci systému na více míst, prostředí, počítačů, procesorů,..,
    jakož i fyzická propojení mezi nimi

-   důležité důvody nebo motivaci pro tuto strukturu nasazení

-   kvalitativní a/nebo výkonnostní vlastnosti této infrastruktury

-   mapování softwarových artefaktů na prvky této infrastruktury

Pro více prostředí nebo alternativní nasazení zkopírujte a upravte tuto
část arc42 pro všechna relevantní prostředí.

***&lt;Přehledový diagram&gt;***

Motivace  
*&lt;vysvětlení v textové podobě&gt;*

Kvalitativní a/nebo výkonnostní vlastnosti  
*&lt;vysvětlení v textové podobě&gt;*

Mapování softwarových artefaktů na prvky infrastruktury  
*&lt;popis mapování&gt;*

## Úroveň infrastruktury 2

Zde můžete zahrnout vnitřní strukturu (některých) prvků infrastruktury z
úrovně 1.

Zkopírujte prosím strukturu z úrovně 1 pro každý vybraný prvek.

### *&lt;prvek infrastruktury 1&gt;*

*&lt;diagram + vysvětlení&gt;*

### *&lt;prvek infrastruktury 2&gt;*

*&lt;diagram + vysvětlení&gt;*

…​

### *&lt;prvek infrastruktury n&gt;*

*&lt;diagram + vysvětlení&gt;*

# Průřezové (cross-cutting) koncepty

**Obsah**

Tato část dokumentace popisuje přesahující principy, předpisy a řešení,
které jsou relevantní pro více částí systému (= průřezové). Takové
koncepty se často týkají více stavebních bloků.

Může zahrnovat mnoho různých témat, jako například

-   modely, zejména doménové modely

-   architekturu nebo designové vzory

-   pravidla pro použití konkrétních technologií

-   zásadní, často technická rozhodnutí zastřešujícího (= průřezového)
    charakteru

-   pravidla implementace

**Motivace**

Koncepty tvoří základ *konceptuální integrity* (konzistence, homogenity)
softwarové architektury. Jsou tedy důležitým příspěvkem k dosažení
vnitřní kvality vyvíjeného systému.

Některé z těchto konceptů nelze přiřadit k jednotlivým stavebním blokům,
například zabezpečení.

**Forma**

Forma může být různá:

-   koncepční dokumenty s jakoukoliv strukturou

-   průřezové modely nebo scénáře, které jsou již využity v jednotlivých
    perspektivách architektury

-   vzorové implementace, zejména pro technické koncepty

-   odkaz na "typické" používání standardních frameworků (například
    používání Hibernate pro objektové/relační mapování)

**Struktura**

Potenciální (nikoli však povinná) struktura pro tento oddíl dokumentace
může být:

-   Koncepty domén

-   Koncepty uživatelské zkušenosti (UX)

-   Koncepty bezpečnosti a zabezpečení

-   Architektura a designové vzory

-   "pod kapotou"

-   Vývojové koncepty

-   Provozní koncepty

Poznámka: Může být obtížné přiřadit jednotlivé koncepty k jednomu
konkrétnímu tématu z tohoto seznamu.

<figure>
<img src="images/08-concepts-EN.drawio.png"
alt="Témata pro průřezové koncepty" />
</figure>

**Další informace**

Anglická dokumentace arc42:
[Concepts](https://docs.arc42.org/section-8/).

## *&lt;Koncept 1&gt;*

*&lt;vysvětlení&gt;*

## *&lt;Koncept 2&gt;*

*&lt;vysvětlení&gt;*

…​

## *&lt;Koncept n&gt;*

*&lt;vysvětlení&gt;*

# Rozhodnutí o architektuře

**Obsah**

Důležitá, drahá, rozsáhlá nebo riskantní rozhodnutí o architektuře
včetně příslušných zdůvodnění. „Rozhodnutím“ rozumíme výběr jedné nebo
více alternativ na základě daných kritérií.

Uvažte, zda má být architektonické rozhodnutí zdokumentována zde v této
centrální sekci, nebo zda je lepší je zdokumentovat lokálně (například v
šabloně white-box konkrétního stavebního bloku).

Vyvarujte se opakovaní. Odkažte na 4. kapitolu, kde jste již zachytili
nejdůležitější architektonická rozhodnutí.

**Motivace**

Strany zainteresované na systému by měly být schopny přijatým
rozhodnutím porozumět a pochopit důvody k ním vedoucí.

**Forma**

Různé možnosti:

-   **ADR** <span class="indexterm"
    primary="Architecture Decision Record"></span>[Architecture Decision
    Record](https://thinkrelevance.com/blog/2011/11/15/documenting-architecture-decisions)
    pro každé důležité rozhodnutí

-   seznam nebo tabulka, seřazené podle důležitosti a důsledků

-   podrobněji ve formě samostatných podkapitol pro jednotlivá
    rozhodnutí

**Další informace**

Anglická dokumentace arc42: [Architecture
Decisions](https://docs.arc42.org/section-9/). Zde najdete odkazy a
příklady k tématu **ADR**.

# Požadavky na kvalitu

**Obsah**

Tato kapitola shrnuje všechny relevantní požadavky na kvalitu.

Nejdůležitější z těchto požadavků již byly popsány v kapitole 1.2
(kvalitativní cíle), a proto by zde měly být pouze odkázány. V této
kapitole (10) je vhodné zaznamenat i méně důležité požadavky na kvalitu,
jejichž nesplnění nepředstavuje zásadní riziko, ale které mohou být
užitečné či žádoucí (*nice-to-have*).

**Motivace**

Požadavky na kvalitu mají výrazný vliv na architektonická rozhodnutí. Je
proto důležité znát kvalitativní očekávání zainteresovaných stran, a to
konkrétně a měřitelně.

-   Dokumentace arc42: [Quality
    Requirements](https://docs.arc42.org/section-10/)

-   Model kvality Q42: [Q42 quality model na
    https://quality.arc42.org](https://quality.arc42.org).

## Přehled požadavků na kvalitu

**Obsah**

Stručný přehled požadavků na kvalitu.

**Motivace**

V praxi se často setkáváme s desítkami či stovkami požadavků na kvalitu.
Tento přehled by měl nabídnout jejich kategorizaci či shrnutí –
například dle standardu [ISO
25010:2023](https://www.iso.org/obp/ui/#iso:std:iso-iec:25010:ed-2:v1:en)
nebo podle [modelu Q42](https://quality.arc42.org).

Pokud je tento přehled dostatečně konkrétní, specifický a měřitelný,
může být část 10.2 vynechána.

**Forma**

Použijte jednoduchou tabulku, kde každý řádek reprezentuje kategorii
nebo typ požadavku na kvalitu spolu s krátkým popisem. Alternativně lze
využít mind map pro vizuální strukturování požadavků. V literatuře se
také vyskytuje pojem *strom kvalitativních atributů* (*Quality Attribute
Utility Tree*), který rozvíjí pojem „kvalita“ jako kořenový uzel stromu
s větvemi představujícími konkrétní požadavky.

## Scénáře kvality

**Obsah**

Scénáře kvality konkretizují požadavky na kvalitu a umožňují ověřit, zda
byly splněny (například pomocí akceptačních kritérií). Scénáře by měly
být jednoznačné a měřitelné.

Dva typy scénářů jsou obzvláště užitečné:

-   *Scénáře použití* (též aplikační nebo provozní scénáře) popisují
    chování systému v reakci na určitý podnět v runtime – včetně
    výkonnosti, odezvy apod. Příklad: Systém odpoví na požadavek
    uživatele do jedné sekundy.

-   *Scénáře změn* popisují chování systému při jeho úpravách nebo
    rozšiřování, případně změnách okolního prostředí. Příklad: Do
    systému je doplněna nová funkce, mění se požadavek na kvalitu a měří
    se náročnost změny.

**Forma**

Typická struktura scénáře může mít dvě podoby:

-   **Krátká forma** (upřednostňuje ji model Q42):

-   **Kontext**: O jaký systém nebo komponentu se jedná? Jaké je okolí
    nebo situace?

-   **Zdroj/Podnět**: Kdo nebo co spouští chování nebo reakci systému?

-   **Kritérium/Metoda ověření**: Jak poznáme, že je požadavek splněn?
    (metrika, měřitelný výstup)

-   **Dlouhá forma** (používaná v SEI, např. \[Bass+21\]):

-   **ID scénáře**

-   **Název scénáře**

-   **Zdroj** (uživatel, systém, událost)

-   **Podnět**

-   **Provozní prostředí**

-   **Artefakt** (část systému, která je podnětem ovlivněna)

-   **Odezva**

-   **Metrika odezvy** (kritérium pro hodnocení odezvy systému)

**Příklady**

Viz [model kvality Q42](https://quality.arc42.org) pro detailní ukázky
scénářů.

-   Len Bass, Paul Clements, Rick Kazman: *Software Architecture in
    Practice*, 4. vydání, Addison-Wesley, 2021.

# Rizika a technické dluhy

**Obsah**

Seznam známých technických rizik nebo technických dluhů seřazený podle
jejich priority.

**Motivace**

„Řízení rizik je řízení projektu pro dospělé.“ — Tim Lister, Atlantic
Systems Guild

Tak by mělo znít motto pro systematické zjišťování a hodnocení rizik a
technických dluhů v architektuře, které potřebují znát zainteresované
strany z oblasti managementu (například projektoví manažeři, vlastníci
produktu - (Product Owner)) jako součást celkové analýzy rizik.

**Forma**

Seznam rizik a/nebo technických dluhů, pravděpodobně včetně navrhovaných
opatření k jejich minimalizaci, zmírnění nebo vyloučení.

**Další informace**

Anglická dokumentace arc42: [Risks and Technical
Debt](https://docs.arc42.org/section-11/).

# Slovník pojmů

**Obsah**

Nejdůležitější doménové a technické termíny, které zainteresované strany
používají při diskuzi o systému.

Pokud pracujete ve vícejazyčných týmech, můžete glosář používat jako
zdroj překladů.

**Motivace**

Je důležité jasně definovat klíčové pojmy, aby všechny zainteresované
strany

-   chápaly tyto pojmy stejně

-   a aby neexistovalo pro jednu a stejnou věc více variant

<!-- -->

-   Tabulka se sloupci &lt;Termín&gt; a &lt;Definice&gt;.

-   Potenciálně více sloupců v případě, že potřebujete překlady.

**Další informace**

Anglická dokumentace arc42:
[Glossary](https://docs.arc42.org/section-12/).

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Termín</th>
<th style="text-align: left;">Definice</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;termín-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definice-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;termín-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definice-2&gt;</em></p></td>
</tr>
</tbody>
</table>
