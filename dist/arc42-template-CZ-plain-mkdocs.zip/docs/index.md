---
hide:
   - navigation
---

# Arc42 Template


**O arc42**

arc42, šablona pro dokumentaci softwaru a architekturu systému.

Verze šablony 9.0-CZ. (na základě AsciiDoc verze), Leden 2025

Created, maintained and © by Dr. Peter Hruschka, Dr. Gernot Starke and contributors. Viz <https://arc42.org>.

## Úvod a cíle {#section-introduction-and-goals}

### Přehled požadavků {#_přehled_požadavků}

### Kvalitativní cíle {#_kvalitativní_cíle}

### Strany zainteresované na systému (stakeholder) {#_strany_zainteresované_na_systému_stakeholder}

 Role/Jméno       | Kontakt             | Očekávání             |
------------------|---------------------|-----------------------|
 *&lt;Role-1&gt;* | *&lt;Kontakt-1&gt;* | *&lt;Očekávání-1&gt;* |
 *&lt;Role-2&gt;* | *&lt;Kontakt-2&gt;* | *&lt;Očekávání-2&gt;* |

## Omezení na realizaci systému {#section-architecture-constraints}

## Vymezení a rozsah systému {#section-context-and-scope}

### Firemní kontext {#_firemní_kontext}

**&lt;vložte diagram nebo tabulku&gt;**

**&lt;(volitelně:) vložte vysvětlení externích doménových rozhraní&gt;**

### Technický kontext {#_technický_kontext}

**&lt;vložte diagram nebo tabulku&gt;**

**&lt;(volitelně:) vložte vysvětlení externích technických rozhraní&gt;**

**&lt;mapování doménových vstupu/výstupu na technické kanály&gt;**

## Strategie řešení {#section-solution-strategy}

## Perspektiva stavebních bloků {#section-building-block-view}

### Celý systém jako white-box {#_celý_systém_jako_white_box}

***&lt;vložte přehledový diagram celého systému&gt;***

Motivace

:   *&lt;popište motivaci&gt;*

Obsažené stavební bloky

:   *&lt;popište obsažené stavební bloky (jako black-box)&gt;*

Důležitá rozhraní

:   *&lt;popište důležitá rozhraní&gt;*

#### &lt;Jméno black-boxu 1&gt; {#_jméno_black_boxu_1}

*&lt;Účel/Odpovědnost&gt;*

*&lt;Rozhraní&gt;*

*&lt;(Volitelně) Požadavky na kvalitu/výkon&gt;*

*&lt;(Volitelně) Umístění/složky a soubory&gt;*

*&lt;(Volitelně) Splněné požadavky&gt;*

*&lt;(Volitelně) Nevyřešené body/problémy/rizika&gt;*

#### &lt;Jméno black-boxu 2&gt; {#_jméno_black_boxu_2}

*&lt;šablona black-box&gt;*

#### &lt;Jméno black-boxu n&gt; {#_jméno_black_boxu_n}

*&lt;šablona black-box&gt;*

#### &lt;Jméno rozhraní 1&gt; {#_jméno_rozhraní_1}

…​

#### &lt;Jméno rozhraní m&gt; {#_jméno_rozhraní_m}

### Úroveň 2 {#_úroveň_2}

#### white-box *&lt;stavební blok 1&gt;* {#_white_box_stavební_blok_1}

*&lt;šablona white-box&gt;*

#### white-box *&lt;stavební blok 2&gt;* {#_white_box_stavební_blok_2}

*&lt;šablona white-box&gt;*

…​

#### white-box *&lt;stavební blok m&gt;* {#_white_box_stavební_blok_m}

*&lt;šablona white-box&gt;*

### Úroveň 3 {#_úroveň_3}

#### white-box &lt;\_stavební blok x.1\_&gt; {#_white_box_stavební_blok_x_1}

*&lt;šablona white-box&gt;*

#### white-box &lt;\_stavební blok x.2\_&gt; {#_white_box_stavební_blok_x_2}

*&lt;šablona white-box&gt;*

#### white-box &lt;\_stavební blok y.1\_&gt; {#_white_box_stavební_blok_y_1}

*&lt;šablona white-box&gt;*

## Perspektiva chování za běhu (runtime) {#section-runtime-view}

### &lt;Scénář runtime 1&gt; {#_scénář_runtime_1}

- *&lt;vložte runtime diagram nebo textový popis scénáře&gt;*

- *&lt;vložte popis důležitých interakcí mezi instancemi stavebních bloků zobrazených v tomto diagramu&gt;*

### &lt;Scénář runtime 2&gt; {#_scénář_runtime_2}

### …​

### &lt;Scénář runtime n&gt; {#_scénář_runtime_n}

## Perspektiva nasazení softwaru (deployment) {#section-deployment-view}

### Úroveň infrastruktury 1 {#_úroveň_infrastruktury_1}

***&lt;Přehledový diagram&gt;***

Motivace

:   *&lt;vysvětlení v textové podobě&gt;*

Kvalitativní a/nebo výkonnostní vlastnosti

:   *&lt;vysvětlení v textové podobě&gt;*

Mapování softwarových artefaktů na prvky infrastruktury

:   *&lt;popis mapování&gt;*

### Úroveň infrastruktury 2 {#_úroveň_infrastruktury_2}

#### *&lt;prvek infrastruktury 1&gt;* {#_prvek_infrastruktury_1}

*&lt;diagram + vysvětlení&gt;*

#### *&lt;prvek infrastruktury 2&gt;* {#_prvek_infrastruktury_2}

*&lt;diagram + vysvětlení&gt;*

…​

#### *&lt;prvek infrastruktury n&gt;* {#_prvek_infrastruktury_n}

*&lt;diagram + vysvětlení&gt;*

## Průřezové (cross-cutting) koncepty {#section-concepts}

### *&lt;Koncept 1&gt;* {#_koncept_1}

*&lt;vysvětlení&gt;*

### *&lt;Koncept 2&gt;* {#_koncept_2}

*&lt;vysvětlení&gt;*

…​

### *&lt;Koncept n&gt;* {#_koncept_n}

*&lt;vysvětlení&gt;*

## Rozhodnutí o architektuře {#section-design-decisions}

## Požadavky na kvalitu {#section-quality-scenarios}

### Přehled požadavků na kvalitu {#_přehled_požadavků_na_kvalitu}

### Scénáře kvality {#_scénáře_kvality}

## Rizika a technické dluhy {#section-technical-risks}

## Slovník pojmů {#section-glossary}

 Termín             | Definice             |
--------------------|----------------------|
 *&lt;termín-1&gt;* | *&lt;definice-1&gt;* |
 *&lt;termín-2&gt;* | *&lt;definice-2&gt;* |

  [arc42]: images/arc42-logo.png
  [Úvod a cíle]: #section-introduction-and-goals {#toc-section-introduction-and-goals}
  [Přehled požadavků]: #_přehled_požadavků {#toc-_přehled_požadavků}
  [Kvalitativní cíle]: #_kvalitativní_cíle {#toc-_kvalitativní_cíle}
  [Strany zainteresované na systému (stakeholder)]: #_strany_zainteresované_na_systému_stakeholder {#toc-_strany_zainteresované_na_systému_stakeholder}
  [Omezení na realizaci systému]: #section-architecture-constraints {#toc-section-architecture-constraints}
  [Vymezení a rozsah systému]: #section-context-and-scope {#toc-section-context-and-scope}
  [Firemní kontext]: #_firemní_kontext {#toc-_firemní_kontext}
  [Technický kontext]: #_technický_kontext {#toc-_technický_kontext}
  [Strategie řešení]: #section-solution-strategy {#toc-section-solution-strategy}
  [Perspektiva stavebních bloků]: #section-building-block-view {#toc-section-building-block-view}
  [Celý systém jako white-box]: #_celý_systém_jako_white_box {#toc-_celý_systém_jako_white_box}
  [&lt;Jméno black-boxu 1&gt;]: #_jméno_black_boxu_1 {#toc-_jméno_black_boxu_1}
  [&lt;Jméno black-boxu 2&gt;]: #_jméno_black_boxu_2 {#toc-_jméno_black_boxu_2}
  [&lt;Jméno black-boxu n&gt;]: #_jméno_black_boxu_n {#toc-_jméno_black_boxu_n}
  [&lt;Jméno rozhraní 1&gt;]: #_jméno_rozhraní_1 {#toc-_jméno_rozhraní_1}
  [&lt;Jméno rozhraní m&gt;]: #_jméno_rozhraní_m {#toc-_jméno_rozhraní_m}
  [Úroveň 2]: #_úroveň_2 {#toc-_úroveň_2}
  [white-box *&lt;stavební blok 1&gt;*]: #_white_box_stavební_blok_1 {#toc-_white_box_stavební_blok_1}
  [white-box *&lt;stavební blok 2&gt;*]: #_white_box_stavební_blok_2 {#toc-_white_box_stavební_blok_2}
  [white-box *&lt;stavební blok m&gt;*]: #_white_box_stavební_blok_m {#toc-_white_box_stavební_blok_m}
  [Úroveň 3]: #_úroveň_3 {#toc-_úroveň_3}
  [white-box &lt;\_stavební blok x.1\_&gt;]: #_white_box_stavební_blok_x_1 {#toc-_white_box_stavební_blok_x_1}
  [white-box &lt;\_stavební blok x.2\_&gt;]: #_white_box_stavební_blok_x_2 {#toc-_white_box_stavební_blok_x_2}
  [white-box &lt;\_stavební blok y.1\_&gt;]: #_white_box_stavební_blok_y_1 {#toc-_white_box_stavební_blok_y_1}
  [Perspektiva chování za běhu (runtime)]: #section-runtime-view {#toc-section-runtime-view}
  [&lt;Scénář runtime 1&gt;]: #_scénář_runtime_1 {#toc-_scénář_runtime_1}
  [&lt;Scénář runtime 2&gt;]: #_scénář_runtime_2 {#toc-_scénář_runtime_2}
  [&lt;Scénář runtime n&gt;]: #_scénář_runtime_n {#toc-_scénář_runtime_n}
  [Perspektiva nasazení softwaru (deployment)]: #section-deployment-view {#toc-section-deployment-view}
  [Úroveň infrastruktury 1]: #_úroveň_infrastruktury_1 {#toc-_úroveň_infrastruktury_1}
  [Úroveň infrastruktury 2]: #_úroveň_infrastruktury_2 {#toc-_úroveň_infrastruktury_2}
  [*&lt;prvek infrastruktury 1&gt;*]: #_prvek_infrastruktury_1 {#toc-_prvek_infrastruktury_1}
  [*&lt;prvek infrastruktury 2&gt;*]: #_prvek_infrastruktury_2 {#toc-_prvek_infrastruktury_2}
  [*&lt;prvek infrastruktury n&gt;*]: #_prvek_infrastruktury_n {#toc-_prvek_infrastruktury_n}
  [Průřezové (cross-cutting) koncepty]: #section-concepts {#toc-section-concepts}
  [*&lt;Koncept 1&gt;*]: #_koncept_1 {#toc-_koncept_1}
  [*&lt;Koncept 2&gt;*]: #_koncept_2 {#toc-_koncept_2}
  [*&lt;Koncept n&gt;*]: #_koncept_n {#toc-_koncept_n}
  [Rozhodnutí o architektuře]: #section-design-decisions {#toc-section-design-decisions}
  [Požadavky na kvalitu]: #section-quality-scenarios {#toc-section-quality-scenarios}
  [Přehled požadavků na kvalitu]: #_přehled_požadavků_na_kvalitu {#toc-_přehled_požadavků_na_kvalitu}
  [Scénáře kvality]: #_scénáře_kvality {#toc-_scénáře_kvality}
  [Rizika a technické dluhy]: #section-technical-risks {#toc-section-technical-risks}
  [Slovník pojmů]: #section-glossary {#toc-section-glossary}