# 

**關於 arc42**

arc42，用於記錄軟體與系統架構的範本。

範本版本 9.0-ZH-TW。(以 AsciiDoc 為基礎的版本)，2026 年 9 月

由 Dr. Peter Hruschka、Dr. Gernot Starke
及其他貢獻者建立、維護並持有著作權。 參見 <https://arc42.org。>

# 簡介與目標

## 需求概述

## 品質目標

## 利害關係人

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">角色/姓名</th>
<th style="text-align: left;">聯絡方式</th>
<th style="text-align: left;">期望</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p><em>&lt;角色-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;聯絡方式-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;期望-1&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"><p><em>&lt;角色-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;聯絡方式-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;期望-2&gt;</em></p></td>
</tr>
</tbody>
</table>

# 架構限制

# 脈絡與範圍

## 業務脈絡

**&lt;圖表或表格&gt;**

**&lt;可選：外部領域介面的說明&gt;**

## 技術脈絡

**&lt;圖表或表格&gt;**

**&lt;可選：技術介面的說明&gt;**

**&lt;輸入、輸出與通道之間的對應關係&gt;**

# 解決方案策略

# 建構模組視圖

## 整體系統白箱

***&lt;概覽圖&gt;***

動機  
*&lt;文字說明&gt;*

包含的建構模組  
*&lt;所包含建構模組（黑箱）的描述&gt;*

重要介面  
*&lt;重要介面的描述&gt;*

### &lt;黑箱 1 的名稱&gt;

*&lt;目的/職責&gt;*

*&lt;介面（一個或多個）&gt;*

*&lt;(選用) 品質/效能特徵&gt;*

*&lt;(選用) 目錄/檔案位置&gt;*

*&lt;(選用) 已滿足的需求&gt;*

*&lt;(選用) 未解決的議題/問題/風險&gt;*

### &lt;黑箱 2 的名稱&gt;

*&lt;黑箱範本&gt;*

### &lt;黑箱 n 的名稱&gt;

*&lt;黑箱範本&gt;*

### &lt;介面 1 的名稱&gt;

…​

### &lt;介面 m 的名稱&gt;

## 層級 2

### 白箱 *&lt;建構模組 1&gt;*

*&lt;白箱範本&gt;*

### 白箱 *&lt;建構模組 2&gt;*

*&lt;白箱範本&gt;*

…​

### 白箱 *&lt;建構模組 m&gt;*

*&lt;白箱範本&gt;*

## 層級 3

### 白箱 &lt;\_建構模組 x.1\_&gt;

*&lt;白箱範本&gt;*

### 白箱 &lt;\_建構模組 x.2\_&gt;

*&lt;白箱範本&gt;*

### 白箱 &lt;\_建構模組 y.1\_&gt;

*&lt;白箱範本&gt;*

# 執行階段視圖

## &lt;執行階段情境 1&gt;

- *&lt;插入情境的執行階段圖或文字描述&gt;*

- *&lt;插入此圖中建構模組實例之間互動關係的重要事項&gt;*

## &lt;執行階段情境 2&gt;

## …​

## &lt;執行階段情境 n&gt;

# 部署視圖

## 基礎設施層級 1

***&lt;概覽圖&gt;***

動機  
*&lt;文字形式的說明&gt;*

品質與/或效能特徵  
*&lt;文字形式的說明&gt;*

建構模組對應至基礎設施  
*&lt;對應關係的描述&gt;*

## 基礎設施層級 2

### *&lt;基礎設施要素 1&gt;*

*&lt;圖表 + 解釋&gt;*

### *&lt;基礎設施要素 2&gt;*

*&lt;圖表 + 解釋&gt;*

…​

### *&lt;基礎設施要素 n&gt;*

*&lt;圖表 + 解釋&gt;*

# 橫切概念

## *&lt;概念 1&gt;*

*&lt;解釋&gt;*

## *&lt;概念 2&gt;*

*&lt;解釋&gt;*

…​

## *&lt;概念 n&gt;*

*&lt;解釋&gt;*

# 架構決策

# 品質需求

## 品質需求概述

## 品質情境

# 風險與技術負債

# 術語表

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">術語</th>
<th style="text-align: left;">英文</th>
<th style="text-align: left;">定義</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p>&lt;術語-1&gt;</p></td>
<td style="text-align: left;"><p>&lt;英文-1&gt;</p></td>
<td style="text-align: left;"><p>&lt;定義-1&gt;</p></td>
</tr>
<tr>
<td style="text-align: left;"><p>&lt;術語-2&gt;</p></td>
<td style="text-align: left;"><p>&lt;英文-2&gt;</p></td>
<td style="text-align: left;"><p>&lt;定義-2&gt;</p></td>
</tr>
</tbody>
</table>
