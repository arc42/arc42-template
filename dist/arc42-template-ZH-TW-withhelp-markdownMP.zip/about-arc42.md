# 

**關於 arc42**

arc42，用於記錄軟體與系統架構的範本。

範本版本 9.0-ZH-TW。(以 AsciiDoc 為基礎的版本)，2026 年 9 月

由 Dr. Peter Hruschka、Dr. Gernot Starke
及其他貢獻者建立、維護並持有著作權。 參見 <https://arc42.org。>
