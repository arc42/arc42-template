# 簡介與目標

描述軟體架構師與開發團隊必須考量的相關需求與驅動因素。 這些包括：

- 核心業務目標

- 核心功能

- 核心功能需求

- 架構的品質目標

- 相關利害關係人及其期望

## 需求概述

內容

功能需求、驅動因素，以及需求摘錄（或摘要）的簡短描述。
連結至（現有的）需求文件，並標示版本號及文件存放位置。

動機

從最終使用者的角度來看，建立或修改系統，是為了改善對業務活動的支援和/或提升品質。

形式

簡短的文字描述，可能採用表格式使用案例格式。
如果存在需求文件，此概述應引用這些文件。

保持這些摘要儘可能簡短，並在本文件的可讀性與需求文件可能出現的冗餘之間取得平衡。

更多資訊

參見 arc42 文件中的 [簡介與目標](https://docs.arc42.org/section-1/)。

## 品質目標

內容

架構需要滿足主要利害關係人最重要的前三個（最多五個）品質目標，且這些目標的達成具有最高優先順序。
我們真正指的是架構本身的品質目標。請不要將它們與專案目標混為一談，兩者不一定相同。

請參考以下依 ISO 25010 標準整理的潛在主題概述：

<figure>
<img src="images/01_2_iso-25010-topics-ZH-TW-2023.png"
alt="品質需求類別" />
</figure>

動機

您應了解最重要利害關係人的品質目標，因為這些目標會影響基本的架構決策。
請務必具體描述這些品質，避免使用空泛的流行術語。
如果身為架構師的您不知道工作品質將如何被評估……

形式

包含品質目標與具體情境、並依優先順序排列的表格。

## 利害關係人

內容

系統利害關係人的明確概述，即所有人員、角色或組織：

- 應了解架構的人

- 必須認同架構的人

- 必須使用架構或程式碼工作的人

- 工作需要依賴架構文件的人

- 必須針對系統或其開發做出決策的人

動機

您應了解所有參與系統開發或受系統影響的相關方，否則在開發流程後期，可能會遇到棘手的意外。
這些利害關係人會決定您的工作及其成果應涵蓋的範圍與詳細程度。

形式

包含角色名稱、人員姓名，以及他們對架構文件的期望之表格。
請勿在此重複利害關係人的功能需求與品質需求，並在此處說明他們對文件的需求。

範例

以下利害關係人角色會在許多專案中反覆出現。請以此作為起點，再依實際專案調整角色、名稱與期望。
並非每個專案都包含所有這些角色，有些專案也可能有其他角色。

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">角色/姓名</th>
<th style="text-align: left;">聯絡方式</th>
<th style="text-align: left;">期望</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p>產品負責人</p></td>
<td style="text-align: left;"><p>產品管理團隊</p></td>
<td
style="text-align: left;"><p>依據業務價值排列功能優先順序；需要確保第 1
節（需求概述、品質目標）與產品策略保持一致</p></td>
</tr>
<tr>
<td style="text-align: left;"><p>最終使用者/客戶</p></td>
<td
style="text-align: left;"><p>透過使用者體驗研究、支援工單等方式代表</p></td>
<td
style="text-align: left;"><p>需要系統易於使用、可靠且快速；推動效能與易用性等品質目標</p></td>
</tr>
<tr>
<td style="text-align: left;"><p>軟體架構師</p></td>
<td style="text-align: left;"><p>架構團隊</p></td>
<td
style="text-align: left;"><p>負責維護本文件，並使用本文件說明及溝通技術決策</p></td>
</tr>
<tr>
<td style="text-align: left;"><p>開發團隊</p></td>
<td style="text-align: left;"><p>工程團隊</p></td>
<td style="text-align: left;"><p>需要清楚的建構模組（第 5
節）與執行階段情境（第 6 節），以正確實作系統</p></td>
</tr>
<tr>
<td style="text-align: left;"><p>維運/SRE</p></td>
<td style="text-align: left;"><p>維運團隊</p></td>
<td style="text-align: left;"><p>需要部署視圖（第 7 節）與橫切概念（第 8
節，例如監控、日誌記錄），以可靠地執行系統</p></td>
</tr>
<tr>
<td style="text-align: left;"><p>資安長/資訊安全</p></td>
<td style="text-align: left;"><p>資安團隊</p></td>
<td style="text-align: left;"><p>依據風險（第 11 節）與品質需求（第 10
節）審查架構；需要確認安全性限制已獲得處理的證據</p></td>
</tr>
<tr>
<td style="text-align: left;"><p>法令遵循/法務</p></td>
<td style="text-align: left;"><p>法務/法令遵循團隊</p></td>
<td style="text-align: left;"><p>需要確認法規限制（第 2
節）已獲遵守的證據，例如資料保護、授權條款</p></td>
</tr>
<tr>
<td style="text-align: left;"><p>專案發起人/管理階層</p></td>
<td style="text-align: left;"><p>指導委員會</p></td>
<td style="text-align: left;"><p>需要確認架構決策（第 9
節）能支援預算、時程與策略目標</p></td>
</tr>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">角色/姓名</th>
<th style="text-align: left;">聯絡方式</th>
<th style="text-align: left;">期望</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p><em>&lt;角色-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;聯絡方式-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;期望-1&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"><p><em>&lt;角色-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;聯絡方式-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;期望-2&gt;</em></p></td>
</tr>
</tbody>
</table>
