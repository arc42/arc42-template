# 術語表

內容

利害關係人討論系統時使用的最重要領域與技術術語。

如果您在多語言團隊中工作，也可以將術語表視為翻譯的依據。

動機

您應清楚定義術語，讓所有利害關係人

- 對這些術語有相同的理解

- 不使用同義詞和同名異義詞

形式

包含 &lt;術語&gt; 與 &lt;定義&gt; 欄位的表格。

如果需要翻譯，也可以增加其他欄位。

更多資訊

參見 arc42 文件中的 [術語表](https://docs.arc42.org/section-12/)。

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">術語</th>
<th style="text-align: left;">英文</th>
<th style="text-align: left;">定義</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p>&lt;術語-1&gt;</p></td>
<td style="text-align: left;"><p>&lt;英文-1&gt;</p></td>
<td style="text-align: left;"><p>&lt;定義-1&gt;</p></td>
</tr>
<tr>
<td style="text-align: left;"><p>&lt;術語-2&gt;</p></td>
<td style="text-align: left;"><p>&lt;英文-2&gt;</p></td>
<td style="text-align: left;"><p>&lt;定義-2&gt;</p></td>
</tr>
</tbody>
</table>
