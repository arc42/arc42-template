---
hide:
   - navigation
---

# Arc42 Template


**About arc42**

arc42, the template for documentation of software and system architecture.

Template Version 9.0-EN. (based upon AsciiDoc version), July 2025

Created, maintained and © by Dr. Peter Hruschka, Dr. Gernot Starke and contributors. See <https://arc42.org>.

## Introduction and Goals {#section-introduction-and-goals}

### Requirements Overview {#_requirements_overview}

### Quality Goals {#_quality_goals}

### Stakeholders {#_stakeholders}

 Role/Name        | Contact             | Expectations            |
------------------|---------------------|-------------------------|
 *&lt;Role-1&gt;* | *&lt;Contact-1&gt;* | *&lt;Expectation-1&gt;* |
 *&lt;Role-2&gt;* | *&lt;Contact-2&gt;* | *&lt;Expectation-2&gt;* |

## Architecture Constraints {#section-architecture-constraints}

## Context and Scope {#section-context-and-scope}

### Business Context {#_business_context}

**&lt;Diagram or Table&gt;**

**&lt;optionally: Explanation of external domain interfaces&gt;**

### Technical Context {#_technical_context}

**&lt;Diagram or Table&gt;**

**&lt;optionally: Explanation of technical interfaces&gt;**

**&lt;Mapping Input/Output to Channels&gt;**

## Solution Strategy {#section-solution-strategy}

## Building Block View {#section-building-block-view}

### Whitebox Overall System {#_whitebox_overall_system}

***&lt;Overview Diagram&gt;***

Motivation

:   *&lt;text explanation&gt;*

Contained Building Blocks

:   *&lt;Description of contained building block (black boxes)&gt;*

Important Interfaces

:   *&lt;Description of important interfaces&gt;*

#### &lt;Name black box 1&gt; {#_name_black_box_1}

*&lt;Purpose/Responsibility&gt;*

*&lt;Interface(s)&gt;*

*&lt;(Optional) Quality/Performance Characteristics&gt;*

*&lt;(Optional) Directory/File Location&gt;*

*&lt;(Optional) Fulfilled Requirements&gt;*

*&lt;(optional) Open Issues/Problems/Risks&gt;*

#### &lt;Name black box 2&gt; {#_name_black_box_2}

*&lt;black box template&gt;*

#### &lt;Name black box n&gt; {#_name_black_box_n}

*&lt;black box template&gt;*

#### &lt;Name interface 1&gt; {#_name_interface_1}

…​

#### &lt;Name interface m&gt; {#_name_interface_m}

### Level 2 {#_level_2}

#### White Box *&lt;building block 1&gt;* {#_white_box_building_block_1}

*&lt;white box template&gt;*

#### White Box *&lt;building block 2&gt;* {#_white_box_building_block_2}

*&lt;white box template&gt;*

…​

#### White Box *&lt;building block m&gt;* {#_white_box_building_block_m}

*&lt;white box template&gt;*

### Level 3 {#_level_3}

#### White Box &lt;\_building block x.1\_&gt; {#_white_box_building_block_x_1}

*&lt;white box template&gt;*

#### White Box &lt;\_building block x.2\_&gt; {#_white_box_building_block_x_2}

*&lt;white box template&gt;*

#### White Box &lt;\_building block y.1\_&gt; {#_white_box_building_block_y_1}

*&lt;white box template&gt;*

## Runtime View {#section-runtime-view}

### &lt;Runtime Scenario 1&gt; {#_runtime_scenario_1}

- *&lt;insert runtime diagram or textual description of the scenario&gt;*

- *&lt;insert description of the notable aspects of the interactions between the building block instances depicted in this diagram.&gt;*

### &lt;Runtime Scenario 2&gt; {#_runtime_scenario_2}

### …​

### &lt;Runtime Scenario n&gt; {#_runtime_scenario_n}

## Deployment View {#section-deployment-view}

### Infrastructure Level 1 {#_infrastructure_level_1}

***&lt;Overview Diagram&gt;***

Motivation

:   *&lt;explanation in text form&gt;*

Quality and/or Performance Features

:   *&lt;explanation in text form&gt;*

Mapping of Building Blocks to Infrastructure

:   *&lt;description of the mapping&gt;*

### Infrastructure Level 2 {#_infrastructure_level_2}

#### *&lt;Infrastructure Element 1&gt;* {#_infrastructure_element_1}

*&lt;diagram + explanation&gt;*

#### *&lt;Infrastructure Element 2&gt;* {#_infrastructure_element_2}

*&lt;diagram + explanation&gt;*

…​

#### *&lt;Infrastructure Element n&gt;* {#_infrastructure_element_n}

*&lt;diagram + explanation&gt;*

## Cross-cutting Concepts {#section-concepts}

### *&lt;Concept 1&gt;* {#_concept_1}

*&lt;explanation&gt;*

### *&lt;Concept 2&gt;* {#_concept_2}

*&lt;explanation&gt;*

…​

### *&lt;Concept n&gt;* {#_concept_n}

*&lt;explanation&gt;*

## Architecture Decisions {#section-design-decisions}

## Quality Requirements {#section-quality-scenarios}

### Quality Requirements Overview {#_quality_requirements_overview}

### Quality Scenarios {#_quality_scenarios}

## Risks and Technical Debts {#section-technical-risks}

## Glossary {#section-glossary}

 Term             | Definition             |
------------------|------------------------|
 *&lt;Term-1&gt;* | *&lt;definition-1&gt;* |
 *&lt;Term-2&gt;* | *&lt;definition-2&gt;* |

  [arc42]: images/arc42-logo.png
  [Introduction and Goals]: #section-introduction-and-goals {#toc-section-introduction-and-goals}
  [Requirements Overview]: #_requirements_overview {#toc-_requirements_overview}
  [Quality Goals]: #_quality_goals {#toc-_quality_goals}
  [Stakeholders]: #_stakeholders {#toc-_stakeholders}
  [Architecture Constraints]: #section-architecture-constraints {#toc-section-architecture-constraints}
  [Context and Scope]: #section-context-and-scope {#toc-section-context-and-scope}
  [Business Context]: #_business_context {#toc-_business_context}
  [Technical Context]: #_technical_context {#toc-_technical_context}
  [Solution Strategy]: #section-solution-strategy {#toc-section-solution-strategy}
  [Building Block View]: #section-building-block-view {#toc-section-building-block-view}
  [Whitebox Overall System]: #_whitebox_overall_system {#toc-_whitebox_overall_system}
  [&lt;Name black box 1&gt;]: #_name_black_box_1 {#toc-_name_black_box_1}
  [&lt;Name black box 2&gt;]: #_name_black_box_2 {#toc-_name_black_box_2}
  [&lt;Name black box n&gt;]: #_name_black_box_n {#toc-_name_black_box_n}
  [&lt;Name interface 1&gt;]: #_name_interface_1 {#toc-_name_interface_1}
  [&lt;Name interface m&gt;]: #_name_interface_m {#toc-_name_interface_m}
  [Level 2]: #_level_2 {#toc-_level_2}
  [White Box *&lt;building block 1&gt;*]: #_white_box_building_block_1 {#toc-_white_box_building_block_1}
  [White Box *&lt;building block 2&gt;*]: #_white_box_building_block_2 {#toc-_white_box_building_block_2}
  [White Box *&lt;building block m&gt;*]: #_white_box_building_block_m {#toc-_white_box_building_block_m}
  [Level 3]: #_level_3 {#toc-_level_3}
  [White Box &lt;\_building block x.1\_&gt;]: #_white_box_building_block_x_1 {#toc-_white_box_building_block_x_1}
  [White Box &lt;\_building block x.2\_&gt;]: #_white_box_building_block_x_2 {#toc-_white_box_building_block_x_2}
  [White Box &lt;\_building block y.1\_&gt;]: #_white_box_building_block_y_1 {#toc-_white_box_building_block_y_1}
  [Runtime View]: #section-runtime-view {#toc-section-runtime-view}
  [&lt;Runtime Scenario 1&gt;]: #_runtime_scenario_1 {#toc-_runtime_scenario_1}
  [&lt;Runtime Scenario 2&gt;]: #_runtime_scenario_2 {#toc-_runtime_scenario_2}
  [&lt;Runtime Scenario n&gt;]: #_runtime_scenario_n {#toc-_runtime_scenario_n}
  [Deployment View]: #section-deployment-view {#toc-section-deployment-view}
  [Infrastructure Level 1]: #_infrastructure_level_1 {#toc-_infrastructure_level_1}
  [Infrastructure Level 2]: #_infrastructure_level_2 {#toc-_infrastructure_level_2}
  [*&lt;Infrastructure Element 1&gt;*]: #_infrastructure_element_1 {#toc-_infrastructure_element_1}
  [*&lt;Infrastructure Element 2&gt;*]: #_infrastructure_element_2 {#toc-_infrastructure_element_2}
  [*&lt;Infrastructure Element n&gt;*]: #_infrastructure_element_n {#toc-_infrastructure_element_n}
  [Cross-cutting Concepts]: #section-concepts {#toc-section-concepts}
  [*&lt;Concept 1&gt;*]: #_concept_1 {#toc-_concept_1}
  [*&lt;Concept 2&gt;*]: #_concept_2 {#toc-_concept_2}
  [*&lt;Concept n&gt;*]: #_concept_n {#toc-_concept_n}
  [Architecture Decisions]: #section-design-decisions {#toc-section-design-decisions}
  [Quality Requirements]: #section-quality-scenarios {#toc-section-quality-scenarios}
  [Quality Requirements Overview]: #_quality_requirements_overview {#toc-_quality_requirements_overview}
  [Quality Scenarios]: #_quality_scenarios {#toc-_quality_scenarios}
  [Risks and Technical Debts]: #section-technical-risks {#toc-section-technical-risks}
  [Glossary]: #section-glossary {#toc-section-glossary}