# Glossar {#section-glossary}

:::::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Inhalt
:::

Die wesentlichen fachlichen und technischen Begriffe, die Stakeholder im
Zusammenhang mit dem System verwenden.
::::

Nutzen Sie das Glossar ebenfalls als Übersetzungsreferenz, falls Sie in
mehrsprachigen Teams arbeiten.

:::: formalpara
::: title
Motivation
:::

Sie sollten relevante Begriffe klar definieren, so dass alle Beteiligten
::::

- diese Begriffe identisch verstehen, und

- vermeiden, mehrere Begriffe für die gleiche Sache zu haben.

:::: formalpara
::: title
Form
:::

Zweispaltige Tabelle mit \<Begriff\> und \<Definition\>.
::::

Eventuell weitere Spalten mit Übersetzungen, falls notwendig.

:::: formalpara
::: title
Weiterführende Informationen
:::

Siehe [Glossar](https://docs.arc42.org/section-12/) in der
online-Dokumentation (auf Englisch!).
::::
::::::::::::

+----------------------+-----------------------------------------------+
| Begriff              | Definition                                    |
+======================+===============================================+
| *\<Begriff-1\>*      | *\<Definition-1\>*                            |
+----------------------+-----------------------------------------------+
| *\<Begriff-2*        | *\<Definition-2\>*                            |
+----------------------+-----------------------------------------------+
