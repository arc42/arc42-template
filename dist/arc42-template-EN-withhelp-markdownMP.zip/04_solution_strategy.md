# Solution Strategy {#section-solution-strategy}

:::::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Contents
:::

A short summary and explanation of the fundamental decisions and
solution strategies, that shape system architecture. It includes
::::

- technology decisions

- decisions about the top-level decomposition of the system, e.g. usage
  of an architectural pattern or design pattern

- decisions on how to achieve key quality goals

- relevant organizational decisions, e.g. selecting a development
  process or delegating certain tasks to third parties.

:::: formalpara
::: title
Motivation
:::

These decisions form the cornerstones for your architecture. They are
the foundation for many other detailed decisions or implementation
rules.
::::

:::: formalpara
::: title
Form
:::

Keep the explanations of such key decisions short.
::::

Motivate what was decided and why it was decided that way, based upon
problem statement, quality goals and key constraints. Refer to details
in the following sections.

:::: formalpara
::: title
Further Information
:::

See [Solution Strategy](https://docs.arc42.org/section-4/) in the arc42
documentation.
::::
::::::::::::
