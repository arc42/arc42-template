# Perspektiva stavebních bloků

## Celý systém jako white-box

***\<vložte přehledový diagram celého systému\>***

Motivace  
*\<popište motivaci\>*

Obsažené stavební bloky  
*\<popište obsažené stavební bloky (jako black-box)\>*

Důležitá rozhraní  
*\<popište důležitá rozhraní\>*

### \<Jméno black-boxu 1\>

*\<Účel/Odpovědnost\>*

*\<Rozhraní\>*

*\<(Volitelně) Požadavky na kvalitu/výkon\>*

*\<(Volitelně) Umístění/složky a soubory\>*

*\<(Volitelně) Splněné požadavky\>*

*\<(Volitelně) Nevyřešené body/problémy/rizika\>*

### \<Jméno black-boxu 2\>

*\<šablona black-box\>*

### \<Jméno black-boxu n\>

*\<šablona black-box\>*

### \<Jméno rozhraní 1\>

…​

### \<Jméno rozhraní m\>

## Úroveň 2

### white-box *\<stavební blok 1\>*

*\<šablona white-box\>*

### white-box *\<stavební blok 2\>*

*\<šablona white-box\>*

…​

### white-box *\<stavební blok m\>*

*\<šablona white-box\>*

## Úroveň 3

### white-box \<\_stavební blok x.1\_\>

*\<šablona white-box\>*

### white-box \<\_stavební blok x.2\_\>

*\<šablona white-box\>*

### white-box \<\_stavební blok y.1\_\>

*\<šablona white-box\>*
