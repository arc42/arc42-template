# Perspektiva nasazení softwaru (deployment)

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Obsah

</div>

Perspektiva nasazení softwaru popisuje:

</div>

1.  technickou infrastrukturu, na které systém poběží, s jednotlivými
    prvky infrastruktury, jako jsou například geografická poloha,
    prostředí, počítače, procesory, kanály a topologie sítí a další,
    jakož i

2.  mapování (softwarových) stavebních bloků na jednotlivé prvky této
    infrastruktury.

Systémy bývají často spouštěny v různých prostředích, například
vývojovém prostředí, testovacím prostředí, produkčním prostředí. V
takových případech by měla být zdokumentována všechna relevantní
prostředí.

Zejména dokumentujte perspektivu nasazení softwaru, pokud je software
provozován jako distribuovaný systém s více než jedním počítačem,
procesorem, serverem nebo kontejnerem nebo když jsou navrhovány a
konstruovány vlastní hardwarové procesory a čipy.

Z hlediska softwaru stačí zachytit pouze ty prvky infrastruktury, které
jsou potřebné k ukázce nasazení jednotlivých stavebních bloků.
Hardwaroví architekti mohou jít dále a popsat infrastrukturu do té
úrovně detailů, kterou je potřeba zachytit.

<div class="formalpara">

<div class="title">

Motivace

</div>

Software neběží bez hardwaru. Tato infrastruktura může a bude ovlivňovat
systém a/nebo některé průřezové koncepty. Proto je potřeba ji znát.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Možná je diagram nasazení softwaru na nejvyšší úrovni již obsažen v
části 3.2. jako technický kontext s vlastní infrastrukturou jako JEDEN
black-box. V této sekci lze tento black-box přiblížit pomocí dalších
diagramů nasazení:

</div>

- UML nabízí diagramy nasazení k vyjádření této perspektivy. Použijte
  je, pravděpodobně s vnořenými diagramy, když je infrastruktura
  složitější.

- Když strany zainteresované na hardwaru preferují jiné druhy diagramů
  než diagram nasazení, nechte je použít jakýkoli druh, který je schopen
  zobrazit uzly a kanály infrastruktury.

<div class="formalpara">

<div class="title">

Další informace

</div>

Anglická dokumentace arc42: [Deployment
View](https://docs.arc42.org/section-7/).

</div>

</div>

## Úroveň infrastruktury 1

<div class="sidebar">

<div class="title">

</div>

Popište (obvykle kombinací diagramů, tabulek a textu):

- distribuci systému na více míst, prostředí, počítačů, procesorů,..,
  jakož i fyzická propojení mezi nimi

- důležité důvody nebo motivaci pro tuto strukturu nasazení

- kvalitativní a/nebo výkonnostní vlastnosti této infrastruktury

- mapování softwarových artefaktů na prvky této infrastruktury

Pro více prostředí nebo alternativní nasazení zkopírujte a upravte tuto
část arc42 pro všechna relevantní prostředí.

</div>

***\<Přehledový diagram\>***

Motivace  
*\<vysvětlení v textové podobě\>*

Kvalitativní a/nebo výkonnostní vlastnosti  
*\<vysvětlení v textové podobě\>*

Mapování softwarových artefaktů na prvky infrastruktury  
*\<popis mapování\>*

## Úroveň infrastruktury 2

<div class="sidebar">

<div class="title">

</div>

Zde můžete zahrnout vnitřní strukturu (některých) prvků infrastruktury z
úrovně 1.

Zkopírujte prosím strukturu z úrovně 1 pro každý vybraný prvek.

</div>

### *\<prvek infrastruktury 1\>*

*\<diagram + vysvětlení\>*

### *\<prvek infrastruktury 2\>*

*\<diagram + vysvětlení\>*

…​

### *\<prvek infrastruktury n\>*

*\<diagram + vysvětlení\>*
