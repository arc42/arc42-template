# Vymezení a rozsah systému

<div class="formalpara-title">

**Obsah**

</div>

Rozsah a kontext systému vymezují – jak název napovídá – systém od všech
jeho komunikačních partnerů (sousední systémy a uživatelé). Tím se
specifikují externí rozhraní (interface) systému a určí zodpovědnost:
Které funkce patří do našeho systému a které do systémů sousedních.

V případě potřeby odlište firemní kontext (doménově specifické vstupy a
výstupy) od technického kontextu (kanály, protokoly, hardware).

<div class="formalpara-title">

**Motivace**

</div>

Doménová a technická komunikační rozhraní patří mezi nejdůležitější
aspekty systému. Ujistěte se, že jim zcela rozumíte.

<div class="formalpara-title">

**Forma**

</div>

Různé možnosti:

-   Kontextové diagramy

-   Seznam komunikačních partnerů a příslušné rozhraní

Anglická dokumentace arc42: [Context and
Scope](https://docs.arc42.org/section-3/).

## Firemní kontext

<div class="formalpara-title">

**Obsah**

</div>

Specifikace **všech** komunikačních partnerů systému (uživatelů, IT
systémů, …) s vysvětlením doménově specifických vstupů a výstupů nebo
rozhraní. Podle potřeby můžete přidat doménově specifické datové formáty
nebo komunikační protokoly.

<div class="formalpara-title">

**Motivace**

</div>

Všechny zainteresované strany by měly rozumět tomu, jaké doménové
informace si systém vyměňuje s okolím.

<div class="formalpara-title">

**Forma**

</div>

Různé druhy diagramů, které ukazují systém jako černou skříňku (black
box) a popisují doménová rozhraní pro komunikaci s partnery.

Alternativně (nebo jako doplnění) můžete použít tabulku. Titulek tabulky
je název systému, tři sloupce obsahují: jméno komunikačního partnera,
vstupy a výstupy.

**\<vložte diagram nebo tabulku>**

**\<(volitelně:) vložte vysvětlení externích doménových rozhraní>**

## Technický kontext

<div class="formalpara-title">

**Obsah**

</div>

Technická rozhraní (kanály a přenosová média) propojující váš systém s
jeho okolím. Navíc mapování doménově specifického vstupu/výstupu na tyto
kanály, tj. vysvětlení, která doménová data používají který kanál.

<div class="formalpara-title">

**Motivace**

</div>

Mnoho zainteresovaných stran činí architektonická rozhodnutí na základě
technických rozhraní mezi systémem a jeho okolím. Zejména při výběru
infrastruktury nebo hardwaru jsou tato technická rozhraní rozhodující.

<div class="formalpara-title">

**Forma**

</div>

Např. UML Diagram popisující technické napojení sousedních systémů spolu
s tabulkou ukazující vztahy mezi technickými kanály a doménovým
vstupem/výstupem.

**\<vložte diagram nebo tabulku>**

**\<(volitelně:) vložte vysvětlení externích technických rozhraní>**

**\<mapování doménových vstupu/výstupu na technické kanály>**
