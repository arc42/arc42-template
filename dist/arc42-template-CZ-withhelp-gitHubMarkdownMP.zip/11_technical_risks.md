# Rizika a technické dluhy

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Obsah

</div>

Seznam známých technických rizik nebo technických dluhů seřazený podle
jejich priority.

</div>

<div class="formalpara">

<div class="title">

Motivace

</div>

„Řízení rizik je řízení projektu pro dospělé.“ — Tim Lister, Atlantic
Systems Guild

</div>

Tak by mělo znít motto pro systematické zjišťování a hodnocení rizik a
technických dluhů v architektuře, které potřebují znát zainteresované
strany z oblasti managementu (například projektoví manažeři, vlastníci
produktu - (Product Owner)) jako součást celkové analýzy rizik.

<div class="formalpara">

<div class="title">

Forma

</div>

Seznam rizik a/nebo technických dluhů, pravděpodobně včetně navrhovaných
opatření k jejich minimalizaci, zmírnění nebo vyloučení.

</div>

<div class="formalpara">

<div class="title">

Další informace

</div>

Anglická dokumentace arc42: [Risks and Technical
Debt](https://docs.arc42.org/section-11/).

</div>

</div>
