# Rizika a technické dluhy

<div class="formalpara-title">

**Obsah**

</div>

Seznam známých technických rizik nebo technických dluhů seřazený podle
jejich priority.

<div class="formalpara-title">

**Motivace**

</div>

„Řízení rizik je řízení projektu pro dospělé.“ — Tim Lister, Atlantic
Systems Guild

Tak by mělo znít motto pro systematické zjišťování a hodnocení rizik a
technických dluhů v architektuře, které potřebují znát zainteresované
strany z oblasti managementu (např. projektoví manažeři, vlastníci
produktu - (Product Owner)) jako součást celkové analýzy rizik.

<div class="formalpara-title">

**Forma**

</div>

Seznam rizik a/nebo technických dluhů, pravděpodobně včetně navrhovaných
opatření k jejich minimalizaci, zmírnění nebo vyloučení.

Anglická dokumentace arc42: [Risks and Technical
Debt](https://docs.arc42.org/section-11/).
