# Rizika a technické dluhy
