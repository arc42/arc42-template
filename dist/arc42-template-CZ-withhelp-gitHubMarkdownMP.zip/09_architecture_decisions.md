# Rozhodnutí o architektuře

<div class="formalpara-title">

**Obsah**

</div>

Důležitá, drahá, rozsáhlá nebo riskantní rozhodnutí o architektuře
včetně příslušných zdůvodnění. „Rozhodnutím“ rozumíme výběr jedné nebo
více alternativ na základě daných kritérií.

Uvažte, zda má být architektonické rozhodnutí zdokumentována zde v této
centrální sekci, nebo zda je lepší je zdokumentovat lokálně (např. v
šabloně white-box konkrétního stavebního bloku).

Vyvarujte se opakovaní. Odkažte na 4. kapitolu, kde jste již zachytili
nejdůležitější architektonická rozhodnutí.

<div class="formalpara-title">

**Motivace**

</div>

Strany zainteresované na systému by měly být schopny přijatým
rozhodnutím porozumět a pochopit důvody k ním vedoucí.

<div class="formalpara-title">

**Forma**

</div>

Různé možnosti:

-   **ADR** <span class="indexterm"
    primary="Architecture Decision Record"></span>[Architecture Decision
    Record](https://thinkrelevance.com/blog/2011/11/15/documenting-architecture-decisions)
    pro každé důležité rozhodnutí

-   seznam nebo tabulka, seřazené podle důležitosti a důsledků

-   podrobněji ve formě samostatných podkapitol pro jednotlivá
    rozhodnutí

Anglická dokumentace arc42: [Architecture
Decisions](https://docs.arc42.org/section-9/). Zde najdete odkazy a
příklady k tématu **ADR**.
