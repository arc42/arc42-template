# Rozhodnutí o architektuře

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Obsah

</div>

Důležitá, drahá, rozsáhlá nebo riskantní rozhodnutí o architektuře
včetně příslušných zdůvodnění. „Rozhodnutím“ rozumíme výběr jedné nebo
více alternativ na základě daných kritérií.

</div>

Uvažte, zda má být architektonické rozhodnutí zdokumentována zde v této
centrální sekci, nebo zda je lepší je zdokumentovat lokálně (například v
šabloně white-box konkrétního stavebního bloku).

Vyvarujte se opakovaní. Odkažte na 4. kapitolu, kde jste již zachytili
nejdůležitější architektonická rozhodnutí.

<div class="formalpara">

<div class="title">

Motivace

</div>

Strany zainteresované na systému by měly být schopny přijatým
rozhodnutím porozumět a pochopit důvody k ním vedoucí.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Různé možnosti:

</div>

- **ADR** <span class="indexterm"
  primary="Architecture Decision Record"></span>[Architecture Decision
  Record](https://thinkrelevance.com/blog/2011/11/15/documenting-architecture-decisions)
  pro každé důležité rozhodnutí

- seznam nebo tabulka, seřazené podle důležitosti a důsledků

- podrobněji ve formě samostatných podkapitol pro jednotlivá rozhodnutí

<div class="formalpara">

<div class="title">

Další informace

</div>

Anglická dokumentace arc42: [Architecture
Decisions](https://docs.arc42.org/section-9/). Zde najdete odkazy a
příklady k tématu **ADR**.

</div>

</div>
