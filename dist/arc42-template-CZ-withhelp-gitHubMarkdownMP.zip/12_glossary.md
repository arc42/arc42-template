# Slovník pojmů

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Obsah

</div>

Nejdůležitější doménové a technické termíny, které zainteresované strany
používají při diskuzi o systému.

</div>

Pokud pracujete ve vícejazyčných týmech, můžete glosář používat jako
zdroj překladů.

<div class="formalpara">

<div class="title">

Motivace

</div>

Je důležité jasně definovat klíčové pojmy, aby všechny zainteresované
strany

</div>

- chápaly tyto pojmy stejně

- a aby neexistovalo pro jednu a stejnou věc více variant

<div>

<div class="title">

Forma

</div>

- Tabulka se sloupci \<Termín\> a \<Definice\>.

- Potenciálně více sloupců v případě, že potřebujete překlady.

</div>

<div class="formalpara">

<div class="title">

Další informace

</div>

Anglická dokumentace arc42:
[Glossary](https://docs.arc42.org/section-12/).

</div>

</div>

| Termín         | Definice         |
|----------------|------------------|
| *\<termín-1\>* | *\<definice-1\>* |
| *\<termín-2\>* | *\<definice-2\>* |
