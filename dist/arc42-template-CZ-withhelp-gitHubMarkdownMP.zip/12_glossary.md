# Slovník pojmů

| Termín         | Definice         |
|----------------|------------------|
| *\<termín-1\>* | *\<definice-1\>* |
| *\<termín-2\>* | *\<definice-2\>* |
