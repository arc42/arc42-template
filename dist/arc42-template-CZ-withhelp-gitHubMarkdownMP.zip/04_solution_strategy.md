# Strategie řešení

<div class="formalpara-title">

**Obsah**

</div>

Krátké shrnutí a vysvětlení zásadních rozhodnutí a strategií řešení,
které utvářejí architekturu systému. Tyto zahrnují

- technologická rozhodnutí

- rozhodnutí o dekompozici systému na nejvyšší úrovni (top-level), např.
  o použití vzoru (pattern) pro architekturu nebo návrh

- rozhodnutí o tom, jak dosáhnout klíčových kvalitativních cílů

- příslušná organizační rozhodnutí, např. výběr procesu vývoje nebo
  delegování určitých úkolů na třetí strany.

<div class="formalpara-title">

**Motivace**

</div>

Tato rozhodnutí tvoří pilíře softwarové architektury. Jsou základem pro
mnoho dalších detailních rozhodnutí nebo pravidel implementace.

<div class="formalpara-title">

**Forma**

</div>

Vysvětlení těchto klíčových rozhodnutí ponechte **krátké**.

Popište, jak jste se rozhodli a proč jste se tak rozhodli, s ohledem na
řešení problému, cíle kvality a klíčová omezení. Pro podrobnosti odkažte
na následující části.

Anglická dokumentace arc42: [Solution
Strategy](https://docs.arc42.org/section-4/).
