# Strategie řešení
