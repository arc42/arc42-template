# Omezení na realizaci systému

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Obsah

</div>

Jakýkoli požadavek, který software-architektům omezuje prostor pro
rozhodování o návrhu a implementaci nebo pro rozhodování o procesu
vývoje. Tato omezení někdy přesahují jednotlivé systémy a platí pro celé
organizace a společnosti.

</div>

<div class="formalpara">

<div class="title">

Motivace

</div>

Softwarový Architekt by měl přesně vědět, které části systému může
určovat a kde musí dodržovat vnější omezení. S omezeními je třeba se
vždy vypořádat; mohou být ale předmětem vyjednávaní.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Tabulka se (všemi) omezeními, včetně jejich vysvětlení. V případě
potřeby rozdělená na technická, organizační nebo politická omezení či
konvence (například co se týče programovaní, verzí systému, dokumentace
nebo pojmenování)

</div>

<div class="formalpara">

<div class="title">

Další informace

</div>

Anglická dokumentace arc42: [Architecture
Constraints](https://docs.arc42.org/section-2/).

</div>

</div>
