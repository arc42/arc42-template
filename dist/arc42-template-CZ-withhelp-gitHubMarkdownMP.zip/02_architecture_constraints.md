# Omezení na realizaci systému
