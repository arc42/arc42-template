# Úvod a cíle

Popisuje nejdůležitější požadavky a omezení, které musí softwaroví
architekti a vývojový tým zvážit. Tyto zahrnují

- základní podnikatelské cíle,

- základní vlastnosti systému,

- funkční požadavky na systém,

- kvalitativní cíle pro architekturu,

- strany zainteresované na systému (Stakeholder) a jejich potřeby

## Přehled požadavků

<div class="formalpara-title">

**Obsah**

</div>

Krátký popis (shrnutí nebo abstrakt) funkčních i kvalitativních
požadavků. Odkaz na (doufejme existující) dokumentaci požadavků (s
číslem verze a informacemi, kde ji najít).

<div class="formalpara-title">

**Motivace**

</div>

Z hlediska koncových uživatelů je cílem vývoje nebo změny systému
zlepšení jeho funkcí k naplňovaní podnikatelské činnosti a/nebo zlepšení
jeho kvality.

<div class="formalpara-title">

**Forma**

</div>

Krátký popis, pravděpodobně ve formátu tabulkového přehledu funkcí
(use-case). Pokud existují dokumenty požadavků, měl by na ně tento
přehled odkazovat.

Udržujte tento popis co nejkratší (z hlediska čitelnosti), ale tak aby
nebyly zbytečně opakovány informace z dokumentace požadavků.

Anglická dokumentace arc42: [Introduction and
Goals](https://docs.arc42.org/section-1/).

## Kvalitativní cíle

<div class="formalpara-title">

**Obsah**

</div>

Tři (maximálně pět) nejdůležitějších kvalitativních cílů pro
architekturu, jejichž splnění je pro hlavní zainteresované strany
nejdůležitější. Opravdu máme na mysli kvalitativní cíle pro
architekturu. Nepleťte si je s cíli projektu, ty nemusí být nutně
totožné.

Norma ISO 25010 poskytuje přehled jednotlivých oblastí:

![Kategorie kvalitativních
cílů](images/01_2_iso-25010-topics-EN.drawio.png)

<div class="formalpara-title">

**Motivace**

</div>

Měli byste znát kvalitativní cíle nejdůležitějších stran
zainteresovaných na systému, protože ty ovlivní zásadní architektonická
rozhodnutí. Ujistěte se, že jsou tyto požadavky na systém jednoznačné
(nebo měřitelné), vyhněte se obecným frázím.

<div class="formalpara-title">

**Forma**

</div>

Tabulka s nejdůležitějšími kvalitativními cíli a konkrétními scénáři,
seřazená podle priorit.

## Strany zainteresované na systému (Stakeholder)

<div class="formalpara-title">

**Obsah**

</div>

Explicitní přehled všech stran zainteresovaných na systému, tedy všech
osob, rolí nebo organizací, které

- by měli architekturu znát,

- by měli s architekturou souhlasit,

- budou s architekturou nebo s kódem pracovat,

- ke své práci potřebují dokumentaci architektury,

- rozhodují o vývoji a designu systému.

<div class="formalpara-title">

**Motivace**

</div>

Měli byste znát všechny strany zapojené do vývoje systému (nebo systémem
ovlivněné). V opačném případě se můžete později v procesu vývoje dočkat
nepříjemných překvapení. Tyto zainteresované strany určují rozsah a
úroveň detailu vaší práce a jejích výsledků.

<div class="formalpara-title">

**Forma**

</div>

Tabulka s názvy rolí, jmény osob a jejich očekáváním na architekturu a
její dokumentaci.

| Role/Jméno   | Kontakt         | Očekávání         |
|--------------|-----------------|-------------------|
| *\<Role-1\>* | *\<Kontakt-1\>* | *\<Očekávání-1\>* |
| *\<Role-2\>* | *\<Kontakt-2\>* | *\<Očekávání-2\>* |
