# Úvod a cíle

<div class="sidebar">

<div class="title">

</div>

Shrnuje klíčové požadavky a omezení, se kterými musí softwaroví
architekti i vývojový tým počítat. Patří sem zejména:

- hlavní obchodní cíle,

- základní vlastnosti systému,

- funkční požadavky,

- kvalitativní cíle architektury,

- zainteresované strany systému (stakeholder) a jejich potřeby.

</div>

## Přehled požadavků

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Obsah

</div>

Stručný popis (shrnutí či abstrakt) funkčních i kvalitativních
požadavků. Odkaz na (doufejme existující) dokumentaci požadavků (s
číslem verze a informacemi, kde ji najít).

</div>

<div class="formalpara">

<div class="title">

Motivace

</div>

Z hlediska koncových uživatelů je cílem vývoje nebo změny systému
zlepšení jeho funkcí k plnění obchodních cílů a/nebo zlepšení jeho
kvality.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Stručný popis, pravděpodobně ve formátu tabulkového přehledu funkcí
(use-case). Pokud existují dokumenty požadavků, měl by na ně tento
přehled odkazovat.

</div>

Udržujte tento popis co nejkratší (z hlediska čitelnosti), ale tak aby
nebyly zbytečně opakovány informace z dokumentace požadavků.

<div class="formalpara">

<div class="title">

Další informace

</div>

Anglická dokumentace arc42: [Introduction and
Goals](https://docs.arc42.org/section-1/).

</div>

</div>

## Kvalitativní cíle

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Obsah

</div>

Tři (maximálně pět) nejdůležitějších kvalitativních cílů pro
architekturu, jejichž splnění je pro hlavní zainteresované strany
nejdůležitější. Jedná se skutečně o kvalitativní cíle pro architekturu.
Nepleťte si je s cíli projektu, ty nemusí být nutně totožné.

</div>

Norma ISO 25010 poskytuje přehled jednotlivých oblastí:

<figure>
<img src="images/01_2_iso-25010-topics-EN-2023.drawio.png"
alt="Kategorie kvalitativních cílů" />
</figure>

<div class="formalpara">

<div class="title">

Motivace

</div>

Je vhodné znát kvalitativní cíle klíčových zainteresovaných stran
systému, protože ty ovlivní zásadní architektonická rozhodnutí. Ujistěte
se, že jsou tyto požadavky na systém jednoznačné či měřitelné, vyvarujte
se vágních formulací.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Tabulka s nejdůležitějšími kvalitativními cíli a praktickými scénáři,
seřazená podle priorit.

</div>

</div>

## Strany zainteresované na systému (stakeholder)

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Obsah

</div>

Jasný přehled všech stran zainteresovaných na systému, tedy všech osob,
rolí nebo organizací, které

</div>

- by měli architekturu znát,

- by měli s architekturou souhlasit,

- budou s architekturou nebo s kódem pracovat,

- ke své práci potřebují dokumentaci architektury,

- rozhodují o vývoji a designu systému.

<div class="formalpara">

<div class="title">

Motivace

</div>

Je vhodné znát všechny strany zapojené do vývoje systému (nebo systémem
ovlivněné). Jinak se může stát, že se později v procesu vývoje objeví
nepříjemná překvapení. Zainteresované strany ovlivňují rozsah a úroveň
detailu vaší práce a jejích výsledků.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Tabulka s názvy rolí, jmény osob a jejich očekáváním na architekturu a
její dokumentaci.

</div>

</div>

| Role/Jméno   | Kontakt         | Očekávání         |
|--------------|-----------------|-------------------|
| *\<Role-1\>* | *\<Kontakt-1\>* | *\<Očekávání-1\>* |
| *\<Role-2\>* | *\<Kontakt-2\>* | *\<Očekávání-2\>* |
