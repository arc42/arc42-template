# Průřezové (cross-cutting) koncepty {#section-concepts}

## *&lt;Koncept 1&gt;* {#_koncept_1}

*&lt;vysvětlení&gt;*

## *&lt;Koncept 2&gt;* {#_koncept_2}

*&lt;vysvětlení&gt;*

…​

## *&lt;Koncept n&gt;* {#_koncept_n}

*&lt;vysvětlení&gt;*

  [Průřezové (cross-cutting) koncepty]: #section-concepts {#toc-section-concepts}
  [*&lt;Koncept 1&gt;*]: #_koncept_1 {#toc-_koncept_1}
  [*&lt;Koncept 2&gt;*]: #_koncept_2 {#toc-_koncept_2}
  [*&lt;Koncept n&gt;*]: #_koncept_n {#toc-_koncept_n}
