# Perspektiva nasazení softwaru (deployment) {#section-deployment-view}

## Úroveň infrastruktury 1 {#_úroveň_infrastruktury_1}

***&lt;Přehledový diagram&gt;***

Motivace

:   *&lt;vysvětlení v textové podobě&gt;*

Kvalitativní a/nebo výkonnostní vlastnosti

:   *&lt;vysvětlení v textové podobě&gt;*

Mapování softwarových artefaktů na prvky infrastruktury

:   *&lt;popis mapování&gt;*

## Úroveň infrastruktury 2 {#_úroveň_infrastruktury_2}

### *&lt;prvek infrastruktury 1&gt;* {#_prvek_infrastruktury_1}

*&lt;diagram + vysvětlení&gt;*

### *&lt;prvek infrastruktury 2&gt;* {#_prvek_infrastruktury_2}

*&lt;diagram + vysvětlení&gt;*

…​

### *&lt;prvek infrastruktury n&gt;* {#_prvek_infrastruktury_n}

*&lt;diagram + vysvětlení&gt;*

  [Perspektiva nasazení softwaru (deployment)]: #section-deployment-view {#toc-section-deployment-view}
  [Úroveň infrastruktury 1]: #_úroveň_infrastruktury_1 {#toc-_úroveň_infrastruktury_1}
  [Úroveň infrastruktury 2]: #_úroveň_infrastruktury_2 {#toc-_úroveň_infrastruktury_2}
  [*&lt;prvek infrastruktury 1&gt;*]: #_prvek_infrastruktury_1 {#toc-_prvek_infrastruktury_1}
  [*&lt;prvek infrastruktury 2&gt;*]: #_prvek_infrastruktury_2 {#toc-_prvek_infrastruktury_2}
  [*&lt;prvek infrastruktury n&gt;*]: #_prvek_infrastruktury_n {#toc-_prvek_infrastruktury_n}
