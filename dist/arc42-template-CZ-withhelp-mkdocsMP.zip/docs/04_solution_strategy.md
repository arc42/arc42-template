# Strategie řešení {#section-solution-strategy}

  [Strategie řešení]: #section-solution-strategy {#toc-section-solution-strategy}
