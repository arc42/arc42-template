# Omezení na realizaci systému {#section-architecture-constraints}

  [Omezení na realizaci systému]: #section-architecture-constraints {#toc-section-architecture-constraints}
