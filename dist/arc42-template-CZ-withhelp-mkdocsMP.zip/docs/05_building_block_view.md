# Perspektiva stavebních bloků {#section-building-block-view}

## Celý systém jako white-box {#_celý_systém_jako_white_box}

***&lt;vložte přehledový diagram celého systému&gt;***

Motivace

:   *&lt;popište motivaci&gt;*

Obsažené stavební bloky

:   *&lt;popište obsažené stavební bloky (jako black-box)&gt;*

Důležitá rozhraní

:   *&lt;popište důležitá rozhraní&gt;*

### &lt;Jméno black-boxu 1&gt; {#_jméno_black_boxu_1}

*&lt;Účel/Odpovědnost&gt;*

*&lt;Rozhraní&gt;*

*&lt;(Volitelně) Požadavky na kvalitu/výkon&gt;*

*&lt;(Volitelně) Umístění/složky a soubory&gt;*

*&lt;(Volitelně) Splněné požadavky&gt;*

*&lt;(Volitelně) Nevyřešené body/problémy/rizika&gt;*

### &lt;Jméno black-boxu 2&gt; {#_jméno_black_boxu_2}

*&lt;šablona black-box&gt;*

### &lt;Jméno black-boxu n&gt; {#_jméno_black_boxu_n}

*&lt;šablona black-box&gt;*

### &lt;Jméno rozhraní 1&gt; {#_jméno_rozhraní_1}

…​

### &lt;Jméno rozhraní m&gt; {#_jméno_rozhraní_m}

## Úroveň 2 {#_úroveň_2}

### white-box *&lt;stavební blok 1&gt;* {#_white_box_stavební_blok_1}

*&lt;šablona white-box&gt;*

### white-box *&lt;stavební blok 2&gt;* {#_white_box_stavební_blok_2}

*&lt;šablona white-box&gt;*

…​

### white-box *&lt;stavební blok m&gt;* {#_white_box_stavební_blok_m}

*&lt;šablona white-box&gt;*

## Úroveň 3 {#_úroveň_3}

### white-box &lt;\_stavební blok x.1\_&gt; {#_white_box_stavební_blok_x_1}

*&lt;šablona white-box&gt;*

### white-box &lt;\_stavební blok x.2\_&gt; {#_white_box_stavební_blok_x_2}

*&lt;šablona white-box&gt;*

### white-box &lt;\_stavební blok y.1\_&gt; {#_white_box_stavební_blok_y_1}

*&lt;šablona white-box&gt;*

  [Perspektiva stavebních bloků]: #section-building-block-view {#toc-section-building-block-view}
  [Celý systém jako white-box]: #_celý_systém_jako_white_box {#toc-_celý_systém_jako_white_box}
  [&lt;Jméno black-boxu 1&gt;]: #_jméno_black_boxu_1 {#toc-_jméno_black_boxu_1}
  [&lt;Jméno black-boxu 2&gt;]: #_jméno_black_boxu_2 {#toc-_jméno_black_boxu_2}
  [&lt;Jméno black-boxu n&gt;]: #_jméno_black_boxu_n {#toc-_jméno_black_boxu_n}
  [&lt;Jméno rozhraní 1&gt;]: #_jméno_rozhraní_1 {#toc-_jméno_rozhraní_1}
  [&lt;Jméno rozhraní m&gt;]: #_jméno_rozhraní_m {#toc-_jméno_rozhraní_m}
  [Úroveň 2]: #_úroveň_2 {#toc-_úroveň_2}
  [white-box *&lt;stavební blok 1&gt;*]: #_white_box_stavební_blok_1 {#toc-_white_box_stavební_blok_1}
  [white-box *&lt;stavební blok 2&gt;*]: #_white_box_stavební_blok_2 {#toc-_white_box_stavební_blok_2}
  [white-box *&lt;stavební blok m&gt;*]: #_white_box_stavební_blok_m {#toc-_white_box_stavební_blok_m}
  [Úroveň 3]: #_úroveň_3 {#toc-_úroveň_3}
  [white-box &lt;\_stavební blok x.1\_&gt;]: #_white_box_stavební_blok_x_1 {#toc-_white_box_stavební_blok_x_1}
  [white-box &lt;\_stavební blok x.2\_&gt;]: #_white_box_stavební_blok_x_2 {#toc-_white_box_stavební_blok_x_2}
  [white-box &lt;\_stavební blok y.1\_&gt;]: #_white_box_stavební_blok_y_1 {#toc-_white_box_stavební_blok_y_1}
