# Perspektiva chování za běhu (runtime) {#section-runtime-view}

## &lt;Scénář runtime 1&gt; {#_scénář_runtime_1}

- *&lt;vložte runtime diagram nebo textový popis scénáře&gt;*

- *&lt;vložte popis důležitých interakcí mezi instancemi stavebních bloků zobrazených v tomto diagramu&gt;*

## &lt;Scénář runtime 2&gt; {#_scénář_runtime_2}

## …​

## &lt;Scénář runtime n&gt; {#_scénář_runtime_n}

  [Perspektiva chování za běhu (runtime)]: #section-runtime-view {#toc-section-runtime-view}
  [&lt;Scénář runtime 1&gt;]: #_scénář_runtime_1 {#toc-_scénář_runtime_1}
  [&lt;Scénář runtime 2&gt;]: #_scénář_runtime_2 {#toc-_scénář_runtime_2}
  [&lt;Scénář runtime n&gt;]: #_scénář_runtime_n {#toc-_scénář_runtime_n}
