# Vymezení a rozsah systému {#section-context-and-scope}

## Firemní kontext {#_firemní_kontext}

**&lt;vložte diagram nebo tabulku&gt;**

**&lt;(volitelně:) vložte vysvětlení externích doménových rozhraní&gt;**

## Technický kontext {#_technický_kontext}

**&lt;vložte diagram nebo tabulku&gt;**

**&lt;(volitelně:) vložte vysvětlení externích technických rozhraní&gt;**

**&lt;mapování doménových vstupu/výstupu na technické kanály&gt;**

  [Vymezení a rozsah systému]: #section-context-and-scope {#toc-section-context-and-scope}
  [Firemní kontext]: #_firemní_kontext {#toc-_firemní_kontext}
  [Technický kontext]: #_technický_kontext {#toc-_technický_kontext}
