# Úvod a cíle {#section-introduction-and-goals}

## Přehled požadavků {#_přehled_požadavků}

## Kvalitativní cíle {#_kvalitativní_cíle}

## Strany zainteresované na systému (stakeholder) {#_strany_zainteresované_na_systému_stakeholder}

| Role/Jméno       | Kontakt             | Očekávání             |
|------------------|---------------------|-----------------------|
| *&lt;Role-1&gt;* | *&lt;Kontakt-1&gt;* | *&lt;Očekávání-1&gt;* |
| *&lt;Role-2&gt;* | *&lt;Kontakt-2&gt;* | *&lt;Očekávání-2&gt;* |

  [Úvod a cíle]: #section-introduction-and-goals {#toc-section-introduction-and-goals}
  [Přehled požadavků]: #_přehled_požadavků {#toc-_přehled_požadavků}
  [Kvalitativní cíle]: #_kvalitativní_cíle {#toc-_kvalitativní_cíle}
  [Strany zainteresované na systému (stakeholder)]: #_strany_zainteresované_na_systému_stakeholder {#toc-_strany_zainteresované_na_systému_stakeholder}
