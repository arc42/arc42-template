# Slovník pojmů {#section-glossary}

| Termín             | Definice             |
|--------------------|----------------------|
| *&lt;termín-1&gt;* | *&lt;definice-1&gt;* |
| *&lt;termín-2&gt;* | *&lt;definice-2&gt;* |

  [Slovník pojmů]: #section-glossary {#toc-section-glossary}
