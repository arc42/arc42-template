# Context and Scope {#section-context-and-scope}

## Business Context {#_business_context}

**&lt;Diagram or Table&gt;**

**&lt;optionally: Explanation of external domain interfaces&gt;**

## Technical Context {#_technical_context}

**&lt;Diagram or Table&gt;**

**&lt;optionally: Explanation of technical interfaces&gt;**

**&lt;Mapping Input/Output to Channels&gt;**

  [Context and Scope]: #section-context-and-scope {#toc-section-context-and-scope}
  [Business Context]: #_business_context {#toc-_business_context}
  [Technical Context]: #_technical_context {#toc-_technical_context}
