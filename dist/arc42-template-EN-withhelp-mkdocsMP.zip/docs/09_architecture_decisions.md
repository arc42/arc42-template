# Architecture Decisions {#section-design-decisions}

  [Architecture Decisions]: #section-design-decisions {#toc-section-design-decisions}
