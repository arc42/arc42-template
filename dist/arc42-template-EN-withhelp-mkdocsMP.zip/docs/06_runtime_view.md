# Runtime View {#section-runtime-view}

## &lt;Runtime Scenario 1&gt; {#_runtime_scenario_1}

- *&lt;insert runtime diagram or textual description of the scenario&gt;*

- *&lt;insert description of the notable aspects of the interactions between the building block instances depicted in this diagram.&gt;*

## &lt;Runtime Scenario 2&gt; {#_runtime_scenario_2}

## …​

## &lt;Runtime Scenario n&gt; {#_runtime_scenario_n}

  [Runtime View]: #section-runtime-view {#toc-section-runtime-view}
  [&lt;Runtime Scenario 1&gt;]: #_runtime_scenario_1 {#toc-_runtime_scenario_1}
  [&lt;Runtime Scenario 2&gt;]: #_runtime_scenario_2 {#toc-_runtime_scenario_2}
  [&lt;Runtime Scenario n&gt;]: #_runtime_scenario_n {#toc-_runtime_scenario_n}
