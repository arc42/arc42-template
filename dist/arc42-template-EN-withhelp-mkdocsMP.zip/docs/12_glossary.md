# Glossary {#section-glossary}

| Term             | Definition             |
|------------------|------------------------|
| *&lt;Term-1&gt;* | *&lt;definition-1&gt;* |
| *&lt;Term-2&gt;* | *&lt;definition-2&gt;* |

  [Glossary]: #section-glossary {#toc-section-glossary}
