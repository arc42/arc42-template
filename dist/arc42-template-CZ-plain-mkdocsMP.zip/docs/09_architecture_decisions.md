# Rozhodnutí o architektuře {#section-design-decisions}

  [Rozhodnutí o architektuře]: #section-design-decisions {#toc-section-design-decisions}
