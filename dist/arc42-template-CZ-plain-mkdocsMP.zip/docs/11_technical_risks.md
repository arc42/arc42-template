# Rizika a technické dluhy {#section-technical-risks}

  [Rizika a technické dluhy]: #section-technical-risks {#toc-section-technical-risks}
