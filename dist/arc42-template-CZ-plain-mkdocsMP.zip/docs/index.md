**O arc42**

arc42, šablona pro dokumentaci softwaru a architekturu systému.

Verze šablony 9.0-CZ. (na základě AsciiDoc verze), Leden 2025

Created, maintained and © by Dr. Peter Hruschka, Dr. Gernot Starke and contributors. Viz <https://arc42.org>.


0. [Úvod a cíle](01_introduction_and_goals.md)

0. [Omezení na realizaci systému](02_architecture_constraints.md)

0. [Vymezení a rozsah systému](03_context_and_scope.md)

0. [Strategie řešení](04_solution_strategy.md)

0. [Perspektiva stavebních bloků](05_building_block_view.md)

0. [Perspektiva chování za běhu (runtime)](06_runtime_view.md)

0. [Perspektiva nasazení softwaru (deployment)](07_deployment_view.md)

0. [Průřezové (cross-cutting) koncepty](08_concepts.md)

0. [Rozhodnutí o architektuře](09_architecture_decisions.md)

0. [Požadavky na kvalitu](10_quality_requirements.md)

0. [Rizika a technické dluhy](11_technical_risks.md)

0. [Slovník pojmů](12_glossary.md)
