# Visão de Blocos de Construção {#section-building-block-view}

## Visão Sistêmica Geral de Caixa Branca {#_visão_sistêmica_geral_de_caixa_branca}

***\<Diagrama de Visão Geral\>***

Motivação

:   *\<explicação textual\>*

Blocos de Construção Contidos

:   *\<Descrição dos blocos de construção contidos (caixas pretas)\>*

Interfaces Importantes

:   *\<Descrição de interfaces importantes\>*

### \<Nome Caixa Preta 1\> {#_nome_caixa_preta_1}

*\<Propósito/Responsabilidade\>*

*\<Interface(s)\>*

*\<(Opcional) Características de Qualidade/Desempenho\>*

*\<(Opcional) Local do Diretório/Arquivo\>*

*\<(Opcional) Requisitos Cumpridos\>*

*\<(opcional) Problemas/Riscos Abertos\>*

### \<Nome Caixa Preta 2\> {#_nome_caixa_preta_2}

*\<modelo de caixa preta\>*

### \<Nome Caixa Preta n\> {#_nome_caixa_preta_n}

*\<modelo de caixa preta\>*

### \<Nome Interface 1\> {#_nome_interface_1}

...​

### \<Nome Interface m\> {#_nome_interface_m}

## Nível 2 {#_nível_2}

### Caixa Branca *\<Bloco de Construção 1\>* {#_caixa_branca_bloco_de_construção_1}

*\<modelo de caixa branca\>*

### Caixa Branca *\<Bloco de Construção 2\>* {#_caixa_branca_bloco_de_construção_2}

*\<modelo de caixa branca\>*

...​

### Caixa Branca *\<Bloco de Construção m\>* {#_caixa_branca_bloco_de_construção_m}

*\<modelo de caixa branca\>*

## Nível 3 {#_nível_3}

### Caixa Branca \<\_Bloco de Construção x.1\_\> {#_caixa_branca_bloco_de_construção_x_1}

*\<modelo de caixa branca\>*

### Caixa Branca \<\_Bloco de Construção x.2\_\> {#_caixa_branca_bloco_de_construção_x_2}

*\<modelo de caixa branca\>*

### Caixa Branca \<\_Bloco de Construção y.1\_\> {#_caixa_branca_bloco_de_construção_y_1}

*\<modelo de caixa branca\>*
