# Visão de Blocos de Construção {#section-building-block-view}

:::::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Conteúdo
:::

A visão de blocos de construção mostra a decomposição estática do
sistema em blocos (módulos, componentes, subsistemas, classes,
interfaces, pacotes, bibliotecas, frameworks, camadas, partições,
níveis, funções, macros, operações, estruturas de dados, ...​) bem como
suas dependências (relacionamentos, associações, ...​)
::::

Esta visão é obrigatória para toda documentação de arquitetura. Em
analogia a uma casa, esta é a *planta baixa*.

:::: formalpara
::: title
Motivação
:::

Mantenha uma visão geral do seu código-fonte tornando sua estrutura
compreensível por meio de abstração.
::::

Isso permite que você se comunique com suas partes interessadas em um
nível abstrato sem revelar detalhes de implementação.

:::: formalpara
::: title
Forma
:::

A visão de blocos de construção é uma coleção hierárquica de caixas
pretas e caixas brancas (veja a figura abaixo) e suas descrições.
::::

![Hierarquia de blocos de construção](images/05_building_blocks-EN.png)

**Nível 1** é a descrição da caixa branca do sistema geral, juntamente
com descrições de caixa preta de todos os blocos de construção contidos.

**Nível 2** amplia alguns blocos de construção do nível 1. Portanto, ele
contém a descrição da caixa branca dos blocos de construção selecionados
do nível 1, juntamente com descrições de caixa preta de seus blocos de
construção internos.

**Nível 3** amplia os blocos de construção selecionados do nível 2, e
assim por diante.

:::: formalpara
::: title
Mais informações
:::

Consulte [Building Block View](https://docs.arc42.org/section-5/) na
documentação do arc42.
::::
::::::::::::

## Visão Sistêmica Geral de Caixa Branca {#_visão_sistêmica_geral_de_caixa_branca}

:::: sidebar
::: title
:::

Aqui você descreve a decomposição geral do sistema usando o seguinte
modelo de caixa branca. Ele contém

- um diagrama de visão geral

- uma motivação para a decomposição

- descrições de caixa preta dos blocos de construção contidos. Para
  isso, oferecemos alternativas:

  - use *uma* tabela para uma visão geral curta e pragmática de todos os
    blocos de construção contidos e suas interfaces

  - use uma lista de descrições de caixa preta dos blocos de construção
    de acordo com o modelo de caixa preta (veja abaixo). Dependendo da
    sua escolha de ferramenta, esta lista pode ser subcapítulos (em
    arquivos de texto), subpáginas (em uma Wiki) ou elementos aninhados
    (em uma ferramenta de modelagem).

- (opcional:) interfaces importantes, que não são explicadas nos modelos
  de caixa preta de um bloco de construção, mas são muito importantes
  para entender a caixa branca. Já que há tantas maneiras de especificar
  interfaces, por que não fornecer um modelo específico para elas? No
  pior caso, você tem que especificar e descrever sintaxe, semântica,
  protocolos, tratamento de erros, restrições, versões, qualidades,
  compatibilidades necessárias e muito mais. Na melhor das hipóteses,
  você conseguirá usar exemplos ou descrições simples.
::::

***\<Diagrama de Visão Geral\>***

Motivação

:   *\<explicação textual\>*

Blocos de Construção Contidos

:   *\<Descrição dos blocos de construção contidos (caixas pretas)\>*

Interfaces Importantes

:   *\<Descrição de interfaces importantes\>*

:::: sidebar
::: title
:::

Insira suas explicações de caixas pretas do nível 1:

Se você usar a forma tabular, você descreverá apenas suas caixas pretas
com nome e responsabilidade de acordo com o seguinte esquema:

+----------------------+-----------------------------------------------+
| **Nome**             | **Responsabilidade**                          |
+======================+===============================================+
| *\<caixa preta 1\>*  | *\<Texto\>*                                   |
+----------------------+-----------------------------------------------+
| *\<caixa preta 2\>*  | *\<Texto\>*                                   |
+----------------------+-----------------------------------------------+

Se você usar uma lista de descrições de caixa preta, então você preenche
um modelo de caixa preta separado para cada bloco de construção
importante. Seu título é o nome da caixa preta.
::::

### \<Nome Caixa Preta 1\> {#_nome_caixa_preta_1}

:::: sidebar
::: title
:::

Aqui você descreve \<caixa preta 1\> de acordo com o seguinte modelo de
caixa preta:

- Propósito/Responsabilidade

- Interface(s), quando não são extraídas como parágrafos separados.
  Essas interfaces podem incluir qualidades e características de
  desempenho.

- (Opcional) Características de qualidade/desempenho da caixa preta, por
  exemplo, disponibilidade, comportamento de tempo de execução, ...​.

- (Opcional) Local do diretório/arquivo

- (Opcional) Requisitos atendidos (se você precisar de rastreabilidade
  para requisitos).

- (Opcional) Problemas/questões/riscos abertos
::::

*\<Propósito/Responsabilidade\>*

*\<Interface(s)\>*

*\<(Opcional) Características de Qualidade/Desempenho\>*

*\<(Opcional) Local do Diretório/Arquivo\>*

*\<(Opcional) Requisitos Cumpridos\>*

*\<(opcional) Problemas/Riscos Abertos\>*

### \<Nome Caixa Preta 2\> {#_nome_caixa_preta_2}

*\<modelo de caixa preta\>*

### \<Nome Caixa Preta n\> {#_nome_caixa_preta_n}

*\<modelo de caixa preta\>*

### \<Nome Interface 1\> {#_nome_interface_1}

...​

### \<Nome Interface m\> {#_nome_interface_m}

## Nível 2 {#_nível_2}

:::: sidebar
::: title
:::

Aqui você pode especificar a estrutura interna de (alguns) blocos de
construção do nível 1 como caixas brancas.

Você tem que decidir quais blocos de construção do seu sistema são
importantes o suficiente para justificar uma descrição tão detalhada.
Por favor, prefira relevância à completude. Especifique blocos de
construção importantes, surpreendentes, arriscados, complexos ou
voláteis. Deixe de fora partes normais, simples, chatas ou padronizadas
do seu sistema
::::

### Caixa Branca *\<Bloco de Construção 1\>* {#_caixa_branca_bloco_de_construção_1}

:::: sidebar
::: title
:::

...​descreve a estrutura interna do *bloco de construção 1*.
::::

*\<modelo de caixa branca\>*

### Caixa Branca *\<Bloco de Construção 2\>* {#_caixa_branca_bloco_de_construção_2}

*\<modelo de caixa branca\>*

...​

### Caixa Branca *\<Bloco de Construção m\>* {#_caixa_branca_bloco_de_construção_m}

*\<modelo de caixa branca\>*

## Nível 3 {#_nível_3}

:::: sidebar
::: title
:::

Aqui você pode especificar a estrutura interna de (alguns) blocos de
construção do nível 2 como caixas brancas.

Quando precisar de níveis mais detalhados de sua arquitetura, copie esta
parte do arc42 para níveis adicionais.
::::

### Caixa Branca \<\_Bloco de Construção x.1\_\> {#_caixa_branca_bloco_de_construção_x_1}

:::: sidebar
::: title
:::

Especifica a estrutura interna do *bloco de construção x.1*.
::::

*\<modelo de caixa branca\>*

### Caixa Branca \<\_Bloco de Construção x.2\_\> {#_caixa_branca_bloco_de_construção_x_2}

*\<modelo de caixa branca\>*

### Caixa Branca \<\_Bloco de Construção y.1\_\> {#_caixa_branca_bloco_de_construção_y_1}

*\<modelo de caixa branca\>*
