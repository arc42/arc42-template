# Riscos e Débitos Técnicos {#section-technical-risks}

:::::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Conteúdo
:::

Uma lista de riscos técnicos identificados ou débitos técnicos,
ordenadas por prioridade
::::

:::: formalpara
::: title
Motivação
:::

"Gerenciamento de riscos é gerenciamento de projetos para adultos" (Tim
Lister, Atlantic Systems Guild.)
::::

Este deve ser seu lema para detecção e avaliação sistemáticas de riscos
e débitos técnicos na arquitetura, que serão necessárias para as partes
interessadas da gerência (por exemplo, gerentes de projeto,
proprietários de produtos) como parte da análise geral de riscos e
planejamento de medição.

:::: formalpara
::: title
Forma
:::

Lista de riscos e/ou débitos técnicos, provavelmente incluindo medidas
sugeridas para minimizar, mitigar ou evitar riscos ou reduzir débitos
técnicos.
::::

:::: formalpara
::: title
Mais informações
:::

Veja [Risks and Technical Debt](https://docs.arc42.org/section-11/) na
documentação do arc42.
::::
::::::::::::
