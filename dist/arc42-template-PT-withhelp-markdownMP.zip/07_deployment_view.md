# Visão de Implantação {#section-deployment-view}

## Nível de Infraestrutura 1 {#_nível_de_infraestrutura_1}

***\<Diagrama de Visão Geral\>***

Motivação

:   *\<explicação em forma de texto\>*

Características de Qualidade e/ou Desempenho

:   *\<explicação em forma de texto\>*

Mapeamento de Blocos de Construção para Infraestrutura

:   *\<descrição do mapeamento\>*

## Nível de Infraestrutura 2 {#_nível_de_infraestrutura_2}

### *\<Elemento de Infraestrutura 1\>* {#_elemento_de_infraestrutura_1}

*\<diagrama + explicação\>*

### *\<Elemento de Infraestrutura 2\>* {#_elemento_de_infraestrutura_2}

*\<diagrama + explicação\>*

...​

### *\<Elemento de Infraestrutura n\>* {#_elemento_de_infraestrutura_n}

*\<diagrama + explicação\>*
