# Contexto e Escopo {#section-context-and-scope}

## Contexto Negocial {#_contexto_negocial}

**\<Diagrama ou Tabela\>**

**\<opcionalmente: Explicação das interfaces de domínio externo\>**

## Contexto Técnico {#_contexto_técnico}

**\<Diagrama ou Tabela\>**

**\<opcionalmente: Explicação das interfaces técnicas\>**

**\<Mapeamento de entrada/saída para canais\>**
