# Glossário {#section-glossary}

:::::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Conteúdo
:::

Os termos técnicos e de domínio mais importantes que suas partes
interessadas usam ao discutir o sistema.
::::

Você também pode ver o glossário como fonte para traduções se trabalhar
em equipes multilíngues.

:::: formalpara
::: title
Motivação
:::

Você deve definir claramente seus termos, para que todas as partes
interessadas
::::

- tenham um entendimento idêntico desses termos

- não usem sinônimos e homônimos

:::: formalpara
::: title
Forma
:::

Uma tabela com colunas \<Termo\> e \<Definição\>.
::::

Possivelmente mais colunas, caso precise de traduções.

:::: formalpara
::: title
Mais informações
:::

Veja [Glossary](https://docs.arc42.org/section-12/) na documentação do
arc42.
::::
::::::::::::

+----------------------+-----------------------------------------------+
| Termo                | Definição                                     |
+======================+===============================================+
| *\<Termo-1\>*        | *\<definição-1\>*                             |
+----------------------+-----------------------------------------------+
| *\<Termo-2\>*        | *\<definição-2\>*                             |
+----------------------+-----------------------------------------------+
