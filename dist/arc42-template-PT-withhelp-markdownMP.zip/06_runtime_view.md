# Visão de Tempo de Execução {#section-runtime-view}

:::::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Conteúdo
:::

A visão de tempo de execução descreve o comportamento concreto e as
interações dos blocos de construção do sistema na forma de cenários das
seguintes áreas:
::::

- casos de uso ou recursos importantes: como os blocos de construção os
  executam?

- interações em interfaces externas críticas: como os blocos de
  construção cooperam com os usuários e sistemas vizinhos?

- operação e administração: lançamento, inicialização, parada

- cenários de erro e exceção

Observação: O principal critério para a escolha de cenários possíveis
(sequências, fluxos de trabalho) é sua **relevância arquitetural**.
**Não** é importante descrever um grande número de cenários. Você deve
documentar uma seleção representativa.

:::: formalpara
::: title
Motivação
:::

Você deve entender como (instâncias de) blocos de construção do seu
sistema realizam seu trabalho e se comunicam em tempo de execução. Você
capturará principalmente cenários em sua documentação para comunicar sua
arquitetura às partes interessadas que estão menos dispostas ou capazes
de ler e entender os modelos estáticos (visão de bloco de construção,
visão de implantação).
::::

:::: formalpara
::: title
Forma
:::

Há muitas notações para descrever cenários, por exemplo,
::::

- lista numerada de etapas (em linguagem natural)

- diagramas de atividade ou fluxogramas

- diagramas de sequência

- BPMN ou EPCs (cadeias de processos de eventos)

- máquinas de estado

- ...​

:::: formalpara
::: title
Mais informações
:::

Consulte [Runtime View](https://docs.arc42.org/section-6/) na
documentação do arc42.
::::
::::::::::::

## \<Cenário de Tempo de Execução 1\> {#_cenário_de_tempo_de_execução_1}

- *\<inserir diagrama de tempo de execução ou descrição textual do
  cenário\>*

- *\<inserir descrição dos aspectos notáveis ​​das interações entre as
  instâncias do bloco de construção descritas neste diagrama.\>*

## \<Cenário de Tempo de Execução 2\> {#_cenário_de_tempo_de_execução_2}

## ...​

## \<Cenário de Tempo de Execução n\> {#_cenário_de_tempo_de_execução_n}
