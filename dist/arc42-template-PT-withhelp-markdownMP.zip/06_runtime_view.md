# Visão de Tempo de Execução {#section-runtime-view}

## \<Cenário de Tempo de Execução 1\> {#_cenário_de_tempo_de_execução_1}

-   *\<inserir diagrama de tempo de execução ou descrição textual do
    cenário\>*

-   *\<inserir descrição dos aspectos notáveis ​​das interações entre as
    instâncias do bloco de construção descritas neste diagrama.\>*

## \<Cenário de Tempo de Execução 2\> {#_cenário_de_tempo_de_execução_2}

## ...​

## \<Cenário de Tempo de Execução n\> {#_cenário_de_tempo_de_execução_n}
