# Conceitos Transversais {#section-concepts}

## *\<Conceito 1>* {#__emphasis_conceito_1_emphasis}

*\<explicação>*

## *\<Conceito 2>* {#__emphasis_conceito_2_emphasis}

*\<explicação>*

...

## *\<Conceito n>* {#__emphasis_conceito_n_emphasis}

*\<explicação>*
