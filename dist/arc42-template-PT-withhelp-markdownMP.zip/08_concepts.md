# Conceitos Transversais {#section-concepts}

:::::::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Conteúdo
:::

Esta seção descreve globalmente, as principais regulamentações e ideias
de soluções que são relevantes em várias partes (= transversais) do seu
sistema. Esses conceitos geralmente estão relacionados a vários blocos
de construção. Eles podem incluir muitos tópicos diferentes, como
::::

- modelos, especialmente modelos de domínio

- padrões de arquitetura ou *design patterns*

- regras para usar tecnologia específica

- principais decisões, geralmente técnicas, de natureza abrangente (=
  transversais)

- regras de implementação

:::: formalpara
::: title
Motivação
:::

Os conceitos formam a base para a *integridade conceitual*
(consistência, homogeneidade) da arquitetura. Portanto, eles são uma
contribuição importante para atingir as qualidades internas do seu
sistema.
::::

Alguns desses conceitos não podem ser atribuídos a blocos de construção
individuais, por exemplo segurança ou proteção.

:::: formalpara
::: title
Forma
:::

A forma pode ser variada:
::::

- documentos conceituais com qualquer tipo de estrutura

- trechos ou cenários de modelos transversais usando notações das
  visualizações de arquitetura

- amostra de implementações, especialmente para conceitos técnicos

- referência ao uso típico de *frameworks* padrão (por exemplo, usando
  Hibernate para mapeamento de objeto/relacional)

:::: formalpara
::: title
Estrutura
:::

Uma estrutura potencial (mas não obrigatória) para esta seção poderia
ser:
::::

- Conceitos de domínio

- Conceitos de Experiência do Usuário (UX)

- Conceitos de proteção e segurança

- Padrões de arquitetura e *design patterns*

- Estruturas internas

- Conceitos de desenvolvimento

- Conceitos operacionais

Observação: pode ser difícil atribuir conceitos individuais a um tópico
específico nesta lista.

![Tópicos possíveis para conceitos
transversais](images/08-concepts-EN.drawio.png)

:::: formalpara
::: title
Mais informações
:::

Veja [Concepts](https://docs.arc42.org/section-8/) na documentação do
arc42.
::::
::::::::::::::

## *\<Conceito 1\>* {#_conceito_1}

*\<explicação\>*

## *\<Conceito 2\>* {#_conceito_2}

*\<explicação\>*

...​

## *\<Conceito n\>* {#_conceito_n}

*\<explicação\>*
