# Conceitos Transversais {#section-concepts}

## *\<Conceito 1\>* {#_conceito_1}

*\<explicação\>*

## *\<Conceito 2\>* {#_conceito_2}

*\<explicação\>*

...​

## *\<Conceito n\>* {#_conceito_n}

*\<explicação\>*
