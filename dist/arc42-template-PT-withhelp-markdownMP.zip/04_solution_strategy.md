# Estratégia de Solução {#section-solution-strategy}
