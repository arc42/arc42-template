# 

**O arc42**

arc42, šablona pro dokumentaci softwaru a architekturu systému.

Verze šablony 8.1 CZ. (na základě AsciiDoc verze), říjen 2022

Created, maintained and © by Dr. Peter Hruschka, Dr. Gernot Starke and
contributors. Viz <https://arc42.org>.

# Úvod a cíle

## Přehled požadavků

## Kvalitativní cíle

## Strany zainteresované na systému (Stakeholder)

| Role/Jméno   | Kontakt         | Očekávání         |
|--------------|-----------------|-------------------|
| *\<Role-1\>* | *\<Kontakt-1\>* | *\<Očekávání-1\>* |
| *\<Role-2\>* | *\<Kontakt-2\>* | *\<Očekávání-2\>* |

# Omezení na realizaci systému

# Vymezení a rozsah systému

## Firemní kontext

**\<vložte diagram nebo tabulku\>**

**\<(volitelně:) vložte vysvětlení externích doménových rozhraní\>**

## Technický kontext

**\<vložte diagram nebo tabulku\>**

**\<(volitelně:) vložte vysvětlení externích technických rozhraní\>**

**\<mapování doménových vstupu/výstupu na technické kanály\>**

# Strategie řešení

# Perspektiva stavebních bloků

## Celý systém jako white-box

***\<vložte přehledový diagram celého systému\>***

Motivace  
*\<popište motivaci\>*

Obsažené stavební bloky  
*\<popište obsažené stavební bloky (jako black-box)\>*

Důležitá rozhraní  
*\<popište důležitá rozhraní\>*

### \<Jméno black-boxu 1\>

*\<Účel/Odpovědnost\>*

*\<Rozhraní\>*

*\<(Volitelně) Požadavky na kvalitu/výkon\>*

*\<(Volitelně) Umístění/složky a soubory\>*

*\<(Volitelně) Splněné požadavky\>*

*\<(Volitelně) Nevyřešené body/problémy/rizika\>*

### \<Jméno black-boxu 2\>

*\<šablona black-box\>*

### \<Jméno black-boxu n\>

*\<šablona black-box\>*

### \<Jméno rozhraní 1\>

…

### \<Jméno rozhraní m\>

## Úroveň 2

### white-box *\<stavební blok 1\>*

*\<šablona white-box\>*

### white-box *\<stavební blok 2\>*

*\<šablona white-box\>*

…

### white-box *\<stavební blok m\>*

*\<šablona white-box\>*

## Úroveň 3

### white-box \<\_stavební blok x.1\_\>

*\<šablona white-box\>*

### white-box \<\_stavební blok x.2\_\>

*\<šablona white-box\>*

### white-box \<\_stavební blok y.1\_\>

*\<šablona white-box\>*

# Perspektiva chování za běhu (runtime)

## \<Scénář runtime 1\>

- *\<vložte runtime diagram nebo textový popis scénáře\>*

- *\<vložte popis důležitých interakcí mezi instancemi stavebních bloků
  zobrazených v tomto diagramu\>*

## \<Scénář runtime 2\>

## …

## \<Scénář runtime n\>

# Perspektiva nasazení softwaru (deployment)

## Úroveň infrastruktury 1

***\<Přehledový diagram\>***

Motivace  
*\<vysvětlení v textové podobě\>*

Kvalitativní a/nebo výkonnostní vlastnosti  
*\<vysvětlení v textové podobě\>*

Mapování softwarových artefaktů na prvky infrastruktury  
*\<popis mapování\>*

## Úroveň infrastruktury 2

### *\<prvek infrastruktury 1\>*

*\<diagram + vysvětlení\>*

### *\<prvek infrastruktury 2\>*

*\<diagram + vysvětlení\>*

…

### *\<prvek infrastruktury n\>*

*\<diagram + vysvětlení\>*

# Průřezové (cross-cutting) koncepty

## *\<Koncept 1\>*

*\<vysvětlení\>*

## *\<Koncept 2\>*

*\<vysvětlení\>*

…

## *\<Koncept n\>*

*\<vysvětlení\>*

# Rozhodnutí o architektuře

# Požadavky na kvalitu

## Strom kvality

## Scénáře kvality

# Rizika a technické dluhy

# Slovník pojmů

| Termín         | Definice         |
|----------------|------------------|
| *\<termín-1\>* | *\<definice-1\>* |
| *\<termín-2\>* | *\<definice-2\>* |
