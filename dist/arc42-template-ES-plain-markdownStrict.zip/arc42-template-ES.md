**Acerca de arc42**

arc42, La plantilla de documentación para arquitectura de sistemas y de
software.

Por Dr. Gernot Starke, Dr. Peter Hruschka y otros contribuyentes.

Revisión de la plantilla: 7.0 ES (basada en asciidoc), Enero 2017

© Reconocemos que este documento utiliza material de la plantilla de
arquitectura arc 42, <http://www.arc42.de>. Creada por Dr. Peter
Hruschka y Dr. Gernot Starke.

Introducción y Metas
====================

Vista de Requerimientos
-----------------------

Metas de Calidad
----------------

Partes interesadas (Stakeholders)
---------------------------------

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr class="header">
<th>Rol/Nombre</th>
<th>Contacto</th>
<th>Expectativas</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><p><em>&lt;Role-1&gt;</em></p></td>
<td><p><em>&lt;Contact-1&gt;</em></p></td>
<td><p><em>&lt;Expectation-1&gt;</em></p></td>
</tr>
<tr class="even">
<td><p><em>&lt;Role-2&gt;</em></p></td>
<td><p><em>&lt;Contact-2&gt;</em></p></td>
<td><p><em>&lt;Expectation-2&gt;</em></p></td>
</tr>
</tbody>
</table>

Restricciones de la Arquitectura
================================

Alcance y Contexto del Sistema
==============================

Contexto de Negocio
-------------------

**&lt;Diagrama o Tabla&gt;**

**&lt;optionally: Explanation of external domain interfaces&gt;**

Contexto Técnico
----------------

**&lt;Diagrama o Tabla&gt;**

**&lt;Opcional: Explicación de las interfases técnicas&gt;**

**&lt;Mapeo de Entrada/Salida a canales&gt;**

Estrategia de solución
======================

Vista de Bloques
================

Sistema General de Caja Blanca
------------------------------

***&lt;Diagrama general&gt;***

Motivación  
*&lt;Explicación en texto&gt;*

Bloques de construcción contenidos  
*&lt;Desripción de los bloques de construcción contenidos (Cajas
negras)&gt;*

Interfases importantes  
*&lt;Descripción de las interfases importantes&gt;*

### &lt;Caja Negra 1&gt;

*&lt;Propósito/Responsabilidad&gt;*

*&lt;Interfase(s)&gt;*

*&lt;(Opcional) Características de Calidad/Performance&gt;*

*&lt;(Opcional) Ubicación Archivo/Directorio&gt;*

*&lt;(Opcional) Requerimientos Satisfechos&gt;*

*&lt;(Opcional) Riesgos/Problemas/Incidentes Abiertos&gt;*

### &lt;Caja Negra 2&gt;

*&lt;plantilla de caja negra&gt;*

### &lt;Caja Negra N&gt;

*&lt;Plantilla de caja negra&gt;*

### &lt;Interfase 1&gt;

…

### &lt;Interfase m&gt;

Nivel 2
-------

### Caja Blanca *&lt;bloque de construcción 1&gt;*

*&lt;plantilla de caja blanca&gt;*

### Caja Blanca *&lt;bloque de construcción 2&gt;*

*&lt;plantilla de caja blanca&gt;*

…

### Caja Blanca *&lt;bloque de construcción m&gt;*

*&lt;plantilla de caja blanca&gt;*

Nivel 3
-------

### Caja Blanca &lt;\_bloque de construcción x.1\_&gt;

*&lt;plantilla de caja blanca&gt;*

### Caja Blanca &lt;\_bloque de construcción x.2\_&gt;

*&lt;plantilla de caja blanca&gt;*

### Caja Blanca &lt;\_bloque de construcción y.1\_&gt;

*&lt;plantilla de caja blanca&gt;*

Vista de Ejecución
==================

&lt;Escenario de ejecución 1&gt;
--------------------------------

-   *&lt;Inserte un diagrama de ejecución o la descripción del
    escenario&gt;*

-   *&lt;Inserte la descripción de aspectos notables de las
    interacciones entre los bloques de construcción mostrados en este
    diagrama.&gt;*

&lt;Escenario de ejecución 2&gt;
--------------------------------

…
-

&lt;Escenario de ejecución n&gt;
--------------------------------

Vista de Despliegue
===================

Nivel de infraestructura 1
--------------------------

***&lt;Diagrama General&gt;***

Motivación  
*&lt;Explicación en forma textual&gt;*

Características de Calidad/Rendimiento  
*&lt;Explicación en forma textual&gt;*

Mapeo de los Bloques de Construcción a Infraestructura  
*&lt;Descripción del mapeo&gt;*

Nivel de Infraestructura 2
--------------------------

### *&lt;Elemento de Infraestructura 1&gt;*

*&lt;diagrama + explicación&gt;*

### *&lt;Elemento de Infraestructura 2&gt;*

*&lt;diagrama + explicación&gt;*

…

### *&lt;Elemento de Infraestructura n&gt;*

*&lt;diagrama + explicación&gt;*

Conceptos Transversales (Cross-cutting)
=======================================

*&lt;Concepto 1&gt;*
--------------------

*&lt;explicación&gt;*

*&lt;Concepto 2&gt;*
--------------------

*&lt;explicación&gt;*

…

*&lt;Concepto n&gt;*
--------------------

*&lt;explicación&gt;*

Decisiones de Diseño
====================

Requerimientos de Calidad
=========================

Árbol de Calidad
----------------

Escenarios de calidad
---------------------

Riesgos y deuda técnica
=======================

Glosario
========

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th>Término</th>
<th>Definición</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><p><em>&lt;Término-1&gt;</em></p></td>
<td><p><em>&lt;definicion-1&gt;</em></p></td>
</tr>
<tr class="even">
<td><p><em>&lt;Término-2&gt;</em></p></td>
<td><p><em>&lt;definicion-2&gt;</em></p></td>
</tr>
</tbody>
</table>
