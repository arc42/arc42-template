**Über arc42**

arc42, das Template zur Dokumentation von Software- und
Systemarchitekturen.

Erstellt von Dr. Gernot Starke, Dr. Peter Hruschka und Mitwirkenden.

Template Revision: 7.0 DE (asciidoc-based), January 2017

© We acknowledge that this document uses material from the arc 42
architecture template, http://www.arc42.de. Created by Dr. Peter
Hruschka & Dr. Gernot Starke.

.. _section-introduction-and-goals:

Einführung und Ziele
====================

.. __aufgabenstellung:

Aufgabenstellung
----------------

.. __qualitätsziele:

Qualitätsziele
--------------

.. __stakeholder:

Stakeholder
-----------

+-----------------+-----------------+-----------------------------------+
| Rolle           | Kontakt         | Erwartungshaltung                 |
+=================+=================+===================================+
| *<Rolle-1>*     | *<Kontakt-1>*   | *<Erwartung-1>*                   |
+-----------------+-----------------+-----------------------------------+
| *<Rolle-2>*     | *<Kontakt-2>*   | *<Erwartung-2>*                   |
+-----------------+-----------------+-----------------------------------+

.. _section-architecture-constraints:

Randbedingungen
===============

.. _section-system-scope-and-context:

Kontextabgrenzung
=================

.. __fachlicher_kontext:

Fachlicher Kontext
------------------

**<Diagramm und/oder Tabelle>**

**<optional: Erläuterung der externen fachlichen Schnittstellen>**

.. __technischer_kontext:

Technischer Kontext
-------------------

**<Diagramm oder Tabelle>**

**<optional: Erläuterung der externen technischen Schnittstellen>**

**<Mapping fachliche auf technische Schnittstellen>**

.. _section-solution-strategy:

Lösungsstrategie
================

.. _section-building-block-view:

Bausteinsicht
=============

.. __whitebox_gesamtsystem:

Whitebox Gesamtsystem
---------------------

**<Übersichtsdiagramm>**

Begründung
   *<Erläuternder Text>*

Enthaltene Bausteine
   *<Beschreibung der enthaltenen Bausteine (Blackboxen)>*

Wichtige Schnittstellen
   *<Beschreibung wichtiger Schnittstellen>*

.. __name_blackbox_1:

<Name Blackbox 1>
~~~~~~~~~~~~~~~~~

*<Zweck/Verantwortung>*

*<Schnittstelle(n)>*

*<(Optional) Qualitäts-/Leistungsmerkmale>*

*<(Optional) Ablageort/Datei(en)>*

*<(Optional) Erfüllte Anforderungen>*

*<(optional) Offene Punkte/Probleme/Risiken>*

.. __name_blackbox_2:

<Name Blackbox 2>
~~~~~~~~~~~~~~~~~

*<Blackbox-Template>*

.. __name_blackbox_n:

<Name Blackbox n>
~~~~~~~~~~~~~~~~~

*<Blackbox-Template>*

.. __name_schnittstelle_1:

<Name Schnittstelle 1>
~~~~~~~~~~~~~~~~~~~~~~

…​

.. __name_schnittstelle_m:

<Name Schnittstelle m>
~~~~~~~~~~~~~~~~~~~~~~

.. __ebene_2:

Ebene 2
-------

.. __whitebox_baustein_1:

Whitebox *<Baustein 1>*
~~~~~~~~~~~~~~~~~~~~~~~

*<Whitebox-Template>*

.. __whitebox_baustein_2:

Whitebox *<Baustein 2>*
~~~~~~~~~~~~~~~~~~~~~~~

*<Whitebox-Template>*

…​

.. __whitebox_baustein_m:

Whitebox *<Baustein m>*
~~~~~~~~~~~~~~~~~~~~~~~

*<Whitebox-Template>*

.. __ebene_3:

Ebene 3
-------

.. __whitebox_baustein_x_1:

Whitebox <_Baustein x.1_>
~~~~~~~~~~~~~~~~~~~~~~~~~

*<Whitebox-Template>*

.. __whitebox_baustein_x_2:

Whitebox <_Baustein x.2_>
~~~~~~~~~~~~~~~~~~~~~~~~~

*<Whitebox-Template>*

.. __whitebox_baustein_y_1:

Whitebox <_Baustein y.1_>
~~~~~~~~~~~~~~~~~~~~~~~~~

*<Whitebox-Template>*

.. _section-runtime-view:

Laufzeitsicht
=============

.. __bezeichnung_laufzeitszenario_1:

*<Bezeichnung Laufzeitszenario 1>*
----------------------------------

-  <hier Laufzeitdiagramm oder Ablaufbeschreibung einfügen>

-  <hier Besonderheiten bei dem Zusammenspiel der Bausteine in diesem
   Szenario erläutern>

.. __bezeichnung_laufzeitszenario_2:

*<Bezeichnung Laufzeitszenario 2>*
----------------------------------

…​

.. __bezeichnung_laufzeitszenario_n:

*<Bezeichnung Laufzeitszenario n>*
----------------------------------

…​

.. _section-deployment-view:

Verteilungssicht
================

.. __infrastruktur_ebene_1:

Infrastruktur Ebene 1
---------------------

**<Übersichtsdiagramm>**

Begründung
   *<Erläuternder Text>*

Qualitäts- und/oder Leistungsmerkmale
   *<Erläuternder Text>*

Zuordnung von Bausteinen zu Infrastruktur
   *<Beschreibung der Zuordnung>*

.. __infrastruktur_ebene_2:

Infrastruktur Ebene 2
---------------------

.. __infrastrukturelement_1:

*<Infrastrukturelement 1>*
~~~~~~~~~~~~~~~~~~~~~~~~~~

*<Diagramm + Erläuterungen>*

.. __infrastrukturelement_2:

*<Infrastrukturelement 2>*
~~~~~~~~~~~~~~~~~~~~~~~~~~

*<Diagramm + Erläuterungen>*

…​

.. __infrastrukturelement_n:

*<Infrastrukturelement n>*
~~~~~~~~~~~~~~~~~~~~~~~~~~

*<Diagramm + Erläuterungen>*

.. _section-concepts:

Querschnittliche Konzepte
=========================

.. __konzept_1:

*<Konzept 1>*
-------------

*<Erklärung>*

.. __konzept_2:

*<Konzept 2>*
-------------

*<Erklärung>*

…​

.. __konzept_n:

*<Konzept n>*
-------------

*<Erklärung>*

.. _section-design-decisions:

Entwurfsentscheidungen
======================

.. _section-quality-scenarios:

Qualitätsanforderungen
======================

.. __qualitätsbaum:

Qualitätsbaum
-------------

.. __qualitätsszenarien:

Qualitätsszenarien
------------------

.. _section-technical-risks:

Risiken und technische Schulden
===============================

.. _section-glossary:

Glossar
=======

+----------------------+-----------------------------------------------+
| Begriff              | Definition                                    |
+======================+===============================================+
| *<Begriff-1>*        | *<Definition-1>*                              |
+----------------------+-----------------------------------------------+
| *<Begriff-2*         | *<Definition-2>*                              |
+----------------------+-----------------------------------------------+

.. |arc42| image:: images/arc42-logo.png

