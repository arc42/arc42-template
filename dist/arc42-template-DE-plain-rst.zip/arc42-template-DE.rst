================
|arc42| Template
================

:Date: Juli 2025

**Über arc42**

arc42, das Template zur Dokumentation von Software- und
Systemarchitekturen.

Template Version 9.0-DE. (basiert auf der AsciiDoc Version), Juli 2025

Created, maintained and © by Dr. Peter Hruschka, Dr. Gernot Starke and
contributors. Siehe https://arc42.org.

.. _section-introduction-and-goals:

Einführung und Ziele
====================

.. _`_aufgabenstellung`:

Aufgabenstellung
----------------

.. _`_qualitätsziele`:

Qualitätsziele
--------------

.. _`_stakeholder`:

Stakeholder
-----------

+-----------------+-----------------+-----------------------------------+
| Rolle           | Kontakt         | Erwartungshaltung                 |
+=================+=================+===================================+
| *<Rolle-1>*     | *<Kontakt-1>*   | *<Erwartung-1>*                   |
+-----------------+-----------------+-----------------------------------+
| *<Rolle-2>*     | *<Kontakt-2>*   | *<Erwartung-2>*                   |
+-----------------+-----------------+-----------------------------------+

.. _section-architecture-constraints:

Randbedingungen
===============

.. _section-context-and-scope:

Kontextabgrenzung
=================

.. _`_fachlicher_kontext`:

Fachlicher Kontext
------------------

**<Diagramm und/oder Tabelle>**

**<optional: Erläuterung der externen fachlichen Schnittstellen>**

.. _`_technischer_kontext`:

Technischer Kontext
-------------------

**<Diagramm oder Tabelle>**

**<optional: Erläuterung der externen technischen Schnittstellen>**

**<Mapping fachliche auf technische Schnittstellen>**

.. _section-solution-strategy:

Lösungsstrategie
================

.. _section-building-block-view:

Bausteinsicht
=============

.. _`_whitebox_gesamtsystem`:

Whitebox Gesamtsystem
---------------------

**<Übersichtsdiagramm>**

Begründung
   *<Erläuternder Text>*

Enthaltene Bausteine
   *<Beschreibung der enthaltenen Bausteine (Blackboxen)>*

Wichtige Schnittstellen
   *<Beschreibung wichtiger Schnittstellen>*

.. _`_name_blackbox_1`:

<Name Blackbox 1>
~~~~~~~~~~~~~~~~~

*<Zweck/Verantwortung>*

*<Schnittstelle(n)>*

*<(Optional) Qualitäts-/Leistungsmerkmale>*

*<(Optional) Ablageort/Datei(en)>*

*<(Optional) Erfüllte Anforderungen>*

*<(optional) Offene Punkte/Probleme/Risiken>*

.. _`_name_blackbox_2`:

<Name Blackbox 2>
~~~~~~~~~~~~~~~~~

*<Blackbox-Template>*

.. _`_name_blackbox_n`:

<Name Blackbox n>
~~~~~~~~~~~~~~~~~

*<Blackbox-Template>*

.. _`_name_schnittstelle_1`:

<Name Schnittstelle 1>
~~~~~~~~~~~~~~~~~~~~~~

…​

.. _`_name_schnittstelle_m`:

<Name Schnittstelle m>
~~~~~~~~~~~~~~~~~~~~~~

.. _`_ebene_2`:

Ebene 2
-------

.. _`_whitebox_baustein_1`:

Whitebox *<Baustein 1>*
~~~~~~~~~~~~~~~~~~~~~~~

*<Whitebox-Template>*

.. _`_whitebox_baustein_2`:

Whitebox *<Baustein 2>*
~~~~~~~~~~~~~~~~~~~~~~~

*<Whitebox-Template>*

…​

.. _`_whitebox_baustein_m`:

Whitebox *<Baustein m>*
~~~~~~~~~~~~~~~~~~~~~~~

*<Whitebox-Template>*

.. _`_ebene_3`:

Ebene 3
-------

.. _`_whitebox_baustein_x_1`:

Whitebox <\_Baustein x.1\_>
~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<Whitebox-Template>*

.. _`_whitebox_baustein_x_2`:

Whitebox <\_Baustein x.2\_>
~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<Whitebox-Template>*

.. _`_whitebox_baustein_y_1`:

Whitebox <\_Baustein y.1\_>
~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<Whitebox-Template>*

.. _section-runtime-view:

Laufzeitsicht
=============

.. _`_bezeichnung_laufzeitszenario_1`:

*<Bezeichnung Laufzeitszenario 1>*
----------------------------------

-  <hier Laufzeitdiagramm oder Ablaufbeschreibung einfügen>

-  <hier Besonderheiten bei dem Zusammenspiel der Bausteine in diesem
   Szenario erläutern>

.. _`_bezeichnung_laufzeitszenario_2`:

*<Bezeichnung Laufzeitszenario 2>*
----------------------------------

…​

.. _`_bezeichnung_laufzeitszenario_n`:

*<Bezeichnung Laufzeitszenario n>*
----------------------------------

…​

.. _section-deployment-view:

Verteilungssicht
================

.. _`_infrastruktur_ebene_1`:

Infrastruktur Ebene 1
---------------------

**<Übersichtsdiagramm>**

Begründung
   *<Erläuternder Text>*

Qualitäts- und/oder Leistungsmerkmale
   *<Erläuternder Text>*

Zuordnung von Bausteinen zu Infrastruktur
   *<Beschreibung der Zuordnung>*

.. _`_infrastruktur_ebene_2`:

Infrastruktur Ebene 2
---------------------

.. _`_infrastrukturelement_1`:

*<Infrastrukturelement 1>*
~~~~~~~~~~~~~~~~~~~~~~~~~~

*<Diagramm + Erläuterungen>*

.. _`_infrastrukturelement_2`:

*<Infrastrukturelement 2>*
~~~~~~~~~~~~~~~~~~~~~~~~~~

*<Diagramm + Erläuterungen>*

…​

.. _`_infrastrukturelement_n`:

*<Infrastrukturelement n>*
~~~~~~~~~~~~~~~~~~~~~~~~~~

*<Diagramm + Erläuterungen>*

.. _section-concepts:

Querschnittliche Konzepte
=========================

.. _`_konzept_1`:

*<Konzept 1>*
-------------

*<Erklärung>*

.. _`_konzept_2`:

*<Konzept 2>*
-------------

*<Erklärung>*

…​

.. _`_konzept_n`:

*<Konzept n>*
-------------

*<Erklärung>*

.. _section-design-decisions:

Architekturentscheidungen
=========================

.. _section-quality-scenarios:

Qualitätsanforderungen
======================

.. _`_übersicht_der_qualitätsanforderungen`:

Übersicht der Qualitätsanforderungen
------------------------------------

.. _`_qualitätsszenarien`:

Qualitätsszenarien
------------------

.. _section-technical-risks:

Risiken und technische Schulden
===============================

.. _section-glossary:

Glossar
=======

+----------------------+-----------------------------------------------+
| Begriff              | Definition                                    |
+======================+===============================================+
| *<Begriff-1>*        | *<Definition-1>*                              |
+----------------------+-----------------------------------------------+
| *<Begriff-2*         | *<Definition-2>*                              |
+----------------------+-----------------------------------------------+

.. |arc42| image:: images/arc42-logo.png
