**Über arc42**

arc42, das Template zur Dokumentation von Software- und
Systemarchitekturen.

Template Version 8.2 DE. (basiert auf AsciiDoc Version), Januar 2023

Created, maintained and © by Dr. Peter Hruschka, Dr. Gernot Starke and
contributors. Siehe https://arc42.org.

.. _section-introduction-and-goals:

Einführung und Ziele
====================

.. _`_aufgabenstellung`:

Aufgabenstellung
----------------

.. _`_qualit_tsziele`:

Qualitätsziele
--------------

.. _`_stakeholder`:

Stakeholder
-----------

+-----------------+-----------------+-----------------------------------+
| Rolle           | Kontakt         | Erwartungshaltung                 |
+=================+=================+===================================+
| *<Rolle-1>*     | *<Kontakt-1>*   | *<Erwartung-1>*                   |
+-----------------+-----------------+-----------------------------------+
| *<Rolle-2>*     | *<Kontakt-2>*   | *<Erwartung-2>*                   |
+-----------------+-----------------+-----------------------------------+

.. _section-architecture-constraints:

Randbedingungen
===============

.. _section-context-and-scope:

Kontextabgrenzung
=================

.. _`_fachlicher_kontext`:

Fachlicher Kontext
------------------

**<Diagramm und/oder Tabelle>**

**<optional: Erläuterung der externen fachlichen Schnittstellen>**

.. _`_technischer_kontext`:

Technischer Kontext
-------------------

**<Diagramm oder Tabelle>**

**<optional: Erläuterung der externen technischen Schnittstellen>**

**<Mapping fachliche auf technische Schnittstellen>**

.. _section-solution-strategy:

Lösungsstrategie
================

.. _section-building-block-view:

Bausteinsicht
=============

.. _`_whitebox_gesamtsystem`:

Whitebox Gesamtsystem
---------------------

**<Übersichtsdiagramm>**

Begründung
   *<Erläuternder Text>*

Enthaltene Bausteine
   *<Beschreibung der enthaltenen Bausteine (Blackboxen)>*

Wichtige Schnittstellen
   *<Beschreibung wichtiger Schnittstellen>*

.. _`__name_blackbox_1`:

<Name Blackbox 1>
~~~~~~~~~~~~~~~~~

*<Zweck/Verantwortung>*

*<Schnittstelle(n)>*

*<(Optional) Qualitäts-/Leistungsmerkmale>*

*<(Optional) Ablageort/Datei(en)>*

*<(Optional) Erfüllte Anforderungen>*

*<(optional) Offene Punkte/Probleme/Risiken>*

.. _`__name_blackbox_2`:

<Name Blackbox 2>
~~~~~~~~~~~~~~~~~

*<Blackbox-Template>*

.. _`__name_blackbox_n`:

<Name Blackbox n>
~~~~~~~~~~~~~~~~~

*<Blackbox-Template>*

.. _`__name_schnittstelle_1`:

<Name Schnittstelle 1>
~~~~~~~~~~~~~~~~~~~~~~

…

.. _`__name_schnittstelle_m`:

<Name Schnittstelle m>
~~~~~~~~~~~~~~~~~~~~~~

.. _`_ebene_2`:

Ebene 2
-------

.. _`_whitebox_emphasis_baustein_1_emphasis`:

Whitebox *<Baustein 1>*
~~~~~~~~~~~~~~~~~~~~~~~

*<Whitebox-Template>*

.. _`_whitebox_emphasis_baustein_2_emphasis`:

Whitebox *<Baustein 2>*
~~~~~~~~~~~~~~~~~~~~~~~

*<Whitebox-Template>*

…

.. _`_whitebox_emphasis_baustein_m_emphasis`:

Whitebox *<Baustein m>*
~~~~~~~~~~~~~~~~~~~~~~~

*<Whitebox-Template>*

.. _`_ebene_3`:

Ebene 3
-------

.. _`_whitebox_baustein_x_1`:

Whitebox <_Baustein x.1_>
~~~~~~~~~~~~~~~~~~~~~~~~~

*<Whitebox-Template>*

.. _`_whitebox_baustein_x_2`:

Whitebox <_Baustein x.2_>
~~~~~~~~~~~~~~~~~~~~~~~~~

*<Whitebox-Template>*

.. _`_whitebox_baustein_y_1`:

Whitebox <_Baustein y.1_>
~~~~~~~~~~~~~~~~~~~~~~~~~

*<Whitebox-Template>*

.. _section-runtime-view:

Laufzeitsicht
=============

.. _`__emphasis_bezeichnung_laufzeitszenario_1_emphasis`:

*<Bezeichnung Laufzeitszenario 1>*
----------------------------------

-  <hier Laufzeitdiagramm oder Ablaufbeschreibung einfügen>

-  <hier Besonderheiten bei dem Zusammenspiel der Bausteine in diesem
   Szenario erläutern>

.. _`__emphasis_bezeichnung_laufzeitszenario_2_emphasis`:

*<Bezeichnung Laufzeitszenario 2>*
----------------------------------

…

.. _`__emphasis_bezeichnung_laufzeitszenario_n_emphasis`:

*<Bezeichnung Laufzeitszenario n>*
----------------------------------

…

.. _section-deployment-view:

Verteilungssicht
================

.. _`_infrastruktur_ebene_1`:

Infrastruktur Ebene 1
---------------------

**<Übersichtsdiagramm>**

Begründung
   *<Erläuternder Text>*

Qualitäts- und/oder Leistungsmerkmale
   *<Erläuternder Text>*

Zuordnung von Bausteinen zu Infrastruktur
   *<Beschreibung der Zuordnung>*

.. _`_infrastruktur_ebene_2`:

Infrastruktur Ebene 2
---------------------

.. _`__emphasis_infrastrukturelement_1_emphasis`:

*<Infrastrukturelement 1>*
~~~~~~~~~~~~~~~~~~~~~~~~~~

*<Diagramm + Erläuterungen>*

.. _`__emphasis_infrastrukturelement_2_emphasis`:

*<Infrastrukturelement 2>*
~~~~~~~~~~~~~~~~~~~~~~~~~~

*<Diagramm + Erläuterungen>*

…

.. _`__emphasis_infrastrukturelement_n_emphasis`:

*<Infrastrukturelement n>*
~~~~~~~~~~~~~~~~~~~~~~~~~~

*<Diagramm + Erläuterungen>*

.. _section-concepts:

Querschnittliche Konzepte
=========================

.. _`__emphasis_konzept_1_emphasis`:

*<Konzept 1>*
-------------

*<Erklärung>*

.. _`__emphasis_konzept_2_emphasis`:

*<Konzept 2>*
-------------

*<Erklärung>*

…

.. _`__emphasis_konzept_n_emphasis`:

*<Konzept n>*
-------------

*<Erklärung>*

.. _section-design-decisions:

Architekturentscheidungen
=========================

.. _section-quality-scenarios:

Qualitätsanforderungen
======================

.. container:: formalpara-title

   **Weiterführende Informationen**

Siehe `Qualitätsanforderungen <https://docs.arc42.org/section-10/>`__ in
der online-Dokumentation (auf Englisch!).

.. _`_qualit_tsbaum`:

Qualitätsbaum
-------------

.. _`_qualit_tsszenarien`:

Qualitätsszenarien
------------------

.. _section-technical-risks:

Risiken und technische Schulden
===============================

.. _section-glossary:

Glossar
=======

+-----------------------+-----------------------------------------------+
| Begriff               | Definition                                    |
+=======================+===============================================+
| *<Begriff-1>*         | *<Definition-1>*                              |
+-----------------------+-----------------------------------------------+
| *<Begriff-2*          | *<Definition-2>*                              |
+-----------------------+-----------------------------------------------+

.. |arc42| image:: images/arc42-logo.png
