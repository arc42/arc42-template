# Deployment View

## Livello infrastruttura 1

***&lt;Overview Diagram&gt;***

Motivatione  
*&lt;spiegazione in forma di testo&gt;*

Requsiti di qualità e/o di prestazioni  
*&lt;spiegazione in forma di testo&gt;*

Mappatura dei Building Blocks nella Architettura  
*&lt;descrizione della mappatura&gt;*

## Livello infrastruttura 2

### *&lt;Elemento infrastruttura 1&gt;*

*&lt;diagramma + spiegazione&gt;*

### *&lt;Elemento infrastruttura 2&gt;*

*&lt;diagramma + spiegazione&gt;*

…

### *&lt;Elemento infrastruttura n&gt;*

*&lt;diagramma + spiegazione&gt;*
