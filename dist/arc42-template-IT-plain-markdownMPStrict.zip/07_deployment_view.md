# Deployment View

## Livello infrastruttura 1

***&lt;Overview Diagram>***

Motivatione  
*&lt;spiegazione in forma di testo>*

Requsiti di qualità e/o di prestazioni  
*&lt;spiegazione in forma di testo>*

Mappatura dei Building Blocks nella Architettura  
*&lt;descrizione della mappatura>*

## Livello infrastruttura 2

### *&lt;Elemento infrastruttura 1>*

*&lt;diagramma + spiegazione>*

### *&lt;Elemento infrastruttura 2>*

*&lt;diagramma + spiegazione>*

…

### *&lt;Elemento infrastruttura n>*

*&lt;diagramma + spiegazione>*
