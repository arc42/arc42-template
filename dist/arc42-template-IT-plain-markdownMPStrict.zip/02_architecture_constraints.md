# Vincoli di architettura
