# Decisioni di progettazione
