# Runtime View

## &lt;Runtime Scenario 1&gt;

-   *&lt;inserire un runtime diagram o una descrizione testuale dello
    scenario&gt;*

-   *&lt;inserire la descrizione degli aspetti degni di nota delle
    interazioni tra i istanze di building block illustrate in questo
    diagramma.&gt;*

## &lt;Runtime Scenario 2&gt;

## …

## &lt;Runtime Scenario n&gt;
