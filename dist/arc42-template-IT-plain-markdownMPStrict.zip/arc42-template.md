# 

**About arc42**

arc42, the Template for documentation of software and system
architecture.

By Dr. Gernot Starke, Dr. Peter Hruschka and contributors.

Template Revision: 7.0 IT (based on asciidoc), April 2021

© We acknowledge that this document uses material from the arc 42
architecture template, <https://www.arc42.org>. Created by Dr. Peter
Hruschka & Dr. Gernot Starke.

# Introduzione e obiettivi

## Panoramica dei requisiti

## Obiettivi di qualità

## Stakeholders

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Rouolo/Nome</th>
<th style="text-align: left;">Contatto</th>
<th style="text-align: left;">Aspettative</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Ruolo-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Contatto-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Aspettatiive-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Ruolo-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Contatto-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Aspettatiive-2&gt;</em></p></td>
</tr>
</tbody>
</table>

# Vincoli di architettura

# Ambito e contesto del sistema

## Contesto di Business

**&lt;Diagramma o Tabella>**

**&lt;opzionale: spiegazione delle interfacce del dominio esterno>**

## Contesto Tecnico

**&lt;Diagramma o Tabella>**

**&lt;opzionale: Spiegazione delle interfacce tecniche>**

**&lt;Mappatura Input/Output sui canali di comunicazione>**

# Strategia della soluzione

# Building Block View

## Whitebox Overall System

***&lt;Overview Diagram>***

Motivazione  
*&lt;spiegazione testuale>*

Contenuto dei Building Blocks  
*&lt;Descrizione del contenuto del building block (black boxes)>*

Important Interfaces  
*&lt;Descrizione delle interfacce importanti>*

### &lt;Nome black box 1>

*&lt;Scopo/responsabilità>*

*&lt;Interfacce>*

*&lt;(Facoltativo) Caratteristiche di qualità/prestazionali>*

*&lt;(Facoltativo) percorso file/directory>*

*&lt;(Facoltativo) Requisiti soddisfatti>*

*&lt;(Facoltativo) Bug noti/Rischi/problemi>*

### &lt;Nome black box 2>

*&lt;black box template>*

### &lt;Nome black box n>

*&lt;black box template>*

### &lt;Nome interface 1>

…

### &lt;Nome interface m>

## Livello 2

### White Box *&lt;building block 1>*

*&lt;white box template>*

### White Box *&lt;building block 2>*

*&lt;white box template>*

…

### White Box *&lt;building block m>*

*&lt;white box template>*

## Livello 3

### White Box &lt;\_building block x.1\_&gt;

*&lt;white box template>*

### White Box &lt;\_building block x.2\_&gt;

*&lt;white box template>*

### White Box &lt;\_building block y.1\_&gt;

*&lt;white box template>*

# Runtime View

## &lt;Runtime Scenario 1>

-   *&lt;inserire un runtime diagram o una descrizione testuale dello
    scenario>*

-   *&lt;inserire la descrizione degli aspetti degni di nota delle
    interazioni tra i istanze di building block illustrate in questo
    diagramma.>*

## &lt;Runtime Scenario 2>

## …

## &lt;Runtime Scenario n>

# Deployment View

## Livello infrastruttura 1

***&lt;Overview Diagram>***

Motivatione  
*&lt;spiegazione in forma di testo>*

Requsiti di qualità e/o di prestazioni  
*&lt;spiegazione in forma di testo>*

Mappatura dei Building Blocks nella Architettura  
*&lt;descrizione della mappatura>*

## Livello infrastruttura 2

### *&lt;Elemento infrastruttura 1>*

*&lt;diagramma + spiegazione>*

### *&lt;Elemento infrastruttura 2>*

*&lt;diagramma + spiegazione>*

…

### *&lt;Elemento infrastruttura n>*

*&lt;diagramma + spiegazione>*

# Concetti trasversali

## *&lt;Concetto 1>*

*&lt;spiegazione>*

## *&lt;Concetto 2>*

*&lt;spiegazione>*

…

## *&lt;Concetto n>*

*&lt;spiegazione>*

# Decisioni di progettazione

# Requisiti di Qualità

## Albero di qualità

## Scenari di qualità

# Rischi e debiti tecnici

# Glossario

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Termine</th>
<th style="text-align: left;">Definizione</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Termine-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definizione-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Termine-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definizione-2&gt;</em></p></td>
</tr>
</tbody>
</table>
