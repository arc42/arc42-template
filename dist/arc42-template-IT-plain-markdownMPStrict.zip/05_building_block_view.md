# Building Block View

## Whitebox Overall System

***&lt;Overview Diagram&gt;***

Motivazione  
*&lt;spiegazione testuale&gt;*

Contenuto dei Building Blocks  
*&lt;Descrizione del contenuto del building block (black boxes)&gt;*

Important Interfaces  
*&lt;Descrizione delle interfacce importanti&gt;*

### &lt;Nome black box 1&gt;

*&lt;Scopo/responsabilità&gt;*

*&lt;Interfacce&gt;*

*&lt;(Facoltativo) Caratteristiche di qualità/prestazionali&gt;*

*&lt;(Facoltativo) percorso file/directory&gt;*

*&lt;(Facoltativo) Requisiti soddisfatti&gt;*

*&lt;(Facoltativo) Bug noti/Rischi/problemi&gt;*

### &lt;Nome black box 2&gt;

*&lt;black box template&gt;*

### &lt;Nome black box n&gt;

*&lt;black box template&gt;*

### &lt;Nome interface 1&gt;

…

### &lt;Nome interface m&gt;

## Livello 2

### White Box *&lt;building block 1&gt;*

*&lt;white box template&gt;*

### White Box *&lt;building block 2&gt;*

*&lt;white box template&gt;*

…

### White Box *&lt;building block m&gt;*

*&lt;white box template&gt;*

## Livello 3

### White Box &lt;\_building block x.1\_&gt;

*&lt;white box template&gt;*

### White Box &lt;\_building block x.2\_&gt;

*&lt;white box template&gt;*

### White Box &lt;\_building block y.1\_&gt;

*&lt;white box template&gt;*
