# Building Block View

## Whitebox Overall System

***&lt;Overview Diagram>***

Motivazione  
*&lt;spiegazione testuale>*

Contenuto dei Building Blocks  
*&lt;Descrizione del contenuto del building block (black boxes)>*

Important Interfaces  
*&lt;Descrizione delle interfacce importanti>*

### &lt;Nome black box 1>

*&lt;Scopo/responsabilità>*

*&lt;Interfacce>*

*&lt;(Facoltativo) Caratteristiche di qualità/prestazionali>*

*&lt;(Facoltativo) percorso file/directory>*

*&lt;(Facoltativo) Requisiti soddisfatti>*

*&lt;(Facoltativo) Bug noti/Rischi/problemi>*

### &lt;Nome black box 2>

*&lt;black box template>*

### &lt;Nome black box n>

*&lt;black box template>*

### &lt;Nome interface 1>

…

### &lt;Nome interface m>

## Livello 2

### White Box *&lt;building block 1>*

*&lt;white box template>*

### White Box *&lt;building block 2>*

*&lt;white box template>*

…

### White Box *&lt;building block m>*

*&lt;white box template>*

## Livello 3

### White Box &lt;\_building block x.1\_&gt;

*&lt;white box template>*

### White Box &lt;\_building block x.2\_&gt;

*&lt;white box template>*

### White Box &lt;\_building block y.1\_&gt;

*&lt;white box template>*
