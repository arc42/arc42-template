# Introduzione e obiettivi

## Panoramica dei requisiti

## Obiettivi di qualità

## Stakeholders

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Rouolo/Nome</th>
<th style="text-align: left;">Contatto</th>
<th style="text-align: left;">Aspettative</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Ruolo-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Contatto-1&gt;</em></p></td>
<td
style="text-align: left;"><p><em>&lt;Aspettatiive-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Ruolo-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Contatto-2&gt;</em></p></td>
<td
style="text-align: left;"><p><em>&lt;Aspettatiive-2&gt;</em></p></td>
</tr>
</tbody>
</table>
