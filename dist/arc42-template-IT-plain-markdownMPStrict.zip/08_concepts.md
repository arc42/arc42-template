# Concetti trasversali

## *&lt;Concetto 1&gt;*

*&lt;spiegazione&gt;*

## *&lt;Concetto 2&gt;*

*&lt;spiegazione&gt;*

…

## *&lt;Concetto n&gt;*

*&lt;spiegazione&gt;*
