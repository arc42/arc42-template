# Glossario

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Termine</th>
<th style="text-align: left;">Definizione</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Termine-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definizione-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Termine-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definizione-2&gt;</em></p></td>
</tr>
</tbody>
</table>
