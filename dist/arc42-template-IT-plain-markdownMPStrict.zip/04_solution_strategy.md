# Strategia della soluzione
