# Ambito e contesto del sistema

## Contesto di Business

**&lt;Diagramma o Tabella&gt;**

**&lt;opzionale: spiegazione delle interfacce del dominio esterno&gt;**

## Contesto Tecnico

**&lt;Diagramma o Tabella&gt;**

**&lt;opzionale: Spiegazione delle interfacce tecniche&gt;**

**&lt;Mappatura Input/Output sui canali di comunicazione&gt;**
