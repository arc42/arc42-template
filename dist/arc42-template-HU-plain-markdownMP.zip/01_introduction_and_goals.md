# Bevezetés és célok {#section-introduction-and-goals}

## Követelmények áttekintése {#_követelmények_áttekintése}

## Minőségi célok {#_minőségi_célok}

## Érdekelt felek {#_érdekelt_felek}

+-------------------+---------------------------+---------------------------+
| Szerepkör/Név     | Elérhetőség               | Elvárások                 |
+===================+===========================+===========================+
| *\<Szerepkör-1\>* | *\<Elérhetőség-1\>*       | *\<Elvárás-1\>*           |
+-------------------+---------------------------+---------------------------+
| *\<Szerepkör-2\>* | *\<Elérhetőség-2\>*       | *\<Elvárás-2\>*           |
+-------------------+---------------------------+---------------------------+
