# Concepts transversaux {#section-concepts}

## *\<Concept 1\>* {#_concept_1}

*\<explication\>*

## *\<Concept 2\>* {#_concept_2}

*\<explication\>*

...​

## *\<Concept n\>* {#_concept_n}

*\<explication\>*
