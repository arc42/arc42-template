# Stratégie de solution {#section-solution-strategy}
