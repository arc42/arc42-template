# Décisions d'architecture {#section-design-decisions}
