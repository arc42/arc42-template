# Vue Exécution {#section-runtime-view}

## \<Scénario d'exécution 1> {#__sc_nario_d_ex_cution_1}

-   *\<insérer un diagramme d'exécution ou une description textuelle du
    scénario>*

-   *\<insérer une description des aspects notables des interactions
    entre les instances des briques représentées dans ce diagramme.\>*

## \<Scénario d'exécution 2> {#__sc_nario_d_ex_cution_2}

## ... {#_}

## \<Scénario d'exécution n> {#__sc_nario_d_ex_cution_n}
