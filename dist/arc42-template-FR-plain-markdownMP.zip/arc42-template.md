# 

**A propos d'arc42**

arc42, le modèle de documentation de l'architecture des logiciels et des
systèmes.

Version du modèle 8.2 FR. (basé sur la version AsciiDoc), January 2023

Créé, maintenu et © par Dr. Peter Hruschka, Dr. Gernot Starke et les
contributeurs. Voir <https://arc42.org>.

# Introduction et Objectifs {#section-introduction-and-goals}

## Vue d'ensemble des exigences {#_vue_d_ensemble_des_exigences}

## Objectifs de Qualité {#_objectifs_de_qualit}

## Parties prenantes {#_parties_prenantes}

+-------------+---------------------------+---------------------------+
| Rôle/Nom    | Contact                   | Attentes                  |
+=============+===========================+===========================+
| *\<Role-1>* | *\<Contact-1>*            | *\<Attente-1>*            |
+-------------+---------------------------+---------------------------+
| *\<Role-2>* | *\<Contact-2>*            | *\<Attente-2>*            |
+-------------+---------------------------+---------------------------+

# Constraintes d'Architecture {#section-architecture-constraints}

# Contexte et périmètre {#section-context-and-scope}

## Contexte métier {#_contexte_m_tier}

**\<Schéma ou tableau>**

**\<éventuellement : Explication des interfaces de domaines externes>**

## Contexte Technique {#_contexte_technique}

**\<Schéma ou tableau>**

**\<en option : Explication des interfaces techniques>**

**\<Correspondance des entrées/sorties aux canaux>**

# Stratégie de solution {#section-solution-strategy}

# Vue en Briques {#section-building-block-view}

## Niveau 1 : Système global Boîte blanche {#_niveau_1_syst_me_global_bo_te_blanche}

***\<Schéma d'ensemble>***

Motivation

:   *\<texte explicatif>*

Briques contenues

:   *\<Description de la brique contenue (boîte noire)>*

Interfaces Importantes

:   *\<Description des interfaces importantes>*

### \<Nom boîte noire 1> {#__nom_bo_te_noire_1}

*\<Objectif/Responsabilité>*

*\<Interface(s)>*

*\<(Facultatif) Caractéristiques de qualité/performance>*

*\<(Facultatif) Emplacement du répertoire/fichier>*

*\<(Facultatif) Exigences respectées>*

*\<(Facultatif) Questions ouvertes/problèmes/risques>*

### \<Nom boîte noire 2> {#__nom_bo_te_noire_2}

*\<template boîte noire>*

### \<Nom boîte noire n> {#__nom_bo_te_noire_n}

*\<template boîte noire>*

### \<Nom interface 1> {#__nom_interface_1}

...

### \<Nom interface m> {#__nom_interface_m}

## Niveau 2 {#_niveau_2}

### Boîte blanche *\<brique 1>* {#_bo_te_blanche_emphasis_brique_1_emphasis}

*\<template boîte blanche>*

### Boîte blanche *\<brique 2>* {#_bo_te_blanche_emphasis_brique_2_emphasis}

*\<template boîte blanche>*

...

### Boîte blanche *\<brique n>* {#_bo_te_blanche_emphasis_brique_n_emphasis}

*\<template boîte blanche>*

# Vue Exécution {#section-runtime-view}

## \<Scénario d'exécution 1> {#__sc_nario_d_ex_cution_1}

-   *\<insérer un diagramme d'exécution ou une description textuelle du
    scénario>*

-   *\<insérer une description des aspects notables des interactions
    entre les instances des briques représentées dans ce diagramme.\>*

## \<Scénario d'exécution 2> {#__sc_nario_d_ex_cution_2}

## ... {#_}

## \<Scénario d'exécution n> {#__sc_nario_d_ex_cution_n}

# Vue Déploiement {#section-deployment-view}

## Infrastructure Niveau 1 {#_infrastructure_niveau_1}

***\<Schéma d'ensemble>***

Motivation

:   *\<explication sous forme de texte>*

Caractéristiques de qualité et/ou de performance

:   *\<explication sous forme de texte>*

Correspondance des briques vis à vis de l'infrastructure

:   *\<description de la correspondance>*

## Infrastructure Niveau 2 {#_infrastructure_niveau_2}

### *\<Infrastructure Element 1>* {#__emphasis_infrastructure_element_1_emphasis}

*\<schéma + explication>*

### *\<Infrastructure Element 2>* {#__emphasis_infrastructure_element_2_emphasis}

*\<schéma + explication>*

...

### *\<Infrastructure Element n>* {#__emphasis_infrastructure_element_n_emphasis}

*\<schéma + explication>*

# Concepts transverses {#section-concepts}

## *\<Concept 1>* {#__emphasis_concept_1_emphasis}

*\<explication>*

## *\<Concept 2>* {#__emphasis_concept_2_emphasis}

*\<explication>*

...

## *\<Concept n>* {#__emphasis_concept_n_emphasis}

*\<explication>*

# Décisions d'architecture {#section-design-decisions}

# Exigences de qualité {#section-quality-scenarios}

## Arbre de qualité {#_arbre_de_qualit}

## Scénarios Qualité {#_sc_narios_qualit}

# Risques et Dettes techniques {#section-technical-risks}

# Glossaire {#section-glossary}

+-----------------------+-----------------------------------------------+
| Terme                 | Définition                                    |
+=======================+===============================================+
| *\<Terme-1>*          | *\<Définition-1>*                             |
+-----------------------+-----------------------------------------------+
| *\<Terme-2>*          | *\<Définition-2>*                             |
+-----------------------+-----------------------------------------------+
