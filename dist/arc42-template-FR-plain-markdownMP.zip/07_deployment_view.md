# Vue Déploiement {#section-deployment-view}

## Infrastructure Niveau 1 {#_infrastructure_niveau_1}

***\<Schéma d'ensemble\>***

Motivation

:   *\<explication sous forme de texte\>*

Caractéristiques de qualité et/ou de performance

:   *\<explication sous forme de texte\>*

Correspondance des briques vis à vis de l'infrastructure

:   *\<description de la correspondance\>*

## Infrastructure Niveau 2 {#_infrastructure_niveau_2}

### *\<Infrastructure Element 1\>* {#_infrastructure_element_1}

*\<schéma + explication\>*

### *\<Infrastructure Element 2\>* {#_infrastructure_element_2}

*\<schéma + explication\>*

...​

### *\<Infrastructure Element n\>* {#_infrastructure_element_n}

*\<schéma + explication\>*
