# Vue Déploiement {#section-deployment-view}

## Infrastructure Niveau 1 {#_infrastructure_niveau_1}

***\<Schéma d'ensemble>***

Motivation

:   *\<explication sous forme de texte>*

Caractéristiques de qualité et/ou de performance

:   *\<explication sous forme de texte>*

Correspondance des briques vis à vis de l'infrastructure

:   *\<description de la correspondance>*

## Infrastructure Niveau 2 {#_infrastructure_niveau_2}

### *\<Infrastructure Element 1>* {#__emphasis_infrastructure_element_1_emphasis}

*\<schéma + explication>*

### *\<Infrastructure Element 2>* {#__emphasis_infrastructure_element_2_emphasis}

*\<schéma + explication>*

...

### *\<Infrastructure Element n>* {#__emphasis_infrastructure_element_n_emphasis}

*\<schéma + explication>*
