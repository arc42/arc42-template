# Constraintes d'Architecture {#section-architecture-constraints}
