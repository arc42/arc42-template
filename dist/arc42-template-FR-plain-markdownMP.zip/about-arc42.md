# 

**A propos d'arc42**

arc42, le modèle de documentation de l'architecture des logiciels et des
systèmes.

Version du modèle 9.0-FR. (basé sur la version AsciiDoc), Avril 2025

Créé, maintenu et © par Dr. Peter Hruschka, Dr. Gernot Starke et les
contributeurs. Voir <https://arc42.org>.
