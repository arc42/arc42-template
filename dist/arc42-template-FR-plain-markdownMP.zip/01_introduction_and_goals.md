# Introduction et Objectifs {#section-introduction-and-goals}

## Vue d'ensemble des exigences {#_vue_d_ensemble_des_exigences}

## Objectifs de Qualité {#_objectifs_de_qualit}

## Parties prenantes {#_parties_prenantes}

+-------------+---------------------------+---------------------------+
| Rôle/Nom    | Contact                   | Attentes                  |
+=============+===========================+===========================+
| *\<Role-1>* | *\<Contact-1>*            | *\<Attente-1>*            |
+-------------+---------------------------+---------------------------+
| *\<Role-2>* | *\<Contact-2>*            | *\<Attente-2>*            |
+-------------+---------------------------+---------------------------+
