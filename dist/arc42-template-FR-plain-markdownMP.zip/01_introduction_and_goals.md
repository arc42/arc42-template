# Introduction et Objectifs {#section-introduction-and-goals}

## Aperçu des spécifications {#_aper_u_des_sp_cifications}

## Objectifs de Qualité {#_objectifs_de_qualit}

## Parties prenantes {#_parties_prenantes}

+-------------+---------------------------+---------------------------+
| Rôle/Nom    | Contact                   | Attentes                  |
+=============+===========================+===========================+
| *\<Role-1>* | *\<Contact-1>*            | *\<Attente-1>*            |
+-------------+---------------------------+---------------------------+
| *\<Role-2>* | *\<Contact-2>*            | *\<Attente-2>*            |
+-------------+---------------------------+---------------------------+
