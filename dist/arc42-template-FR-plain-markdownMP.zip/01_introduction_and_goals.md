# Introduction et Objectifs {#section-introduction-and-goals}

## Aperçu des spécifications {#_aperçu_des_spécifications}

## Objectifs de Qualité {#_objectifs_de_qualité}

## Parties prenantes {#_parties_prenantes}

+--------------+---------------------------+---------------------------+
| Rôle/Nom     | Contact                   | Attentes                  |
+==============+===========================+===========================+
| *\<Role-1\>* | *\<Contact-1\>*           | *\<Attente-1\>*           |
+--------------+---------------------------+---------------------------+
| *\<Role-2\>* | *\<Contact-2\>*           | *\<Attente-2\>*           |
+--------------+---------------------------+---------------------------+
