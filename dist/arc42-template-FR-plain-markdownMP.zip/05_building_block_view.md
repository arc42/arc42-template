# Vue en Briques {#section-building-block-view}

## Niveau 1 : Système global Boîte blanche {#_niveau_1_syst_me_global_bo_te_blanche}

***\<Schéma d'ensemble>***

Motivation

:   *\<texte explicatif>*

Briques contenues

:   *\<Description de la brique contenue (boîte noire)>*

Interfaces Importantes

:   *\<Description des interfaces importantes>*

### \<Nom boîte noire 1> {#__nom_bo_te_noire_1}

*\<Objectif/Responsabilité>*

*\<Interface(s)>*

*\<(Facultatif) Caractéristiques de qualité/performance>*

*\<(Facultatif) Emplacement du répertoire/fichier>*

*\<(Facultatif) Exigences respectées>*

*\<(Facultatif) Questions ouvertes/problèmes/risques>*

### \<Nom boîte noire 2> {#__nom_bo_te_noire_2}

*\<template boîte noire>*

### \<Nom boîte noire n> {#__nom_bo_te_noire_n}

*\<template boîte noire>*

### \<Nom interface 1> {#__nom_interface_1}

...

### \<Nom interface m> {#__nom_interface_m}

## Niveau 2 {#_niveau_2}

### Boîte blanche *\<brique 1>* {#_bo_te_blanche_emphasis_brique_1_emphasis}

*\<template boîte blanche>*

### Boîte blanche *\<brique 2>* {#_bo_te_blanche_emphasis_brique_2_emphasis}

*\<template boîte blanche>*

...

### Boîte blanche *\<brique n>* {#_bo_te_blanche_emphasis_brique_n_emphasis}

*\<template boîte blanche>*
