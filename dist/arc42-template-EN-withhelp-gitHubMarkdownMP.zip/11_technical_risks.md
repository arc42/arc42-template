# Risks and Technical Debts

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contents

</div>

A list of identified technical risks or technical debts, ordered by
priority

</div>

<div class="formalpara">

<div class="title">

Motivation

</div>

“Risk management is project management for grown-ups” (Tim Lister,
Atlantic Systems Guild.)

</div>

This should be your motto for systematic detection and evaluation of
risks and technical debts in the architecture, which will be needed by
management stakeholders (e.g. project managers, product owners) as part
of the overall risk analysis and measurement planning.

<div class="formalpara">

<div class="title">

Form

</div>

List of risks and/or technical debts, probably including suggested
measures to minimize, mitigate or avoid risks or reduce technical debts.

</div>

<div class="formalpara">

<div class="title">

Further Information

</div>

See [Risks and Technical Debt](https://docs.arc42.org/section-11/) in
the arc42 documentation.

</div>

</div>
