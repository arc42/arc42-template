# Architecture Constraints

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contents

</div>

Any requirement that constraints software architects in their freedom of
design and implementation decisions or decision about the development
process. These constraints sometimes go beyond individual systems and
are valid for whole organizations and companies.

</div>

<div class="formalpara">

<div class="title">

Motivation

</div>

Architects should know exactly where they are free in their design
decisions and where they must adhere to constraints. Constraints must
always be dealt with; they may be negotiable, though.

</div>

<div class="formalpara">

<div class="title">

Form

</div>

Simple tables of constraints with explanations. If needed you can
subdivide them into technical constraints, organizational and political
constraints and conventions (e.g. programming or versioning guidelines,
documentation or naming conventions)

</div>

<div class="formalpara">

<div class="title">

Further Information

</div>

See [Architecture Constraints](https://docs.arc42.org/section-2/) in the
arc42 documentation.

</div>

</div>
