# Glossary

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contents

</div>

The most important domain and technical terms that your stakeholders use
when discussing the system.

</div>

You can also see the glossary as source for translations if you work in
multi-language teams.

<div class="formalpara">

<div class="title">

Motivation

</div>

You should clearly define your terms, so that all stakeholders

</div>

- have an identical understanding of these terms

- do not use synonyms and homonyms

<div class="formalpara">

<div class="title">

Form

</div>

A table with columns \<Term\> and \<Definition\>.

</div>

Potentially more columns in case you need translations.

<div class="formalpara">

<div class="title">

Further Information

</div>

See [Glossary](https://docs.arc42.org/section-12/) in the arc42
documentation.

</div>

</div>

| Term         | Definition         |
|--------------|--------------------|
| *\<Term-1\>* | *\<definition-1\>* |
| *\<Term-2\>* | *\<definition-2\>* |
