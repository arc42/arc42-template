# Solution Strategy

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contents

</div>

A short summary and explanation of the fundamental decisions and
solution strategies, that shape system architecture. It includes

</div>

- technology decisions

- decisions about the top-level decomposition of the system, e.g. usage
  of an architectural pattern or design pattern

- decisions on how to achieve key quality goals

- relevant organizational decisions, e.g. selecting a development
  process or delegating certain tasks to third parties.

<div class="formalpara">

<div class="title">

Motivation

</div>

These decisions form the cornerstones for your architecture. They are
the foundation for many other detailed decisions or implementation
rules.

</div>

<div class="formalpara">

<div class="title">

Form

</div>

Keep the explanations of such key decisions short.

</div>

Motivate what was decided and why it was decided that way, based upon
problem statement, quality goals and key constraints. Refer to details
in the following sections.

<div class="formalpara">

<div class="title">

Further Information

</div>

See [Solution Strategy](https://docs.arc42.org/section-4/) in the arc42
documentation.

</div>

</div>
