# 

**Over arc42**

arc42, de Template voor documentatie van software en systeem
architectuur.

Gecreeerd en onderhouden door Dr. Peter Hruschka, Dr. Gernot Starke en
bijdragers.

Template Versie: 8. De NL versie is gebaseerd op EN template versie 8,
februari 2022

© We erkennen dat dit document materiaal gebruikt van de arc 42
architectuur template, <https://arc42.org>.

<div class="note">

Deze versie van de template bevat hulp en uitleg. Het is bedoel om
bekend te raken met arc42 en om de concepten te begrijpen. Om uw eigen
sytemen te documenteren adviseren we om de *kale* versie te gebruiken.

</div>

# Introductie en Doelen

Beschrijft de relevante requirements en het krachtenveld waar software
architecten en het development team rekening mee moeten houden. Die
bestaan onder ander uit

-   het begrijpen van de achterliggende doelen van de business,

-   essentiele features,

-   essentiele functionele requirements,

-   kwaliteits doelen voor de architectuur en

-   relevante belanghebbenden en hun verwachtingen

## Requirements Overzicht

<div class="formalpara-title">

**Inhoud**

</div>

Korte beschrijven van de functionele requirements, drijvende krachten,
uittreksel (of samenvatting) van de requirements. Verwijzing naar de
(hopelijk bestaande) requirements documentatie (met versie nummer en
informatie waar deze te vinden is).

<div class="formalpara-title">

**Motivatie**

</div>

Vanuit het perspectief van de eind gebruikers is een systeem ontwikkeld
of aangepast om een business activiteit beter te ondersteunen en/of om
de kwaliteit van die activiteit te verbeteren.

<div class="formalpara-title">

**Vorm**

</div>

Korte textuele beschrijving, mogelijk in use-case tabel formaat. Dit
overzichts document moet naar het requirements document verwijzen (als
dat bestaat).

Houd deze uittreksels zo kort mogelijk. Zoek een evenwicht tussen
leesbaarheid van dit document en mogelijke dubbelingen met betrekking
tot het requirements document.

Zie [Introductie en Doelen](https://docs.arc42.org/section-1/) in de
arc42 documentatie.

## Kwaliteits Doelen

<div class="formalpara-title">

**Inhoud**

</div>

De top drie (max vijf) kwaliteits doelen aan de architectuur waarvan het
behalen van het grootste belang is voor de primaire belanghebbenden.

We bedoelen hier echt kwaliteits doelen voor de architectuur. Niet te
verwarren met project doelen.

Overweeg dit overzicht met mogelijke onderwerpen (gebaseerd op de ISO
25010 standaard):

![Categorieen van mogelijke Kwaliteits
Requirements](images/01_2_iso-25010-topics-EN.png)

<div class="formalpara-title">

**Motivatie**

</div>

Het is belangrijk de kwaliteits doelen van je belangrijkste
belanghebbenden te kennen omdat deze invloed hebben op fundamentele
architectuur keuzes. Denk eraan heel concreet te zijn over deze
kwaliteiten, vermijd modewoorden. Alsof je als architect niet weet hoe
de kwaliteit van je werk beoordeeld zal worden…

<div class="formalpara-title">

**Vorm**

</div>

Een tabel met kwaliteits doelen en concrete scenarios, gesorteerd op
prioriteit.

## Belanghebbenden

<div class="formalpara-title">

**Inhoud**

</div>

Expliciet overzicht van belanghebbenden van het systeem, dat wil zeggen
alle personen, rollen of oranisaties die

-   de architectuur moeten kennen

-   van de architectuur overtuigd moeten worden

-   met de architectuur of code moeten werken

-   de documentatie van de architectuur nodig hebben voor hun werk

-   beslissingen moeten maken over het systeem of de ontwikkeling
    daarvan

<div class="formalpara-title">

**Motivatie**

</div>

Alle partijen die betrokken zijn bij de ontwikkeling of anderzinds
geraakt worden door het systeem moeten bekend zijn. Anders kan dat later
in het ontwikkelings proces tot nare verassingen zorgen. Deze
belanghebbenden bepalen in een grote mate de omvang en het detail niveau
van de werkzaameheden en de resultaten.

<div class="formalpara-title">

**Vorm**

</div>

Tabel met de rollen, personen en hun verwachting met betrekking tot de
architectuur en haar documentatie.

| Rol/Naam   | Contact persoon | Verwachtingen      |
|------------|-----------------|--------------------|
| *\<Rol-1>* | *\<Contact-1>*  | *\<Verwachting-1>* |
| *\<Rol-2>* | *\<Contact-2>*  | *\<Verwachting-2>* |

# Architectuur Beperkingen

<div class="formalpara-title">

**Inhoud**

</div>

Iedere requirement die de sofware architecten in hun vrijheid met
betrekking tot ontwerp, implementatie of het ontwikkel proces beperken.
Het kan zijn dat deze beperkingen verder gaan dan de individuele
systemen en van toepassing zijn op hele organisaties of bedrijven.

<div class="formalpara-title">

**Motivatie**

</div>

Architecten moeten weten waar ze vrij zijn in de ontwerp keuzes en waar
ze zich aan beperkingen moeten houden. Beperkingen moeten altijd onder
ogen worden gezien; echter, het kan zijn dat er over te onderhandelen
valt.

<div class="formalpara-title">

**Vorm**

</div>

Simpele tabellen met beperkingen en bijbehorende uitleg. Zo nodig
opgedeeld in technische, organisatorische en politieke beperkingen en
conventies (bijv. programmeer of versionering guidelines, documentatie
of naamgevings conventies).

Zie [Architectuur Beperkingen](https://docs.arc42.org/section-2/) in de
arc42 documentatie.

# Oplossing Strategie

<div class="formalpara-title">

**Inhoud**

</div>

Een korte samenvatting en uitleg van de fundamentele beslissingen en
oplossings strategieen die de systeem architectuur vormen. Die bestaan
uit onder andere

-   beslissingen met betrekking tot technologie

-   beslissingen over de top-level decompositie van het systeem,
    bijvoorbeeld het gebruik van een architectuur pattern of een design
    pattern

-   beslissingen over hoe de meest belangrijke kwaliteits doelen behaald
    zullen worden

-   relevante organisatorische beslissingen, bijvoorbeeld de keuze van
    een onwikkel proces of het delegeren van bepaalde taken aan derden.

<div class="formalpara-title">

**Motivatie**

</div>

Deze beslissingen vormen het fundament van de architectuur. Ze vormen de
basis waarop vele andere gedetailleerde beslissingen of implemenatie
regels worden gebaseerd.

<div class="formalpara-title">

**Vorm**

</div>

Hou de uitleg van deze fundamentele beslissingen kort.

Leg de motivatie en reden waarom van de beslissingen zo zijn genomen
vast, gebaseerd op een probleem beschrijving, kwaliteitsdoelen en de
belangrijkste kaders. Verwijs naar details in de volgende secties.

Zie [Solution Strategy](https://docs.arc42.org/section-4/) in de arc42
documentatie.

# Bouwstenen View

<div class="formalpara-title">

**Inhoud**

</div>

De bouwstenen view toont de statische decompositie van het systeem in
bouwstenen (modules, componenten, subsystemen, classes, interfaces,
packages, libraries, frameworks, lagen, partitions, lagen, functies,
macros, operaties, data structuren, …) en hun onderlinge
afhankelijkheden (relaties, associaties, …).

Deze view is verplicht voor iedere architectuur documentatie. In termen
van een huis is dit het *grond plan*.

<div class="formalpara-title">

**Motivatie**

</div>

Hou een overzicht van de source code bij door de structuur begrijpelijk
te maken door middel van abstracties.

Dit zorgt ervoor dat het mogelijk is om op een abstract niveau te
communiceren met de belanghebbenden zonder daarbij op implementatie
details in te hoeven gaan.

<div class="formalpara-title">

**Vorm**

</div>

De bouwstenen view is een hiërarchische verzameling van *black boxes* en
*white boxes* (zie het onderstaande plaatje) met de bijbehorende
beschrijvingen.

![Hiërarchie van bouwstenen](images/05_building_blocks-EN.png)

**Niveau 1** is een *white box* beschijving van het gehele systeem
gecombineerd met *black box* beschrijvingen van alle ingesloten
bouwstenen.

**Niveau 2** zoomt in op sommige bouwstenen uit niveau 1. Zodoende bevat
het de *white box* beschrijving van specifieke bouwstenen uit niveau 1,
gecombineerd met *black box* beschrijvingen van hun interne bouwstenen.

**Niveau 3** zoomt in op geslecteerde bouwstenen uit niveau 2, en zo
verder.

Zie [Building Block View](https://docs.arc42.org/section-5/) in de arc42
documentatie.

## Gehele whitebox Systeem

Hier wordt de decompositie van het gehele systeem beschreven aan de hand
van het volgende *white box* template. Die bestaat uit

-   een overzichts diagram

-   een motivatie voor de decompositie

-   *black box* beschrijvingen van ingesloten bouwstenen. Hiervoor zijn
    er verschillende alternatieven:

    -   gebruik *één* tabel for een korte en pragmatisch overzicht van
        alle ingesloten bouwstenen en hun interfaces.

    -   gebruik een lijst met *black box* beschrijvingen van de
        bouwstenen aan de hand van het *black box* template (zie
        hieronder). Afhankelijk van de gebruikte tool kan deze lijst in
        de vorm van een sub-hoofdstuk (in tekst bestanden), sub-pagina’s
        (in een Wiki) of geneste elementen (in een modelleer tool) zijn.

-   (optioneel:) belangrijke interfaces die niet in de *black box*
    templates van de bouwstenen worden uitgelegd maar desondanks van
    belang zijn om de *white box* goed te kunnen begrijpen. Omdat er zo
    veel verschillende manieren zijn om interfaces te specificeren wordt
    er geen specifiek template aangeboden. In het ergste geval moeten
    syntax, semantiek, protocollen, error afhandeling, beperkingen,
    versies, kwaliteits attributen, benodigde compatibiliteit en vele
    andere zaken gespecificeerd en beschreven worden. In het beste geval
    zijn voorbeelden of simpele beschrijvingen voldoende.

***\<Overzichts Diagram>***

Motivatie  
*\<tekstuele uitleg>*

Ingesloten bouwstenen  
*\<Beschrijving van ingesloten bouwstenen (*black boxes*)>*

Belangrijke Interfaces  
*\<Beschrijving van belangrijke interfaces>*

Voeg hier de uitleg van de *black boxes* van niveau 1 toe:

In tabel vorm moeten hier enkel de *black boxes* met hun naam een
verantwoordelijkheden worden beschreven:

| **Naam**         | **Verantwoordelijkeid** |
|------------------|-------------------------|
| *\<black box 1>* | *\<Tekst>*              |
| *\<black box 2>* | *\<Tekst>*              |

In het geval er een lijst met *black box* beschrijvingen wordt gebruikt,
vul dan een aparte *black box* template in voor iedere belangrijke
bouwsteen. De kop bij die sectie is dan de naam van de specifieke *black
box*.

### \<Naam black box 1>

Beschrijf hier \<'black box' 1> Aan de hand van de onderstaande *black
box* template:

-   Doel/Verantwoordelijkheid

-   Interface(s), als ze niet als aparte paragraven worden geadresseerd.
    Deze interface beschrijvingen kunnen kwaliteit en prestatie
    karakteristieken bevatten.

-   (Optioneel) Kwaliteits-/Prestatie karakteristieken van de *black
    box*, bijvoorbeeld beschikbaarheid, run time gedrag, ….

-   (Optioneel) directories/bestand locaties

-   (Optioneel) Vervulde requirements (als er traceerbaarheid van de
    requirements is vereist)

-   (Optioneel) Open issues/problemen/risico’s

*\<Doel/Verantwoordelijkheid>*

*\<Interface(s)>*

*\<((Optioneel) Kwaliteits-/Prestatie karakteristieken>*

*\<(Optioneel) directories/bestand locaties>*

*\<(Optioneel) Vervulde requirements>*

*\<(Optioneel) Open issues/problemen/risico’s>*

## \<Naam black box 2>

*\<black box template>*

### \<Naam black box n>

*\<black box template>*

### \<Naam interface 1>

…

### \<Naam interface m>

## Niveau 2

Hier kunnen de innerlijke structuren van (sommige) bouwstenen uit niveau
1 als *white boxes* worden gespecificeerd.

Er moet een keuze gemaakt worden voor welke bouwstenen het
gerechtvaardigd is om zo’n gedetailleerde beschrijving te maken. Geeft
de voorkeur aan relevantie boven compleetheid. Beschrijf belangrijke,
verassende, risicovolle, complexe of vluchtige bouwstenen. Laat normale,
simpele, saaie of gestandardiseerde delen van het systeem buiten
beschouwing.

### White Box *\<bouwsteen 1>*

…beschrijft de interne structuur van *bouwsteen 1*.

*\<white box template>*

### White Box *\<bouwsteen 2>*

*\<white box template>*

…

### White Box *\<bouwsteen m>*

*\<white box template>*

## Niveau 3

Hier kan de interne structuur van (sommige) niveau 2 bouwstenen als
*white boxes* worden beschreven.

Als er meer gedetailleerde niveaus van de architectuur nodig zijn,
kopieer dan dit deel van arc42 voor aanvullende niveaus.

### White Box *\<bouwsteen x.1>*

Specificeer de interne structuur van *bouwsteen x.1*.

*\<white box template>*

### White Box *\<bouwsteen x.2>*

*\<white box template>*

### White Box *\<bouwsteen y.1>*

*\<white box template>*

# Runtime View

<div class="formalpara-title">

**Inhoud**

</div>

De runtime view beschrijft concreet gedrag en de interacties tussen de
bouwstenen van het systeem vanuit de volgende gebieden:

-   belangrijke use cases of eigenschappen: op welke manier voeren de
    bouwstenen deze uit?

-   interactie bij kritieke externe interfaces: hoe werken bouwstenen
    samen met gebruikers en aanpalende systemen?

-   operations en administrie: uitvoeren, starten, stoppen

-   error en uitzonderlijke (exception) scenarios

<div class="note">

Het primaire criterium bij de keuze van mogelijke scenarios (sequences,
workflows) is de relevantie met betrekking tot de architectuur. Het is
uitdrukkelijk **niet** van belang om een groot aantal scenarios te
beschrijven. Beschrijf liever een representatieve doorsnede.

</div>

<div class="formalpara-title">

**Motivatie**

</div>

Beschrijft hoe (instanties van) bouwstenen van het systeem hun taken
uitvoeren en hoe ze *at runtime* communiceren.

De scenarios zullen hoofdzakelijk beschreven worden om de architectuur
aan belanghebbenden te communiceren die minder behoefte of kunde hebben
om statische modellen (bouwstenen view, deploy view) te lezen en te
doorgronden.

<div class="formalpara-title">

**Vorm**

</div>

Er zijn meerdere manieren om de schenarios vast te leggen, bijvoorbeeld

-   (uitgeschreven) opsomming van de stappen

-   activiteiten of flow diagrammen

-   sequence diagrammen

-   BPMN of EPCs (event process chains)

-   state machines

-   …

Zie [Runtime View](https://docs.arc42.org/section-6/) in de arc42
documentatie.

## \<Runtime Scenario 1>

-   *\<voeg een runtime diagram of een tekstuele beschrijving van het
    scenario toe>*

-   *\<voeg een beschrijving toe van bijzondere aspecten van de
    interactie tussen de instanties van de bouwstenen die in dit diagram
    worden weergegeven>*

## \<Runtime Scenario 2>

## …

## \<Runtime Scenario n>

# Deployment View

<div class="formalpara-title">

**Inhoud**

</div>

De deployment view beschrijft:

1.  de benodigede technische infrastructuur om het systeem uit te kunnen
    voeren, met infrastructurele elementen zoals geografische locatie,
    omgeving, computers, processors, kanalen en netwerk topologie als
    ook andere infrastructurele elementen;

2.  mapping van (software) bouwstenen naar infrastructuur elementen.

Vaak worden systeem in verschillende omgevingen gedraaid, e.g. ontwikkel
omgeving, test omgeving, productie omgeving. In zulke gevallen moeten
alle relevevante omgevingen worden gedocumenteerd.

In het bijzonder als de software wordt uitgevoerd op een gedistribueerd
systeem, met meer dan een computer, processor, server of container *of*
als er gebruik wordt gemaakt van zelf ontworpen hardware en/of chips, is
het van belang om de deployment view vast te leggen.

Vanuit een software perspectief is het voldoende om alleen die elementen
van de infrastrucuur vast te leggen die nodig zijn om de deployment view
van de bouwstenen te tonen. Hardware architecten kunnen verder gaan en
de infrastruur beschrijven tot het detail niveau dat voor hun passend
is.

<div class="formalpara-title">

**Motivatie**

</div>

Software draait niet zonder hardware. Deze onderliggende infrastructuur
heeft invloed om het systeem en/of sommige cross-cutting concepten.
Daarom is het van belang kennis te hebben van de infrastructuur.

Mogelijk is er op het hoogste niveau al een deployment diagram opgenomen
in paragraaf 3.2. als technische context met de eigen infrastructuur als
1 "black box".

In deze paragraaf kan worden ingezoomd op deze "black box" met
aanvullende deployment diagrammen:

-   UML bied deployment diagrammen om die view weer te geven. Gebruik
    deze, eventueel met geneste diagrammen, als de infrastructuur
    ingewikkelder is.

-   Als de (hardware) belanghebbenden er de voorkeur aan geven kunnen
    ander type diagrammen gebruikt worden. Gebruik passende diagrammen
    om de nodes en kanalen van de infrastructuur weer te geven.

Zie [Deployment View](https://docs.arc42.org/section-7/) in de arc42
documentatie.

## Infrastructuur Niveau 1

Beschrijf (normaliter in een combinatie van diagrammen, tabellen en
text):

-   distributie van het systeem over meerdere locaties, omgevingen,
    computers, processors, .., als ook de fysieke verbindingen ertussen

-   verantwoording of motivatie voor deze deployment strucuur

-   kwaliteit en/of performance attributen van deze infrastructuur

-   mapping van software artifacten naar elementen van deze
    infrastructuur

Als er sprake is van meerdere omgevingen of alternatieve deployments
kopieer en pas deze paragraaf van arc42 aan voor alle relevente
omgevingen.

***\<Overzichts Diagram>***

Motivatie  
*\<uitleg in tekstuele vorm>*

Kwaliteit en/of Performance Eigenschappen  
*\<uitleg in tekstuele vorm>*

Mapping van Bouwstenen naar Infrastructuur  
*\<beschrijving van de mapping>*

## Infrastructuur Niveau 2

Hier kunnen de interne structuren van (sommige) infrastructuur elementen
uit niveau 1 worden toegevoegd.

Kopieer de structuur van niveau 1 voor ieder geselecteerd element.

### *\<Infrastructuur Element 1>*

*\<diagram + uitleg>*

### *\<Infrastructuur Element 2>*

*\<diagram + uitleg>*

…

### *\<Infrastructuur Element n>*

*\<diagram + uitleg>*

# Cross-cutting Concepten

<div class="formalpara-title">

**Inhoud**

</div>

Dit deel beschrijft uitgangspunten en concepten die relevant zijn voor
meerdere delen (=cross-cutting) van het systeem. Dergelijke concepten
zijn vaak van toepassing op meerdere bouwstenen. Ze kunnen meerdere
onderwerpen beslaan, zoals

-   modellen, in het bijzonder domein modellen

-   architectuur of design patterns

-   regels om specifiek technologie te gebruiken

-   uitgangspunten, vaak technische afspraken van overkoepelende aard (=
    cross-cutting) aard

-   implementatie regels

<div class="formalpara-title">

**Motivatie**

</div>

Concepten vormen de basis van *conceptuele integriteit* (consistentie en
homogeniteit) van de architectuur. Zodoende vormen ze een belangrijk
hulpmiddel om de innerlijke kenmerken van de architectuur vast te
leggen.

Sommige van deze concepten kunnen niet toegekend worden aan individuele
bouwstenen, e.g. security of veiligheid.

<div class="formalpara-title">

**Vorm**

</div>

De vorm kan varieeren:

-   concept papers die een structuur beschrijven

-   cross-cutting model uittreksels of scenarios waarbij gebruik wordt
    gemaakt van architectuur views

-   voorbeeld implementaties, specifiek voor technische concepten

-   referenties naar typerend gebruik van standaard frameworks (e.g.
    Hibernate gebruiken voor object/relational mapping)

<div class="formalpara-title">

**Structuur**

</div>

Een mogelijke (maar niet verplicht) structuur van deze paragraaf zou
kunnen bestaan uit:

-   Domein concepten

-   User Experience concepten (UX)

-   Veiligheid en security concepten

-   Architectuur en design patterns

-   "Under-de-motorkap"

-   ontwikkel concepten

-   operationele concepten

<div class="note">

het kan moeilijk zijn om individuele concepten toe te kennen aan een
specifiek onderwerp van deze lijst

</div>

![Mogelijke onderwerpen voor cross-cutting
concepten](images/08-concepts-EN.drawio.png)

Zie [Concepts](https://docs.arc42.org/section-8/) in de arc42
documentatie.

## *\<Concept 1>*

*\<uitleg>*

## *\<Concept 2>*

*\<uitleg>*

…

## *\<Concept n>*

*\<uitleg>*

# Architectuur Beslissingen

<div class="formalpara-title">

**Inhoud**

</div>

Belangrijke, kostbare, ver reikende of risicovolle beslissingen die
betrekking hebben op de architectuur met bijbehorende motivering. Met
"beslissingen" wordt bedoeld dat, op basis van gegeven criteria, een
alternatief wordt gekozen.

Beoordeel zelf of de architectuur keuze op deze centrale plek moet
worden vastgelegd of in de gespecialiseerde context (bijvoorbeeld binnen
een "white box" template van een bouwsteen).

Vermijd doublures. Verwijs naar hoodstuk 4 als daar al belangrijke
architectuur beslissingen zijn vastgelegd.

<div class="formalpara-title">

**Motivatie**

</div>

Belanghebbende van het systeem moeten in staat zijn om de gemaakte
keuzes te begrijpen en te herleiden.

<div class="formalpara-title">

**Vorm**

</div>

Er zijn verschillende opties:

-   ADR ([Documenting Architecture
    Decisions](https://cognitect.com/blog/2011/11/15/documenting-architecture-decisions))
    voor iedere belangrijke beslissing;

-   Lijst of tabel, gesorteerd op belang en consequenties of;

-   meer gedetaileerd in de vorm van een paragraaf per gemaakte
    beslissing

Zie [Architecture Decisions](https://docs.arc42.org/section-9/) in de
arc42 documentatie. Daar zijn ook links en voorbeelden van een ADR te
vinden.

# Kwaliteits Requirements

<div class="formalpara-title">

**Inhoud**

</div>

Dit hoofdstuk bevat alle kwaliteits requirements als een kwaliteits boom
met scenarios. De belangrijkste zijn al beschreven in paragraaf 1.2
(kwaliteits doelen.)

Op deze plaats kunnen ook lagere prioriteit kwaliteits requirements
worden vastgelegd die, als ze niet (volledig) worden gerealiseerd, geen
hoog risico vormen.

<div class="formalpara-title">

**Motivatie**

</div>

Omdat kwaliteits requirements grote invloed invloed hebben op
architectuur beslissingen is het van belang om voor iedere
belanghebbende, in concrete en meetbare termen, te begrijpen wat echt
van belang is.

Zie [Quality Requirements](https://docs.arc42.org/section-10/) in de
arc42 documentatie.

## Kwaliteits Boom

<div class="formalpara-title">

**Inhoud**

</div>

De kwaliteits boom (zoals gedefinieerd in ATAM - Architecture Analysis
Method) met kwaliteit/evaluatie scenarios als bladeren.

<div class="formalpara-title">

**Motivatie**

</div>

De geprioriteerde boomstructuur bied overzicht over, een mogelijk groot
aantal, kwaliteits requirements.

<div class="formalpara-title">

**Vorm**

</div>

De kwaliteitsboom is een hoog niveau overzicht van de kwaliteits doelen
en requirements:

-   verdieping van de term "kwaliteit" in de vorm van een boom structuur
    Gebruik daarbij "kwaliteit" als de root van de boom.

-   een mind map met kwaliteit categorieen als eerste takken

De boom moet in elk geval verwijzingen/links bevatten naar de scenarios
in de volgende paragraaf.

## Kwaliteits Scenarios

<div class="formalpara-title">

**Inhoud**

</div>

Het concreet maken van (soms vage of impliciete) kwaliteits requirements
gebruik makend van (kwaliteits) scenarios.

Deze scenarios beschrijven wat er moet gebeuren als het systeem wordt
geconfronteerd met een stimulus.

Voor architecten zijn er twee soorten scenarios van belang:

-   Gebruik scenarios (ook wel applicatie scenarios of use case
    scenarios genoemd) beschrijven het runtime gedrag van het systeem
    naar aanleiding van een bepaalde stimulus. Dit is inclusief
    scenarios die de efficientie of performance van het systeem
    beschrijven. Bijvoorbeeld: Het systeem reageert binnen een seconde
    op een request.

-   Verander scenarios beschrijven modificaties aan het systeem, of aan
    haar onmiddelijke omgeving Bijvoorbeeld: Er moet aanvullende
    functionaliteit geimplementeerd worden of de eis voor een
    kwaliteitskenmerk verandert.

<div class="formalpara-title">

**Motivatie**

</div>

Scenarios maken kwaliteits requirements concreet en maken het daarmee
eenvoudiger om te meten of te bepalen of ze vervuld worden.

Vooral als er methodes als ATAM worden gebruikt is het van belang om de
kwaliteits doelen (uit paragraaf 1.2) tot op het niveau van scenarios
die besproken en bediscussieerd kunnen worden, te beschrijven.

<div class="formalpara-title">

**Vorm**

</div>

Lijst of vrije tekst vorm.

# Risico’s en Technical Debt

<div class="formalpara-title">

**Inhoud**

</div>

Een op prioriteit gesorteerde lijst, met bekende technische risico’s en
technical dept.

<div class="formalpara-title">

**Motivatie**

</div>

“Risk management is project management for grown-ups” (Tim Lister,
Atlantic Systems Guild.)

Dit zou het motto moeten zijn bij het systematisch bepalen en evalueren
van risico’s en technical dept in de architectuur. Management
stakeholder (bijvoorbeeld project managers of project owners) hebben dit
inzicht nodig om keuzes te kunnen maken met betrekking tot risico en
planning.

<div class="formalpara-title">

**Vorm**

</div>

Lijst van risico’s en/of technical dept eventueel aangevuld met
maatregelen om deze te minimaliseren, verzachten of te vermijden.

Zie [Risks and Technical Debt](https://docs.arc42.org/section-11/) in de
arc42 documentatie.

# Woordenlijst

<div class="formalpara-title">

**Inhoud**

</div>

De belangrijkste domein en technische termen die belanghebbenden
gebruiken tijdens het bespreken van het systeem.

De woordenlijst kan ook als bron voor vertaalde termen worden gebruikt
bij meertalige teams.

<div class="formalpara-title">

**Motivatie**

</div>

Termen moeten helder worden gedefinieerd zodat alle belanghebbenden

-   een gemeenschappelijk en eenduidig begrip hebben van deze termen

-   geen gebruik maken van synoniemen of homoniemen

<!-- -->

-   Een tabel met kolommen \<Term> en \<Definitie>.

-   Eventueel meerdere kolommen als er vertalingen nodig zijn.

See [Glossary](https://docs.arc42.org/section-12/) in the arc42
documentation.

| Term        | Definitie        |
|-------------|------------------|
| *\<Term-1>* | *\<definitie-1>* |
| *\<Term-2>* | *\<definitie-2>* |
