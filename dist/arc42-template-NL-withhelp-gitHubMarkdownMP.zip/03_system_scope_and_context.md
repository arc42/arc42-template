# Systeem Scope en Context

<div class="formalpara-title">

**Inhoud**

</div>

De systeem scope en context maakt - zoals de naam suggereert - een
onderscheid tussen het eigen systeem (d.w.z. de scope van het systeem
dat wordt beschreven) en alle partners waarmee wordt gecommuniceerd
(buur systemen en gebruikers, met andere woorden, de context van het
systeem). Hiermee worden externe interfaces gedefineerd.

Maak, als het nodig is, onderscheid tussen business context (domein
specifieke inputs en outputs) en technische context (kanalen,
protocollen, hardware).

<div class="formalpara-title">

**Motivatie**

</div>

De domein en technische interfaces met communicatie partners horen bij
meest kritieke aspecten van het systeem. Wees er zeker van dat deze
volledig te doorgronden.

<div class="formalpara-title">

**Vorm**

</div>

Verschillend opties:

- Context diagrammen

- Lijst van communicatie partners en bijbehorende interfaces.

Zie [Context en Scope](https://docs.arc42.org/section-3/) in de arc42
documentatie.

## Business Context

<div class="formalpara-title">

**Inhoud**

</div>

Specificatie van **alle** communicatie partners (gebruikers,
IT-systemen, …) met uitleg van domein specifieke inputs en outputs of
interfaces. Het is eventueel mogelijk om domein specifieke formaten of
communicatie protocollen toe te voegen.

<div class="formalpara-title">

**Motivatie**

</div>

Alle belanghebbenden moeten begrijpen welke data er uitgewisseld wordt
met de omgeving van het systeem.

<div class="formalpara-title">

**Vorm**

</div>

Alle soorten diagrammen die het systeem als een black box weergeven en
die de domein interfaces naar communicatie partners laten zien.

Een tabel vorm zou als alternatief (of toevoeging) gebruikt kunnen
worden. De naam van het systeem is de titel van de tabel. De drie
kolommen bevatten de naam van de communicatie partner, de inputs en de
outputs.

**\<Diagram of Tabel\>**

**\<optioneel: Uitleg van de externe domein interfaces\>**

## Technische Context

<div class="formalpara-title">

**Inhoud**

</div>

Technische interfaces (kanalen en mechanismen) die het systeem met haar
omgeving verbind. Naast een mapping van domein specifieke input/output
naar kanalen, dat wil zeggen, een uitleg welke I/O welke kanalen
gebruikt.

<div class="formalpara-title">

**Motivatie**

</div>

Veel belanghebbenden maken beslisisingen met betrekkeing tot de
architectuur gebaseerd op de technische interfaces tussen het systeem en
haar context. Met name infrastructuur of hardware ontwerpers beslissen
aan de hand van deze technische interfaces.

<div class="formalpara-title">

**Vorm**

</div>

Bijvoorbeeld UML deployment diagrammen die de kanalen naar naburige
systemen beschrijven, gecombineerd met mapping tabellen die de relatie
tussen de kanalen en de input/output tonen.

**\<Diagram of Tabel\>**

**\<optioneel: Uitleg van technische interfaces\>**

**\<Mapping Input/Output naar kanalen\>**
