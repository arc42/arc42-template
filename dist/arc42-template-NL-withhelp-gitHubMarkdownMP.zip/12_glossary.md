# Woordenlijst

| Term        | Definitie        |
|-------------|------------------|
| *\<Term-1>* | *\<definitie-1>* |
| *\<Term-2>* | *\<definitie-2>* |
