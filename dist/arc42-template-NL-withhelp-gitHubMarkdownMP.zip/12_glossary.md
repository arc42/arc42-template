# Woordenlijst

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Inhoud

</div>

De belangrijkste domein en technische termen die belanghebbenden
gebruiken tijdens het bespreken van het systeem.

</div>

De woordenlijst kan ook als bron voor vertaalde termen worden gebruikt
bij meertalige teams.

<div class="formalpara">

<div class="title">

Motivatie

</div>

Termen moeten helder worden gedefinieerd zodat alle belanghebbenden

</div>

- een gemeenschappelijk en eenduidig begrip hebben van deze termen

- geen gebruik maken van synoniemen of homoniemen

<div>

<div class="title">

Vorm

</div>

- Een tabel met kolommen \<Term\> en \<Definitie\>.

- Eventueel meerdere kolommen als er vertalingen nodig zijn.

</div>

<div class="formalpara">

<div class="title">

Verdere Informatie

</div>

See [Glossary](https://docs.arc42.org/section-12/) in the arc42
documentation.

</div>

</div>

| Term         | Definitie         |
|--------------|-------------------|
| *\<Term-1\>* | *\<definitie-1\>* |
| *\<Term-2\>* | *\<definitie-2\>* |
