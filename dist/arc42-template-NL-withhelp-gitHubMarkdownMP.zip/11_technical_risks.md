# Risico’s en Technical Debt

<div class="formalpara-title">

**Inhoud**

</div>

Een op prioriteit gesorteerde lijst, met bekende technische risico’s en
technical dept.

<div class="formalpara-title">

**Motivatie**

</div>

“Risk management is project management for grown-ups” (Tim Lister,
Atlantic Systems Guild.)

Dit zou het motto moeten zijn bij het systematisch bepalen en evalueren
van risico’s en technical dept in de architectuur. Management
stakeholder (bijvoorbeeld project managers of project owners) hebben dit
inzicht nodig om keuzes te kunnen maken met betrekking tot risico en
planning.

<div class="formalpara-title">

**Vorm**

</div>

Lijst van risico’s en/of technical dept eventueel aangevuld met
maatregelen om deze te minimaliseren, verzachten of te vermijden.

Zie [Risks and Technical Debt](https://docs.arc42.org/section-11/) in de
arc42 documentatie.
