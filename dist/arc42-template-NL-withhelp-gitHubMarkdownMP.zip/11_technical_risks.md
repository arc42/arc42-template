# Risico’s en Technical Debt

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Inhoud

</div>

Een op prioriteit gesorteerde lijst, met bekende technische risico’s en
technical dept.

</div>

<div class="formalpara">

<div class="title">

Motivatie

</div>

“Risk management is project management for grown-ups” (Tim Lister,
Atlantic Systems Guild.)

</div>

Dit zou het motto moeten zijn bij het systematisch bepalen en evalueren
van risico’s en technical dept in de architectuur. Management
stakeholder (bijvoorbeeld project managers of project owners) hebben dit
inzicht nodig om keuzes te kunnen maken met betrekking tot risico en
planning.

<div class="formalpara">

<div class="title">

Vorm

</div>

Lijst van risico’s en/of technical dept eventueel aangevuld met
maatregelen om deze te minimaliseren, verzachten of te vermijden.

</div>

<div class="formalpara">

<div class="title">

Verdere Informatie

</div>

Zie [Risks and Technical Debt](https://docs.arc42.org/section-11/) in de
arc42 documentatie.

</div>

</div>
