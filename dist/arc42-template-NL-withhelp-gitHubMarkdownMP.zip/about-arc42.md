**Over arc42**

arc42, de Template voor documentatie van software en systeem
architectuur.

Gecreeerd en onderhouden door {author}.

Template Versie: {revnumber}. {revremark}, {revdate}

© We erkennen dat dit document materiaal gebruikt van de arc 42
architectuur template, <https://arc42.org>.
