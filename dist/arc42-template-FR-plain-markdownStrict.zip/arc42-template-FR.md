# 

**A propos d’arc42**

arc42, le modèle de documentation de l’architecture des logiciels et des
systèmes.

Version du modèle 9.0-FR. (basé sur la version AsciiDoc), Avril 2025

Créé, maintenu et © par Dr. Peter Hruschka, Dr. Gernot Starke et les
contributeurs. Voir <https://arc42.org>.

# Introduction et Objectifs

## Aperçu des spécifications

## Objectifs de Qualité

## Parties prenantes

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">Rôle/Nom</th>
<th style="text-align: left;">Contact</th>
<th style="text-align: left;">Attentes</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p><em>&lt;Role-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Contact-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Attente-1&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"><p><em>&lt;Role-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Contact-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Attente-2&gt;</em></p></td>
</tr>
</tbody>
</table>

# Contraintes d’Architecture

# Contexte et périmètre

## Contexte métier

**&lt;Schéma ou tableau&gt;**

**&lt;éventuellement : Explication des interfaces de domaines
externes&gt;**

## Contexte Technique

**&lt;Schéma ou tableau&gt;**

**&lt;en option : Explication des interfaces techniques&gt;**

**&lt;Correspondance des entrées/sorties aux canaux&gt;**

# Stratégie de solution

# Vue en Briques

## Niveau 1 : Système global Boîte blanche

***&lt;Schéma d’ensemble&gt;***

Motivation  
*&lt;texte explicatif&gt;*

Briques contenues  
*&lt;Description de la brique contenue (boîte noire)&gt;*

Interfaces Importantes  
*&lt;Description des interfaces importantes&gt;*

### &lt;Nom boîte noire 1&gt;

*&lt;Objectif/Responsabilité&gt;*

*&lt;Interface(s)&gt;*

*&lt;(Facultatif) Caractéristiques de qualité/performance&gt;*

*&lt;(Facultatif) Emplacement du répertoire/fichier&gt;*

*&lt;(Facultatif) Exigences respectées&gt;*

*&lt;(Facultatif) Questions ouvertes/problèmes/risques&gt;*

### &lt;Nom boîte noire 2&gt;

*&lt;template boîte noire&gt;*

### &lt;Nom boîte noire n&gt;

*&lt;template boîte noire&gt;*

### &lt;Nom interface 1&gt;

…​

### &lt;Nom interface m&gt;

## Niveau 2

### Boîte blanche *&lt;brique 1&gt;*

*&lt;template boîte blanche&gt;*

### Boîte blanche *&lt;brique 2&gt;*

*&lt;template boîte blanche&gt;*

…​

### Boîte blanche *&lt;brique n&gt;*

*&lt;template boîte blanche&gt;*

# Vue Exécution

## &lt;Scénario d’exécution 1&gt;

- *&lt;insérer un diagramme d’exécution ou une description textuelle du
  scénario&gt;*

- *&lt;insérer une description des aspects notables des interactions
  entre les instances des briques représentées dans ce diagramme.&gt;*

## &lt;Scénario d’exécution 2&gt;

## …​

## &lt;Scénario d’exécution n&gt;

# Vue Déploiement

## Infrastructure Niveau 1

***&lt;Schéma d’ensemble&gt;***

Motivation  
*&lt;explication sous forme de texte&gt;*

Caractéristiques de qualité et/ou de performance  
*&lt;explication sous forme de texte&gt;*

Correspondance des briques vis à vis de l’infrastructure  
*&lt;description de la correspondance&gt;*

## Infrastructure Niveau 2

### *&lt;Infrastructure Element 1&gt;*

*&lt;schéma + explication&gt;*

### *&lt;Infrastructure Element 2&gt;*

*&lt;schéma + explication&gt;*

…​

### *&lt;Infrastructure Element n&gt;*

*&lt;schéma + explication&gt;*

# Concepts transversaux

## *&lt;Concept 1&gt;*

*&lt;explication&gt;*

## *&lt;Concept 2&gt;*

*&lt;explication&gt;*

…​

## *&lt;Concept n&gt;*

*&lt;explication&gt;*

# Décisions d’architecture

# Critères de qualité

## Exigences de qualité - Vue d’ensemble

## Scénarios Qualité

# Risques et Dettes techniques

# Glossaire

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">Terme</th>
<th style="text-align: left;">Définition</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p><em>&lt;Terme-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Définition-1&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"><p><em>&lt;Terme-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Définition-2&gt;</em></p></td>
</tr>
</tbody>
</table>
