Architecture Constraints {#section-architecture-constraints}
========================
