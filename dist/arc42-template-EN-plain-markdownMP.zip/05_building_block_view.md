Building Block View {#section-building-block-view}
===================

Whitebox Overall System {#_whitebox_overall_system}
-----------------------

***&lt;Overview Diagram&gt;***

Motivation

:   *&lt;text explanation&gt;*

Contained Building Blocks

:   *&lt;Description of contained building block (black boxes)&gt;*

Important Interfaces

:   *&lt;Description of important interfaces&gt;*

### &lt;Name black box 1&gt; {#__name_black_box_1}

*&lt;Purpose/Responsibility&gt;*

*&lt;Interface(s)&gt;*

*&lt;(Optional) Quality/Performance Characteristics&gt;*

*&lt;(Optional) Directory/File Location&gt;*

*&lt;(Optional) Fulfilled Requirements&gt;*

*&lt;(optional) Open Issues/Problems/Risks&gt;*

### &lt;Name black box 2&gt; {#__name_black_box_2}

*&lt;black box template&gt;*

### &lt;Name black box n&gt; {#__name_black_box_n}

*&lt;black box template&gt;*

### &lt;Name interface 1&gt; {#__name_interface_1}

…

### &lt;Name interface m&gt; {#__name_interface_m}

Level 2 {#_level_2}
-------

### White Box *&lt;building block 1&gt;* {#_white_box_emphasis_building_block_1_emphasis}

*&lt;white box template&gt;*

### White Box *&lt;building block 2&gt;* {#_white_box_emphasis_building_block_2_emphasis}

*&lt;white box template&gt;*

…

### White Box *&lt;building block m&gt;* {#_white_box_emphasis_building_block_m_emphasis}

*&lt;white box template&gt;*

Level 3 {#_level_3}
-------

### White Box &lt;\_building block x.1\_&gt; {#_white_box_building_block_x_1}

*&lt;white box template&gt;*

### White Box &lt;\_building block x.2\_&gt; {#_white_box_building_block_x_2}

*&lt;white box template&gt;*

### White Box &lt;\_building block y.1\_&gt; {#_white_box_building_block_y_1}

*&lt;white box template&gt;*
