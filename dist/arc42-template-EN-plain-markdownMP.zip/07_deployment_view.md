Deployment View {#section-deployment-view}
===============

Infrastructure Level 1 {#_infrastructure_level_1}
----------------------

***&lt;Overview Diagram&gt;***

Motivation

:   *&lt;explanation in text form&gt;*

Quality and/or Performance Features

:   *&lt;explanation in text form&gt;*

Mapping of Building Blocks to Infrastructure

:   *&lt;description of the mapping&gt;*

Infrastructure Level 2 {#_infrastructure_level_2}
----------------------

### *&lt;Infrastructure Element 1&gt;* {#__emphasis_infrastructure_element_1_emphasis}

*&lt;diagram + explanation&gt;*

### *&lt;Infrastructure Element 2&gt;* {#__emphasis_infrastructure_element_2_emphasis}

*&lt;diagram + explanation&gt;*

…

### *&lt;Infrastructure Element n&gt;* {#__emphasis_infrastructure_element_n_emphasis}

*&lt;diagramm + explanation&gt;*
