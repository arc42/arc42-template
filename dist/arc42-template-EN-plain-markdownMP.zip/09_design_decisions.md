Design Decisions {#section-design-decisions}
================
