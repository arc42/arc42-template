Solution Strategy {#section-solution-strategy}
=================
