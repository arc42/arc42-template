# Architecture Decisions {#section-design-decisions}
