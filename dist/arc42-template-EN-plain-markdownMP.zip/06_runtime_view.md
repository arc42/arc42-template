Runtime View {#section-runtime-view}
============

&lt;Runtime Scenario 1&gt; {#__runtime_scenario_1}
--------------------------

-   *&lt;insert runtime diagram or textual description of the
    scenario&gt;*

-   *&lt;insert description of the notable aspects of the interactions
    between the building block instances depicted in this diagram.&gt;*

&lt;Runtime Scenario 2&gt; {#__runtime_scenario_2}
--------------------------

… {#_}
-

&lt;Runtime Scenario n&gt; {#__runtime_scenario_n}
--------------------------
