System Scope and Context {#section-system-scope-and-context}
========================

Business Context {#_business_context}
----------------

**&lt;Diagram or Table&gt;**

**&lt;optionally: Explanation of external domain interfaces&gt;**

Technical Context {#_technical_context}
-----------------

**&lt;Diagram or Table&gt;**

**&lt;optionally: Explanation of technical interfaces&gt;**

**&lt;Mapping Input/Output to Channels&gt;**
