Cross-cutting Concepts {#section-concepts}
======================

*&lt;Concept 1&gt;* {#__emphasis_concept_1_emphasis}
-------------------

*&lt;explanation&gt;*

*&lt;Concept 2&gt;* {#__emphasis_concept_2_emphasis}
-------------------

*&lt;explanation&gt;*

…

*&lt;Concept n&gt;* {#__emphasis_concept_n_emphasis}
-------------------

*&lt;explanation&gt;*
