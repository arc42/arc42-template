# Visão de Implantação

## Nível de Infraestrutura 1

***\<Diagrama de Visão Geral>***

Motivação  
*\<explicação em forma de texto>*

Características de Qualidade e/ou Desempenho  
*\<explicação em forma de texto>*

Mapeamento de Blocos de Construção para Infraestrutura  
*\<descrição do mapeamento>*

## Nível de Infraestrutura 2

### *\<Elemento de Infraestrutura 1>*

*\<diagrama + explicação>*

### *\<Elemento de Infraestrutura 2>*

*\<diagrama + explicação>*

…

### *\<Elemento de Infraestrutura n>*

*\<diagrama + explicação>*
