# Deployment View {#section-deployment-view}

## Infrastructuur Niveau 1 {#_infrastructuur_niveau_1}

***\<Overzichts Diagram\>***

Motivatie

:   *\<uitleg in tekstuele vorm\>*

Kwaliteit en/of Performance Eigenschappen

:   *\<uitleg in tekstuele vorm\>*

Mapping van Bouwstenen naar Infrastructuur

:   *\<beschrijving van de mapping\>*

## Infrastructuur Niveau 2 {#_infrastructuur_niveau_2}

### *\<Infrastructuur Element 1\>* {#__emphasis_infrastructuur_element_1_emphasis}

*\<diagram + uitleg\>*

### *\<Infrastructuur Element 2\>* {#__emphasis_infrastructuur_element_2_emphasis}

*\<diagram + uitleg\>*

...

### *\<Infrastructuur Element n\>* {#__emphasis_infrastructuur_element_n_emphasis}

*\<diagram + uitleg\>*
