# Architectuur Beslissingen {#section-design-decisions}
