# Risico's en Technical Debt {#section-technical-risks}
