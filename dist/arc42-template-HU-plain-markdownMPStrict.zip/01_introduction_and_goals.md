# Bevezetés és célok

## Követelmények áttekintése

## Minőségi célok

## Érdekelt felek

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Szerepkör/Név</th>
<th style="text-align: left;">Elérhetőség</th>
<th style="text-align: left;">Elvárások</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Szerepkör-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Elérhetőség-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Elvárás-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Szerepkör-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Elérhetőség-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Elvárás-2&gt;</em></p></td>
</tr>
</tbody>
</table>
