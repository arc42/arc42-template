# Futásidejű nézet

## &lt;Futásidejű forgatókönyv 1&gt;

-   *&lt;illesszen be futásidejű diagramot vagy a forgatókönyv szöveges
    leírását&gt;*

-   *&lt;illesszen be leírást az ábrázolt építőelem-példányok közötti
    interakciók figyelemre méltó aspektusairól.&gt;*

## &lt;Futásidejű forgatókönyv 2&gt;

## …​

## &lt;Futásidejű forgatókönyv n&gt;
