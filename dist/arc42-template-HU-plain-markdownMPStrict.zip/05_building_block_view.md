# Építőelem-nézet

## Fehér doboz Teljes rendszer

***&lt;Áttekintő diagram&gt;***

Motiváció  
*&lt;szöveges magyarázat&gt;*

Tartalmazott építőelemek  
*&lt;A tartalmazott építőelemek (fekete dobozok) leírása&gt;*

Fontos interfészek  
*&lt;Fontos interfészek leírása&gt;*

### &lt;Fekete doboz 1 neve&gt;

*&lt;Cél/Felelősség&gt;*

*&lt;Interfész(ek)&gt;*

*&lt;(Opcionális) Minőségi/Teljesítményjellemzők&gt;*

*&lt;(Opcionális) Könyvtár/Fájl elérési út&gt;*

*&lt;(Opcionális) Teljesített követelmények&gt;*

*&lt;(Opcionális) Nyitott kérdések/Problémák/Kockázatok&gt;*

### &lt;Fekete doboz 2 neve&gt;

*&lt;fekete doboz sablon&gt;*

### &lt;Fekete doboz n neve&gt;

*&lt;fekete doboz sablon&gt;*

### &lt;Interfész 1 neve&gt;

…​

### &lt;Interfész m neve&gt;

## 2. szint

### Fehér doboz *&lt;1. építőelem&gt;*

*&lt;fehér doboz sablon&gt;*

### Fehér doboz *&lt;2. építőelem&gt;*

*&lt;fehér doboz sablon&gt;*

…​

### Fehér doboz *&lt;m. építőelem&gt;*

*&lt;fehér doboz sablon&gt;*

## 3. szint

### Fehér doboz &lt;\_x.1 építőelem\_&gt;

*&lt;fehér doboz sablon&gt;*

### Fehér doboz &lt;\_x.2 építőelem\_&gt;

*&lt;fehér doboz sablon&gt;*

### Fehér doboz &lt;\_y.1 építőelem\_&gt;

*&lt;fehér doboz sablon&gt;*
