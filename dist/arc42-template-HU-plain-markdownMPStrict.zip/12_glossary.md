# Szójegyzék

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Kifejezés</th>
<th style="text-align: left;">Meghatározás</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Kifejezés-1&gt;</em></p></td>
<td
style="text-align: left;"><p><em>&lt;meghatározás-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Kifejezés-2&gt;</em></p></td>
<td
style="text-align: left;"><p><em>&lt;meghatározás-2&gt;</em></p></td>
</tr>
</tbody>
</table>
