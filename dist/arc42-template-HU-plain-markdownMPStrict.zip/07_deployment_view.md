# Telepítési nézet

## 1. infrastruktúra-szint

***&lt;Áttekintő diagram&gt;***

Motiváció  
*&lt;szöveges magyarázat&gt;*

Minőségi és/vagy teljesítményjellemzők  
*&lt;szöveges magyarázat&gt;*

Építőelemek leképezése az infrastruktúrára  
*&lt;a leképezés leírása&gt;*

## 2. infrastruktúra-szint

### *&lt;1. infrastruktúra-elem&gt;*

*&lt;diagram + magyarázat&gt;*

### *&lt;2. infrastruktúra-elem&gt;*

*&lt;diagram + magyarázat&gt;*

…​

### *&lt;n. infrastruktúra-elem&gt;*

*&lt;diagram + magyarázat&gt;*
