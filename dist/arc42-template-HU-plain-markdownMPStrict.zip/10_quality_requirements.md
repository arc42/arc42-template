# Minőségi követelmények

## Minőségi követelmények áttekintése

## Minőségi forgatókönyvek
