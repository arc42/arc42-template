# Keresztmetszeti koncepciók

## *&lt;1. koncepció&gt;*

*&lt;magyarázat&gt;*

## *&lt;2. koncepció&gt;*

*&lt;magyarázat&gt;*

…​

## *&lt;n. koncepció&gt;*

*&lt;magyarázat&gt;*
