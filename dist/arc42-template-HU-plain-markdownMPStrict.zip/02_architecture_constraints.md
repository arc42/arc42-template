# Architekturális megkötések
