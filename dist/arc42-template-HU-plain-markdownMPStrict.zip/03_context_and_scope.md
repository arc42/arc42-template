# Kontextus és hatókör

## Üzleti kontextus

**&lt;Diagram vagy táblázat&gt;**

**&lt;opcionális: Külső szakterületi interfészek magyarázata&gt;**

## Technikai kontextus

**&lt;Diagram vagy táblázat&gt;**

**&lt;opcionális: Technikai interfészek magyarázata&gt;**

**&lt;Bemenet/kimenet leképezése csatornákra&gt;**
