# 

**Über arc42**

arc42, das Template zur Dokumentation von Software- und
Systemarchitekturen.

Template Version 9.0-DE. (basiert auf der AsciiDoc Version), Juli 2025

Created, maintained and © by Dr. Peter Hruschka, Dr. Gernot Starke and
contributors. Siehe <https://arc42.org>.

# Einführung und Ziele

## Aufgabenstellung

## Qualitätsziele

## Stakeholder

<table>
<colgroup>
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">Rolle</th>
<th style="text-align: left;">Kontakt</th>
<th style="text-align: left;">Erwartungshaltung</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p><em>&lt;Rolle-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Kontakt-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Erwartung-1&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"><p><em>&lt;Rolle-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Kontakt-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Erwartung-2&gt;</em></p></td>
</tr>
</tbody>
</table>

# Randbedingungen

# Kontextabgrenzung

## Fachlicher Kontext

**&lt;Diagramm und/oder Tabelle&gt;**

**&lt;optional: Erläuterung der externen fachlichen Schnittstellen&gt;**

## Technischer Kontext

**&lt;Diagramm oder Tabelle&gt;**

**&lt;optional: Erläuterung der externen technischen
Schnittstellen&gt;**

**&lt;Mapping fachliche auf technische Schnittstellen&gt;**

# Lösungsstrategie

# Bausteinsicht

## Whitebox Gesamtsystem

***&lt;Übersichtsdiagramm&gt;***

Begründung  
*&lt;Erläuternder Text&gt;*

Enthaltene Bausteine  
*&lt;Beschreibung der enthaltenen Bausteine (Blackboxen)&gt;*

Wichtige Schnittstellen  
*&lt;Beschreibung wichtiger Schnittstellen&gt;*

### &lt;Name Blackbox 1&gt;

*&lt;Zweck/Verantwortung&gt;*

*&lt;Schnittstelle(n)&gt;*

*&lt;(Optional) Qualitäts-/Leistungsmerkmale&gt;*

*&lt;(Optional) Ablageort/Datei(en)&gt;*

*&lt;(Optional) Erfüllte Anforderungen&gt;*

*&lt;(optional) Offene Punkte/Probleme/Risiken&gt;*

### &lt;Name Blackbox 2&gt;

*&lt;Blackbox-Template&gt;*

### &lt;Name Blackbox n&gt;

*&lt;Blackbox-Template&gt;*

### &lt;Name Schnittstelle 1&gt;

…​

### &lt;Name Schnittstelle m&gt;

## Ebene 2

### Whitebox *&lt;Baustein 1&gt;*

*&lt;Whitebox-Template&gt;*

### Whitebox *&lt;Baustein 2&gt;*

*&lt;Whitebox-Template&gt;*

…​

### Whitebox *&lt;Baustein m&gt;*

*&lt;Whitebox-Template&gt;*

## Ebene 3

### Whitebox &lt;\_Baustein x.1\_&gt;

*&lt;Whitebox-Template&gt;*

### Whitebox &lt;\_Baustein x.2\_&gt;

*&lt;Whitebox-Template&gt;*

### Whitebox &lt;\_Baustein y.1\_&gt;

*&lt;Whitebox-Template&gt;*

# Laufzeitsicht

## *&lt;Bezeichnung Laufzeitszenario 1&gt;*

- &lt;hier Laufzeitdiagramm oder Ablaufbeschreibung einfügen&gt;

- &lt;hier Besonderheiten bei dem Zusammenspiel der Bausteine in diesem
  Szenario erläutern&gt;

## *&lt;Bezeichnung Laufzeitszenario 2&gt;*

…​

## *&lt;Bezeichnung Laufzeitszenario n&gt;*

…​

# Verteilungssicht

## Infrastruktur Ebene 1

***&lt;Übersichtsdiagramm&gt;***

Begründung  
*&lt;Erläuternder Text&gt;*

Qualitäts- und/oder Leistungsmerkmale  
*&lt;Erläuternder Text&gt;*

Zuordnung von Bausteinen zu Infrastruktur  
*&lt;Beschreibung der Zuordnung&gt;*

## Infrastruktur Ebene 2

### *&lt;Infrastrukturelement 1&gt;*

*&lt;Diagramm + Erläuterungen&gt;*

### *&lt;Infrastrukturelement 2&gt;*

*&lt;Diagramm + Erläuterungen&gt;*

…​

### *&lt;Infrastrukturelement n&gt;*

*&lt;Diagramm + Erläuterungen&gt;*

# Querschnittliche Konzepte

## *&lt;Konzept 1&gt;*

*&lt;Erklärung&gt;*

## *&lt;Konzept 2&gt;*

*&lt;Erklärung&gt;*

…​

## *&lt;Konzept n&gt;*

*&lt;Erklärung&gt;*

# Architekturentscheidungen

# Qualitätsanforderungen

## Übersicht der Qualitätsanforderungen

## Qualitätsszenarien

# Risiken und technische Schulden

# Glossar

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">Begriff</th>
<th style="text-align: left;">Definition</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p><em>&lt;Begriff-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Definition-1&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"><p><em>&lt;Begriff-2</em></p></td>
<td style="text-align: left;"><p><em>&lt;Definition-2&gt;</em></p></td>
</tr>
</tbody>
</table>
