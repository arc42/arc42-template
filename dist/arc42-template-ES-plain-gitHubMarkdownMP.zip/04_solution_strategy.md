# Estrategia de solución
