# Estrategia de solución
