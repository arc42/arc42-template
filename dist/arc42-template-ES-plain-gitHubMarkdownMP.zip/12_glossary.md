# Glosario

| Término       | Definición       |
| ------------- | ---------------- |
| \<Término-1\> | \<definicion-1\> |
| \<Término-2\> | \<definicion-2\> |
