# Introducción y Metas

## Vista de Requerimientos

## Metas de Calidad

## Partes interesadas (Stakeholders)

| Rol/Nombre   | Contacto        | Expectativas        |
|--------------|-----------------|---------------------|
| *\<Role-1\>* | *\<Contact-1\>* | *\<Expectation-1\>* |
| *\<Role-2\>* | *\<Contact-2\>* | *\<Expectation-2\>* |
