# Restricciones de la Arquitectura
