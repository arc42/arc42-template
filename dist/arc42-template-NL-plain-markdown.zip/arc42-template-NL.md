# 

**Over arc42**

arc42, de Template voor documentatie van software en systeem
architectuur.

Gecreeerd en onderhouden door Dr. Peter Hruschka, Dr. Gernot Starke en
bijdragers.

Template Versie: 8. De NL versie is gebaseerd op EN template versie 8,
februari 2022

© We erkennen dat dit document materiaal gebruikt van de arc 42
architectuur template, <https://arc42.org>.

# Introductie en Doelen {#section-introduction-and-goals}

## Requirements Overzicht {#_requirements_overzicht}

## Kwaliteits Doelen {#_kwaliteits_doelen}

## Belanghebbenden {#_belanghebbenden}

+-------------+---------------------------+---------------------------+
| Rol/Naam    | Contact persoon           | Verwachtingen             |
+=============+===========================+===========================+
| *\<Rol-1>*  | *\<Contact-1>*            | *\<Verwachting-1>*        |
+-------------+---------------------------+---------------------------+
| *\<Rol-2>*  | *\<Contact-2>*            | *\<Verwachting-2>*        |
+-------------+---------------------------+---------------------------+

# Architectuur Beperkingen {#section-architecture-constraints}

# Oplossing Strategie {#section-solution-strategy}

# Bouwstenen View {#section-building-block-view}

## Gehele whitebox Systeem {#_gehele_whitebox_systeem}

***\<Overzichts Diagram>***

Motivatie

:   *\<tekstuele uitleg>*

Ingesloten bouwstenen

:   *\<Beschrijving van ingesloten bouwstenen (*black boxes*)>*

Belangrijke Interfaces

:   *\<Beschrijving van belangrijke interfaces>*

### \<Naam black box 1> {#__naam_black_box_1}

*\<Doel/Verantwoordelijkheid>*

*\<Interface(s)>*

*\<((Optioneel) Kwaliteits-/Prestatie karakteristieken>*

*\<(Optioneel) directories/bestand locaties>*

*\<(Optioneel) Vervulde requirements>*

*\<(Optioneel) Open issues/problemen/risico's>*

## \<Naam black box 2> {#__naam_black_box_2}

*\<black box template>*

### \<Naam black box n> {#__naam_black_box_n}

*\<black box template>*

### \<Naam interface 1> {#__naam_interface_1}

...

### \<Naam interface m> {#__naam_interface_m}

## Niveau 2 {#_niveau_2}

### White Box *\<bouwsteen 1>* {#_white_box_emphasis_bouwsteen_1_emphasis}

*\<white box template>*

### White Box *\<bouwsteen 2>* {#_white_box_emphasis_bouwsteen_2_emphasis}

*\<white box template>*

...

### White Box *\<bouwsteen m>* {#_white_box_emphasis_bouwsteen_m_emphasis}

*\<white box template>*

## Niveau 3 {#_niveau_3}

### White Box *\<bouwsteen x.1>* {#_white_box_emphasis_bouwsteen_x_1_emphasis}

*\<white box template>*

### White Box *\<bouwsteen x.2>* {#_white_box_emphasis_bouwsteen_x_2_emphasis}

*\<white box template>*

### White Box *\<bouwsteen y.1>* {#_white_box_emphasis_bouwsteen_y_1_emphasis}

*\<white box template>*

# Runtime View {#section-runtime-view}

## \<Runtime Scenario 1> {#__runtime_scenario_1}

-   *\<voeg een runtime diagram of een tekstuele beschrijving van het
    scenario toe>*

-   *\<voeg een beschrijving toe van bijzondere aspecten van de
    interactie tussen de instanties van de bouwstenen die in dit diagram
    worden weergegeven>*

## \<Runtime Scenario 2> {#__runtime_scenario_2}

## ... {#_}

## \<Runtime Scenario n> {#__runtime_scenario_n}

# Deployment View {#section-deployment-view}

## Infrastructuur Niveau 1 {#_infrastructuur_niveau_1}

***\<Overzichts Diagram>***

Motivatie

:   *\<uitleg in tekstuele vorm>*

Kwaliteit en/of Performance Eigenschappen

:   *\<uitleg in tekstuele vorm>*

Mapping van Bouwstenen naar Infrastructuur

:   *\<beschrijving van de mapping>*

## Infrastructuur Niveau 2 {#_infrastructuur_niveau_2}

### *\<Infrastructuur Element 1>* {#__emphasis_infrastructuur_element_1_emphasis}

*\<diagram + uitleg>*

### *\<Infrastructuur Element 2>* {#__emphasis_infrastructuur_element_2_emphasis}

*\<diagram + uitleg>*

...

### *\<Infrastructuur Element n>* {#__emphasis_infrastructuur_element_n_emphasis}

*\<diagram + uitleg>*

# Cross-cutting Concepten {#section-concepts}

## *\<Concept 1>* {#__emphasis_concept_1_emphasis}

*\<uitleg>*

## *\<Concept 2>* {#__emphasis_concept_2_emphasis}

*\<uitleg>*

...

## *\<Concept n>* {#__emphasis_concept_n_emphasis}

*\<uitleg>*

# Architectuur Beslissingen {#section-design-decisions}

# Kwaliteits Requirements {#section-quality-scenarios}

## Kwaliteits Boom {#_kwaliteits_boom}

## Kwaliteits Scenarios {#_kwaliteits_scenarios}

# Risico's en Technical Debt {#section-technical-risks}

# Woordenlijst {#section-glossary}

+-----------------------+-----------------------------------------------+
| Term                  | Definitie                                     |
+=======================+===============================================+
| *\<Term-1>*           | *\<definitie-1>*                              |
+-----------------------+-----------------------------------------------+
| *\<Term-2>*           | *\<definitie-2>*                              |
+-----------------------+-----------------------------------------------+
