# 

**About arc42**

arc42, the Template for documentation of software and system
architecture.

By Dr. Gernot Starke, Dr. Peter Hruschka and contributors.

Template Revision: 7.0 IT (based on asciidoc), April 2021

© We acknowledge that this document uses material from the arc 42
architecture template, <http://www.arc42.de>. Created by Dr. Peter
Hruschka & Dr. Gernot Starke.

# Introduzione e obiettivi

## Panoramica dei requisiti

## Obiettivi di qualità

## Stakeholders

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Rouolo/Nome</th>
<th style="text-align: left;">Contatto</th>
<th style="text-align: left;">Aspettative</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Ruolo-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Contatto-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Aspettatiive-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Ruolo-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Contatto-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Aspettatiive-2&gt;</em></p></td>
</tr>
</tbody>
</table>

# Vincoli di architettura

# Ambito e contesto del sistema

## Contesto di Business

**&lt;Diagramma o Tabella&gt;**

**&lt;opzionale: spiegazione delle interfacce del dominio esterno&gt;**

## Contesto Tecnico

**&lt;Diagramma o Tabella&gt;**

**&lt;opzionale: Spiegazione delle interfacce tecniche&gt;**

**&lt;Mappatura Input/Output sui canali di comunicazione&gt;**

# Strategia della soluzione

# Building Block View

## Whitebox Overall System

***&lt;Overview Diagram&gt;***

Motivazione  
*&lt;spiegazione testuale&gt;*

Contenuto dei Building Blocks  
*&lt;Descrizione del contenuto del building block (black boxes)&gt;*

Important Interfaces  
*&lt;Descrizione delle interfacce importanti&gt;*

### &lt;Nome black box 1&gt;

*&lt;Scopo/responsabilità&gt;*

*&lt;Interfacce&gt;*

*&lt;(Facoltativo) Caratteristiche di qualità/prestazionali&gt;*

*&lt;(Facoltativo) percorso file/directory&gt;*

*&lt;(Facoltativo) Requisiti soddisfatti&gt;*

*&lt;(Facoltativo) Bug noti/Rischi/problemi&gt;*

### &lt;Nome black box 2&gt;

*&lt;black box template&gt;*

### &lt;Nome black box n&gt;

*&lt;black box template&gt;*

### &lt;Nome interface 1&gt;

…

### &lt;Nome interface m&gt;

## Livello 2

### White Box *&lt;building block 1&gt;*

*&lt;white box template&gt;*

### White Box *&lt;building block 2&gt;*

*&lt;white box template&gt;*

…

### White Box *&lt;building block m&gt;*

*&lt;white box template&gt;*

## Livello 3

### White Box &lt;\_building block x.1\_&gt;

*&lt;white box template&gt;*

### White Box &lt;\_building block x.2\_&gt;

*&lt;white box template&gt;*

### White Box &lt;\_building block y.1\_&gt;

*&lt;white box template&gt;*

# Runtime View

## &lt;Runtime Scenario 1&gt;

-   *&lt;inserire un runtime diagram o una descrizione testuale dello
    scenario&gt;*

-   *&lt;inserire la descrizione degli aspetti degni di nota delle
    interazioni tra i istanze di building block illustrate in questo
    diagramma.&gt;*

## &lt;Runtime Scenario 2&gt;

## …

## &lt;Runtime Scenario n&gt;

# Deployment View

## Livello infrastruttura 1

***&lt;Overview Diagram&gt;***

Motivatione  
*&lt;spiegazione in forma di testo&gt;*

Requsiti di qualità e/o di prestazioni  
*&lt;spiegazione in forma di testo&gt;*

Mappatura dei Building Blocks nella Architettura  
*&lt;descrizione della mappatura&gt;*

## Livello infrastruttura 2

### *&lt;Elemento infrastruttura 1&gt;*

*&lt;diagramma + spiegazione&gt;*

### *&lt;Elemento infrastruttura 2&gt;*

*&lt;diagramma + spiegazione&gt;*

…

### *&lt;Elemento infrastruttura n&gt;*

*&lt;diagramma + spiegazione&gt;*

# Concetti trasversali

## *&lt;Concetto 1&gt;*

*&lt;spiegazione&gt;*

## *&lt;Concetto 2&gt;*

*&lt;spiegazione&gt;*

…

## *&lt;Concetto n&gt;*

*&lt;spiegazione&gt;*

# Decisioni di progettazione

# Requisiti di Qualità

## Albero di qualità

## Scenari di qualità

# Rischi e debiti tecnici

# Glossario

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Termine</th>
<th style="text-align: left;">Definizione</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Termine-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definizione-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Termine-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definizione-2&gt;</em></p></td>
</tr>
</tbody>
</table>
