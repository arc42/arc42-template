# Glossar

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Inhalt

</div>

Die wesentlichen fachlichen und technischen Begriffe, die Stakeholder im
Zusammenhang mit dem System verwenden.

</div>

Nutzen Sie das Glossar ebenfalls als Übersetzungsreferenz, falls Sie in
mehrsprachigen Teams arbeiten.

<div class="formalpara">

<div class="title">

Motivation

</div>

Sie sollten relevante Begriffe klar definieren, so dass alle Beteiligten

</div>

- diese Begriffe identisch verstehen, und

- vermeiden, mehrere Begriffe für die gleiche Sache zu haben.

<div class="formalpara">

<div class="title">

Form

</div>

Zweispaltige Tabelle mit \<Begriff\> und \<Definition\>.

</div>

Eventuell weitere Spalten mit Übersetzungen, falls notwendig.

<div class="formalpara">

<div class="title">

Weiterführende Informationen

</div>

Siehe [Glossar](https://docs.arc42.org/section-12/) in der
online-Dokumentation (auf Englisch!).

</div>

</div>

| Begriff         | Definition         |
|-----------------|--------------------|
| *\<Begriff-1\>* | *\<Definition-1\>* |
| *\<Begriff-2*   | *\<Definition-2\>* |
