# Concepts transversaux

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenu

</div>

Cette section décrit les réglementations générales, principales et les
idées de solutions qui sont importantes dans plusieurs parties (=
transversales) de votre système. Ces concepts sont souvent liés à
plusieurs briques. Ils peuvent inclure de nombreux sujets différents,
tels que

</div>

- les modèles, particulièrement les modèles de domaine

- les modèles d’architecture ou de conception

- règles d’utilisation d’une technologie spécifique

- les décisions principales, souvent techniques, de nature globale (=
  transversale)

- règles de mise en œuvre

<div class="formalpara">

<div class="title">

Motivation

</div>

Les concepts constituent la base de l'*intégrité conceptuelle*
(cohérence, homogénéité) de l’architecture. Ils constituent donc une
contribution importante à l’obtention des qualités internes de votre
système.

</div>

Certains de ces concepts ne peuvent pas être attribués à des briques
individuelles, par exemple la sécurité ou la fiabilité.

<div class="formalpara">

<div class="title">

Représentation

</div>

La représentation peut être variée :

</div>

- des documents conceptuels avec n’importe quel type de structure

- des extraits de modèles transverses ou des scénarios utilisant les
  notations des vues de l’architecture

- des exemples de mise en œuvre, en particulier pour les concepts
  techniques

- référence à l’utilisation typique de frameworks standard (par exemple,
  l’utilisation d’Hibernate pour le mappage objet/relationnel)

<div class="formalpara">

<div class="title">

Structure

</div>

Une structure potentielle (mais non obligatoire) pour cette section
pourrait être la suivante :

</div>

- Concepts de domaine

- Concepts d’expérience utilisateur (UX)

- Concepts de fiabilité et de sécurité

- Architecture et modèles de conception

- "Sous le capot"

- Concepts de développement

- Concepts opérationnels

Remarque : il peut être difficile d’affecter des concepts individuels à
un thème spécifique de cette liste.

<figure>
<img src="images/08-concepts-EN.drawio.png"
alt="Thèmes possibles pour les concepts transversaux" />
</figure>

<div class="formalpara">

<div class="title">

Plus d’informations

</div>

Voir [Concepts](https://docs.arc42.org/section-8/) dans la documentation
arc42.

</div>

</div>

## *\<Concept 1\>*

*\<explication\>*

## *\<Concept 2\>*

*\<explication\>*

…​

## *\<Concept n\>*

*\<explication\>*
