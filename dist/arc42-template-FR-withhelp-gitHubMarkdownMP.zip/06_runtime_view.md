# Vue Exécution

## \<Scénario d’exécution 1\>

- *\<insérer un diagramme d’exécution ou une description textuelle du
  scénario\>*

- *\<insérer une description des aspects notables des interactions entre
  les instances des briques représentées dans ce diagramme.\>*

## \<Scénario d’exécution 2\>

## …​

## \<Scénario d’exécution n\>
