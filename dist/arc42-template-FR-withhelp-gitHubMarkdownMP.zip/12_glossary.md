# Glossaire

<div class="formalpara-title">

**Contenu**

</div>

Les termes techniques et métier les plus importants que vos parties
prenantes utilisent lorsqu’elles discutent du système.

Le glossaire peut également servir de source pour les traductions si
vous travaillez dans des équipes multilingues.

<div class="formalpara-title">

**Motivation**

</div>

Vous devez définir clairement vos termes, de manière à ce que toutes les
parties prenantes

-   aient une compréhension identique de ces termes

-   n’utilisent pas de synonymes et d’homonymes

Un tableau avec les colonnes \<Terme> et \<Définition>.

Potentiellement plus de colonnes au cas où vous auriez besoin de
traductions.

| Terme        | Définition        |
|--------------|-------------------|
| *\<Terme-1>* | *\<Définition-1>* |
| *\<Terme-2>* | *\<Définition-2>* |

Voir [Glossary](https://docs.arc42.org/section-12/) dans la
documentation arc42.

| Terme        | Définition        |
|--------------|-------------------|
| *\<Terme-1>* | *\<Définition-1>* |
| *\<Terme-2>* | *\<Définition-2>* |
