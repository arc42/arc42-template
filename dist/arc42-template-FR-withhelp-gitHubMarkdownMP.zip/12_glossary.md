# Glossaire

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenu

</div>

Les termes techniques et métier les plus importants que vos parties
prenantes utilisent lorsqu’elles discutent du système.

</div>

Le glossaire peut également servir de source pour les traductions si
vous travaillez dans des équipes multilingues.

<div class="formalpara">

<div class="title">

Motivation

</div>

Vous devez définir clairement vos termes, de manière à ce que toutes les
parties prenantes

</div>

- aient une compréhension identique de ces termes

- n’utilisent pas de synonymes et d’homonymes

<div class="formalpara">

<div class="title">

Représentation

</div>

Un tableau avec les colonnes \<Terme\> et \<Définition\>.

</div>

Potentiellement plus de colonnes au cas où vous auriez besoin de
traductions.

| Terme         | Définition         |
|---------------|--------------------|
| *\<Terme-1\>* | *\<Définition-1\>* |
| *\<Terme-2\>* | *\<Définition-2\>* |

<div class="formalpara">

<div class="title">

Informations supplémentaires

</div>

Voir [Glossary](https://docs.arc42.org/section-12/) dans la
documentation arc42.

</div>

</div>

| Terme         | Définition         |
|---------------|--------------------|
| *\<Terme-1\>* | *\<Définition-1\>* |
| *\<Terme-2\>* | *\<Définition-2\>* |
