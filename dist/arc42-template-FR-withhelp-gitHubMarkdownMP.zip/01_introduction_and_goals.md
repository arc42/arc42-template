# Introduction et Objectifs

<div class="sidebar">

<div class="title">

</div>

Décrit les specifications importantes et les facteurs déterminants que
les architectes logiciels et l’équipe de développement doivent prendre
en compte. Il s’agit notamment

- des objectifs métier sous-jacents,

- des caractéristiques essentielles,

- des spécifications fonctionnelles essentielles,

- des objectifs de qualité pour l’architecture et

- des parties prenantes concernées et leurs attentes

</div>

## Aperçu des spécifications

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenu

</div>

Brève description des spécifications fonctionnelles, des facteurs
déterminants, de l’extrait (ou du résumé) des spécifications. Liens vers
(en espérant qu’ils existent) les documents décrivant les spécifications
(avec le numéro de version et des informations sur l’endroit où les
trouver).

</div>

<div class="formalpara">

<div class="title">

Motivation

</div>

Du point de vue des utilisateurs, un système est créé ou modifié pour
améliorer le soutien d’une activité métier et/ou améliorer la qualité.

</div>

<div class="formalpara">

<div class="title">

Représentation

</div>

Brève description textuelle, probablement sous forme de tableau de cas
d’utilisation. S’il existe des documents décrivant les spécifications,
cet aperçu général doit s’y référer.

</div>

Ces extraits doivent être aussi courts que possible. Trouver un
équilibre entre la lisibilité de ce document et la redondance
potentielle par rapport aux documents décrivant les spécifications.

<div class="formalpara">

<div class="title">

Informations supplémentaires

</div>

Voir [Introduction and Goals](https://docs.arc42.org/section-1/) dans la
documentation arc42.

</div>

</div>

## Objectifs de Qualité

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenu

</div>

Les trois (maximum cinq) principaux objectifs de qualité pour
l’architecture dont la réalisation est de la plus haute importance pour
les principaux acteurs. Nous parlons bien d’objectifs de qualité pour
l’architecture. Ne les confondez pas avec les objectifs du projet. Ils
ne sont pas nécessairement identiques.

</div>

Voici un aperçu des sujets potentiels (basé sur la norme ISO 25010) :

<figure>
<img src="images/01_2_iso-25010-topics-EN-2023.drawio.png"
alt="Catégories d’exigences de Qualité" />
</figure>

<div class="formalpara">

<div class="title">

Motivation

</div>

Vous devez connaître les objectifs de qualité de vos principales parties
prenantes, car ils influenceront les décisions architecturales
fondamentales. Veillez à être très concret sur ces qualités, évitez les
mots à la mode. En tant qu’architecte, vous ne savez pas comment la
qualité de votre travail sera jugée…​

</div>

<div class="formalpara">

<div class="title">

Représentation

</div>

Un tableau avec des objectifs de qualité et des scénarios concrets,
classés par ordre de priorité

</div>

</div>

## Parties prenantes

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenu

</div>

Aperçu explicite des parties prenantes du système, c’est-à-dire toute
personne, rôle ou organisation qui

</div>

- doit connaître l’architecture

- doit être convaincue de l’architecture

- doit travailler avec l’architecture ou avec le code

- a besoin de la documentation d’architecture pour son travail

- doit prendre des décisions concernant le système ou son développement

<div class="formalpara">

<div class="title">

Motivation

</div>

Vous devez connaître toutes les parties impliquées dans le développement
du système ou concernées par celui-ci. Sinon, vous risquez d’avoir de
mauvaises surprises plus tard dans le processus de développement. Ces
parties prenantes déterminent l’étendue et le niveau de détail de votre
travail et de ses résultats.

</div>

<div class="formalpara">

<div class="title">

Représentation

</div>

Tableau avec les noms des rôles, les noms des personnes et leurs
attentes par rapport à l’architecture et à sa documentation.

</div>

</div>

| Rôle/Nom     | Contact         | Attentes        |
|--------------|-----------------|-----------------|
| *\<Role-1\>* | *\<Contact-1\>* | *\<Attente-1\>* |
| *\<Role-2\>* | *\<Contact-2\>* | *\<Attente-2\>* |
