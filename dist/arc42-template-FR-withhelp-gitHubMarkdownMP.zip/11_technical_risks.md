# Risques et Dettes techniques

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenu

</div>

Une liste des risques ou des dettes techniques identifiés, classés par
ordre de priorité

</div>

<div class="formalpara">

<div class="title">

Motivation

</div>

“Risk management is project management for grown-ups” (Tim Lister,
Atlantic Systems Guild.)

</div>

C’est la devise pour la détection et l’évaluation systématiques des
risques et des dettes techniques dans l’architecture, dont auront besoin
les acteurs de la gestion de projet (par exemple, les chefs de projet,
les propriétaires de produits) dans le cadre de l’analyse globale des
risques et de la planification de la mesure.

<div class="formalpara">

<div class="title">

Représentation

</div>

Liste des risques et/ou des dettes techniques, comprenant probablement
des mesures suggérées pour minimiser, atténuer ou éviter les risques ou
réduire les dettes techniques.

</div>

<div class="formalpara">

<div class="title">

Informations supplémentaires

</div>

Voir [Risks and Technical Debt](https://docs.arc42.org/section-11/) dans
la documentation arc42.

</div>

</div>
