# Contexte et périmètre

## Contexte métier

**\<Schéma ou tableau>**

**\<éventuellement : Explication des interfaces de domaines externes>**

## Contexte Technique

**\<Schéma ou tableau>**

**\<en option : Explication des interfaces techniques>**

**\<Correspondance des entrées/sorties aux canaux>**
