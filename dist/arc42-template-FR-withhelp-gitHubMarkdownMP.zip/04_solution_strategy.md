# Stratégie de solution
