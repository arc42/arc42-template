# Exigences de qualité

<div class="formalpara-title">

**Contenu**

</div>

Cette section contient toutes les exigences de qualité sous la forme
d’un arbre de qualité avec des scénarios. Les plus importantes ont déjà
été décrites au point 1.2 (objectifs de qualité).

Ici, vous pouvez également capturer des exigences de qualité avec une
priorité moindre, qui n’entraîneront pas de risques élevés si elles ne
sont pas entièrement satisfaites.

<div class="formalpara-title">

**Motivation**

</div>

Étant donné que les exigences de qualité auront une grande influence sur
les décisions architecturales, vous devez savoir, pour chaque partie
prenante, ce qui est vraiment important pour elle, ce qui est concret et
mesurable.

Voir [Quality Requirements](https://docs.arc42.org/section-10/) dans la
documentation arc42.

## Arbre de qualité

<div class="formalpara-title">

**Contenu**

</div>

L’arbre de qualité (tel que défini dans ATAM – Architecture Tradeoff
Analysis Method) avec des scénarios de qualité/évaluation sous forme de
feuilles.

<div class="formalpara-title">

**Motivation**

</div>

L’arborescence avec les priorités permet d’avoir une vue d’ensemble d’un
nombre parfois important d’exigences de qualité.

<div class="formalpara-title">

**Représentation**

</div>

L’arbre de qualité est une vue d’ensemble des objectifs et des exigences
en matière de qualité :

-   raffinement arborescent du terme "qualité". Utiliser "qualité" ou
    "utilité" comme racine

-   une carte mentale dont les principales branches sont les catégories
    de qualité

Dans tous les cas, l’arbre doit inclure des liens vers les scénarios de
la section suivante.

## Scénarios Qualité

<div class="formalpara-title">

**Contenu**

</div>

Concrétisation des exigences de qualité (parfois vagues ou implicites) à
l’aide de scénarios Qualité.

Ces scénarios décrivent ce qui doit se passer lorsqu’un stimulus arrive
au système.

Pour les architectes, deux types de scénarios sont importants :

-   Les scénarios d’utilisation (également appelés scénarios
    d’application ou scénarios de cas d’utilisation) décrivent la
    réaction du système en cours d’exécution à un certain stimulus. Cela
    inclut également les scénarios qui décrivent l’efficacité ou la
    performance du système. Exemple : Le système réagit à la demande
    d’un utilisateur en une seconde.

-   Les scénarios de changement décrivent une modification du système ou
    de son environnement immédiat. Exemple : Une fonctionnalité
    supplémentaire est mise en œuvre ou les exigences relatives à la
    modification d’un attribut Qualité.

<div class="formalpara-title">

**Motivation**

</div>

Les scénarios concrétisent les exigences de qualité et permettent de
mesurer ou de décider plus facilement si elles sont satisfaites.

En particulier lorsque vous souhaitez évaluer votre architecture à
l’aide de méthodes telles que ATAM, vous devez décrire vos objectifs
qualité (voir section 1.2) plus précisément à un niveau de scénarios qui
peuvent être discutés et évalués.

<div class="formalpara-title">

**Représentation**

</div>

Texte tabulaire ou libre.
