# Vue Déploiement

## Infrastructure Niveau 1

***\<Schéma d’ensemble\>***

Motivation  
*\<explication sous forme de texte\>*

Caractéristiques de qualité et/ou de performance  
*\<explication sous forme de texte\>*

Correspondance des briques vis à vis de l’infrastructure  
*\<description de la correspondance\>*

## Infrastructure Niveau 2

### *\<Infrastructure Element 1\>*

*\<schéma + explication\>*

### *\<Infrastructure Element 2\>*

*\<schéma + explication\>*

…​

### *\<Infrastructure Element n\>*

*\<schéma + explication\>*
