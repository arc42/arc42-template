# Contraintes d’Architecture

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenu

</div>

Toute spécification qui limite la liberté des architectes logiciels dans
leurs décisions de conception et de mise en œuvre ou dans leurs
décisions concernant le processus de développement. Ces contraintes vont
parfois au-delà des systèmes individuels et sont valables pour
l’ensemble des organisations et des entreprises.

</div>

<div class="formalpara">

<div class="title">

Motivation

</div>

Les architectes doivent savoir exactement où ils sont libres dans leurs
décisions de conception et où ils doivent respecter des contraintes. Les
contraintes doivent toujours être prises en compte ; elles peuvent
toutefois être négociables.

</div>

<div class="formalpara">

<div class="title">

Représentation

</div>

Tableaux simples de contraintes avec explications. Si nécessaire, vous
pouvez les subdiviser en contraintes techniques, contraintes
organisationnelles, politiques et conventions (par exemple, règles de
développement ou de gestion de versions, conventions de documentation ou
de nomenclature).

</div>

<div class="formalpara">

<div class="title">

Informations supplémentaires

</div>

Voir [Architecture Constraints](https://docs.arc42.org/section-2/) dans
la documentation arc42.

</div>

</div>
