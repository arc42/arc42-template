---
date: 2026. május
title: "![arc42](images/arc42-logo.png) Sablon"
---

# 

**Az arc42-ről**

arc42, a szoftver- és rendszerarchitektúra dokumentálásának sablonja.

Sablonverzió 9.0-HU. (az AsciiDoc verzió alapján), 2026. május

Készítették és karbantartják Dr. Peter Hruschka, Dr. Gernot Starke és a
közreműködők (©). Lásd <https://arc42.org>.

# Bevezetés és célok

## Követelmények áttekintése

## Minőségi célok

## Érdekelt felek

| Szerepkör/Név     | Elérhetőség         | Elvárások       |
|-------------------|---------------------|-----------------|
| *\<Szerepkör-1\>* | *\<Elérhetőség-1\>* | *\<Elvárás-1\>* |
| *\<Szerepkör-2\>* | *\<Elérhetőség-2\>* | *\<Elvárás-2\>* |

# Architekturális megkötések

# Kontextus és hatókör

## Üzleti kontextus

**\<Diagram vagy táblázat\>**

**\<opcionális: Külső szakterületi interfészek magyarázata\>**

## Technikai kontextus

**\<Diagram vagy táblázat\>**

**\<opcionális: Technikai interfészek magyarázata\>**

**\<Bemenet/kimenet leképezése csatornákra\>**

# Megoldási stratégia

# Építőelem-nézet

## Fehér doboz Teljes rendszer

***\<Áttekintő diagram\>***

Motiváció  
*\<szöveges magyarázat\>*

Tartalmazott építőelemek  
*\<A tartalmazott építőelemek (fekete dobozok) leírása\>*

Fontos interfészek  
*\<Fontos interfészek leírása\>*

### \<Fekete doboz 1 neve\>

*\<Cél/Felelősség\>*

*\<Interfész(ek)\>*

*\<(Opcionális) Minőségi/Teljesítményjellemzők\>*

*\<(Opcionális) Könyvtár/Fájl elérési út\>*

*\<(Opcionális) Teljesített követelmények\>*

*\<(Opcionális) Nyitott kérdések/Problémák/Kockázatok\>*

### \<Fekete doboz 2 neve\>

*\<fekete doboz sablon\>*

### \<Fekete doboz n neve\>

*\<fekete doboz sablon\>*

### \<Interfész 1 neve\>

…​

### \<Interfész m neve\>

## 2. szint

### Fehér doboz *\<1. építőelem\>*

*\<fehér doboz sablon\>*

### Fehér doboz *\<2. építőelem\>*

*\<fehér doboz sablon\>*

…​

### Fehér doboz *\<m. építőelem\>*

*\<fehér doboz sablon\>*

## 3. szint

### Fehér doboz \<\_x.1 építőelem\_\>

*\<fehér doboz sablon\>*

### Fehér doboz \<\_x.2 építőelem\_\>

*\<fehér doboz sablon\>*

### Fehér doboz \<\_y.1 építőelem\_\>

*\<fehér doboz sablon\>*

# Futásidejű nézet

## \<Futásidejű forgatókönyv 1\>

- *\<illesszen be futásidejű diagramot vagy a forgatókönyv szöveges
  leírását\>*

- *\<illesszen be leírást az ábrázolt építőelem-példányok közötti
  interakciók figyelemre méltó aspektusairól.\>*

## \<Futásidejű forgatókönyv 2\>

## …​

## \<Futásidejű forgatókönyv n\>

# Telepítési nézet

## 1. infrastruktúra-szint

***\<Áttekintő diagram\>***

Motiváció  
*\<szöveges magyarázat\>*

Minőségi és/vagy teljesítményjellemzők  
*\<szöveges magyarázat\>*

Építőelemek leképezése az infrastruktúrára  
*\<a leképezés leírása\>*

## 2. infrastruktúra-szint

### *\<1. infrastruktúra-elem\>*

*\<diagram + magyarázat\>*

### *\<2. infrastruktúra-elem\>*

*\<diagram + magyarázat\>*

…​

### *\<n. infrastruktúra-elem\>*

*\<diagram + magyarázat\>*

# Keresztmetszeti koncepciók

## *\<1. koncepció\>*

*\<magyarázat\>*

## *\<2. koncepció\>*

*\<magyarázat\>*

…​

## *\<n. koncepció\>*

*\<magyarázat\>*

# Architektúra-döntések

# Minőségi követelmények

## Minőségi követelmények áttekintése

## Minőségi forgatókönyvek

# Kockázatok és technikai adósságok

# Szójegyzék

| Kifejezés         | Meghatározás         |
|-------------------|----------------------|
| *\<Kifejezés-1\>* | *\<meghatározás-1\>* |
| *\<Kifejezés-2\>* | *\<meghatározás-2\>* |
