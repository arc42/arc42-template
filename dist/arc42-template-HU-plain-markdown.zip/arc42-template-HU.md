---
date: 2026. május
title: "![arc42](images/arc42-logo.png) Sablon"
---

# 

**Az arc42-ről**

arc42, a szoftver- és rendszerarchitektúra dokumentálásának sablonja.

Sablonverzió 9.0-HU. (az AsciiDoc verzió alapján), 2026. május

Készítették és karbantartják Dr. Peter Hruschka, Dr. Gernot Starke és a
közreműködők (©). Lásd <https://arc42.org>.

# Bevezetés és célok {#section-introduction-and-goals}

## Követelmények áttekintése {#_követelmények_áttekintése}

## Minőségi célok {#_minőségi_célok}

## Érdekelt felek {#_érdekelt_felek}

+-------------+---------------------------+---------------------------+
| Sz          | Elérhetőség               | Elvárások                 |
| erepkör/Név |                           |                           |
+=============+===========================+===========================+
| *\<Sze      | *\<Elérhetőség-1\>*       | *\<Elvárás-1\>*           |
| repkör-1\>* |                           |                           |
+-------------+---------------------------+---------------------------+
| *\<Sze      | *\<Elérhetőség-2\>*       | *\<Elvárás-2\>*           |
| repkör-2\>* |                           |                           |
+-------------+---------------------------+---------------------------+

# Architekturális megkötések {#section-architecture-constraints}

# Kontextus és hatókör {#section-context-and-scope}

## Üzleti kontextus {#_üzleti_kontextus}

**\<Diagram vagy táblázat\>**

**\<opcionális: Külső szakterületi interfészek magyarázata\>**

## Technikai kontextus {#_technikai_kontextus}

**\<Diagram vagy táblázat\>**

**\<opcionális: Technikai interfészek magyarázata\>**

**\<Bemenet/kimenet leképezése csatornákra\>**

# Megoldási stratégia {#section-solution-strategy}

# Építőelem-nézet {#section-building-block-view}

## Fehér doboz Teljes rendszer {#_fehér_doboz_teljes_rendszer}

***\<Áttekintő diagram\>***

Motiváció

:   *\<szöveges magyarázat\>*

Tartalmazott építőelemek

:   *\<A tartalmazott építőelemek (fekete dobozok) leírása\>*

Fontos interfészek

:   *\<Fontos interfészek leírása\>*

### \<Fekete doboz 1 neve\> {#_fekete_doboz_1_neve}

*\<Cél/Felelősség\>*

*\<Interfész(ek)\>*

*\<(Opcionális) Minőségi/Teljesítményjellemzők\>*

*\<(Opcionális) Könyvtár/Fájl elérési út\>*

*\<(Opcionális) Teljesített követelmények\>*

*\<(Opcionális) Nyitott kérdések/Problémák/Kockázatok\>*

### \<Fekete doboz 2 neve\> {#_fekete_doboz_2_neve}

*\<fekete doboz sablon\>*

### \<Fekete doboz n neve\> {#_fekete_doboz_n_neve}

*\<fekete doboz sablon\>*

### \<Interfész 1 neve\> {#_interfész_1_neve}

...​

### \<Interfész m neve\> {#_interfész_m_neve}

## 2. szint {#_2_szint}

### Fehér doboz *\<1. építőelem\>* {#_fehér_doboz_1_építőelem}

*\<fehér doboz sablon\>*

### Fehér doboz *\<2. építőelem\>* {#_fehér_doboz_2_építőelem}

*\<fehér doboz sablon\>*

...​

### Fehér doboz *\<m. építőelem\>* {#_fehér_doboz_m_építőelem}

*\<fehér doboz sablon\>*

## 3. szint {#_3_szint}

### Fehér doboz \<\_x.1 építőelem\_\> {#_fehér_doboz_x_1_építőelem}

*\<fehér doboz sablon\>*

### Fehér doboz \<\_x.2 építőelem\_\> {#_fehér_doboz_x_2_építőelem}

*\<fehér doboz sablon\>*

### Fehér doboz \<\_y.1 építőelem\_\> {#_fehér_doboz_y_1_építőelem}

*\<fehér doboz sablon\>*

# Futásidejű nézet {#section-runtime-view}

## \<Futásidejű forgatókönyv 1\> {#_futásidejű_forgatókönyv_1}

-   *\<illesszen be futásidejű diagramot vagy a forgatókönyv szöveges
    leírását\>*

-   *\<illesszen be leírást az ábrázolt építőelem-példányok közötti
    interakciók figyelemre méltó aspektusairól.\>*

## \<Futásidejű forgatókönyv 2\> {#_futásidejű_forgatókönyv_2}

## ...​

## \<Futásidejű forgatókönyv n\> {#_futásidejű_forgatókönyv_n}

# Telepítési nézet {#section-deployment-view}

## 1. infrastruktúra-szint {#_1_infrastruktúra_szint}

***\<Áttekintő diagram\>***

Motiváció

:   *\<szöveges magyarázat\>*

Minőségi és/vagy teljesítményjellemzők

:   *\<szöveges magyarázat\>*

Építőelemek leképezése az infrastruktúrára

:   *\<a leképezés leírása\>*

## 2. infrastruktúra-szint {#_2_infrastruktúra_szint}

### *\<1. infrastruktúra-elem\>* {#_1_infrastruktúra_elem}

*\<diagram + magyarázat\>*

### *\<2. infrastruktúra-elem\>* {#_2_infrastruktúra_elem}

*\<diagram + magyarázat\>*

...​

### *\<n. infrastruktúra-elem\>* {#_n_infrastruktúra_elem}

*\<diagram + magyarázat\>*

# Keresztmetszeti koncepciók {#section-concepts}

## *\<1. koncepció\>* {#_1_koncepció}

*\<magyarázat\>*

## *\<2. koncepció\>* {#_2_koncepció}

*\<magyarázat\>*

...​

## *\<n. koncepció\>* {#_n_koncepció}

*\<magyarázat\>*

# Architektúra-döntések {#section-design-decisions}

# Minőségi követelmények {#section-quality-scenarios}

## Minőségi követelmények áttekintése {#_minőségi_követelmények_áttekintése}

## Minőségi forgatókönyvek {#_minőségi_forgatókönyvek}

# Kockázatok és technikai adósságok {#section-technical-risks}

# Szójegyzék {#section-glossary}

+----------------------+-----------------------------------------------+
| Kifejezés            | Meghatározás                                  |
+======================+===============================================+
| *\<Kifejezés-1\>*    | *\<meghatározás-1\>*                          |
+----------------------+-----------------------------------------------+
| *\<Kifejezés-2\>*    | *\<meghatározás-2\>*                          |
+----------------------+-----------------------------------------------+
