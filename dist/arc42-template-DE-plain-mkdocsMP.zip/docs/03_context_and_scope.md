# Kontextabgrenzung {#section-context-and-scope}

## Fachlicher Kontext {#_fachlicher_kontext}

**&lt;Diagramm und/oder Tabelle&gt;**

**&lt;optional: Erläuterung der externen fachlichen Schnittstellen&gt;**

## Technischer Kontext {#_technischer_kontext}

**&lt;Diagramm oder Tabelle&gt;**

**&lt;optional: Erläuterung der externen technischen Schnittstellen&gt;**

**&lt;Mapping fachliche auf technische Schnittstellen&gt;**

  [Kontextabgrenzung]: #section-context-and-scope {#toc-section-context-and-scope}
  [Fachlicher Kontext]: #_fachlicher_kontext {#toc-_fachlicher_kontext}
  [Technischer Kontext]: #_technischer_kontext {#toc-_technischer_kontext}
