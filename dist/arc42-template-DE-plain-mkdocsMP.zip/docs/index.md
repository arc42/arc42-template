**Über arc42**

arc42, das Template zur Dokumentation von Software- und Systemarchitekturen.

Template Version 9.0-DE. (basiert auf der AsciiDoc Version), Juli 2025

Created, maintained and © by Dr. Peter Hruschka, Dr. Gernot Starke and contributors. Siehe <https://arc42.org>.


0. [Einführung und Ziele](01_introduction_and_goals.md)

0. [Randbedingungen](02_architecture_constraints.md)

0. [Kontextabgrenzung](03_context_and_scope.md)

0. [Lösungsstrategie](04_solution_strategy.md)

0. [Bausteinsicht](05_building_block_view.md)

0. [Laufzeitsicht](06_runtime_view.md)

0. [Verteilungssicht](07_deployment_view.md)

0. [Querschnittliche Konzepte](08_concepts.md)

0. [Architekturentscheidungen](09_architecture_decisions.md)

0. [Qualitätsanforderungen](10_quality_requirements.md)

0. [Risiken und technische Schulden](11_technical_risks.md)

0. [Glossar](12_glossary.md)
