# Querschnittliche Konzepte {#section-concepts}

## *&lt;Konzept 1&gt;* {#_konzept_1}

*&lt;Erklärung&gt;*

## *&lt;Konzept 2&gt;* {#_konzept_2}

*&lt;Erklärung&gt;*

…​

## *&lt;Konzept n&gt;* {#_konzept_n}

*&lt;Erklärung&gt;*

  [Querschnittliche Konzepte]: #section-concepts {#toc-section-concepts}
  [*&lt;Konzept 1&gt;*]: #_konzept_1 {#toc-_konzept_1}
  [*&lt;Konzept 2&gt;*]: #_konzept_2 {#toc-_konzept_2}
  [*&lt;Konzept n&gt;*]: #_konzept_n {#toc-_konzept_n}
