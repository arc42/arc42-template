# Словарь

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Термин</th>
<th style="text-align: left;">Определение</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Термин-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Определение-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Термин-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Определение-2&gt;</em></p></td>
</tr>
</tbody>
</table>
