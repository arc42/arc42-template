Словарь
=======

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th>Термин</th>
<th>Определение</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><p><em>&lt;Термин-1&gt;</em></p></td>
<td><p><em>&lt;Определение-1&gt;</em></p></td>
</tr>
<tr class="even">
<td><p><em>&lt;Термин-2&gt;</em></p></td>
<td><p><em>&lt;Определение-2&gt;</em></p></td>
</tr>
</tbody>
</table>
