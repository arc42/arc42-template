# Введение и цели

## Обзор требований

## Цели по качеству

## Заинтересованные стороны

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Роль/Имя</th>
<th style="text-align: left;">Контактные данные</th>
<th style="text-align: left;">Ожидания</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Роль-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Контактные-данные-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Ожидания-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Роль-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Контактные-данные-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Ожидания-2&gt;</em></p></td>
</tr>
</tbody>
</table>
