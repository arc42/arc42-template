# Glossario

**Contenuti**

Il dominio più importante e i termini tecnici utilizzati dagli
stakeholder quando discutono del sistema.

Puoi anche vedere il glossario come fonte per le traduzioni se lavori in
team multilingue.

**Motivazione**

Dovresti definire chiaramente i tuoi termini, in modo che tutte le parti
interessate

-   abbiano una comprensione identica di questi termini

-   non utilizzino sinonimi e omonimi

<!-- -->

-   Una tabella con colonne &lt;Termine&gt; e &lt;Definizione&gt;.

-   Potenzialmente più colonne nel caso tu abbia bisogno di traduzioni.

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Termine</th>
<th style="text-align: left;">Definizione</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Termine-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definizione-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Termine-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definizione-2&gt;</em></p></td>
</tr>
</tbody>
</table>
