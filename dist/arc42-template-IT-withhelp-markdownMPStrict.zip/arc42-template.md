# 

**About arc42**

arc42, the Template for documentation of software and system
architecture.

By Dr. Gernot Starke, Dr. Peter Hruschka and contributors.

Template Revision: 7.0 IT (based on asciidoc), April 2021

© We acknowledge that this document uses material from the arc 42
architecture template, <https://www.arc42.org>. Created by Dr. Peter
Hruschka & Dr. Gernot Starke.

This version of the template contains some help and explanations. It is
used for familiarization with arc42 and the understanding of the
concepts. For documentation of your own system you use better the
*plain* version.

# Introduzione e obiettivi

Descrive i requisiti rilevanti e le forze trainanti che gli architetti
del software e il team di sviluppo devono considerare. Questi includono

-   obiettivi di business sottostanti, caratteristiche essenziali e
    requisiti funzionali per il sistema

-   obiettivi di qualità per l’architettura

-   stakeholder rilevanti e le loro aspettative

## Panoramica dei requisiti

**Contenuti**

Breve descrizione dei requisiti funzionali, forze trainanti, estratto (o
abstract) dei requisiti. Collegamento ai documenti dei requisiti (si
spera esistenti) (con il numero di versione e le informazioni su dove
trovarlo).

**Motivazione**

Dal punto di vista degli utenti finali un sistema viene creato o
modificato per migliorare il supporto di un’attività di business e/o
migliorare la qualità.

**Forma**

Breve descrizione testuale, casi d’uso in forma tabellare. Se esistono
documenti sui requisiti, questa panoramica dovrebbe fare riferimento a
questi documenti.

Mantieni questi estratti il ​​più brevi possibile. Bilancia la
leggibilità di questo documento con la potenziale ridondanza rispetto ai
documenti dei requisiti.

## Obiettivi di qualità

**Contenuti**

I principali tre (massimo cinque) obiettivi di qualità per
l’architettura la cui realizzazione è della massima importanza per i
principali stakeholder, Intendiamo davvero obiettivi di qualità per
l’architettura. Non confonderli con gli obiettivi del progetto. Non sono
necessariamente identici.

**Motivazione**

Dovresti conoscere gli obiettivi di qualità dei tuoi stakeholder più
importanti, poiché influenzeranno le decisioni architettoniche
fondamentali. Assicurati di essere molto concreto su queste qualità,
evita le parole d’ordine. Se tu come architetto non sai come verrà
giudicata la qualità del tuo lavoro

**Forma**

Una tabella con obiettivi di qualità e scenari concreti, ordinati per
priorità

## Stakeholders

Panoramica esplicita degli stakeholder del sistema, ovvero tutte le
persone, i ruoli o le organizzazioni che

-   dovrebbero conoscere l’architettura

-   devono essere convinti dell’architettura

-   devono lavorare con l’architettura o con il codice

-   necessitano della documentazione dell’architettura per il loro
    lavoro

-   devono prendere decisioni sul sistema o sul suo sviluppo

**Motivazione**

È necessario conoscere tutte le parti coinvolte nello sviluppo del
sistema o interessate dal sistema. Altrimenti, potresti ricevere brutte
sorprese più avanti nel processo di sviluppo. Questi stakeholder
determinano la portata e il livello di dettaglio del tuo lavoro e dei
suoi risultati.

**Forma**

Tabella con i nomi dei ruoli, i nomi delle persone e le loro aspettative
rispetto all’architettura e alla sua documentazione

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Rouolo/Nome</th>
<th style="text-align: left;">Contatto</th>
<th style="text-align: left;">Aspettative</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Ruolo-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Contatto-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Aspettatiive-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Ruolo-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Contatto-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Aspettatiive-2&gt;</em></p></td>
</tr>
</tbody>
</table>

# Vincoli di architettura

**Contenuti**

Qualsiasi requisito che limiti gli architetti del software nella loro
libertà di decisioni di progettazione e implementazione o decisione sul
processo di sviluppo. Questi vincoli a volte vanno oltre i singoli
sistemi e sono validi per intere organizzazioni e aziende.

**Motivazione**

Gli architetti dovrebbero sapere esattamente dove sono liberi nelle loro
decisioni di progettazione e dove devono aderire ai vincoli. I vincoli
devono essere sempre affrontati; possono essere negoziabili però.

**Forma**

Semplici tabelle di vincoli con spiegazioni. Se necessario puoi
suddividerli in file vincoli tecnici, vincoli organizzativi e politici e
convenzioni (ad es. linee guida di programmazione o di controllo delle
versioni, documentazione o convenzioni di denominazione)

# Ambito e contesto del sistema

**Contenuti**

L’ambito e il contesto del sistema, come suggerisce il nome, delimitano
il sistema (ovvero l’ambito) da tutti i suoi partner di comunicazione
(sistemi e utenti vicini, ovvero il contesto del tuo sistema). In tal
modo specifica le interfacce esterne.

Se necessario, differenziare il contesto di business (input e output
specifici del dominio) dal contesto tecnico (canali, protocolli,
hardware).

**Motivazione**

Le interfacce di dominio e le interfacce tecniche per i partner di
comunicazione sono tra gli aspetti più critici del sistema. Assicurati
di capirli completamente.

**Forma**

Diverse opzioni:

-   Diagrammi di contesto

-   Elenchi di partner di comunicazione e loro interfacce.

## Contesto di Business

**Contenuti**

Specifica di **tutti** i partner di comunicazione (utenti, sistemi IT,
…) con spiegazioni di input e output specifici del dominio o interfacce.
Facoltativamente è possibile aggiungere formati specifici del dominio o
protocolli di comunicazione.

**Motivazione**

Tutti gli stakeholder dovrebbero capire quali dati vengono scambiati con
l’ambiente del sistema.

**Forma**

Tutti i tipi di diagrammi che mostrano il sistema come una scatola nera
e specificano le interfacce di dominio per i partner di comunicazione.

In alternativa (o in aggiunta) puoi usare una tabella. Il titolo della
tabella è il nome del sistema, le tre colonne contengono il nome del
partner di comunicazione, gli ingressi e le uscite.

**&lt;Diagramma o Tabella>**

**&lt;opzionale: spiegazione delle interfacce del dominio esterno>**

## Contesto Tecnico

**Contenuti**

Interfacce tecniche (canali e mezzi di trasmissione) che collegano il
sistema al suo ambiente. Oltre alla mappatura dell’input/output
specifico del dominio sui canali di comunicazione, ad es. una
spiegazione con I/O dell’utilizza del canale di comunicazione.

**Motivazione**

Spesso, gli stakeholders prendono decisioni architetturali in base alle
interfacce tecniche tra il sistema e il suo contesto. Sono,
principalmente i progettisti di infrastrutture o hardware che decidono
queste interfacce tecniche.

**Forma**

Esempio: un deployment diagram UML che descrive i canali di
comunicazione dei sistemi vicini, insieme a una tabella di mappatura che
mostra le relazioni tra canali e input/output.

**&lt;Diagramma o Tabella>**

**&lt;opzionale: Spiegazione delle interfacce tecniche>**

**&lt;Mappatura Input/Output sui canali di comunicazione>**

# Strategia della soluzione

**Contenuti**

Un breve riassunto e spiegazione delle decisioni fondamentali e delle
strategie di soluzione che modellano l’architettura del sistema. Questi
includono

-   decisioni tecnologiche

-   decisioni sulla scomposizione di primo livello del sistema, ad es.
    utilizzo di un modello architetturale o di un modello di
    progettazione

-   decisioni su come raggiungere gli obiettivi chiave di qualità

-   decisioni organizzative rilevanti, ad es. selezionare un processo di
    sviluppo o delegare determinati compiti a terzi.

**Motivazione**

Queste decisioni costituiscono le pietre angolari della tua
architettura. Sono la base per molte altre decisioni dettagliate o
regole di attuazione.

**Forma**

Mantieni breve la spiegazione di queste decisioni chiave.

Motiva ciò che hai deciso e perché lo hai deciso in questo modo, in base
alla dichiarazione del problema, agli obiettivi di qualità e ai vincoli
chiave. Fare riferimento ai dettagli nelle sezioni seguenti.

# Building Block View

**Contenuti**

La visualizzazione building block mostra la scomposizione statica del
sistema in building block (moduli, componenti, sottosistemi, classi,
interfacce, pacchetti, librerie, framework, livelli, partizioni,
livelli, funzioni, macro, operazioni, strutture dei dati, …) così come
le loro dipendenze (relazioni, associazioni, …)

Questa vista dovrebbe essere obbligatoria per ogni documentazione
sull’architettura. In analogia con una casa, questa è la *pianta dei
piani*.

**Motivazione**

Mantieni una panoramica del tuo codice sorgente rendendone comprensibile
la struttura tramite astrazioni di essa.

Ciò consente di comunicare con gli stakeholder a livello astratto senza
rivelare i dettagli di implementazione.

**Forma**

è una raccolta gerarchica di black box e white box (vedi figura sotto) e
le loro descrizioni.

![Gerarchia dei building blocks](images/05_building_blocks-IT.png)

**Livello 1** è la descrizione della white box del sistema complessivo
insieme alle descrizioni delle black box di tutti i building block
contenuti.

**Livello 2** entra nel dettaglio dei building block di livello 1.
Quindi contiene la descrizione della white box dei building block
selezionati del livello 1, insieme alle descrizioni della black box dei
building block interni.

**Livello 3** entra nel dettaglio dei building block di livello 2, e
cosi via..

## Whitebox Overall System

Qui descrivi la scomposizione dell’intero sistema utilizzando il
seguente template white box. Contiene

-   un diagramma generico

-   una motivazione per la decomposizione

-   descrizioni in black box dei building blocks contenuti. Per questi
    ti offriamo alternative:

    -   usa la tabella *one* per una panoramica breve e pragmatica di
        tutti gli elementi costitutivi contenuti e delle loro interfacce

    -   utilizzare un elenco di descrizioni delle black box dei building
        box secondo il template black box (vedi sotto). A seconda dello
        strumento scelto, questo elenco potrebbe essere sottocapitoli
        (in file di testo), sottopagine (in un Wiki) o elementi
        nidificati (in uno strumento di modellazione).

-   (opzionale) interfacce importanti, che non sono spiegate nelle black
    box di un building block, ma sono molto importanti per comprendere
    la white box. Poiché ci sono così tanti modi per specificare le
    interfacce, non forniamo un template specifico per loro. Nel
    peggiore dei casi devi specificare e descrivere sintassi, semantica,
    protocolli, gestione degli errori, restrizioni, versioni, qualità,
    compatibilità necessarie e molte altre cose. Nel migliore dei casi
    te la caverai con esempi o semplici firme.

***&lt;Overview Diagram>***

Motivazione  
*&lt;spiegazione testuale>*

Contenuto dei Building Blocks  
*&lt;Descrizione del contenuto del building block (black boxes)>*

Important Interfaces  
*&lt;Descrizione delle interfacce importanti>*

Inserisci le spiegazioni delle black box dal livello 1:

Se usi la forma tabulare descriveresti solo le black box con nome e
responsabilità secondo il seguente schema:

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;"><strong>Nome</strong></th>
<th style="text-align: left;"><strong>Responsibilità</strong></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;black box 1&gt;</em></p></td>
<td style="text-align: left;"><p> <em>&lt;Text&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;black box 2&gt;</em></p></td>
<td style="text-align: left;"><p> <em>&lt;Text&gt;</em></p></td>
</tr>
</tbody>
</table>

Se si utilizza un elenco di descrizioni delle black box, si compila un
template di black box separato per ogni building block importante. Il
titolo è il nome della black box.

### &lt;Nome black box 1>

Qui descrivi la &lt;black box 1> secondo il seguente template di scatola
nera:

-   Scopo/responsabilità

-   Interfacce, quando non vengono estratte come paragrafi separati.
    Queste interfacce possono includere caratteristiche di qualità e
    prestazionali.

-   (Facoltativo) Caratteristiche di qualità/prestazionali della black
    box, ad esempio disponibilità, comportamento in fase di esecuzione,
    ….

-   (Facoltativo) percorso file/directory

-   (Facoltativo) Requisiti soddisfatti (se è necessaria la
    tracciabilità dei requisiti).

-   (Facoltativo) Bug noti/Rischi/problemi

*&lt;Scopo/responsabilità>*

*&lt;Interfacce>*

*&lt;(Facoltativo) Caratteristiche di qualità/prestazionali>*

*&lt;(Facoltativo) percorso file/directory>*

*&lt;(Facoltativo) Requisiti soddisfatti>*

*&lt;(Facoltativo) Bug noti/Rischi/problemi>*

### &lt;Nome black box 2>

*&lt;black box template>*

### &lt;Nome black box n>

*&lt;black box template>*

### &lt;Nome interface 1>

…

### &lt;Nome interface m>

## Livello 2

Qui puoi specificare la struttura interna di (alcuni) building block dal
livello 1 come white box.

Devi decidere quali building block del tuo sistema sono abbastanza
importanti da giustificare una descrizione così dettagliata. Si prega di
preferire la pertinenza alla completezza. Specifica i building blocks
importanti, sorprendenti, rischiosi, complessi o volatili. Tralascia le
parti normali, semplici, noiose o standardizzate del tuo sistema

### White Box *&lt;building block 1>*

…descrive la struttura interna del *building block 1*.

*&lt;white box template>*

### White Box *&lt;building block 2>*

*&lt;white box template>*

…

### White Box *&lt;building block m>*

*&lt;white box template>*

## Livello 3

Qui puoi specificare la struttura interna di (alcuni) building block dal
livello 2 come white box.

Quando hai bisogno di livelli più dettagliati della tua architettura,
copia questa parte di arc42 per livelli aggiuntivi.

### White Box &lt;\_building block x.1\_&gt;

Specifica la struttura interna del *building block x.1*.

*&lt;white box template>*

### White Box &lt;\_building block x.2\_&gt;

*&lt;white box template>*

### White Box &lt;\_building block y.1\_&gt;

*&lt;white box template>*

# Runtime View

**Contenuti**

La runtime view descrive il comportamento concreto e le interazioni dei
building block del sistema sotto forma di scenari dalle seguenti aree:

-   importanti casi d’uso o funzionalità: come vengono eseguiti dai
    building block?

-   interazioni alle interfacce esterne critiche: in che modo i building
    block cooperano con gli utenti e i sistemi vicini?

-   funzionamento e amministrazione: lancio, avvio, arresto

-   errori e scenari di eccezione

Nota: il criterio principale per la scelta dei possibili scenari
(sequenze, flussi di lavoro) è la loro **rilevanza architettonica**.
**Non** è importante descrivere un gran numero di scenari. Dovresti
piuttosto documentare una selezione rappresentativa.

**Motivazione**

È necessario comprendere in che modo (istanze di) building block del
sistema eseguono il proprio lavoro e comunicano in fase di esecuzione.
Acquisirai principalmente scenari nella tua documentazione per
comunicare la tua architettura alle parti interessate che sono meno
disposte o in grado di leggere e comprendere i modelli statici (building
block view, deployment view).

**Forma**

Ci sono molte notazioni per descrivere gli scenari, ad es.

-   elenco numerato di passaggi (in linguaggio naturale)

-   activity diagram o diagrammi di flusso

-   sequence diagram

-   BPMN o EPC (catene di processi di eventi)

-   state diagram

-   …

## &lt;Runtime Scenario 1>

-   *&lt;inserire un runtime diagram o una descrizione testuale dello
    scenario>*

-   *&lt;inserire la descrizione degli aspetti degni di nota delle
    interazioni tra i istanze di building block illustrate in questo
    diagramma.>*

## &lt;Runtime Scenario 2>

## …

## &lt;Runtime Scenario n>

# Deployment View

**Contenuti**

La Deployment View descrive:

1.  l’infrastruttura tecnica utilizzata per eseguire il sistema, con
    elementi dell’infrastruttura come posizioni geografiche, ambienti,
    computer, processori, canali e topologie di rete, nonché altri
    elementi dell’infrastruttura e

2.  la mappatura dei building block (software) di tali elementi
    dell’infrastruttura.

Spesso i sistemi vengono eseguiti in ambienti diversi, ad es. ambiente
di sviluppo, ambiente di test, ambiente di produzione. In questi casi è
necessario documentare tutti gli ambienti rilevanti.

Documentare in particolare la Deployment View quando il software viene
eseguito come sistema distribuito con più di un computer, processore,
server o container o quando si progettano e si costruiscono processori e
chip hardware personalizzati.

Dal punto di vista del software è sufficiente acquisire quegli elementi
dell’infrastruttura necessari per mostrare la distribuzione dei building
block. Gli architetti hardware possono andare oltre e descrivere
l’infrastruttura con qualsiasi livello di dettaglio di cui hanno bisogno
per acquisire.

**Motivazione**

Il software non funziona senza hardware. Questa infrastruttura
sottostante può e influenzerà il tuo sistema e/o alcuni concetti
trasversali. Pertanto, è necessario conoscere l’infrastruttura.

**Forma**

Può essere che il Deployment View di livello più alto sia già contenuto
nella sezione 3.2. come contesto tecnico con la propria infrastruttura
come UNA scatola nera. In questa sezione lo farai ingrandire questa
scatola nera utilizzando Deployment View aggiuntivi:

-   UML offre diagrammi di distribuzione per esprimere quella vista.
    Usalo, probabilmente con diagrammi annidati, quando la tua
    infrastruttura è più complessa.

-   Quando i tuoi stakeholder (hardware) preferiscono altri tipi di
    diagrammi piuttosto che il Deployment View, lascia che utilizzino
    qualsiasi tipo che sia in grado di mostrare nodi e canali
    dell’infrastruttura.

## Livello infrastruttura 1

Descrivi (di solito in una combinazione di diagrammi, tabelle e testo):

-   la distribuzione del sistema in più posizioni, ambienti, computer,
    processori, .. così come le connessioni fisiche tra di loro

-   una giustificazione o motivazione importante per questa struttura di
    distribuzione

-   Caratteristiche di qualità e/o prestazioni dell’infrastruttura

-   la mappatura degli artefatti software agli elementi
    dell’infrastruttura

Per più ambienti o distribuzioni alternative, copia quella sezione di
arc42 per tutti gli ambienti pertinenti.

***&lt;Overview Diagram>***

Motivatione  
*&lt;spiegazione in forma di testo>*

Requsiti di qualità e/o di prestazioni  
*&lt;spiegazione in forma di testo>*

Mappatura dei Building Blocks nella Architettura  
*&lt;descrizione della mappatura>*

## Livello infrastruttura 2

Qui puoi includere la struttura interna di (alcuni) elementi
dell’infrastruttura dal livello 1.

Si prega di copiare la struttura dal livello 1 per ogni elemento
selezionato.

### *&lt;Elemento infrastruttura 1>*

*&lt;diagramma + spiegazione>*

### *&lt;Elemento infrastruttura 2>*

*&lt;diagramma + spiegazione>*

…

### *&lt;Elemento infrastruttura n>*

*&lt;diagramma + spiegazione>*

# Concetti trasversali

**Contenuto**

Questa sezione descrive le normative generali e principali e le idee di
soluzione che sono rilevante in più parti (= trasversali) del sistema.
Tali concetti sono spesso correlati a più building blocks. Possono
includere molti argomenti diversi, come

-   modello di domonio

-   modelli di architettura o modelli di design

-   regole per l’utilizzo di una tecnologia specifica

-   decisioni principali, spesso tecniche, di decisioni generali

-   regole di implementazione

**Motivazione**

I concetti costituiscono la base per l '\_ integrità concettuale\_
(coerenza, omogeneità) dell’architettura. Pertanto, sono un contributo
importante per raggiungere le qualità interne del tuo sistema.

Alcuni di questi concetti non possono essere assegnati a singoli
building blocks (ad es. sicurezza o protezione). Questo è il posto nel
template che abbiamo fornito per una specifica coerente di tali
concetti.

**Forma**

Le forme possono eessere varie:

-   documenti concettuali con qualsiasi tipo di struttura

-   estratti di modelli trasversali o scenari che utilizzano le
    notazioni delle viste dell’architettura

-   implementazioni di esempio, soprattutto per concetti tecnici

-   riferimento all’uso tipico di framework standard (es. utilizzo di
    Hibernate per object/relational mapping)

**Struttura**

Una struttura potenziale (ma non obbligatoria) per questa sezione
potrebbe essere:

-   Concetti di dominio

-   Concetti sull’esperienza utente (UX)

-   Concetti di sicurezza e protezione

-   Architettura e modelli di design

-   "Sotto il cappuccio"

-   concetti di sviluppo

-   concetti operativi

Nota: potrebbe essere difficile assegnare concetti individuali a un
argomento specifico in questo elenco.

![Possibili argomenti per concetti
trasversali](images/08-concepts-EN.drawio.png)

## *&lt;Concetto 1>*

*&lt;spiegazione>*

## *&lt;Concetto 2>*

*&lt;spiegazione>*

…

## *&lt;Concetto n>*

*&lt;spiegazione>*

# Decisioni di progettazione

**Contenuti**

Decisioni di architettura importanti, costose, su larga scala o
rischiose, inclusi i razionali. Con "decisioni" si intende selezionare
un’alternativa in base a determinati criteri.

Si prega di utilizzare il proprio giudizio per decidere se una decisione
architetturale debba essere documentata qui in questa sezione centrale o
se è meglio documentarlo localmente (ad es. all’interno del whitebox di
un building block).

Evita la ridondanza. Fare riferimento alla sezione 4, dove sono già
state acquisite le decisioni più importanti della propria architettura.

**Motivazione**

Gli stakeholder del tuo sistema dovrebbero essere in grado di
comprendere e ripercorrere le tue decisioni.

**Forma**

Diverse opzioni:

-   Elenco o tabella, ordinati per importanza e conseguenze oppure:

-   più dettagliato sotto forma di sezioni separate per le decisioni

-   ADR (architecture decision record) per ogni decisione importante

# Requisiti di Qualità

**Contenuto**

Questa sezione contiene tutti i requisiti di qualità come albero di
qualità con scenari. I più importanti sono già stati descritti nella
sezione 1.2. (obiettivi di qualità)

Qui puoi anche acquisire i requisiti di qualità con una priorità minore,
il che non creerà rischi elevati quando non sono pienamente raggiunti.

**Motivazione**

Poiché i requisiti di qualità avranno molta influenza sulle decisioni
architetturali, dovresti sapere per ogni stakeholder cosa è veramente
importante per loro, concreto e misurabile.

## Albero di qualità

**Contenuto**

L’albero della qualità (come definito in ATAM – Architecture Tradeoff
Analysis Method) con scenari di qualità/valutazione come foglie.

**Motivazione**

La struttura ad albero con le priorità fornisce una panoramica per un
numero talvolta elevato di requisiti di qualità.

**Forma**

L’albero della qualità è una panoramica di alto livello degli obiettivi
e dei requisiti di qualità:

-   espande il termine "qualità" con la forma di un’albero. Usa
    "qualità" o "utilità" come radice

-   una mappa mentale con categorie di qualità come rami principali

In ogni caso l’albero dovrebbe includere collegamenti agli scenari della
sezione successiva.

## Scenari di qualità

**Contenuti**

Concretizzazione dei requisiti di qualità (a volte vaghi o impliciti)
utilizzando scenari (di qualità).

Questi scenari descrivono cosa dovrebbe accadere quando uno stimolo
arriva al sistema.

Per gli architetti, due tipi di scenari sono importanti:

-   Gli scenari di utilizzo (chiamati anche scenari di applicazione o
    scenari di casi d’uso) descrivono la reazione di runtime del sistema
    a un determinato stimolo. Ciò include anche scenari che descrivono
    l’efficienza o le prestazioni del sistema. Esempio: il sistema
    risponde alla richiesta di un utente entro un secondo.

-   Gli scenari di cambiamento descrivono una modifica del sistema o
    dell’ambiente circostante. Esempio: sono implementate funzionalità
    aggiuntive o requisiti per una modifica dell’attributo di qualità.

**Motivazione**

Gli scenari rendono concreti i requisiti di qualità e consentono di
misurare o decidere più facilmente se sono soddisfatti.

Soprattutto quando vuoi valutare la tua architettura usando metodi come
ATAM devi descrivere i tuoi obiettivi di qualità (dalla sezione 1.2) più
precisamente fino a un livello di scenari che possono essere discussi e
valutati.

**Forma**

Testo tabulare o testo in formato libero.

# Rischi e debiti tecnici

**Contenuti**

Un elenco di rischi tecnici o debiti tecnici identificati, ordinati per
priorità

**Motivazione**

“La gestione del rischio è la gestione del progetto per adulti” (Tim
Lister, Atlantic Systems Guild.)

Questo dovrebbe essere il tuo motto per il rilevamento e la valutazione
sistematica dei rischi e dei debiti tecnici nell’architettura, che
saranno necessari agli stakeholder del management (ad esempio i project
manager, i proprietari dei prodotti) come parte dell’analisi complessiva
dei rischi e della pianificazione delle misurazioni.

**Forma**

Elenco dei rischi e/o dei debiti tecnici, possibilmente comprendendo le
misure suggerite per minimizzare, mitigare o evitare i rischi o ridurre
i debiti tecnici.

# Glossario

**Contenuti**

Il dominio più importante e i termini tecnici utilizzati dagli
stakeholder quando discutono del sistema.

Puoi anche vedere il glossario come fonte per le traduzioni se lavori in
team multilingue.

**Motivazione**

Dovresti definire chiaramente i tuoi termini, in modo che tutte le parti
interessate

-   abbiano una comprensione identica di questi termini

-   non utilizzino sinonimi e omonimi

<!-- -->

-   Una tabella con colonne &lt;Termine> e &lt;Definizione>.

-   Potenzialmente più colonne nel caso tu abbia bisogno di traduzioni.

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Termine</th>
<th style="text-align: left;">Definizione</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Termine-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definizione-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Termine-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definizione-2&gt;</em></p></td>
</tr>
</tbody>
</table>
