# Concetti trasversali

## *&lt;Concetto 1>*

*&lt;spiegazione>*

## *&lt;Concetto 2>*

*&lt;spiegazione>*

…

## *&lt;Concetto n>*

*&lt;spiegazione>*
