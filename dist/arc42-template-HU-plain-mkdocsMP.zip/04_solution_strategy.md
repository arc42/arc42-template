# Megoldási stratégia {#section-solution-strategy}
