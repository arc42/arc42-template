# Futásidejű nézet {#section-runtime-view}

## \<Futásidejű forgatókönyv 1\> {#_futásidejű_forgatókönyv_1}

-   *\<illesszen be futásidejű diagramot vagy a forgatókönyv szöveges
    leírását\>*

-   *\<illesszen be leírást az ábrázolt építőelem-példányok közötti
    interakciók figyelemre méltó aspektusairól.\>*

## \<Futásidejű forgatókönyv 2\> {#_futásidejű_forgatókönyv_2}

## ...​

## \<Futásidejű forgatókönyv n\> {#_futásidejű_forgatókönyv_n}
