# Bevezetés és célok {#section-introduction-and-goals}

## Követelmények áttekintése {#_követelmények_áttekintése}

## Minőségi célok {#_minőségi_célok}

## Érdekelt felek {#_érdekelt_felek}

+-------------+---------------------------+---------------------------+
| Sz          | Elérhetőség               | Elvárások                 |
| erepkör/Név |                           |                           |
+=============+===========================+===========================+
| *\<Sze      | *\<Elérhetőség-1\>*       | *\<Elvárás-1\>*           |
| repkör-1\>* |                           |                           |
+-------------+---------------------------+---------------------------+
| *\<Sze      | *\<Elérhetőség-2\>*       | *\<Elvárás-2\>*           |
| repkör-2\>* |                           |                           |
+-------------+---------------------------+---------------------------+
