# Telepítési nézet {#section-deployment-view}

## 1. infrastruktúra-szint {#_1_infrastruktúra_szint}

***\<Áttekintő diagram\>***

Motiváció

:   *\<szöveges magyarázat\>*

Minőségi és/vagy teljesítményjellemzők

:   *\<szöveges magyarázat\>*

Építőelemek leképezése az infrastruktúrára

:   *\<a leképezés leírása\>*

## 2. infrastruktúra-szint {#_2_infrastruktúra_szint}

### *\<1. infrastruktúra-elem\>* {#_1_infrastruktúra_elem}

*\<diagram + magyarázat\>*

### *\<2. infrastruktúra-elem\>* {#_2_infrastruktúra_elem}

*\<diagram + magyarázat\>*

...​

### *\<n. infrastruktúra-elem\>* {#_n_infrastruktúra_elem}

*\<diagram + magyarázat\>*
