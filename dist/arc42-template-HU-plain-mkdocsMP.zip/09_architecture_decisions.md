# Architektúra-döntések {#section-design-decisions}
