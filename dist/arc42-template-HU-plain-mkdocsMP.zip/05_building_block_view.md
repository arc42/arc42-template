# Építőelem-nézet {#section-building-block-view}

## Fehér doboz Teljes rendszer {#_fehér_doboz_teljes_rendszer}

***\<Áttekintő diagram\>***

Motiváció

:   *\<szöveges magyarázat\>*

Tartalmazott építőelemek

:   *\<A tartalmazott építőelemek (fekete dobozok) leírása\>*

Fontos interfészek

:   *\<Fontos interfészek leírása\>*

### \<Fekete doboz 1 neve\> {#_fekete_doboz_1_neve}

*\<Cél/Felelősség\>*

*\<Interfész(ek)\>*

*\<(Opcionális) Minőségi/Teljesítményjellemzők\>*

*\<(Opcionális) Könyvtár/Fájl elérési út\>*

*\<(Opcionális) Teljesített követelmények\>*

*\<(Opcionális) Nyitott kérdések/Problémák/Kockázatok\>*

### \<Fekete doboz 2 neve\> {#_fekete_doboz_2_neve}

*\<fekete doboz sablon\>*

### \<Fekete doboz n neve\> {#_fekete_doboz_n_neve}

*\<fekete doboz sablon\>*

### \<Interfész 1 neve\> {#_interfész_1_neve}

...​

### \<Interfész m neve\> {#_interfész_m_neve}

## 2. szint {#_2_szint}

### Fehér doboz *\<1. építőelem\>* {#_fehér_doboz_1_építőelem}

*\<fehér doboz sablon\>*

### Fehér doboz *\<2. építőelem\>* {#_fehér_doboz_2_építőelem}

*\<fehér doboz sablon\>*

...​

### Fehér doboz *\<m. építőelem\>* {#_fehér_doboz_m_építőelem}

*\<fehér doboz sablon\>*

## 3. szint {#_3_szint}

### Fehér doboz \<\_x.1 építőelem\_\> {#_fehér_doboz_x_1_építőelem}

*\<fehér doboz sablon\>*

### Fehér doboz \<\_x.2 építőelem\_\> {#_fehér_doboz_x_2_építőelem}

*\<fehér doboz sablon\>*

### Fehér doboz \<\_y.1 építőelem\_\> {#_fehér_doboz_y_1_építőelem}

*\<fehér doboz sablon\>*
