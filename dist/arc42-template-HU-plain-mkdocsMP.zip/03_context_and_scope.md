# Kontextus és hatókör {#section-context-and-scope}

## Üzleti kontextus {#_üzleti_kontextus}

**\<Diagram vagy táblázat\>**

**\<opcionális: Külső szakterületi interfészek magyarázata\>**

## Technikai kontextus {#_technikai_kontextus}

**\<Diagram vagy táblázat\>**

**\<opcionális: Technikai interfészek magyarázata\>**

**\<Bemenet/kimenet leképezése csatornákra\>**
