# Architekturális megkötések {#section-architecture-constraints}
