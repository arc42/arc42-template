# Kockázatok és technikai adósságok {#section-technical-risks}
