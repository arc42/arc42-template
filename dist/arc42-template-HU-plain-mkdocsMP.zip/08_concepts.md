# Keresztmetszeti koncepciók {#section-concepts}

## *\<1. koncepció\>* {#_1_koncepció}

*\<magyarázat\>*

## *\<2. koncepció\>* {#_2_koncepció}

*\<magyarázat\>*

...​

## *\<n. koncepció\>* {#_n_koncepció}

*\<magyarázat\>*
