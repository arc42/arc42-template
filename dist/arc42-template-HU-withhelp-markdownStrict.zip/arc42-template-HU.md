# 

**Az arc42-ről**

arc42, a szoftver- és rendszerarchitektúra dokumentálásának sablonja.

Sablonverzió 9.0-HU. (az AsciiDoc verzió alapján), 2026. május

Készítették és karbantartják Dr. Peter Hruschka, Dr. Gernot Starke és a
közreműködők (©). Lásd <https://arc42.org>.

A sablon ezen verziója súgókat és magyarázatokat tartalmaz. Az arc42
megismeréséhez és a koncepciók megértéséhez használható. Saját rendszer
dokumentálásához használja inkább az *egyszerű* verziót.

# Bevezetés és célok

Leírja azokat a követelményeket és hajtóerőket, amelyeket a
szoftverarchitekteknek és a fejlesztőcsapatnak figyelembe kell venniük.
Ezek a következők:

-   alapvető üzleti célok,

-   lényeges funkciók,

-   lényeges funkcionális követelmények,

-   az architektúra minőségi céljai és

-   a releváns érdekelt felek és elvárásaik

## Követelmények áttekintése

**Tartalom**

A funkcionális követelmények rövid leírása, hajtóerők, a követelmények
kivonata (vagy összefoglalása). Hivatkozás a (remélhetőleg létező)
követelmény-dokumentumokra (verziószámmal és az elérhetőség
megjelölésével).

**Motiváció**

A végfelhasználók szemszögéből a rendszert egy üzleti tevékenység jobb
támogatása és/vagy a minőség javítása érdekében hozzák létre vagy
módosítják.

**Forma**

Rövid szöveges leírás, valószínűleg táblázatos használati eset
formátumban. Ha léteznek követelmény-dokumentumok, ez az áttekintés
hivatkozzon azokra.

Tartsa ezeket a kivonatokat a lehető legrövidebben. Egyensúlyozzon a
dokumentum olvashatósága és a követelmény-dokumentumokkal való esetleges
redundancia között.

**További információ**

Lásd [Bevezetés és célok](https://docs.arc42.org/section-1/) az arc42
dokumentációban.

## Minőségi célok

**Tartalom**

Az architektúra három (legfeljebb öt) legfontosabb minőségi célja,
amelyek teljesülése a legfontosabb érdekelt felek számára a legnagyobb
jelentőséggel bír. Valóban az architektúra minőségi céljairól van szó.
Ne keverje össze ezeket a projekt céljaival. Nem feltétlenül azonosak.

Tekintse át a lehetséges témák alábbi áttekintését (az ISO 25010
szabvány alapján):

<figure>
<img src="images/01_2_iso-25010-topics-HU-2023.drawio.png"
alt="Minőségi követelmények kategóriái" />
</figure>

**Motiváció**

Ismernie kell a legfontosabb érdekelt felek minőségi céljait, mivel ezek
alapvető architekturális döntéseket befolyásolnak. Legyen nagyon konkrét
ezekkel a minőségi jellemzőkkel kapcsolatban, kerülje a divatos
szavakat. Ha architektként nem tudja, hogyan fogják munkája minőségét
megítélni…​

**Forma**

Táblázat minőségi célokkal és konkrét forgatókönyvekkel, prioritás
szerint rendezve

## Érdekelt felek

**Tartalom**

A rendszer érdekelt feleinek explicit áttekintése, azaz minden személy,
szerepkör vagy szervezet, amely

-   ismernie kell az architektúrát

-   meg kell győzni az architektúráról

-   az architektúrával vagy a kóddal kell dolgoznia

-   munkájához szüksége van az architektúra dokumentációjára

-   a rendszerrel vagy annak fejlesztésével kapcsolatos döntéseket kell
    hoznia

**Motiváció**

Ismernie kell minden, a rendszer fejlesztésében érintett vagy a rendszer
által érintett felet. Ellenkező esetben kellemetlen meglepetések érhetik
a fejlesztési folyamat során. Ezek az érdekelt felek határozzák meg
munkája és annak eredményei terjedelmét, valamint részletességi
szintjét.

**Forma**

Táblázat szerepkörökkel, személynevekkel és az architektúrával, illetve
annak dokumentációjával kapcsolatos elvárásaikkal.

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Szerepkör/Név</th>
<th style="text-align: left;">Elérhetőség</th>
<th style="text-align: left;">Elvárások</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Szerepkör-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Elérhetőség-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Elvárás-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Szerepkör-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Elérhetőség-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Elvárás-2&gt;</em></p></td>
</tr>
</tbody>
</table>

# Architekturális megkötések

**Tartalom**

Minden olyan követelmény, amely korlátozza a szoftverarchitekteket a
tervezési és megvalósítási döntéseikben, illetve a fejlesztési
folyamatra vonatkozó döntéseikben. Ezek a megkötések néha túlmutatnak az
egyes rendszereken, és egész szervezetekre vagy vállalatokra érvényesek.

**Motiváció**

Az architekteknek pontosan tudniuk kell, hol szabadok a tervezési
döntéseikben, és hol kell betartaniuk a megkötéseket. A megkötésekkel
mindig foglalkozni kell; bár lehetnek tárgyalhatók.

**Forma**

Egyszerű táblázatok megkötésekkel és magyarázatokkal. Szükség esetén
feloszthatók technikai korlátokra, szervezeti és politikai megkötésekre,
valamint konvenciókra (pl. programozási vagy verziókezelési irányelvek,
dokumentációs vagy elnevezési konvenciók).

**További információ**

Lásd [Architekturális megkötések](https://docs.arc42.org/section-2/) az
arc42 dokumentációban.

# Kontextus és hatókör

**Tartalom**

A kontextus és hatókör – ahogy a neve is sugallja – elhatárolja a
rendszert (azaz a hatókört) az összes kommunikációs partnerétől
(szomszédos rendszerek és felhasználók, azaz a rendszer kontextusa).
Ezáltal meghatározza a külső interfészeket.

Szükség esetén különítse el az üzleti kontextust (szakterület-specifikus
bemenetek és kimenetek) a technikai kontextustól (csatornák,
protokollok, hardver).

**Motiváció**

A kommunikációs partnerek felé mutató szakterületi és technikai
interfészek a rendszer legkritikusabb szempontjai közé tartoznak.
Győződjön meg róla, hogy teljesen megérti őket.

**Forma**

Különböző lehetőségek:

-   Kontextus-diagramok

-   Kommunikációs partnerek és interfészeik listája.

**További információ**

Lásd [Kontextus és hatókör](https://docs.arc42.org/section-3/) az arc42
dokumentációban.

## Üzleti kontextus

**Tartalom**

Az **összes** kommunikációs partner (felhasználók, IT-rendszerek, …​)
specifikációja a szakterület-specifikus bemenetek és kimenetek, illetve
interfészek magyarázatával. Opcionálisan hozzáadhatók
szakterület-specifikus formátumok vagy kommunikációs protokollok.

**Motiváció**

Minden érdekelt félnek meg kell értenie, milyen adatok cserélődnek a
rendszer környezetével.

**Forma**

Bármilyen diagram, amely a rendszert fekete dobozként mutatja, és
meghatározza a szakterületi interfészeket a kommunikációs partnerek
felé.

Alternatívaként (vagy kiegészítésként) használhat táblázatot is. A
táblázat címe a rendszer neve, a három oszlop tartalmazza a
kommunikációs partner nevét, a bemeneteket és a kimeneteket.

**&lt;Diagram vagy táblázat&gt;**

**&lt;opcionális: Külső szakterületi interfészek magyarázata&gt;**

## Technikai kontextus

**Tartalom**

Technikai interfészek (csatornák és átviteli közegek), amelyek a
rendszert a környezetéhez kapcsolják. Emellett a szakterület-specifikus
bemenet/kimenet leképezése a csatornákra, azaz annak magyarázata, hogy
melyik I/O melyik csatornát használja.

**Motiváció**

Sok érdekelt fél a rendszer és kontextusa közötti technikai interfészek
alapján hoz architekturális döntéseket. Különösen az infrastruktúra-
vagy hardvertervezők döntik el ezeket a technikai interfészeket.

**Forma**

Pl. UML telepítési diagram, amely a szomszédos rendszerek felé mutató
csatornákat írja le, kiegészítve egy leképezési táblázattal, amely a
csatornák és a bemenet/kimenet közötti kapcsolatokat mutatja.

**&lt;Diagram vagy táblázat&gt;**

**&lt;opcionális: Technikai interfészek magyarázata&gt;**

**&lt;Bemenet/kimenet leképezése csatornákra&gt;**

# Megoldási stratégia

**Tartalom**

Az alapvető döntések és megoldási stratégiák rövid összefoglalása és
magyarázata, amelyek a rendszer architektúráját alakítják. Ezek a
következők:

-   technológiai döntések

-   a rendszer legfelső szintű dekompozíciójára vonatkozó döntések, pl.
    architekturális minta vagy tervezési minta alkalmazása

-   a kulcsfontosságú minőségi célok elérésére vonatkozó döntések

-   releváns szervezeti döntések, pl. fejlesztési folyamat kiválasztása
    vagy bizonyos feladatok harmadik félnek történő delegálása.

**Motiváció**

Ezek a döntések képezik az architektúra sarokköveit. Számos más
részletes döntés vagy megvalósítási szabály alapjául szolgálnak.

**Forma**

Tartsa rövidre az ilyen kulcsfontosságú döntések magyarázatát.

Indokolja meg, hogy mit döntöttek és miért úgy döntöttek, a
probléma-meghatározás, a minőségi célok és a kulcsfontosságú megkötések
alapján. Hivatkozzon a következő fejezetek részleteire.

**További információ**

Lásd [Megoldási stratégia](https://docs.arc42.org/section-4/) az arc42
dokumentációban.

# Építőelem-nézet

**Tartalom**

Az építőelem-nézet a rendszer statikus dekompozícióját mutatja
építőelemekre (modulok, komponensek, alrendszerek, osztályok,
interfészek, csomagok, könyvtárak, keretrendszerek, rétegek, partíciók,
szintek, függvények, makrók, műveletek, adatstruktúrák, …​), valamint
azok függőségeit (kapcsolatok, asszociációk, …​).

Ez a nézet minden architektúra-dokumentációban kötelező. Egy ház
analógiájával élve ez az *alaprajz*.

**Motiváció**

Őrizze meg a forráskód áttekinthetőségét azáltal, hogy szerkezetét
absztrakcióval érthetővé teszi.

Ez lehetővé teszi, hogy absztrakt szinten kommunikáljon az érdekelt
felekkel, anélkül, hogy a megvalósítás részleteit felfedné.

**Forma**

Az építőelem-nézet fekete dobozok és fehér dobozok hierarchikus
gyűjteménye (lásd az alábbi ábrát) és azok leírásai.

<figure>
<img src="images/05_building_blocks-HU.png"
alt="Építőelemek hierarchiája" />
</figure>

Az **1. szint** a teljes rendszer fehér doboz leírása a benne található
összes építőelem fekete doboz leírásával együtt.

A **2. szint** ráközelít az 1. szint néhány építőelemére. Így az 1.
szint kiválasztott építőelemeinek fehér doboz leírását tartalmazza, azok
belső építőelemeinek fekete doboz leírásával együtt.

A **3. szint** ráközelít a 2. szint kiválasztott építőelemeire, és így
tovább.

**További információ**

Lásd [Építőelem-nézet](https://docs.arc42.org/section-5/) az arc42
dokumentációban.

## Fehér doboz Teljes rendszer

Itt írja le a teljes rendszer dekompozícióját az alábbi fehér doboz
sablon segítségével. Ez tartalmazza:

-   egy áttekintő diagramot

-   a dekompozíció motivációját

-   a tartalmazott építőelemek fekete doboz leírásait. Ehhez a következő
    alternatívákat kínáljuk:

    -   használjon *egy* táblázatot az összes tartalmazott építőelem és
        interfészük rövid és pragmatikus áttekintéséhez

    -   használja a fekete doboz sablon szerinti fekete doboz leírások
        listáját (lásd alább). Az eszközválasztástól függően ez a lista
        lehet alfejezet (szöveges fájlokban), aloldal (wikiben) vagy
        beágyazott elem (modellező eszközben).

-   (opcionális:) olyan fontos interfészek, amelyeket nem a fekete doboz
    sablonok magyaráznak meg, de nagyon fontosak a fehér doboz
    megértéséhez. Mivel az interfészek megadásának oly sok módja
    létezik, nem adunk meg hozzájuk specifikus sablont. A legrosszabb
    esetben meg kell adnia és le kell írnia a szintaxist, szemantikát,
    protokollokat, hibakezelést, korlátozásokat, verziókat, minőségi
    jellemzőket, szükséges kompatibilitásokat és sok mást. A legjobb
    esetben elegendőek lesznek a példák vagy egyszerű szignatúrák.

***&lt;Áttekintő diagram&gt;***

Motiváció  
*&lt;szöveges magyarázat&gt;*

Tartalmazott építőelemek  
*&lt;A tartalmazott építőelemek (fekete dobozok) leírása&gt;*

Fontos interfészek  
*&lt;Fontos interfészek leírása&gt;*

Illessze be az 1. szint fekete dobozainak magyarázatát:

Ha táblázatos formát használ, a fekete dobozokat csak név és felelősség
szerint írja le a következő séma szerint:

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;"><strong>Név</strong></th>
<th style="text-align: left;"><strong>Felelősség</strong></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;fekete doboz
1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Szöveg&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;fekete doboz
2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Szöveg&gt;</em></p></td>
</tr>
</tbody>
</table>

Ha fekete doboz leírások listáját használja, minden fontos építőelemhez
külön fekete doboz sablont tölt ki. A címsora az adott fekete doboz
neve.

### &lt;Fekete doboz 1 neve&gt;

Itt írja le a &lt;fekete doboz 1&gt;-et a következő fekete doboz sablon
szerint:

-   Cél/Felelősség

-   Interfész(ek), ha nem külön bekezdésbe vannak kiemelve. Ezek az
    interfészek tartalmazhatnak minőségi és teljesítményjellemzőket.

-   (Opcionális) Minőségi/Teljesítményjellemzők a fekete dobozra
    vonatkozóan, pl. rendelkezésre állás, futásidejű viselkedés, …​.

-   (Opcionális) Könyvtár/fájl elérési út

-   (Opcionális) Teljesített követelmények (ha nyomon követhetőség
    szükséges a követelményekhez).

-   (Opcionális) Nyitott kérdések/problémák/kockázatok

*&lt;Cél/Felelősség&gt;*

*&lt;Interfész(ek)&gt;*

*&lt;(Opcionális) Minőségi/Teljesítményjellemzők&gt;*

*&lt;(Opcionális) Könyvtár/Fájl elérési út&gt;*

*&lt;(Opcionális) Teljesített követelmények&gt;*

*&lt;(Opcionális) Nyitott kérdések/Problémák/Kockázatok&gt;*

### &lt;Fekete doboz 2 neve&gt;

*&lt;fekete doboz sablon&gt;*

### &lt;Fekete doboz n neve&gt;

*&lt;fekete doboz sablon&gt;*

### &lt;Interfész 1 neve&gt;

…​

### &lt;Interfész m neve&gt;

## 2. szint

Itt adhatja meg az 1. szint (néhány) építőelemének belső szerkezetét
fehér dobozként.

El kell döntenie, hogy a rendszer mely építőelemei elég fontosak ahhoz,
hogy ilyen részletes leírást kapjanak. Részesítse előnyben a relevanciát
a teljességgel szemben. Írja le a fontos, meglepő, kockázatos, összetett
vagy instabil építőelemeket. Hagyja ki a rendszer normális, egyszerű,
unalmas vagy szabványos részeit.

### Fehér doboz *&lt;1. építőelem&gt;*

…​az *1. építőelem* belső szerkezetét írja le.

*&lt;fehér doboz sablon&gt;*

### Fehér doboz *&lt;2. építőelem&gt;*

*&lt;fehér doboz sablon&gt;*

…​

### Fehér doboz *&lt;m. építőelem&gt;*

*&lt;fehér doboz sablon&gt;*

## 3. szint

Itt adhatja meg a 2. szint (néhány) építőelemének belső szerkezetét
fehér dobozként.

Ha az architektúrában részletesebb szintekre van szükség, másolja le az
arc42 ezen részét a további szintekhez.

### Fehér doboz &lt;\_x.1 építőelem\_&gt;

Az *x.1 építőelem* belső szerkezetét adja meg.

*&lt;fehér doboz sablon&gt;*

### Fehér doboz &lt;\_x.2 építőelem\_&gt;

*&lt;fehér doboz sablon&gt;*

### Fehér doboz &lt;\_y.1 építőelem\_&gt;

*&lt;fehér doboz sablon&gt;*

# Futásidejű nézet

**Tartalom**

A futásidejű nézet a rendszer építőelemeinek konkrét viselkedését és
interakcióit írja le forgatókönyvek formájában, az alábbi területekről:

-   fontos használati esetek vagy funkciók: hogyan hajtják végre az
    építőelemek?

-   interakciók kritikus külső interfészeken: hogyan működnek együtt az
    építőelemek a felhasználókkal és szomszédos rendszerekkel?

-   üzemeltetés és adminisztráció: indítás, elindulás, leállás

-   hiba- és kivételforgatókönyvek

Megjegyzés: A lehetséges forgatókönyvek (szekvenciák, munkafolyamatok)
kiválasztásának fő kritériuma az **architekturális relevancia**. **Nem**
fontos nagyszámú forgatókönyvet leírni. Inkább egy reprezentatív
válogatást dokumentáljon.

**Motiváció**

Meg kell értenie, hogyan végzik el a rendszerét alkotó építőelemek
(illetve azok példányai) a feladataikat, és hogyan kommunikálnak
futásidőben. A forgatókönyveket elsősorban azért rögzíti a
dokumentációban, hogy az architektúrát kommunikálja azoknak az érdekelt
feleknek, akik kevésbé hajlandók vagy képesek elolvasni és megérteni a
statikus modelleket (építőelem-nézet, telepítési nézet).

**Forma**

Számos jelölés létezik a forgatókönyvek leírására, pl.:

-   lépések számozott listája (természetes nyelven)

-   tevékenységdiagramok vagy folyamatábrák

-   szekvenciadiagramok

-   BPMN vagy EPC-k (eseményvezérelt folyamatláncok)

-   állapotgépek

-   …​

**További információ**

Lásd [Futásidejű nézet](https://docs.arc42.org/section-6/) az arc42
dokumentációban.

## &lt;Futásidejű forgatókönyv 1&gt;

-   *&lt;illesszen be futásidejű diagramot vagy a forgatókönyv szöveges
    leírását&gt;*

-   *&lt;illesszen be leírást az ábrázolt építőelem-példányok közötti
    interakciók figyelemre méltó aspektusairól.&gt;*

## &lt;Futásidejű forgatókönyv 2&gt;

## …​

## &lt;Futásidejű forgatókönyv n&gt;

# Telepítési nézet

**Tartalom**

A telepítési nézet a következőket írja le:

1.  a rendszer futtatásához használt technikai infrastruktúrát,
    beleértve az infrastruktúra-elemeket, mint földrajzi helyszínek,
    környezetek, számítógépek, processzorok, csatornák és hálózati
    topológiák, valamint egyéb infrastruktúra-elemek, és

2.  a (szoftver) építőelemek leképezését ezekre az
    infrastruktúra-elemekre.

A rendszerek gyakran különböző környezetekben futnak, pl. fejlesztői
környezet, tesztkörnyezet, éles környezet. Ilyen esetekben dokumentálja
az összes releváns környezetet.

Különösen akkor dokumentálja a telepítési nézetet, ha a szoftver
elosztott rendszerként fut egynél több számítógépen, processzoron,
szerveren vagy konténerben, illetve ha saját hardverprocesszorokat és
chipeket tervez és épít.

Szoftver szempontból elegendő csak azokat az infrastruktúra-elemeket
rögzíteni, amelyek szükségesek az építőelemek telepítésének
bemutatásához. A hardverarchitektek túlmehetnek ezen, és az
infrastruktúrát bármilyen részletességi szintig leírhatják.

**Motiváció**

A szoftver nem fut hardver nélkül. Ez az alapul szolgáló infrastruktúra
befolyásolja, és befolyásolni is fogja a rendszert és/vagy néhány
keresztmetszeti koncepciót. Ezért szükséges az infrastruktúra ismerete.

**Forma**

Lehetséges, hogy a legfelső szintű telepítési diagram már a 3.2.
fejezetben megjelent technikai kontextusként, ahol saját
infrastruktúráját EGY fekete dobozként ábrázolja. Ebben a fejezetben
további telepítési diagramok segítségével részletesebben megvizsgálhatja
(belenagyíthat) ebbe a fekete dobozba:

-   Az UML telepítési diagramokat kínál ennek a nézetnek a kifejezésére.
    Használja ezeket, esetleg beágyazott diagramokkal, ha az
    infrastruktúra összetettebb.

-   Ha a (hardver) érdekelt felek más jellegű diagramokat részesítenek
    előnyben a telepítési diagram helyett, engedje, hogy bármilyen
    diagramot használjanak, amely képes az infrastruktúra csomópontjait
    és csatornáit megjeleníteni.

**További információ**

Lásd [Telepítési nézet](https://docs.arc42.org/section-7/) az arc42
dokumentációban.

## 1. infrastruktúra-szint

Írja le (általában diagramok, táblázatok és szöveg kombinációjával):

-   a rendszer elosztását több helyszínre, környezetre, számítógépre,
    processzorra stb., valamint a közöttük lévő fizikai kapcsolatokat

-   a telepítési struktúra fontos indoklásait vagy motivációit

-   az infrastruktúra minőségi és/vagy teljesítményjellemzőit

-   a szoftver-artefaktumok leképezését az infrastruktúra-elemekre

Több környezet vagy alternatív telepítés esetén kérjük, másolja és
adaptálja az arc42 ezen fejezetét az összes releváns környezethez.

***&lt;Áttekintő diagram&gt;***

Motiváció  
*&lt;szöveges magyarázat&gt;*

Minőségi és/vagy teljesítményjellemzők  
*&lt;szöveges magyarázat&gt;*

Építőelemek leképezése az infrastruktúrára  
*&lt;a leképezés leírása&gt;*

## 2. infrastruktúra-szint

Itt megadhatja az 1. szint (néhány) infrastruktúra-elemének belső
szerkezetét.

Kérjük, másolja az 1. szint struktúráját minden kiválasztott elemhez.

### *&lt;1. infrastruktúra-elem&gt;*

*&lt;diagram + magyarázat&gt;*

### *&lt;2. infrastruktúra-elem&gt;*

*&lt;diagram + magyarázat&gt;*

…​

### *&lt;n. infrastruktúra-elem&gt;*

*&lt;diagram + magyarázat&gt;*

# Keresztmetszeti koncepciók

**Tartalom**

Ez a fejezet a keresztmetszeti koncepciókat (gyakorlatok, minták,
szabályozások vagy megoldási ötletek) írja le. Az ilyen koncepciók
gyakran több építőelemhez kapcsolódnak. Számos különböző témát
tartalmazhatnak, mint például az alábbi ábrán bemutatottak:

<figure>
<img src="images/08-concepts-HU.drawio.png"
alt="A keresztmetszeti koncepciók lehetséges témái" />
</figure>

**Motiváció**

A koncepciók alkotják az architektúra *fogalmi integritásának*
(konzisztencia, homogenitás) alapját. Ezáltal fontos hozzájárulást
jelentenek a rendszer belső minőségeinek eléréséhez.

Ez a sablon azon helye, amelyet az ilyen koncepciók egységes
specifikációjára biztosítottunk.

Ezek közül sok koncepció több építőelemhez kapcsolódik vagy hat rájuk.

**Forma**

A forma változatos lehet:

-   koncepciódokumentumok bármilyen struktúrával

-   példamegvalósítások, különösen technikai koncepciókhoz

-   keresztmetszeti modellrészletek vagy forgatókönyvek az
    architekturális nézetek jelöléseivel

**Struktúra**

Válassza ki **csak** a rendszer számára leginkább szükséges témákat, és
rendeljen hozzájuk egy 2. szintű címsort ebben a fejezetben (pl. 8.1,
8.2 stb).

NE PRÓBÁLJA meg lefedni a fent említett diagram összes témáját.

**További információ**

Egyes témák a rendszerekben gyakran több építőelemet, hardverelemet vagy
fejlesztési folyamatot érintenek. Könnyebb lehet az ilyen
*keresztmetszeti* témákat egy központi helyen kommunikálni vagy
dokumentálni, ahelyett hogy megismételnénk őket az érintett építőelemek,
hardverelemek vagy fejlesztési folyamatok leírásában.

Bizonyos koncepciók **minden** elemre vonatkozhatnak, mások csak
néhányra lehetnek relevánsak. A fenti ábrán a naplózás mindhárom
komponenst érinti, míg a biztonság csak két komponens számára releváns.

Lásd [Koncepciók](https://docs.arc42.org/section-8/) az arc42
dokumentációban.

## *&lt;1. koncepció&gt;*

*&lt;magyarázat&gt;*

## *&lt;2. koncepció&gt;*

*&lt;magyarázat&gt;*

…​

## *&lt;n. koncepció&gt;*

*&lt;magyarázat&gt;*

# Architektúra-döntések

**Tartalom**

Fontos, költséges, nagy léptékű vagy kockázatos architekturális
döntések, beleértve az indoklásokat. A „döntések” alatt egy alternatíva
kiválasztását értjük adott kritériumok alapján.

Kérjük, használja a saját megítélését annak eldöntéséhez, hogy egy
architekturális döntést itt, ebben a központi fejezetben kell-e
dokumentálni, vagy inkább lokálisan (pl. egy építőelem fehér doboz
sablonján belül).

Kerülje a redundanciát. Hivatkozzon a 4. fejezetre, ahol már rögzítette
az architektúra legfontosabb döntéseit.

**Motiváció**

Rendszere érdekelt feleinek képesnek kell lenniük megérteni és nyomon
követni az Ön döntéseit.

**Forma**

Különböző lehetőségek:

-   ADR ([Architektúra-döntések
    dokumentálása](https://cognitect.com/blog/2011/11/15/documenting-architecture-decisions))
    minden fontos döntéshez

-   Lista vagy táblázat, fontosság és következmények szerint rendezve,
    vagy:

-   részletesebben, döntésenként külön fejezetben

**További információ**

Lásd [Architektúra-döntések](https://docs.arc42.org/section-9/) az arc42
dokumentációban. Ott hivatkozásokat és példákat talál az ADR-ekről.

# Minőségi követelmények

**Tartalom**

Ez a fejezet tartalmazza az összes releváns minőségi követelményt.

Ezek közül a legfontosabbak már az 1.2. fejezetben (minőségi célok) le
lettek írva, ezért itt csak hivatkozni kell rájuk. Ebben a 10.
fejezetben rögzítse azokat a minőségi követelményeket is, amelyek kisebb
jelentőségűek, és amelyek nem teljesülése nem jelent nagy kockázatot (de
lehetnek *kívánatos, nem kötelező* elemek).

**Motiváció**

Mivel a minőségi követelmények nagymértékben befolyásolják az
architekturális döntéseket, tudnia kell, milyen minőségi jellemzők
igazán fontosak az érdekelt felek számára, konkrét és mérhető módon.

-   Lásd [Minőségi követelmények](https://docs.arc42.org/section-10/) az
    arc42 dokumentációban.

-   Lásd a részletes [Q42 minőségi modellt a https://quality.arc42.org
    oldalon](https://quality.arc42.org).

## Minőségi követelmények áttekintése

**Tartalom**

A minőségi követelmények áttekintése vagy összefoglalása.

**Motiváció**

Gyakran találkozunk tucatnyi (vagy akár százas nagyságrendű) részletes
minőségi követelménnyel. Ebben az áttekintő fejezetben próbálja meg
összefoglalni őket, pl. kategóriák vagy témák leírásával (ahogyan az
[ISO
25010:2023](https://www.iso.org/obp/ui/#iso:std:iso-iec:25010:ed-2:v1:en)
vagy a [Q42](https://quality.arc42.org) javasolja).

Ha ezek az összefoglaló leírások már elég pontosak, specifikusak és
mérhetőek, kihagyhatja a 10.2. fejezetet.

**Forma**

Használjon egyszerű táblázatot, amelyben minden sor egy kategóriát vagy
témát és a minőségi követelmény rövid leírását tartalmazza.
Alternatívaként gondolattérképet is használhat a minőségi követelmények
strukturálásához. Az irodalomban a *minőségi attribútum fa* gondolata is
leírásra került, amely a „minőség” általános fogalmát helyezi a
gyökérbe, és a „minőség” fogalmának faszerű finomítását alkalmazza.
\[Bass+21\] erre a célra a „Minőségi attribútum hasznossági fa” (Quality
Attribute Utility Tree) kifejezést vezette be.

## Minőségi forgatókönyvek

**Tartalom**

A minőségi forgatókönyvek konkretizálják a minőségi követelményeket, és
lehetővé teszik annak eldöntését, hogy teljesültek-e (elfogadási
kritériumok értelmében). Győződjön meg róla, hogy a forgatókönyvei
specifikusak és mérhetőek.

Két fajta forgatókönyv különösen hasznos:

-   *Használati forgatókönyvek* (más néven alkalmazási forgatókönyvek
    vagy használati eset forgatókönyvek) írják le a rendszer futásidejű
    reakcióját egy adott ingerre. Ide tartoznak a rendszer hatékonyságát
    vagy teljesítményét leíró forgatókönyvek is. Példa: A rendszer egy
    másodpercen belül reagál a felhasználó kérésére.

-   *Változási forgatókönyvek* írják le a rendszer vagy közvetlen
    környezete módosításának vagy bővítésének kívánt hatását. Példa:
    További funkcionalitás kerül megvalósításra, vagy egy minőségi
    attribútum követelménye megváltozik, és a változtatás ráfordítása
    vagy időtartama mérhető.

**Forma**

A részletes forgatókönyvek jellemző információi a következők:

Rövid formában (a Q42 modell által előnyben részesítve):

-   **Kontextus/Háttér**: Milyen rendszerről vagy komponensről van szó,
    mi a környezet vagy helyzet?

-   **Forrás/Inger**: Ki vagy mi indít el egy viselkedést, reakciót vagy
    cselekvést.

-   **Metrika/Elfogadási kritérium**: Egy válasz *mérőszámmal* vagy
    *metrikával*

A forgatókönyvek hosszú formája (az SEI és \[Bass+21\] által előnyben
részesítve) részletesebb, és a következő információkat tartalmazza:

-   **Forgatókönyv-azonosító**: A forgatókönyv egyedi azonosítója.

-   **Forgatókönyv neve**: A forgatókönyv rövid, leíró neve.

-   **Forrás**: A forgatókönyvet kezdeményező entitás (felhasználó,
    rendszer vagy esemény).

-   **Inger**: A kiváltó esemény vagy feltétel, amelyet a rendszernek
    kezelnie kell.

-   **Környezet**: Az az üzemeltetési kontextus vagy feltétel, amelyben
    a rendszer az ingert tapasztalja.

-   **Artefaktum**: Az inger által érintett építőelemek vagy a rendszer
    egyéb elemei.

-   **Válasz**: Az eredmény vagy viselkedés, amelyet a rendszer az
    ingerre adott reakcióként mutat.

-   **Válaszmérték**: A kritérium vagy metrika, amely alapján a rendszer
    válaszát értékelik.

**Példák**

Lásd [a Q42 minőségi modell weboldalt](https://quality.arc42.org) a
minőségi követelmények részletes példáiért.

-   Len Bass, Paul Clements, Rick Kazman: "Software Architecture in
    Practice", 4th Edition, Addison-Wesley, 2021.

# Kockázatok és technikai adósságok

**Tartalom**

Az azonosított technikai kockázatok vagy technikai adósságok listája,
prioritás szerint rendezve.

**Motiváció**

„A kockázatkezelés felnőttek projektmenedzsmentje” (Tim Lister, Atlantic
Systems Guild.)

Ez legyen az irányelv a kockázatok és technikai adósságok szisztematikus
felderítéséhez és értékeléséhez az architektúrában, amelyre a vezetői
szintű érdekelt feleknek (pl. projektvezetők, terméktulajdonosok)
szükségük van az átfogó kockázatelemzés és méréstervezés részeként.

**Forma**

Kockázatok és/vagy technikai adósságok listája, valószínűleg javasolt
intézkedésekkel a kockázatok minimalizálására, mérséklésére vagy
elkerülésére, illetve a technikai adósságok csökkentésére.

**További információ**

Lásd [Kockázatok és technikai
adósság](https://docs.arc42.org/section-11/) az arc42 dokumentációban.

# Szójegyzék

**Tartalom**

A legfontosabb szakterületi és technikai kifejezések, amelyeket az
érdekelt felek a rendszer megvitatásakor használnak.

A szójegyzék fordítási forrásként is szolgálhat, ha többnyelvű
csapatokban dolgozik.

**Motiváció**

Egyértelműen meg kell határoznia a kifejezéseket, hogy minden érdekelt
fél

-   azonos módon értse ezeket a kifejezéseket

-   ne használjon szinonimákat és homonimákat

**Forma**

Táblázat &lt;Kifejezés&gt; és &lt;Meghatározás&gt; oszlopokkal.

Szükség esetén további oszlopok fordításokhoz.

**További információ**

Lásd [Szójegyzék](https://docs.arc42.org/section-12/) az arc42
dokumentációban.

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Kifejezés</th>
<th style="text-align: left;">Meghatározás</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Kifejezés-1&gt;</em></p></td>
<td
style="text-align: left;"><p><em>&lt;meghatározás-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Kifejezés-2&gt;</em></p></td>
<td
style="text-align: left;"><p><em>&lt;meghatározás-2&gt;</em></p></td>
</tr>
</tbody>
</table>
