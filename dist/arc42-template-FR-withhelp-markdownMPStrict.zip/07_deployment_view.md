# Vue Déploiement

## Infrastructure Niveau 1

***&lt;Schéma d’ensemble&gt;***

Motivation  
*&lt;explication sous forme de texte&gt;*

Caractéristiques de qualité et/ou de performance  
*&lt;explication sous forme de texte&gt;*

Correspondance des briques vis à vis de l’infrastructure  
*&lt;description de la correspondance&gt;*

## Infrastructure Niveau 2

### *&lt;Infrastructure Element 1&gt;*

*&lt;schéma + explication&gt;*

### *&lt;Infrastructure Element 2&gt;*

*&lt;schéma + explication&gt;*

…​

### *&lt;Infrastructure Element n&gt;*

*&lt;schéma + explication&gt;*
