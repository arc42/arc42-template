# Vue Exécution

## &lt;Scénario d’exécution 1&gt;

- *&lt;insérer un diagramme d’exécution ou une description textuelle du
  scénario&gt;*

- *&lt;insérer une description des aspects notables des interactions
  entre les instances des briques représentées dans ce diagramme.&gt;*

## &lt;Scénario d’exécution 2&gt;

## …​

## &lt;Scénario d’exécution n&gt;
