# Vue en Briques

## Niveau 1 : Système global Boîte blanche

***&lt;Schéma d’ensemble&gt;***

Motivation  
*&lt;texte explicatif&gt;*

Briques contenues  
*&lt;Description de la brique contenue (boîte noire)&gt;*

Interfaces Importantes  
*&lt;Description des interfaces importantes&gt;*

### &lt;Nom boîte noire 1&gt;

*&lt;Objectif/Responsabilité&gt;*

*&lt;Interface(s)&gt;*

*&lt;(Facultatif) Caractéristiques de qualité/performance&gt;*

*&lt;(Facultatif) Emplacement du répertoire/fichier&gt;*

*&lt;(Facultatif) Exigences respectées&gt;*

*&lt;(Facultatif) Questions ouvertes/problèmes/risques&gt;*

### &lt;Nom boîte noire 2&gt;

*&lt;template boîte noire&gt;*

### &lt;Nom boîte noire n&gt;

*&lt;template boîte noire&gt;*

### &lt;Nom interface 1&gt;

…​

### &lt;Nom interface m&gt;

## Niveau 2

### Boîte blanche *&lt;brique 1&gt;*

*&lt;template boîte blanche&gt;*

### Boîte blanche *&lt;brique 2&gt;*

*&lt;template boîte blanche&gt;*

…​

### Boîte blanche *&lt;brique n&gt;*

*&lt;template boîte blanche&gt;*
