# Concepts transversaux

## *&lt;Concept 1&gt;*

*&lt;explication&gt;*

## *&lt;Concept 2&gt;*

*&lt;explication&gt;*

…​

## *&lt;Concept n&gt;*

*&lt;explication&gt;*
