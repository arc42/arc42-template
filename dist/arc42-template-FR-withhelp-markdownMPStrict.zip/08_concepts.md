# Concepts transversaux

## *&lt;Concept 1>*

*&lt;explication>*

## *&lt;Concept 2>*

*&lt;explication>*

…

## *&lt;Concept n>*

*&lt;explication>*
