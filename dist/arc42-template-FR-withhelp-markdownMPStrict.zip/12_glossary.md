# Glossaire

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Terme</th>
<th style="text-align: left;">Définition</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Terme-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Définition-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Terme-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Définition-2&gt;</em></p></td>
</tr>
</tbody>
</table>
