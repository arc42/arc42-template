# Glossaire

**Contenu**

Les termes techniques et métier les plus importants que vos parties
prenantes utilisent lorsqu’elles discutent du système.

Le glossaire peut également servir de source pour les traductions si
vous travaillez dans des équipes multilingues.

**Motivation**

Vous devez définir clairement vos termes, de manière à ce que toutes les
parties prenantes

-   aient une compréhension identique de ces termes

-   n’utilisent pas de synonymes et d’homonymes

Un tableau avec les colonnes &lt;Terme> et &lt;Définition>.

Potentiellement plus de colonnes au cas où vous auriez besoin de
traductions.

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Terme</th>
<th style="text-align: left;">Définition</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Terme-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Définition-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Terme-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Définition-2&gt;</em></p></td>
</tr>
</tbody>
</table>

Voir [Glossary](https://docs.arc42.org/section-12/) dans la
documentation arc42.

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Terme</th>
<th style="text-align: left;">Définition</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Terme-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Définition-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Terme-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Définition-2&gt;</em></p></td>
</tr>
</tbody>
</table>
