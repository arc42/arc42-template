# Introduction et Objectifs

## Aperçu des spécifications

## Objectifs de Qualité

## Parties prenantes

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">Rôle/Nom</th>
<th style="text-align: left;">Contact</th>
<th style="text-align: left;">Attentes</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p><em>&lt;Role-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Contact-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Attente-1&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"><p><em>&lt;Role-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Contact-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Attente-2&gt;</em></p></td>
</tr>
</tbody>
</table>
