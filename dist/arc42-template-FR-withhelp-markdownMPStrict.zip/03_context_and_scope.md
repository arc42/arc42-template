# Contexte et périmètre

## Contexte métier

**&lt;Schéma ou tableau>**

**&lt;éventuellement : Explication des interfaces de domaines
externes>**

## Contexte Technique

**&lt;Schéma ou tableau>**

**&lt;en option : Explication des interfaces techniques>**

**&lt;Correspondance des entrées/sorties aux canaux>**
