# Contexte et périmètre

## Contexte métier

**&lt;Schéma ou tableau&gt;**

**&lt;éventuellement : Explication des interfaces de domaines
externes&gt;**

## Contexte Technique

**&lt;Schéma ou tableau&gt;**

**&lt;en option : Explication des interfaces techniques&gt;**

**&lt;Correspondance des entrées/sorties aux canaux&gt;**
