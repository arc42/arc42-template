# Stratégie de solution

Contenu

Un bref résumé et une explication des décisions fondamentales et des
stratégies de solution qui façonnent l’architecture du système. Il
comprend

- les décisions technologiques

- les décisions relatives à la décomposition du système au niveau le
  plus élevé, par exemple l’utilisation d’un modèle architectural ou
  d’un modèle de conception

- les décisions sur la manière d’atteindre les principaux objectifs de
  qualité

- les décisions organisationnelles pertinentes, par exemple la sélection
  d’un processus de développement ou la délégation de certaines tâches à
  des tierces personnes.

Motivation

Ces décisions constituent les pierres angulaires de votre architecture.
Elles constituent le fondement de nombreuses autres décisions détaillées
ou règles de mise en œuvre.

Représentation

Les explications relatives à ces décisions clés doivent être brèves.

Motiver ce qui a été décidé et pourquoi cela a été décidé de cette
manière, sur la base de l’énoncé du problème, des objectifs de qualité
et des principales contraintes.

Pour documenter la manière d’atteindre les principaux objectifs de
qualité, vous pouvez utiliser le tableau suivant :

<table>
<colgroup>
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">Objectif de qualité</th>
<th style="text-align: left;">Scénario</th>
<th style="text-align: left;">Approche de la solution</th>
<th style="text-align: left;">Lien vers les détails</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p><em>&lt;Objectif-Q1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Scénario-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Solution-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Lien-1&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"><p><em>&lt;Objectif-Q2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Scénario-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Solution-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Lien-2&gt;</em></p></td>
</tr>
</tbody>
</table>

Informations supplémentaires

Voir [Solution Strategy](https://docs.arc42.org/section-4/) dans la
documentation arc42.
