# Introduction et Objectifs {#section-introduction-and-goals}

:::: sidebar
::: title
:::

Décrit les specifications importantes et les facteurs déterminants que
les architectes logiciels et l'équipe de développement doivent prendre
en compte. Il s'agit notamment

- des objectifs métier sous-jacents,

- des caractéristiques essentielles,

- des spécifications fonctionnelles essentielles,

- des objectifs de qualité pour l'architecture et

- des parties prenantes concernées et leurs attentes
::::

## Aperçu des spécifications {#_aperçu_des_spécifications}

:::::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Contenu
:::

Brève description des spécifications fonctionnelles, des facteurs
déterminants, de l'extrait (ou du résumé) des spécifications. Liens vers
(en espérant qu'ils existent) les documents décrivant les spécifications
(avec le numéro de version et des informations sur l'endroit où les
trouver).
::::

:::: formalpara
::: title
Motivation
:::

Du point de vue des utilisateurs, un système est créé ou modifié pour
améliorer le soutien d'une activité métier et/ou améliorer la qualité.
::::

:::: formalpara
::: title
Représentation
:::

Brève description textuelle, probablement sous forme de tableau de cas
d'utilisation. S'il existe des documents décrivant les spécifications,
cet aperçu général doit s'y référer.
::::

Ces extraits doivent être aussi courts que possible. Trouver un
équilibre entre la lisibilité de ce document et la redondance
potentielle par rapport aux documents décrivant les spécifications.

:::: formalpara
::: title
Informations supplémentaires
:::

Voir [Introduction and Goals](https://docs.arc42.org/section-1/) dans la
documentation arc42.
::::
::::::::::::

## Objectifs de Qualité {#_objectifs_de_qualité}

:::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Contenu
:::

Les trois (maximum cinq) principaux objectifs de qualité pour
l'architecture dont la réalisation est de la plus haute importance pour
les principaux acteurs. Nous parlons bien d'objectifs de qualité pour
l'architecture. Ne les confondez pas avec les objectifs du projet. Ils
ne sont pas nécessairement identiques.
::::

Voici un aperçu des sujets potentiels (basé sur la norme ISO 25010) :

![Catégories d'exigences de
Qualité](images/01_2_iso-25010-topics-EN-2023.drawio.png)

:::: formalpara
::: title
Motivation
:::

Vous devez connaître les objectifs de qualité de vos principales parties
prenantes, car ils influenceront les décisions architecturales
fondamentales. Veillez à être très concret sur ces qualités, évitez les
mots à la mode. En tant qu'architecte, vous ne savez pas comment la
qualité de votre travail sera jugée...​
::::

:::: formalpara
::: title
Représentation
:::

Un tableau avec des objectifs de qualité et des scénarios concrets,
classés par ordre de priorité
::::
::::::::::

## Parties prenantes {#_parties_prenantes}

:::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Contenu
:::

Aperçu explicite des parties prenantes du système, c'est-à-dire toute
personne, rôle ou organisation qui
::::

- doit connaître l'architecture

- doit être convaincue de l'architecture

- doit travailler avec l'architecture ou avec le code

- a besoin de la documentation d'architecture pour son travail

- doit prendre des décisions concernant le système ou son développement

:::: formalpara
::: title
Motivation
:::

Vous devez connaître toutes les parties impliquées dans le développement
du système ou concernées par celui-ci. Sinon, vous risquez d'avoir de
mauvaises surprises plus tard dans le processus de développement. Ces
parties prenantes déterminent l'étendue et le niveau de détail de votre
travail et de ses résultats.
::::

:::: formalpara
::: title
Représentation
:::

Tableau avec les noms des rôles, les noms des personnes et leurs
attentes par rapport à l'architecture et à sa documentation.
::::
::::::::::

+--------------+---------------------------+---------------------------+
| Rôle/Nom     | Contact                   | Attentes                  |
+==============+===========================+===========================+
| *\<Role-1\>* | *\<Contact-1\>*           | *\<Attente-1\>*           |
+--------------+---------------------------+---------------------------+
| *\<Role-2\>* | *\<Contact-2\>*           | *\<Attente-2\>*           |
+--------------+---------------------------+---------------------------+
