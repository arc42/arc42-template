# Concepts transversaux {#section-concepts}

:::::::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Contenu
:::

Cette section décrit les réglementations générales, principales et les
idées de solutions qui sont importantes dans plusieurs parties (=
transversales) de votre système. Ces concepts sont souvent liés à
plusieurs briques. Ils peuvent inclure de nombreux sujets différents,
tels que
::::

- les modèles, particulièrement les modèles de domaine

- les modèles d'architecture ou de conception

- règles d'utilisation d'une technologie spécifique

- les décisions principales, souvent techniques, de nature globale (=
  transversale)

- règles de mise en œuvre

:::: formalpara
::: title
Motivation
:::

Les concepts constituent la base de l\'*intégrité conceptuelle*
(cohérence, homogénéité) de l'architecture. Ils constituent donc une
contribution importante à l'obtention des qualités internes de votre
système.
::::

Certains de ces concepts ne peuvent pas être attribués à des briques
individuelles, par exemple la sécurité ou la fiabilité.

:::: formalpara
::: title
Représentation
:::

La représentation peut être variée :
::::

- des documents conceptuels avec n'importe quel type de structure

- des extraits de modèles transverses ou des scénarios utilisant les
  notations des vues de l'architecture

- des exemples de mise en œuvre, en particulier pour les concepts
  techniques

- référence à l'utilisation typique de frameworks standard (par exemple,
  l'utilisation d'Hibernate pour le mappage objet/relationnel)

:::: formalpara
::: title
Structure
:::

Une structure potentielle (mais non obligatoire) pour cette section
pourrait être la suivante :
::::

- Concepts de domaine

- Concepts d'expérience utilisateur (UX)

- Concepts de fiabilité et de sécurité

- Architecture et modèles de conception

- \"Sous le capot\"

- Concepts de développement

- Concepts opérationnels

Remarque : il peut être difficile d'affecter des concepts individuels à
un thème spécifique de cette liste.

![Thèmes possibles pour les concepts
transversaux](images/08-concepts-EN.drawio.png)

:::: formalpara
::: title
Plus d'informations
:::

Voir [Concepts](https://docs.arc42.org/section-8/) dans la documentation
arc42.
::::
::::::::::::::

## *\<Concept 1\>* {#_concept_1}

*\<explication\>*

## *\<Concept 2\>* {#_concept_2}

*\<explication\>*

...​

## *\<Concept n\>* {#_concept_n}

*\<explication\>*
