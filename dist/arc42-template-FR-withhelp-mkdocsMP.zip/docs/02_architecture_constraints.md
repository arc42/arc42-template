# Contraintes d’Architecture {#section-architecture-constraints}

  [Contraintes d’Architecture]: #section-architecture-constraints {#toc-section-architecture-constraints}
