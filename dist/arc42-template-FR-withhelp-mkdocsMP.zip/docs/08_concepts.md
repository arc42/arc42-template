# Concepts transversaux {#section-concepts}

## *&lt;Concept 1&gt;* {#_concept_1}

*&lt;explication&gt;*

## *&lt;Concept 2&gt;* {#_concept_2}

*&lt;explication&gt;*

…​

## *&lt;Concept n&gt;* {#_concept_n}

*&lt;explication&gt;*

  [Concepts transversaux]: #section-concepts {#toc-section-concepts}
  [*&lt;Concept 1&gt;*]: #_concept_1 {#toc-_concept_1}
  [*&lt;Concept 2&gt;*]: #_concept_2 {#toc-_concept_2}
  [*&lt;Concept n&gt;*]: #_concept_n {#toc-_concept_n}
