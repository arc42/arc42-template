# Contexte et périmètre {#section-context-and-scope}

## Contexte métier {#_contexte_métier}

**&lt;Schéma ou tableau&gt;**

**&lt;éventuellement : Explication des interfaces de domaines externes&gt;**

## Contexte Technique {#_contexte_technique}

**&lt;Schéma ou tableau&gt;**

**&lt;en option : Explication des interfaces techniques&gt;**

**&lt;Correspondance des entrées/sorties aux canaux&gt;**

  [Contexte et périmètre]: #section-context-and-scope {#toc-section-context-and-scope}
  [Contexte métier]: #_contexte_métier {#toc-_contexte_métier}
  [Contexte Technique]: #_contexte_technique {#toc-_contexte_technique}
