# Vue Exécution {#section-runtime-view}

## &lt;Scénario d’exécution 1&gt; {#_scénario_dexécution_1}

- *&lt;insérer un diagramme d’exécution ou une description textuelle du scénario&gt;*

- *&lt;insérer une description des aspects notables des interactions entre les instances des briques représentées dans ce diagramme.&gt;*

## &lt;Scénario d’exécution 2&gt; {#_scénario_dexécution_2}

## …​

## &lt;Scénario d’exécution n&gt; {#_scénario_dexécution_n}

  [Vue Exécution]: #section-runtime-view {#toc-section-runtime-view}
  [&lt;Scénario d’exécution 1&gt;]: #_scénario_dexécution_1 {#toc-_scénario_dexécution_1}
  [&lt;Scénario d’exécution 2&gt;]: #_scénario_dexécution_2 {#toc-_scénario_dexécution_2}
  [&lt;Scénario d’exécution n&gt;]: #_scénario_dexécution_n {#toc-_scénario_dexécution_n}
