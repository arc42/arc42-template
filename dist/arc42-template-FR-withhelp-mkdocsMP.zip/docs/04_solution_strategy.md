# Stratégie de solution {#section-solution-strategy}

  [Stratégie de solution]: #section-solution-strategy {#toc-section-solution-strategy}
