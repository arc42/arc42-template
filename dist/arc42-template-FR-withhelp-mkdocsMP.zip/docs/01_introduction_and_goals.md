# Introduction et Objectifs {#section-introduction-and-goals}

## Aperçu des spécifications {#_aperçu_des_spécifications}

## Objectifs de Qualité {#_objectifs_de_qualité}

## Parties prenantes {#_parties_prenantes}

| Rôle/Nom         | Contact             | Attentes            |
|------------------|---------------------|---------------------|
| *&lt;Role-1&gt;* | *&lt;Contact-1&gt;* | *&lt;Attente-1&gt;* |
| *&lt;Role-2&gt;* | *&lt;Contact-2&gt;* | *&lt;Attente-2&gt;* |

  [Introduction et Objectifs]: #section-introduction-and-goals {#toc-section-introduction-and-goals}
  [Aperçu des spécifications]: #_aperçu_des_spécifications {#toc-_aperçu_des_spécifications}
  [Objectifs de Qualité]: #_objectifs_de_qualité {#toc-_objectifs_de_qualité}
  [Parties prenantes]: #_parties_prenantes {#toc-_parties_prenantes}
