# Vue Déploiement {#section-deployment-view}

## Infrastructure Niveau 1 {#_infrastructure_niveau_1}

***&lt;Schéma d’ensemble&gt;***

Motivation

:   *&lt;explication sous forme de texte&gt;*

Caractéristiques de qualité et/ou de performance

:   *&lt;explication sous forme de texte&gt;*

Correspondance des briques vis à vis de l’infrastructure

:   *&lt;description de la correspondance&gt;*

## Infrastructure Niveau 2 {#_infrastructure_niveau_2}

### *&lt;Infrastructure Element 1&gt;* {#_infrastructure_element_1}

*&lt;schéma + explication&gt;*

### *&lt;Infrastructure Element 2&gt;* {#_infrastructure_element_2}

*&lt;schéma + explication&gt;*

…​

### *&lt;Infrastructure Element n&gt;* {#_infrastructure_element_n}

*&lt;schéma + explication&gt;*

  [Vue Déploiement]: #section-deployment-view {#toc-section-deployment-view}
  [Infrastructure Niveau 1]: #_infrastructure_niveau_1 {#toc-_infrastructure_niveau_1}
  [Infrastructure Niveau 2]: #_infrastructure_niveau_2 {#toc-_infrastructure_niveau_2}
  [*&lt;Infrastructure Element 1&gt;*]: #_infrastructure_element_1 {#toc-_infrastructure_element_1}
  [*&lt;Infrastructure Element 2&gt;*]: #_infrastructure_element_2 {#toc-_infrastructure_element_2}
  [*&lt;Infrastructure Element n&gt;*]: #_infrastructure_element_n {#toc-_infrastructure_element_n}
