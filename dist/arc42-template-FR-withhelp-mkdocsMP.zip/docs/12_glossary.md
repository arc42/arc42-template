# Glossaire {#section-glossary}

| Terme             | Définition             |
|-------------------|------------------------|
| *&lt;Terme-1&gt;* | *&lt;Définition-1&gt;* |
| *&lt;Terme-2&gt;* | *&lt;Définition-2&gt;* |

  [Glossaire]: #section-glossary {#toc-section-glossary}
