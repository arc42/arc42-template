# Stratégie de solution {#section-solution-strategy}

:::::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Contenu
:::

Un bref résumé et une explication des décisions fondamentales et des
stratégies de solution qui façonnent l'architecture du système. Il
comprend
::::

- les décisions technologiques

- les décisions relatives à la décomposition du système au niveau le
  plus élevé, par exemple l'utilisation d'un modèle architectural ou
  d'un modèle de conception

- les décisions sur la manière d'atteindre les principaux objectifs de
  qualité

- les décisions organisationnelles pertinentes, par exemple la sélection
  d'un processus de développement ou la délégation de certaines tâches à
  des tierces personnes.

:::: formalpara
::: title
Motivation
:::

Ces décisions constituent les pierres angulaires de votre architecture.
Elles constituent le fondement de nombreuses autres décisions détaillées
ou règles de mise en œuvre.
::::

:::: formalpara
::: title
Représentation
:::

Les explications relatives à ces décisions clés doivent être brèves.
::::

Motiver ce qui a été décidé et pourquoi cela a été décidé de cette
manière, sur la base de l'énoncé du problème, des objectifs de qualité
et des principales contraintes.

Pour documenter la manière d'atteindre les principaux objectifs de
qualité, vous pouvez utiliser le tableau suivant :

+-------------------+------------------+------------------+-----------------+
| Objectif de       | Scénario         | Approche de la   | Lien vers les   |
| qualité           |                  | solution         | détails         |
+===================+==================+==================+=================+
| *\<Objectif-Q1\>* | *\<Scénario-1\>* | *\<Solution-1\>* | *\<Lien-1\>*    |
+-------------------+------------------+------------------+-----------------+
| *\<Objectif-Q2\>* | *\<Scénario-2\>* | *\<Solution-2\>* | *\<Lien-2\>*    |
+-------------------+------------------+------------------+-----------------+

:::: formalpara
::: title
Informations supplémentaires
:::

Voir [Solution Strategy](https://docs.arc42.org/section-4/) dans la
documentation arc42.
::::
::::::::::::
