================
|arc42| Template
================

:Date: Leden 2025

**O arc42**

arc42, šablona pro dokumentaci softwaru a architekturu systému.

Verze šablony 9.0-CZ. (na základě AsciiDoc verze), Leden 2025

Created, maintained and © by Dr. Peter Hruschka, Dr. Gernot Starke and
contributors. Viz https://arc42.org.

.. container:: informalexample

   Tato verze arc42 šablony obsahuje nápovědu a vysvětlivky a slouží
   proto k seznámení s arc42 a pochopení pojmů. Pro dokumentaci vašeho
   vlastního systému použijte raději *plain* verzi.

.. _section-introduction-and-goals:

Úvod a cíle
===========

Shrnuje klíčové požadavky a omezení, se kterými musí softwaroví
architekti i vývojový tým počítat. Patří sem zejména:

-  hlavní obchodní cíle,

-  základní vlastnosti systému,

-  funkční požadavky,

-  kvalitativní cíle architektury,

-  zainteresované strany systému (stakeholder) a jejich potřeby.

.. _`_přehled_požadavků`:

Přehled požadavků
-----------------

.. container:: formalpara-title

   **Obsah**

Stručný popis (shrnutí či abstrakt) funkčních i kvalitativních
požadavků. Odkaz na (doufejme existující) dokumentaci požadavků (s
číslem verze a informacemi, kde ji najít).

.. container:: formalpara-title

   **Motivace**

Z hlediska koncových uživatelů je cílem vývoje nebo změny systému
zlepšení jeho funkcí k plnění obchodních cílů a/nebo zlepšení jeho
kvality.

.. container:: formalpara-title

   **Forma**

Stručný popis, pravděpodobně ve formátu tabulkového přehledu funkcí
(use-case). Pokud existují dokumenty požadavků, měl by na ně tento
přehled odkazovat.

Udržujte tento popis co nejkratší (z hlediska čitelnosti), ale tak aby
nebyly zbytečně opakovány informace z dokumentace požadavků.

.. container:: formalpara-title

   **Další informace**

Anglická dokumentace arc42: `Introduction and
Goals <https://docs.arc42.org/section-1/>`__.

.. _`_kvalitativní_cíle`:

Kvalitativní cíle
-----------------

.. container:: formalpara-title

   **Obsah**

Tři (maximálně pět) nejdůležitějších kvalitativních cílů pro
architekturu, jejichž splnění je pro hlavní zainteresované strany
nejdůležitější. Jedná se skutečně o kvalitativní cíle pro architekturu.
Nepleťte si je s cíli projektu, ty nemusí být nutně totožné.

Norma ISO 25010 poskytuje přehled jednotlivých oblastí:

.. figure:: images/01_2_iso-25010-topics-EN-2023.drawio.png
   :alt: Kategorie kvalitativních cílů

.. container:: formalpara-title

   **Motivace**

Je vhodné znát kvalitativní cíle klíčových zainteresovaných stran
systému, protože ty ovlivní zásadní architektonická rozhodnutí. Ujistěte
se, že jsou tyto požadavky na systém jednoznačné či měřitelné, vyvarujte
se vágních formulací.

.. container:: formalpara-title

   **Forma**

Tabulka s nejdůležitějšími kvalitativními cíli a praktickými scénáři,
seřazená podle priorit.

.. _`_strany_zainteresované_na_systému_stakeholder`:

Strany zainteresované na systému (stakeholder)
----------------------------------------------

.. container:: formalpara-title

   **Obsah**

Jasný přehled všech stran zainteresovaných na systému, tedy všech osob,
rolí nebo organizací, které

-  by měli architekturu znát,

-  by měli s architekturou souhlasit,

-  budou s architekturou nebo s kódem pracovat,

-  ke své práci potřebují dokumentaci architektury,

-  rozhodují o vývoji a designu systému.

.. container:: formalpara-title

   **Motivace**

Je vhodné znát všechny strany zapojené do vývoje systému (nebo systémem
ovlivněné). Jinak se může stát, že se později v procesu vývoje objeví
nepříjemná překvapení. Zainteresované strany ovlivňují rozsah a úroveň
detailu vaší práce a jejích výsledků.

.. container:: formalpara-title

   **Forma**

Tabulka s názvy rolí, jmény osob a jejich očekáváním na architekturu a
její dokumentaci.

+-------------+---------------------------+---------------------------+
| Role/Jméno  | Kontakt                   | Očekávání                 |
+=============+===========================+===========================+
| *<Role-1>*  | *<Kontakt-1>*             | *<Očekávání-1>*           |
+-------------+---------------------------+---------------------------+
| *<Role-2>*  | *<Kontakt-2>*             | *<Očekávání-2>*           |
+-------------+---------------------------+---------------------------+

.. _section-architecture-constraints:

Omezení na realizaci systému
============================

.. container:: formalpara-title

   **Obsah**

Jakýkoli požadavek, který software-architektům omezuje prostor pro
rozhodování o návrhu a implementaci nebo pro rozhodování o procesu
vývoje. Tato omezení někdy přesahují jednotlivé systémy a platí pro celé
organizace a společnosti.

.. container:: formalpara-title

   **Motivace**

Softwarový Architekt by měl přesně vědět, které části systému může
určovat a kde musí dodržovat vnější omezení. S omezeními je třeba se
vždy vypořádat; mohou být ale předmětem vyjednávaní.

.. container:: formalpara-title

   **Forma**

Tabulka se (všemi) omezeními, včetně jejich vysvětlení. V případě
potřeby rozdělená na technická, organizační nebo politická omezení či
konvence (například co se týče programovaní, verzí systému, dokumentace
nebo pojmenování)

.. container:: formalpara-title

   **Další informace**

Anglická dokumentace arc42: `Architecture
Constraints <https://docs.arc42.org/section-2/>`__.

.. _section-context-and-scope:

Vymezení a rozsah systému
=========================

.. container:: formalpara-title

   **Obsah**

Rozsah a kontext systému vymezují – jak název napovídá – systém od všech
jeho komunikačních partnerů (sousední systémy a uživatelé). Tím se
specifikují externí rozhraní (interface) systému a určí zodpovědnost:
Které funkce patří do našeho systému a které do systémů sousedních.

V případě potřeby odlište firemní kontext (doménově specifické vstupy a
výstupy) od technického kontextu (kanály, protokoly, hardware).

.. container:: formalpara-title

   **Motivace**

Doménová a technická komunikační rozhraní patří mezi nejdůležitější
aspekty systému. Ujistěte se, že jim zcela rozumíte.

.. container:: formalpara-title

   **Forma**

Různé možnosti:

-  Kontextové diagramy

-  Seznam komunikačních partnerů a příslušné rozhraní

.. container:: formalpara-title

   **Další informace**

Anglická dokumentace arc42: `Context and
Scope <https://docs.arc42.org/section-3/>`__.

.. _`_firemní_kontext`:

Firemní kontext
---------------

.. container:: formalpara-title

   **Obsah**

Specifikace **všech** komunikačních partnerů systému (uživatelů, IT
systémů, …) s vysvětlením doménově specifických vstupů a výstupů nebo
rozhraní. Podle potřeby můžete přidat doménově specifické datové formáty
nebo komunikační protokoly.

.. container:: formalpara-title

   **Motivace**

Všechny zainteresované strany by měly rozumět tomu, jaké doménové
informace si systém vyměňuje s okolím.

.. container:: formalpara-title

   **Forma**

Různé druhy diagramů, které ukazují systém jako černou skříňku (black
box) a popisují doménová rozhraní pro komunikaci s partnery.

Alternativně (nebo jako doplnění) můžete použít tabulku. Titulek tabulky
je název systému, tři sloupce obsahují: jméno komunikačního partnera,
vstupy a výstupy.

**<vložte diagram nebo tabulku>**

**<(volitelně:) vložte vysvětlení externích doménových rozhraní>**

.. _`_technický_kontext`:

Technický kontext
-----------------

.. container:: formalpara-title

   **Obsah**

Technická rozhraní (kanály a přenosová média) propojující váš systém s
jeho okolím. Navíc mapování doménově specifického vstupu/výstupu na tyto
kanály, tj. vysvětlení, která doménová data používají který kanál.

.. container:: formalpara-title

   **Motivace**

Mnoho zainteresovaných stran činí architektonická rozhodnutí na základě
technických rozhraní mezi systémem a jeho okolím. Zejména při výběru
infrastruktury nebo hardwaru jsou tato technická rozhraní rozhodující.

.. container:: formalpara-title

   **Forma**

Např. UML Diagram popisující technické napojení sousedních systémů spolu
s tabulkou ukazující vztahy mezi technickými kanály a doménovým
vstupem/výstupem.

**<vložte diagram nebo tabulku>**

**<(volitelně:) vložte vysvětlení externích technických rozhraní>**

**<mapování doménových vstupu/výstupu na technické kanály>**

.. _section-solution-strategy:

Strategie řešení
================

.. container:: formalpara-title

   **Obsah**

Krátké shrnutí a vysvětlení zásadních rozhodnutí a strategií řešení,
které utvářejí architekturu systému. Tyto zahrnují

-  technologická rozhodnutí

-  rozhodnutí o dekompozici systému na nejvyšší úrovni (top-level),
   například o použití vzoru (pattern) pro architekturu nebo návrh

-  rozhodnutí o tom, jak dosáhnout klíčových kvalitativních cílů

-  příslušná organizační rozhodnutí, například výběr procesu vývoje nebo
   delegování určitých úkolů na třetí strany.

.. container:: formalpara-title

   **Motivace**

Tato rozhodnutí tvoří pilíře softwarové architektury. Jsou základem pro
mnoho dalších detailních rozhodnutí nebo pravidel implementace.

.. container:: formalpara-title

   **Forma**

Vysvětlení těchto klíčových rozhodnutí ponechte **krátké**.

Popište, jak jste se rozhodli a proč jste se tak rozhodli, s ohledem na
řešení problému, cíle kvality a klíčová omezení. Pro podrobnosti odkažte
na následující části.

.. container:: formalpara-title

   **Další informace**

Anglická dokumentace arc42: `Solution
Strategy <https://docs.arc42.org/section-4/>`__.

.. _section-building-block-view:

Perspektiva stavebních bloků
============================

.. container:: formalpara-title

   **Obsah**

Perspektiva stavebních bloků ukazuje statický rozklad systému na
stavební bloky (moduly, komponenty, subsystémy, třídy, rozhraní,
balíčky, knihovny, framework, oddíly, vrstvy, funkce, makra, operace,
datové struktury, …) stejně jako jejich vzájemné závislosti (vztahy,
asociace, …).

Toto perspektiva je povinná pro každou dokumentaci architektury, stejně
jako je to u domu jeho *půdorys*.

.. container:: formalpara-title

   **Motivace**

Udržujte si přehled o zdrojovém kódu tím, že jeho strukturu učiníte
srozumitelnou prostřednictvím abstrakce.

To vám umožní komunikovat se zainteresovanými stranami na abstraktní
úrovni, aniž byste prozradili podrobnosti o implementaci.

.. container:: formalpara-title

   **Forma**

Perspektiva stavebních bloků je hierarchický přehled "černých" a
"bílých" skříněk (black-box, white-box, viz obrázek níže) a jejich
popisů.

.. figure:: images/05_building_blocks-EN.png
   :alt: Hierarchie stavebních bloků

**Úroveň 1** je popis celého systému jako white-box spolu s popisem
všech obsažených stavebních bloků ve formátu black-box.

**Úroveň 2** přibližuje některé stavební bloky úrovně 1. Obsahuje tedy
popis vybraných stavebních bloků úrovně 1 jako white-box spolu s popisy
jejich vnitřních stavebních bloků jako black-box.

**Úroveň 3** přiblíží vybrané stavební bloky úrovně 2 a tak dále.

.. container:: formalpara-title

   **Další informace**

Anglická dokumentace arc42: `Building Block
View <https://docs.arc42.org/section-5/>`__.

.. _`_celý_systém_jako_white_box`:

Celý systém jako white-box
--------------------------

Zde popisujete rozklad celého systému pomocí následující white-box
šablony. Obsahuje

-  přehledový diagram

-  motivaci k rozkladu

-  popis jednotlivých stavebních bloků jako black-box. K tomu jsou k
   dispozici různé alternativy:

   -  použijte *jednu* tabulku pro krátký a pragmatický přehled všech
      obsažených stavebních bloků a jejich rozhraní.

   -  použijte seznam stavebních bloků popsaných podle black-box šablony
      (viz níže). V závislosti na výběru konkrétního nástroje může tento
      seznam obsahovat podkapitoly (v textových souborech), podstránky
      (ve Wiki) nebo vnořené prvky (v modelovacím nástroji).

-  (Volitelně:) důležitá rozhraní, která nejsou vysvětlena v black-box
   šablonách stavebního bloku, ale jsou velmi důležitá pro pochopení
   popisovaného white-boxu. Protože existuje mnoho způsobů, jak
   specifikovat rozhraní, neposkytujeme žádnou konkrétní šablonu. V
   nejhorším případě musíte specifikovat a popsat syntax, sémantiku,
   protokoly, zpracování chyb, různá omezení, verze, nároky na kvalitu,
   potřebnou kompatibilitu a mnoho dalších věcí. V lepším případě vám
   stačí příklady nebo jednoduché podpisy.

**<vložte přehledový diagram celého systému>**

Motivace
   *<popište motivaci>*

Obsažené stavební bloky
   *<popište obsažené stavební bloky (jako black-box)>*

Důležitá rozhraní
   *<popište důležitá rozhraní>*

Vložte vysvětlení black-boxů z úrovně 1:

Pokud použijete tabulkovou formu, popište black-boxy pouze jménem a
odpovědností podle následujícího schématu:

+----------------------+-----------------------------------------------+
| **Jméno**            | **Odpovědnost**                               |
+======================+===============================================+
| *<black-box 1>*      |  *<Text>*                                     |
+----------------------+-----------------------------------------------+
| *<black-box 2>*      |  *<Text>*                                     |
+----------------------+-----------------------------------------------+

Pokud použijete seznam popisů jednotlivých black-boxů, vyplňte
samostatnou black-box šablonu pro každý důležitý stavební blok. Její
titulek je název black-boxu.

.. _`_jméno_black_boxu_1`:

<Jméno black-boxu 1>
~~~~~~~~~~~~~~~~~~~~

Popište <black-box 1> podle následující black-box šablony:

-  Účel/Odpovědnost

-  Rozhraní, pokud nejsou vyjmuta jako samostatné odstavce. Případně sem
   patří nároky na kvalitu a výkonnostní rozhraní.

-  (Volitelně) Popis požadavků na kvalitu/výkon black-boxu, například
   dostupnost, runtime vlastnosti, ….

-  (Volitelně) Umístění/složky a soubory

-  (Volitelně) Splněné požadavky (pokud potřebujete dohledat vztah k
   požadavkům).

-  (Volitelně) Nevyřešené body/problémy/rizika

*<Účel/Odpovědnost>*

*<Rozhraní>*

*<(Volitelně) Požadavky na kvalitu/výkon>*

*<(Volitelně) Umístění/složky a soubory>*

*<(Volitelně) Splněné požadavky>*

*<(Volitelně) Nevyřešené body/problémy/rizika>*

.. _`_jméno_black_boxu_2`:

<Jméno black-boxu 2>
~~~~~~~~~~~~~~~~~~~~

*<šablona black-box>*

.. _`_jméno_black_boxu_n`:

<Jméno black-boxu n>
~~~~~~~~~~~~~~~~~~~~

*<šablona black-box>*

.. _`_jméno_rozhraní_1`:

<Jméno rozhraní 1>
~~~~~~~~~~~~~~~~~~

…​

.. _`_jméno_rozhraní_m`:

<Jméno rozhraní m>
~~~~~~~~~~~~~~~~~~

.. _`_úroveň_2`:

Úroveň 2
--------

Zde popište vnitřní strukturu (některých) stavebních bloků z úrovně 1
jako white-box.

Musíte rozhodnout, které stavební bloky systému jsou natolik důležité,
aby ospravedlnily tak podrobný popis. Upřednostněte relevanci před
úplností. Uveďte důležité, překvapivé, riskantní, komplexní nebo
volatilní stavební bloky. Vynechejte normální, jednoduché nebo
standardizované části systému.

.. _`_white_box_stavební_blok_1`:

white-box *<stavební blok 1>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

…​popisuje vnitřní strukturu *stavebního bloku 1*.

*<šablona white-box>*

.. _`_white_box_stavební_blok_2`:

white-box *<stavební blok 2>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<šablona white-box>*

…​

.. _`_white_box_stavební_blok_m`:

white-box *<stavební blok m>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<šablona white-box>*

.. _`_úroveň_3`:

Úroveň 3
--------

Zde můžete popsat vnitřní strukturu (některých) stavebních bloků z
úrovně 2 jako white-box.

Pokud potřebujete podrobnější úrovně architektury, zkopírujte si pro ně
tuto část arc42.

.. _`_white_box_stavební_blok_x_1`:

white-box <\_stavební blok x.1\_>
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

…​popisuje vnitřní strukturu *stavebního bloku x.1*.

*<šablona white-box>*

.. _`_white_box_stavební_blok_x_2`:

white-box <\_stavební blok x.2\_>
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<šablona white-box>*

.. _`_white_box_stavební_blok_y_1`:

white-box <\_stavební blok y.1\_>
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<šablona white-box>*

.. _section-runtime-view:

Perspektiva chování za běhu (runtime)
=====================================

.. container:: formalpara-title

   **Obsah**

Perspektiva runtime popisuje konkrétní chování a interakce stavebních
bloků systému ve formě scénářů v následujících oblastech:

-  důležité procesy nebo funkce: jak je stavební bloky systému
   provádějí?

-  interakce na kritických externích rozhraních: jak spolupracují
   stavební bloky s uživateli a sousedními systémy?

-  provoz a administrace: prvotní konfigurace, spuštění, zastavení

-  scénáře pro chyby a výjimky

Poznámka: Hlavním kritériem pro výběr dokumentovaných scénářů (sekvencí,
pracovních postupů) je jejich **význam pro architekturu**. Není cílem
popisovat velké množství scénářů, ale raději **reprezentativní** výběr.

.. container:: formalpara-title

   **Motivace**

Je důležité rozumět tomu, jak stavební bloky systému (nebo jejich
instance) vykonávají svoji práci a jak spolu komunikují za běhu. Ve této
části dokumentace popište především scénáře, kterými architekturu
vysvětlíte těm stranám zainteresovaným na systému, které jsou méně
ochotné nebo schopné číst a chápat statické modely (perspektivu
stavebních bloků, perspektivu nasazení softwaru).

.. container:: formalpara-title

   **Forma**

Existuje mnoho notací pro popis scénářů, například

-  očíslovaný seznam jednotlivých kroků (jako text)

-  diagramy aktivit nebo vývojové diagramy (flow chart)

-  sekvenční diagramy

-  Business Process Model and Notation (BPMN) nebo Event-driven Process
   Chain (EPC)

-  konečné automaty nebo přechodové systémy

-  …​

.. container:: formalpara-title

   **Další informace**

Anglická dokumentace arc42: `Runtime
View <https://docs.arc42.org/section-6/>`__.

.. _`_scénář_runtime_1`:

<Scénář runtime 1>
------------------

-  *<vložte runtime diagram nebo textový popis scénáře>*

-  *<vložte popis důležitých interakcí mezi instancemi stavebních bloků
   zobrazených v tomto diagramu>*

.. _`_scénář_runtime_2`:

<Scénář runtime 2>
------------------

…​
-

.. _`_scénář_runtime_n`:

<Scénář runtime n>
------------------

.. _section-deployment-view:

Perspektiva nasazení softwaru (deployment)
==========================================

.. container:: formalpara-title

   **Obsah**

Perspektiva nasazení softwaru popisuje:

1. technickou infrastrukturu, na které systém poběží, s jednotlivými
   prvky infrastruktury, jako jsou například geografická poloha,
   prostředí, počítače, procesory, kanály a topologie sítí a další,
   jakož i

2. mapování (softwarových) stavebních bloků na jednotlivé prvky této
   infrastruktury.

Systémy bývají často spouštěny v různých prostředích, například
vývojovém prostředí, testovacím prostředí, produkčním prostředí. V
takových případech by měla být zdokumentována všechna relevantní
prostředí.

Zejména dokumentujte perspektivu nasazení softwaru, pokud je software
provozován jako distribuovaný systém s více než jedním počítačem,
procesorem, serverem nebo kontejnerem nebo když jsou navrhovány a
konstruovány vlastní hardwarové procesory a čipy.

Z hlediska softwaru stačí zachytit pouze ty prvky infrastruktury, které
jsou potřebné k ukázce nasazení jednotlivých stavebních bloků.
Hardwaroví architekti mohou jít dále a popsat infrastrukturu do té
úrovně detailů, kterou je potřeba zachytit.

.. container:: formalpara-title

   **Motivace**

Software neběží bez hardwaru. Tato infrastruktura může a bude ovlivňovat
systém a/nebo některé průřezové koncepty. Proto je potřeba ji znát.

.. container:: formalpara-title

   **Forma**

Možná je diagram nasazení softwaru na nejvyšší úrovni již obsažen v
části 3.2. jako technický kontext s vlastní infrastrukturou jako JEDEN
black-box. V této sekci lze tento black-box přiblížit pomocí dalších
diagramů nasazení:

-  UML nabízí diagramy nasazení k vyjádření této perspektivy. Použijte
   je, pravděpodobně s vnořenými diagramy, když je infrastruktura
   složitější.

-  Když strany zainteresované na hardwaru preferují jiné druhy diagramů
   než diagram nasazení, nechte je použít jakýkoli druh, který je
   schopen zobrazit uzly a kanály infrastruktury.

.. container:: formalpara-title

   **Další informace**

Anglická dokumentace arc42: `Deployment
View <https://docs.arc42.org/section-7/>`__.

.. _`_úroveň_infrastruktury_1`:

Úroveň infrastruktury 1
-----------------------

Popište (obvykle kombinací diagramů, tabulek a textu):

-  distribuci systému na více míst, prostředí, počítačů, procesorů,..,
   jakož i fyzická propojení mezi nimi

-  důležité důvody nebo motivaci pro tuto strukturu nasazení

-  kvalitativní a/nebo výkonnostní vlastnosti této infrastruktury

-  mapování softwarových artefaktů na prvky této infrastruktury

Pro více prostředí nebo alternativní nasazení zkopírujte a upravte tuto
část arc42 pro všechna relevantní prostředí.

**<Přehledový diagram>**

Motivace
   *<vysvětlení v textové podobě>*

Kvalitativní a/nebo výkonnostní vlastnosti
   *<vysvětlení v textové podobě>*

Mapování softwarových artefaktů na prvky infrastruktury
   *<popis mapování>*

.. _`_úroveň_infrastruktury_2`:

Úroveň infrastruktury 2
-----------------------

Zde můžete zahrnout vnitřní strukturu (některých) prvků infrastruktury z
úrovně 1.

Zkopírujte prosím strukturu z úrovně 1 pro každý vybraný prvek.

.. _`_prvek_infrastruktury_1`:

*<prvek infrastruktury 1>*
~~~~~~~~~~~~~~~~~~~~~~~~~~

*<diagram + vysvětlení>*

.. _`_prvek_infrastruktury_2`:

*<prvek infrastruktury 2>*
~~~~~~~~~~~~~~~~~~~~~~~~~~

*<diagram + vysvětlení>*

…​

.. _`_prvek_infrastruktury_n`:

*<prvek infrastruktury n>*
~~~~~~~~~~~~~~~~~~~~~~~~~~

*<diagram + vysvětlení>*

.. _section-concepts:

Průřezové (cross-cutting) koncepty
==================================

.. container:: formalpara-title

   **Obsah**

Tato část dokumentace popisuje přesahující principy, předpisy a řešení,
které jsou relevantní pro více částí systému (= průřezové). Takové
koncepty se často týkají více stavebních bloků.

Může zahrnovat mnoho různých témat, jako například

-  modely, zejména doménové modely

-  architekturu nebo designové vzory

-  pravidla pro použití konkrétních technologií

-  zásadní, často technická rozhodnutí zastřešujícího (= průřezového)
   charakteru

-  pravidla implementace

.. container:: formalpara-title

   **Motivace**

Koncepty tvoří základ *konceptuální integrity* (konzistence, homogenity)
softwarové architektury. Jsou tedy důležitým příspěvkem k dosažení
vnitřní kvality vyvíjeného systému.

Některé z těchto konceptů nelze přiřadit k jednotlivým stavebním blokům,
například zabezpečení.

.. container:: formalpara-title

   **Forma**

Forma může být různá:

-  koncepční dokumenty s jakoukoliv strukturou

-  průřezové modely nebo scénáře, které jsou již využity v jednotlivých
   perspektivách architektury

-  vzorové implementace, zejména pro technické koncepty

-  odkaz na "typické" používání standardních frameworků (například
   používání Hibernate pro objektové/relační mapování)

.. container:: formalpara-title

   **Struktura**

Potenciální (nikoli však povinná) struktura pro tento oddíl dokumentace
může být:

-  Koncepty domén

-  Koncepty uživatelské zkušenosti (UX)

-  Koncepty bezpečnosti a zabezpečení

-  Architektura a designové vzory

-  "pod kapotou"

-  Vývojové koncepty

-  Provozní koncepty

Poznámka: Může být obtížné přiřadit jednotlivé koncepty k jednomu
konkrétnímu tématu z tohoto seznamu.

.. figure:: images/08-concepts-EN.drawio.png
   :alt: Témata pro průřezové koncepty

.. container:: formalpara-title

   **Další informace**

Anglická dokumentace arc42:
`Concepts <https://docs.arc42.org/section-8/>`__.

.. _`_koncept_1`:

*<Koncept 1>*
-------------

*<vysvětlení>*

.. _`_koncept_2`:

*<Koncept 2>*
-------------

*<vysvětlení>*

…​

.. _`_koncept_n`:

*<Koncept n>*
-------------

*<vysvětlení>*

.. _section-design-decisions:

Rozhodnutí o architektuře
=========================

.. container:: formalpara-title

   **Obsah**

Důležitá, drahá, rozsáhlá nebo riskantní rozhodnutí o architektuře
včetně příslušných zdůvodnění. „Rozhodnutím“ rozumíme výběr jedné nebo
více alternativ na základě daných kritérií.

Uvažte, zda má být architektonické rozhodnutí zdokumentována zde v této
centrální sekci, nebo zda je lepší je zdokumentovat lokálně (například v
šabloně white-box konkrétního stavebního bloku).

Vyvarujte se opakovaní. Odkažte na 4. kapitolu, kde jste již zachytili
nejdůležitější architektonická rozhodnutí.

.. container:: formalpara-title

   **Motivace**

Strany zainteresované na systému by měly být schopny přijatým
rozhodnutím porozumět a pochopit důvody k ním vedoucí.

.. container:: formalpara-title

   **Forma**

Různé možnosti:

-  **ADR** `Architecture Decision
   Record <https://thinkrelevance.com/blog/2011/11/15/documenting-architecture-decisions>`__
   pro každé důležité rozhodnutí

-  seznam nebo tabulka, seřazené podle důležitosti a důsledků

-  podrobněji ve formě samostatných podkapitol pro jednotlivá rozhodnutí

.. container:: formalpara-title

   **Další informace**

Anglická dokumentace arc42: `Architecture
Decisions <https://docs.arc42.org/section-9/>`__. Zde najdete odkazy a
příklady k tématu **ADR**.

.. _section-quality-scenarios:

Požadavky na kvalitu
====================

.. container:: formalpara-title

   **Obsah**

Tato kapitola shrnuje všechny relevantní požadavky na kvalitu.

Nejdůležitější z těchto požadavků již byly popsány v kapitole 1.2
(kvalitativní cíle), a proto by zde měly být pouze odkázány. V této
kapitole (10) je vhodné zaznamenat i méně důležité požadavky na kvalitu,
jejichž nesplnění nepředstavuje zásadní riziko, ale které mohou být
užitečné či žádoucí (*nice-to-have*).

.. container:: formalpara-title

   **Motivace**

Požadavky na kvalitu mají výrazný vliv na architektonická rozhodnutí. Je
proto důležité znát kvalitativní očekávání zainteresovaných stran, a to
konkrétně a měřitelně.

-  Dokumentace arc42: `Quality
   Requirements <https://docs.arc42.org/section-10/>`__

-  Model kvality Q42: `Q42 quality model na
   https://quality.arc42.org <https://quality.arc42.org>`__.

.. _`_přehled_požadavků_na_kvalitu`:

Přehled požadavků na kvalitu
----------------------------

.. container:: formalpara-title

   **Obsah**

Stručný přehled požadavků na kvalitu.

.. container:: formalpara-title

   **Motivace**

V praxi se často setkáváme s desítkami či stovkami požadavků na kvalitu.
Tento přehled by měl nabídnout jejich kategorizaci či shrnutí –
například dle standardu `ISO
25010:2023 <https://www.iso.org/obp/ui/#iso:std:iso-iec:25010:ed-2:v1:en>`__
nebo podle `modelu Q42 <https://quality.arc42.org>`__.

Pokud je tento přehled dostatečně konkrétní, specifický a měřitelný,
může být část 10.2 vynechána.

.. container:: formalpara-title

   **Forma**

Použijte jednoduchou tabulku, kde každý řádek reprezentuje kategorii
nebo typ požadavku na kvalitu spolu s krátkým popisem. Alternativně lze
využít mind map pro vizuální strukturování požadavků. V literatuře se
také vyskytuje pojem *strom kvalitativních atributů* (*Quality Attribute
Utility Tree*), který rozvíjí pojem „kvalita“ jako kořenový uzel stromu
s větvemi představujícími konkrétní požadavky.

.. _`_scénáře_kvality`:

Scénáře kvality
---------------

.. container:: formalpara-title

   **Obsah**

Scénáře kvality konkretizují požadavky na kvalitu a umožňují ověřit, zda
byly splněny (například pomocí akceptačních kritérií). Scénáře by měly
být jednoznačné a měřitelné.

Dva typy scénářů jsou obzvláště užitečné:

-  *Scénáře použití* (též aplikační nebo provozní scénáře) popisují
   chování systému v reakci na určitý podnět v runtime – včetně
   výkonnosti, odezvy apod. Příklad: Systém odpoví na požadavek
   uživatele do jedné sekundy.

-  *Scénáře změn* popisují chování systému při jeho úpravách nebo
   rozšiřování, případně změnách okolního prostředí. Příklad: Do systému
   je doplněna nová funkce, mění se požadavek na kvalitu a měří se
   náročnost změny.

.. container:: formalpara-title

   **Forma**

Typická struktura scénáře může mít dvě podoby:

-  **Krátká forma** (upřednostňuje ji model Q42):

-  **Kontext**: O jaký systém nebo komponentu se jedná? Jaké je okolí
   nebo situace?

-  **Zdroj/Podnět**: Kdo nebo co spouští chování nebo reakci systému?

-  **Kritérium/Metoda ověření**: Jak poznáme, že je požadavek splněn?
   (metrika, měřitelný výstup)

-  **Dlouhá forma** (používaná v SEI, např. [Bass+21]):

-  **ID scénáře**

-  **Název scénáře**

-  **Zdroj** (uživatel, systém, událost)

-  **Podnět**

-  **Provozní prostředí**

-  **Artefakt** (část systému, která je podnětem ovlivněna)

-  **Odezva**

-  **Metrika odezvy** (kritérium pro hodnocení odezvy systému)

.. container:: formalpara-title

   **Příklady**

Viz `model kvality Q42 <https://quality.arc42.org>`__ pro detailní
ukázky scénářů.

-  Len Bass, Paul Clements, Rick Kazman: *Software Architecture in
   Practice*, 4. vydání, Addison-Wesley, 2021.

.. _section-technical-risks:

Rizika a technické dluhy
========================

.. container:: formalpara-title

   **Obsah**

Seznam známých technických rizik nebo technických dluhů seřazený podle
jejich priority.

.. container:: formalpara-title

   **Motivace**

„Řízení rizik je řízení projektu pro dospělé.“ — Tim Lister, Atlantic
Systems Guild

Tak by mělo znít motto pro systematické zjišťování a hodnocení rizik a
technických dluhů v architektuře, které potřebují znát zainteresované
strany z oblasti managementu (například projektoví manažeři, vlastníci
produktu - (Product Owner)) jako součást celkové analýzy rizik.

.. container:: formalpara-title

   **Forma**

Seznam rizik a/nebo technických dluhů, pravděpodobně včetně navrhovaných
opatření k jejich minimalizaci, zmírnění nebo vyloučení.

.. container:: formalpara-title

   **Další informace**

Anglická dokumentace arc42: `Risks and Technical
Debt <https://docs.arc42.org/section-11/>`__.

.. _section-glossary:

Slovník pojmů
=============

.. container:: formalpara-title

   **Obsah**

Nejdůležitější doménové a technické termíny, které zainteresované strany
používají při diskuzi o systému.

Pokud pracujete ve vícejazyčných týmech, můžete glosář používat jako
zdroj překladů.

.. container:: formalpara-title

   **Motivace**

Je důležité jasně definovat klíčové pojmy, aby všechny zainteresované
strany

-  chápaly tyto pojmy stejně

-  a aby neexistovalo pro jednu a stejnou věc více variant

-  Tabulka se sloupci <Termín> a <Definice>.

-  Potenciálně více sloupců v případě, že potřebujete překlady.

.. container:: formalpara-title

   **Další informace**

Anglická dokumentace arc42:
`Glossary <https://docs.arc42.org/section-12/>`__.

+----------------------+-----------------------------------------------+
| Termín               | Definice                                      |
+======================+===============================================+
| *<termín-1>*         | *<definice-1>*                                |
+----------------------+-----------------------------------------------+
| *<termín-2>*         | *<definice-2>*                                |
+----------------------+-----------------------------------------------+

.. |arc42| image:: images/arc42-logo.png
