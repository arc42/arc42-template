# Ambito e contesto del sistema

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenuti

</div>

L’ambito e il contesto del sistema, come suggerisce il nome, delimitano
il sistema (ovvero l’ambito) da tutti i suoi partner di comunicazione
(sistemi e utenti vicini, ovvero il contesto del tuo sistema). In tal
modo specifica le interfacce esterne.

</div>

Se necessario, differenziare il contesto di business (input e output
specifici del dominio) dal contesto tecnico (canali, protocolli,
hardware).

<div class="formalpara">

<div class="title">

Motivazione

</div>

Le interfacce di dominio e le interfacce tecniche per i partner di
comunicazione sono tra gli aspetti più critici del sistema. Assicurati
di capirli completamente.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Diverse opzioni:

</div>

- Diagrammi di contesto

- Elenchi di partner di comunicazione e loro interfacce.

</div>

## Contesto di Business

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenuti

</div>

Specifica di **tutti** i partner di comunicazione (utenti, sistemi IT,
…​) con spiegazioni di input e output specifici del dominio o interfacce.
Facoltativamente è possibile aggiungere formati specifici del dominio o
protocolli di comunicazione.

</div>

<div class="formalpara">

<div class="title">

Motivazione

</div>

Tutti gli stakeholder dovrebbero capire quali dati vengono scambiati con
l’ambiente del sistema.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Tutti i tipi di diagrammi che mostrano il sistema come una scatola nera
e specificano le interfacce di dominio per i partner di comunicazione.

</div>

In alternativa (o in aggiunta) puoi usare una tabella. Il titolo della
tabella è il nome del sistema, le tre colonne contengono il nome del
partner di comunicazione, gli ingressi e le uscite.

</div>

**\<Diagramma o Tabella\>**

**\<opzionale: spiegazione delle interfacce del dominio esterno\>**

## Contesto Tecnico

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenuti

</div>

Interfacce tecniche (canali e mezzi di trasmissione) che collegano il
sistema al suo ambiente. Oltre alla mappatura dell’input/output
specifico del dominio sui canali di comunicazione, ad es. una
spiegazione con I/O dell’utilizza del canale di comunicazione.

</div>

<div class="formalpara">

<div class="title">

Motivazione

</div>

Spesso, gli stakeholders prendono decisioni architetturali in base alle
interfacce tecniche tra il sistema e il suo contesto. Sono,
principalmente i progettisti di infrastrutture o hardware che decidono
queste interfacce tecniche.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Esempio: un deployment diagram UML che descrive i canali di
comunicazione dei sistemi vicini, insieme a una tabella di mappatura che
mostra le relazioni tra canali e input/output.

</div>

</div>

**\<Diagramma o Tabella\>**

**\<opzionale: Spiegazione delle interfacce tecniche\>**

**\<Mappatura Input/Output sui canali di comunicazione\>**
