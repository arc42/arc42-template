# Vincoli di architettura

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenuti

</div>

Qualsiasi requisito che limiti gli architetti del software nella loro
libertà di decisioni di progettazione e implementazione o decisione sul
processo di sviluppo. Questi vincoli a volte vanno oltre i singoli
sistemi e sono validi per intere organizzazioni e aziende.

</div>

<div class="formalpara">

<div class="title">

Motivazione

</div>

Gli architetti dovrebbero sapere esattamente dove sono liberi nelle loro
decisioni di progettazione e dove devono aderire ai vincoli. I vincoli
devono essere sempre affrontati; possono essere negoziabili però.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Semplici tabelle di vincoli con spiegazioni. Se necessario puoi
suddividerli in file vincoli tecnici, vincoli organizzativi e politici e
convenzioni (ad es. linee guida di programmazione o di controllo delle
versioni, documentazione o convenzioni di denominazione)

</div>

</div>
