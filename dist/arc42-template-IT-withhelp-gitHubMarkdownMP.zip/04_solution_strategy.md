# Strategia della soluzione

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenuti

</div>

Un breve riassunto e spiegazione delle decisioni fondamentali e delle
strategie di soluzione che modellano l’architettura del sistema. Questi
includono

</div>

- decisioni tecnologiche

- decisioni sulla scomposizione di primo livello del sistema, ad es.
  utilizzo di un modello architetturale o di un modello di progettazione

- decisioni su come raggiungere gli obiettivi chiave di qualità

- decisioni organizzative rilevanti, ad es. selezionare un processo di
  sviluppo o delegare determinati compiti a terzi.

<div class="formalpara">

<div class="title">

Motivazione

</div>

Queste decisioni costituiscono le pietre angolari della tua
architettura. Sono la base per molte altre decisioni dettagliate o
regole di attuazione.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Mantieni breve la spiegazione di queste decisioni chiave.

</div>

Motiva ciò che hai deciso e perché lo hai deciso in questo modo, in base
alla dichiarazione del problema, agli obiettivi di qualità e ai vincoli
chiave. Fare riferimento ai dettagli nelle sezioni seguenti.

</div>
