# Runtime View

## \<Runtime Scenario 1>

-   *\<inserire un runtime diagram o una descrizione testuale dello
    scenario>*

-   *\<inserire la descrizione degli aspetti degni di nota delle
    interazioni tra i istanze di building block illustrate in questo
    diagramma.>*

## \<Runtime Scenario 2>

## …

## \<Runtime Scenario n>
