# Glossario

<div class="formalpara-title">

**Contenuti**

</div>

Il dominio più importante e i termini tecnici utilizzati dagli
stakeholder quando discutono del sistema.

Puoi anche vedere il glossario come fonte per le traduzioni se lavori in
team multilingue.

<div class="formalpara-title">

**Motivazione**

</div>

Dovresti definire chiaramente i tuoi termini, in modo che tutte le parti
interessate

-   abbiano una comprensione identica di questi termini

-   non utilizzino sinonimi e omonimi

<!-- -->

-   Una tabella con colonne &lt;Termine&gt; e &lt;Definizione&gt;.

-   Potenzialmente più colonne nel caso tu abbia bisogno di traduzioni.

| Termine             | Definizione             |
|---------------------|-------------------------|
| *&lt;Termine-1&gt;* | *&lt;definizione-1&gt;* |
| *&lt;Termine-2&gt;* | *&lt;definizione-2&gt;* |
