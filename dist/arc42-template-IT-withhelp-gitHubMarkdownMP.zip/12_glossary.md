# Glossario

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenuti

</div>

Il dominio più importante e i termini tecnici utilizzati dagli
stakeholder quando discutono del sistema.

</div>

Puoi anche vedere il glossario come fonte per le traduzioni se lavori in
team multilingue.

<div class="formalpara">

<div class="title">

Motivazione

</div>

Dovresti definire chiaramente i tuoi termini, in modo che tutte le parti
interessate

</div>

- abbiano una comprensione identica di questi termini

- non utilizzino sinonimi e omonimi

<div>

<div class="title">

Forma

</div>

- Una tabella con colonne \<Termine\> e \<Definizione\>.

- Potenzialmente più colonne nel caso tu abbia bisogno di traduzioni.

</div>

</div>

| Termine         | Definizione         |
|-----------------|---------------------|
| *\<Termine-1\>* | *\<definizione-1\>* |
| *\<Termine-2\>* | *\<definizione-2\>* |
