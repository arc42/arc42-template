# Vue en Briques {#section-building-block-view}

## Niveau 1 : Système global Boîte blanche {#_niveau_1_système_global_boîte_blanche}

***&lt;Schéma d’ensemble&gt;***

Motivation

:   *&lt;texte explicatif&gt;*

Briques contenues

:   *&lt;Description de la brique contenue (boîte noire)&gt;*

Interfaces Importantes

:   *&lt;Description des interfaces importantes&gt;*

### &lt;Nom boîte noire 1&gt; {#_nom_boîte_noire_1}

*&lt;Objectif/Responsabilité&gt;*

*&lt;Interface(s)&gt;*

*&lt;(Facultatif) Caractéristiques de qualité/performance&gt;*

*&lt;(Facultatif) Emplacement du répertoire/fichier&gt;*

*&lt;(Facultatif) Exigences respectées&gt;*

*&lt;(Facultatif) Questions ouvertes/problèmes/risques&gt;*

### &lt;Nom boîte noire 2&gt; {#_nom_boîte_noire_2}

*&lt;template boîte noire&gt;*

### &lt;Nom boîte noire n&gt; {#_nom_boîte_noire_n}

*&lt;template boîte noire&gt;*

### &lt;Nom interface 1&gt; {#_nom_interface_1}

…​

### &lt;Nom interface m&gt; {#_nom_interface_m}

## Niveau 2 {#_niveau_2}

### Boîte blanche *&lt;brique 1&gt;* {#_boîte_blanche_brique_1}

*&lt;template boîte blanche&gt;*

### Boîte blanche *&lt;brique 2&gt;* {#_boîte_blanche_brique_2}

*&lt;template boîte blanche&gt;*

…​

### Boîte blanche *&lt;brique n&gt;* {#_boîte_blanche_brique_n}

*&lt;template boîte blanche&gt;*

  [Vue en Briques]: #section-building-block-view {#toc-section-building-block-view}
  [Niveau 1 : Système global Boîte blanche]: #_niveau_1_système_global_boîte_blanche {#toc-_niveau_1_système_global_boîte_blanche}
  [&lt;Nom boîte noire 1&gt;]: #_nom_boîte_noire_1 {#toc-_nom_boîte_noire_1}
  [&lt;Nom boîte noire 2&gt;]: #_nom_boîte_noire_2 {#toc-_nom_boîte_noire_2}
  [&lt;Nom boîte noire n&gt;]: #_nom_boîte_noire_n {#toc-_nom_boîte_noire_n}
  [&lt;Nom interface 1&gt;]: #_nom_interface_1 {#toc-_nom_interface_1}
  [&lt;Nom interface m&gt;]: #_nom_interface_m {#toc-_nom_interface_m}
  [Niveau 2]: #_niveau_2 {#toc-_niveau_2}
  [Boîte blanche *&lt;brique 1&gt;*]: #_boîte_blanche_brique_1 {#toc-_boîte_blanche_brique_1}
  [Boîte blanche *&lt;brique 2&gt;*]: #_boîte_blanche_brique_2 {#toc-_boîte_blanche_brique_2}
  [Boîte blanche *&lt;brique n&gt;*]: #_boîte_blanche_brique_n {#toc-_boîte_blanche_brique_n}
