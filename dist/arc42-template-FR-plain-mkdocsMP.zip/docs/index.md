**A propos d’arc42**

arc42, le modèle de documentation de l’architecture des logiciels et des systèmes.

Version du modèle 9.0-FR. (basé sur la version AsciiDoc), Avril 2025

Créé, maintenu et © par Dr. Peter Hruschka, Dr. Gernot Starke et les contributeurs. Voir <https://arc42.org>.


0. [Introduction et Objectifs](01_introduction_and_goals.md)

0. [Contraintes d’Architecture](02_architecture_constraints.md)

0. [Contexte et périmètre](03_context_and_scope.md)

0. [Stratégie de solution](04_solution_strategy.md)

0. [Vue en Briques](05_building_block_view.md)

0. [Vue Exécution](06_runtime_view.md)

0. [Vue Déploiement](07_deployment_view.md)

0. [Concepts transversaux](08_concepts.md)

0. [Décisions d’architecture](09_architecture_decisions.md)

0. [Critères de qualité](10_quality_requirements.md)

0. [Risques et Dettes techniques](11_technical_risks.md)

0. [Glossaire](12_glossary.md)
