# Décisions d’architecture {#section-design-decisions}

  [Décisions d’architecture]: #section-design-decisions {#toc-section-design-decisions}
