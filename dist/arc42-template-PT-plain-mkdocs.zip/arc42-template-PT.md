---
date: Setembro de 2024
title: Modelo ![arc42](images/arc42-logo.png)
---

# 

**Sobre o arc42**

arc42, o template para documentação de software e arquitetura de
sistemas.

Versão do template 8.2-PT. (based upon AsciiDoc version), Setembro de
2024

Criado, mantido e © pelo Dr. Peter Hruschka, Dr. Gernot Starke e
colaboradores. Veja <https://arc42.org>.

# Introdução e Objetivos {#section-introduction-and-goals}

## Visão Geral dos Requisitos {#_visão_geral_dos_requisitos}

## Objetivos de Qualidade {#_objetivos_de_qualidade}

## Partes Interessadas {#_partes_interessadas}

+-------------+---------------------------+---------------------------+
| Função/Nome | Contato                   | Expectativas              |
+=============+===========================+===========================+
| *\<         | *\<Contato-1\>*           | *\<Expectativa-1\>*       |
| Função-1\>* |                           |                           |
+-------------+---------------------------+---------------------------+
| *\<         | *\<Contato-2\>*           | *\<Expectativa-2\>*       |
| Função-2\>* |                           |                           |
+-------------+---------------------------+---------------------------+

# Restrições Arquiteturais {#section-architecture-constraints}

# Contexto e Escopo {#section-context-and-scope}

## Contexto Negocial {#_contexto_negocial}

**\<Diagrama ou Tabela\>**

**\<opcionalmente: Explicação das interfaces de domínio externo\>**

## Contexto Técnico {#_contexto_técnico}

**\<Diagrama ou Tabela\>**

**\<opcionalmente: Explicação das interfaces técnicas\>**

**\<Mapeamento de entrada/saída para canais\>**

# Estratégia de Solução {#section-solution-strategy}

# Visão de Blocos de Construção {#section-building-block-view}

## Visão Sistêmica Geral de Caixa Branca {#_visão_sistêmica_geral_de_caixa_branca}

***\<Diagrama de Visão Geral\>***

Motivação

:   *\<explicação textual\>*

Blocos de Construção Contidos

:   *\<Descrição dos blocos de construção contidos (caixas pretas)\>*

Interfaces Importantes

:   *\<Descrição de interfaces importantes\>*

### \<Nome Caixa Preta 1\> {#_nome_caixa_preta_1}

*\<Propósito/Responsabilidade\>*

*\<Interface(s)\>*

*\<(Opcional) Características de Qualidade/Desempenho\>*

*\<(Opcional) Local do Diretório/Arquivo\>*

*\<(Opcional) Requisitos Cumpridos\>*

*\<(opcional) Problemas/Riscos Abertos\>*

### \<Nome Caixa Preta 2\> {#_nome_caixa_preta_2}

*\<modelo de caixa preta\>*

### \<Nome Caixa Preta n\> {#_nome_caixa_preta_n}

*\<modelo de caixa preta\>*

### \<Nome Interface 1\> {#_nome_interface_1}

...​

### \<Nome Interface m\> {#_nome_interface_m}

## Nível 2 {#_nível_2}

### Caixa Branca *\<Bloco de Construção 1\>* {#_caixa_branca_bloco_de_construção_1}

*\<modelo de caixa branca\>*

### Caixa Branca *\<Bloco de Construção 2\>* {#_caixa_branca_bloco_de_construção_2}

*\<modelo de caixa branca\>*

...​

### Caixa Branca *\<Bloco de Construção m\>* {#_caixa_branca_bloco_de_construção_m}

*\<modelo de caixa branca\>*

## Nível 3 {#_nível_3}

### Caixa Branca \<\_Bloco de Construção x.1\_\> {#_caixa_branca_bloco_de_construção_x_1}

*\<modelo de caixa branca\>*

### Caixa Branca \<\_Bloco de Construção x.2\_\> {#_caixa_branca_bloco_de_construção_x_2}

*\<modelo de caixa branca\>*

### Caixa Branca \<\_Bloco de Construção y.1\_\> {#_caixa_branca_bloco_de_construção_y_1}

*\<modelo de caixa branca\>*

# Visão de Tempo de Execução {#section-runtime-view}

## \<Cenário de Tempo de Execução 1\> {#_cenário_de_tempo_de_execução_1}

-   *\<inserir diagrama de tempo de execução ou descrição textual do
    cenário\>*

-   *\<inserir descrição dos aspectos notáveis ​​das interações entre as
    instâncias do bloco de construção descritas neste diagrama.\>*

## \<Cenário de Tempo de Execução 2\> {#_cenário_de_tempo_de_execução_2}

## ...​

## \<Cenário de Tempo de Execução n\> {#_cenário_de_tempo_de_execução_n}

# Visão de Implantação {#section-deployment-view}

## Nível de Infraestrutura 1 {#_nível_de_infraestrutura_1}

***\<Diagrama de Visão Geral\>***

Motivação

:   *\<explicação em forma de texto\>*

Características de Qualidade e/ou Desempenho

:   *\<explicação em forma de texto\>*

Mapeamento de Blocos de Construção para Infraestrutura

:   *\<descrição do mapeamento\>*

## Nível de Infraestrutura 2 {#_nível_de_infraestrutura_2}

### *\<Elemento de Infraestrutura 1\>* {#_elemento_de_infraestrutura_1}

*\<diagrama + explicação\>*

### *\<Elemento de Infraestrutura 2\>* {#_elemento_de_infraestrutura_2}

*\<diagrama + explicação\>*

...​

### *\<Elemento de Infraestrutura n\>* {#_elemento_de_infraestrutura_n}

*\<diagrama + explicação\>*

# Conceitos Transversais {#section-concepts}

## *\<Conceito 1\>* {#_conceito_1}

*\<explicação\>*

## *\<Conceito 2\>* {#_conceito_2}

*\<explicação\>*

...​

## *\<Conceito n\>* {#_conceito_n}

*\<explicação\>*

# Decisões Arquiteturais {#section-design-decisions}

# Requisitos de qualidade {#section-quality-scenarios}

## Árvore de qualidade {#_árvore_de_qualidade}

## Cenários de Qualidade {#_cenários_de_qualidade}

# Riscos e Débitos Técnicos {#section-technical-risks}

# Glossário {#section-glossary}

+----------------------+-----------------------------------------------+
| Termo                | Definição                                     |
+======================+===============================================+
| *\<Termo-1\>*        | *\<definição-1\>*                             |
+----------------------+-----------------------------------------------+
| *\<Termo-2\>*        | *\<definição-2\>*                             |
+----------------------+-----------------------------------------------+
