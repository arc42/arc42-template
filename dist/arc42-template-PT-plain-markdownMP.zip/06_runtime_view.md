# Visão de Tempo de Execução {#section-runtime-view}

## \<Cenário de Tempo de Execução 1> {#__cen_rio_de_tempo_de_execu_o_1}

-   *\<inserir diagrama de tempo de execução ou descrição textual do
    cenário>*

-   *\<inserir descrição dos aspectos notáveis ​​das interações entre as
    instâncias do bloco de construção descritas neste diagrama.\>*

## \<Cenário de Tempo de Execução 2> {#__cen_rio_de_tempo_de_execu_o_2}

## ... {#_}

## \<Cenário de Tempo de Execução n> {#__cen_rio_de_tempo_de_execu_o_n}
