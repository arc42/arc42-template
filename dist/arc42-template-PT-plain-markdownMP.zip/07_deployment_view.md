# Visão de Implantação {#section-deployment-view}

## Nível de Infraestrutura 1 {#_n_vel_de_infraestrutura_1}

***\<Diagrama de Visão Geral>***

Motivação

:   *\<explicação em forma de texto>*

Características de Qualidade e/ou Desempenho

:   *\<explicação em forma de texto>*

Mapeamento de Blocos de Construção para Infraestrutura

:   *\<descrição do mapeamento>*

## Nível de Infraestrutura 2 {#_n_vel_de_infraestrutura_2}

### *\<Elemento de Infraestrutura 1>* {#__emphasis_elemento_de_infraestrutura_1_emphasis}

*\<diagrama + explicação>*

### *\<Elemento de Infraestrutura 2>* {#__emphasis_elemento_de_infraestrutura_2_emphasis}

*\<diagrama + explicação>*

...

### *\<Elemento de Infraestrutura n>* {#__emphasis_elemento_de_infraestrutura_n_emphasis}

*\<diagrama + explicação>*
