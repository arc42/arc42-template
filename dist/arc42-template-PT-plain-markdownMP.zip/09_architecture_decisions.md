# Decisões Arquiteturais {#section-design-decisions}
