# Riscos e Débitos Técnicos {#section-technical-risks}
