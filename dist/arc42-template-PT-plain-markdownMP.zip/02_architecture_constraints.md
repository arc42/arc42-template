# Restrições Arquiteturais {#section-architecture-constraints}
