**Over arc42**

arc42, de Template voor documentatie van software en systeem
architectuur.

Gecreeerd en onderhouden door Dr. Peter Hruschka, Dr. Gernot Starke en
bijdragers.

Template Versie: 8. De NL versie is gebaseerd op EN template versie 8,
februari 2022

© We erkennen dat dit document materiaal gebruikt van de arc 42
architectuur template, https://arc42.org.

.. _section-introduction-and-goals:

Introductie en Doelen
=====================

.. _`_requirements_overzicht`:

Requirements Overzicht
----------------------

.. _`_kwaliteits_doelen`:

Kwaliteits Doelen
-----------------

.. _`_belanghebbenden`:

Belanghebbenden
---------------

+-------------+---------------------------+---------------------------+
| Rol/Naam    | Contact persoon           | Verwachtingen             |
+=============+===========================+===========================+
| *<Rol-1>*   | *<Contact-1>*             | *<Verwachting-1>*         |
+-------------+---------------------------+---------------------------+
| *<Rol-2>*   | *<Contact-2>*             | *<Verwachting-2>*         |
+-------------+---------------------------+---------------------------+

.. _section-architecture-constraints:

Architectuur Beperkingen
========================

.. _section-solution-strategy:

Oplossing Strategie
===================

.. _section-building-block-view:

Bouwstenen View
===============

.. _`_gehele_whitebox_systeem`:

Gehele whitebox Systeem
-----------------------

**<Overzichts Diagram>**

Motivatie
   *<tekstuele uitleg>*

Ingesloten bouwstenen
   *<Beschrijving van ingesloten bouwstenen (black boxes)>*

Belangrijke Interfaces
   *<Beschrijving van belangrijke interfaces>*

.. _`__naam_black_box_1`:

<Naam black box 1>
~~~~~~~~~~~~~~~~~~

*<Doel/Verantwoordelijkheid>*

*<Interface(s)>*

*<((Optioneel) Kwaliteits-/Prestatie karakteristieken>*

*<(Optioneel) directories/bestand locaties>*

*<(Optioneel) Vervulde requirements>*

*<(Optioneel) Open issues/problemen/risico’s>*

.. _`__naam_black_box_2`:

<Naam black box 2>
------------------

*<black box template>*

.. _`__naam_black_box_n`:

<Naam black box n>
~~~~~~~~~~~~~~~~~~

*<black box template>*

.. _`__naam_interface_1`:

<Naam interface 1>
~~~~~~~~~~~~~~~~~~

…

.. _`__naam_interface_m`:

<Naam interface m>
~~~~~~~~~~~~~~~~~~

.. _`_niveau_2`:

Niveau 2
--------

.. _`_white_box_emphasis_bouwsteen_1_emphasis`:

White Box *<bouwsteen 1>*
~~~~~~~~~~~~~~~~~~~~~~~~~

*<white box template>*

.. _`_white_box_emphasis_bouwsteen_2_emphasis`:

White Box *<bouwsteen 2>*
~~~~~~~~~~~~~~~~~~~~~~~~~

*<white box template>*

…

.. _`_white_box_emphasis_bouwsteen_m_emphasis`:

White Box *<bouwsteen m>*
~~~~~~~~~~~~~~~~~~~~~~~~~

*<white box template>*

.. _`_niveau_3`:

Niveau 3
--------

.. _`_white_box_emphasis_bouwsteen_x_1_emphasis`:

White Box *<bouwsteen x.1>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<white box template>*

.. _`_white_box_emphasis_bouwsteen_x_2_emphasis`:

White Box *<bouwsteen x.2>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<white box template>*

.. _`_white_box_emphasis_bouwsteen_y_1_emphasis`:

White Box *<bouwsteen y.1>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<white box template>*

.. _section-runtime-view:

Runtime View
============

.. _`__runtime_scenario_1`:

<Runtime Scenario 1>
--------------------

-  *<voeg een runtime diagram of een tekstuele beschrijving van het
   scenario toe>*

-  *<voeg een beschrijving toe van bijzondere aspecten van de interactie
   tussen de instanties van de bouwstenen die in dit diagram worden
   weergegeven>*

.. _`__runtime_scenario_2`:

<Runtime Scenario 2>
--------------------

.. _`_`:

…
-

.. _`__runtime_scenario_n`:

<Runtime Scenario n>
--------------------

.. _section-deployment-view:

Deployment View
===============

.. _`_infrastructuur_niveau_1`:

Infrastructuur Niveau 1
-----------------------

**<Overzichts Diagram>**

Motivatie
   *<uitleg in tekstuele vorm>*

Kwaliteit en/of Performance Eigenschappen
   *<uitleg in tekstuele vorm>*

Mapping van Bouwstenen naar Infrastructuur
   *<beschrijving van de mapping>*

.. _`_infrastructuur_niveau_2`:

Infrastructuur Niveau 2
-----------------------

.. _`__emphasis_infrastructuur_element_1_emphasis`:

*<Infrastructuur Element 1>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<diagram + uitleg>*

.. _`__emphasis_infrastructuur_element_2_emphasis`:

*<Infrastructuur Element 2>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<diagram + uitleg>*

…

.. _`__emphasis_infrastructuur_element_n_emphasis`:

*<Infrastructuur Element n>*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*<diagram + uitleg>*

.. _section-concepts:

Cross-cutting Concepten
=======================

.. _`__emphasis_concept_1_emphasis`:

*<Concept 1>*
-------------

*<uitleg>*

.. _`__emphasis_concept_2_emphasis`:

*<Concept 2>*
-------------

*<uitleg>*

…

.. _`__emphasis_concept_n_emphasis`:

*<Concept n>*
-------------

*<uitleg>*

.. _section-design-decisions:

Architectuur Beslissingen
=========================

.. _section-quality-scenarios:

Kwaliteits Requirements
=======================

.. _`_kwaliteits_boom`:

Kwaliteits Boom
---------------

.. _`_kwaliteits_scenarios`:

Kwaliteits Scenarios
--------------------

.. _section-technical-risks:

Risico’s en Technical Debt
==========================

.. _section-glossary:

Woordenlijst
============

+-----------------------+-----------------------------------------------+
| Term                  | Definitie                                     |
+=======================+===============================================+
| *<Term-1>*            | *<definitie-1>*                               |
+-----------------------+-----------------------------------------------+
| *<Term-2>*            | *<definitie-2>*                               |
+-----------------------+-----------------------------------------------+

.. |arc42| image:: images/arc42-logo.png
