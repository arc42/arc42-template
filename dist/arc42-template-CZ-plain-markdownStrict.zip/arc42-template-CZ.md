# 

**O arc42**

arc42, šablona pro dokumentaci softwaru a architekturu systému.

Verze šablony 8.1 CZ. (na základě AsciiDoc verze), říjen 2022

Created, maintained and © by Dr. Peter Hruschka, Dr. Gernot Starke and
contributors. Viz <https://arc42.org>.

# Úvod a cíle

## Přehled požadavků

## Kvalitativní cíle

## Strany zainteresované na systému (Stakeholder)

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Role/Jméno</th>
<th style="text-align: left;">Kontakt</th>
<th style="text-align: left;">Očekávání</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Role-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Kontakt-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Očekávání-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Role-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Kontakt-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Očekávání-2&gt;</em></p></td>
</tr>
</tbody>
</table>

# Omezení na realizaci systému

# Vymezení a rozsah systému

## Firemní kontext

**&lt;vložte diagram nebo tabulku>**

**&lt;(volitelně:) vložte vysvětlení externích doménových rozhraní>**

## Technický kontext

**&lt;vložte diagram nebo tabulku>**

**&lt;(volitelně:) vložte vysvětlení externích technických rozhraní>**

**&lt;mapování doménových vstupu/výstupu na technické kanály>**

# Strategie řešení

# Perspektiva stavebních bloků

## Celý systém jako white-box

***&lt;vložte přehledový diagram celého systému>***

Motivace  
*&lt;popište motivaci>*

Obsažené stavební bloky  
*&lt;popište obsažené stavební bloky (jako black-box)>*

Důležitá rozhraní  
*&lt;popište důležitá rozhraní>*

### &lt;Jméno black-boxu 1>

*&lt;Účel/Odpovědnost>*

*&lt;Rozhraní>*

*&lt;(Volitelně) Požadavky na kvalitu/výkon>*

*&lt;(Volitelně) Umístění/složky a soubory>*

*&lt;(Volitelně) Splněné požadavky>*

*&lt;(Volitelně) Nevyřešené body/problémy/rizika>*

### &lt;Jméno black-boxu 2>

*&lt;šablona black-box>*

### &lt;Jméno black-boxu n>

*&lt;šablona black-box>*

### &lt;Jméno rozhraní 1>

…

### &lt;Jméno rozhraní m>

## Úroveň 2

### white-box *&lt;stavební blok 1>*

*&lt;šablona white-box>*

### white-box *&lt;stavební blok 2>*

*&lt;šablona white-box>*

…

### white-box *&lt;stavební blok m>*

*&lt;šablona white-box>*

## Úroveň 3

### white-box &lt;\_stavební blok x.1\_&gt;

*&lt;šablona white-box>*

### white-box &lt;\_stavební blok x.2\_&gt;

*&lt;šablona white-box>*

### white-box &lt;\_stavební blok y.1\_&gt;

*&lt;šablona white-box>*

# Perspektiva chování za běhu (runtime)

## &lt;Scénář runtime 1>

-   *&lt;vložte runtime diagram nebo textový popis scénáře>*

-   *&lt;vložte popis důležitých interakcí mezi instancemi stavebních
    bloků zobrazených v tomto diagramu>*

## &lt;Scénář runtime 2>

## …

## &lt;Scénář runtime n>

# Perspektiva nasazení softwaru (deployment)

## Úroveň infrastruktury 1

***&lt;Přehledový diagram>***

Motivace  
*&lt;vysvětlení v textové podobě>*

Kvalitativní a/nebo výkonnostní vlastnosti  
*&lt;vysvětlení v textové podobě>*

Mapování softwarových artefaktů na prvky infrastruktury  
*&lt;popis mapování>*

## Úroveň infrastruktury 2

### *&lt;prvek infrastruktury 1>*

*&lt;diagram + vysvětlení>*

### *&lt;prvek infrastruktury 2>*

*&lt;diagram + vysvětlení>*

…

### *&lt;prvek infrastruktury n>*

*&lt;diagram + vysvětlení>*

# Průřezové (cross-cutting) koncepty

## *&lt;Koncept 1>*

*&lt;vysvětlení>*

## *&lt;Koncept 2>*

*&lt;vysvětlení>*

…

## *&lt;Koncept n>*

*&lt;vysvětlení>*

# Rozhodnutí o architektuře

# Požadavky na kvalitu

## Strom kvality

## Scénáře kvality

# Rizika a technické dluhy

# Slovník pojmů

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Termín</th>
<th style="text-align: left;">Definice</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;termín-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definice-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;termín-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definice-2&gt;</em></p></td>
</tr>
</tbody>
</table>
