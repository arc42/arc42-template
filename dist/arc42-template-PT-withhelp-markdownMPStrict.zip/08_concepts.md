# Conceitos Transversais

Conteúdo

Esta seção descreve globalmente, as principais regulamentações e ideias
de soluções que são relevantes em várias partes (= transversais) do seu
sistema. Esses conceitos geralmente estão relacionados a vários blocos
de construção. Eles podem incluir muitos tópicos diferentes, como

- modelos, especialmente modelos de domínio

- padrões de arquitetura ou *design patterns*

- regras para usar tecnologia específica

- principais decisões, geralmente técnicas, de natureza abrangente (=
  transversais)

- regras de implementação

Motivação

Os conceitos formam a base para a *integridade conceitual*
(consistência, homogeneidade) da arquitetura. Portanto, eles são uma
contribuição importante para atingir as qualidades internas do seu
sistema.

Alguns desses conceitos não podem ser atribuídos a blocos de construção
individuais, por exemplo segurança ou proteção.

Forma

A forma pode ser variada:

- documentos conceituais com qualquer tipo de estrutura

- trechos ou cenários de modelos transversais usando notações das
  visualizações de arquitetura

- amostra de implementações, especialmente para conceitos técnicos

- referência ao uso típico de *frameworks* padrão (por exemplo, usando
  Hibernate para mapeamento de objeto/relacional)

Estrutura

Uma estrutura potencial (mas não obrigatória) para esta seção poderia
ser:

- Conceitos de domínio

- Conceitos de Experiência do Usuário (UX)

- Conceitos de proteção e segurança

- Padrões de arquitetura e *design patterns*

- Estruturas internas

- Conceitos de desenvolvimento

- Conceitos operacionais

Observação: pode ser difícil atribuir conceitos individuais a um tópico
específico nesta lista.

<figure>
<img src="images/08-concepts-EN.drawio.png"
alt="Tópicos possíveis para conceitos transversais" />
</figure>

Mais informações

Veja [Concepts](https://docs.arc42.org/section-8/) na documentação do
arc42.

## *&lt;Conceito 1&gt;*

*&lt;explicação&gt;*

## *&lt;Conceito 2&gt;*

*&lt;explicação&gt;*

…​

## *&lt;Conceito n&gt;*

*&lt;explicação&gt;*
