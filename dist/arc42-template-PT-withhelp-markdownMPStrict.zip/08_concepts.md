# Conceitos Transversais

## *&lt;Conceito 1&gt;*

*&lt;explicação&gt;*

## *&lt;Conceito 2&gt;*

*&lt;explicação&gt;*

…​

## *&lt;Conceito n&gt;*

*&lt;explicação&gt;*
