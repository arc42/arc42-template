# Conceitos Transversais

## *&lt;Conceito 1>*

*&lt;explicação>*

## *&lt;Conceito 2>*

*&lt;explicação>*

…

## *&lt;Conceito n>*

*&lt;explicação>*
