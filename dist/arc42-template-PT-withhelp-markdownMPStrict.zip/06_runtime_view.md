# Visão de Tempo de Execução

## &lt;Cenário de Tempo de Execução 1&gt;

-   *&lt;inserir diagrama de tempo de execução ou descrição textual do
    cenário&gt;*

-   *&lt;inserir descrição dos aspectos notáveis ​​das interações entre as
    instâncias do bloco de construção descritas neste diagrama.&gt;*

## &lt;Cenário de Tempo de Execução 2&gt;

## …​

## &lt;Cenário de Tempo de Execução n&gt;
