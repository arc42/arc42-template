# Visão de Tempo de Execução

## &lt;Cenário de Tempo de Execução 1>

-   *&lt;inserir diagrama de tempo de execução ou descrição textual do
    cenário>*

-   *&lt;inserir descrição dos aspectos notáveis ​​das interações entre
    as instâncias do bloco de construção descritas neste diagrama.>*

## &lt;Cenário de Tempo de Execução 2>

## …

## &lt;Cenário de Tempo de Execução n>
