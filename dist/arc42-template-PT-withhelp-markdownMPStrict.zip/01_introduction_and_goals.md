# Introdução e Objetivos

## Visão Geral dos Requisitos

## Objetivos de Qualidade

## Partes Interessadas

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Função/Nome</th>
<th style="text-align: left;">Contato</th>
<th style="text-align: left;">Expectativas</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Função-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Contato-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Expectativa-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Função-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Contato-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Expectativa-2&gt;</em></p></td>
</tr>
</tbody>
</table>
