# Glossário

Conteúdo

Os termos técnicos e de domínio mais importantes que suas partes
interessadas usam ao discutir o sistema.

Você também pode ver o glossário como fonte para traduções se trabalhar
em equipes multilíngues.

Motivação

Você deve definir claramente seus termos, para que todas as partes
interessadas

- tenham um entendimento idêntico desses termos

- não usem sinônimos e homônimos

Forma

Uma tabela com colunas &lt;Termo&gt; e &lt;Definição&gt;.

Possivelmente mais colunas, caso precise de traduções.

Mais informações

Veja [Glossary](https://docs.arc42.org/section-12/) na documentação do
arc42.

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">Termo</th>
<th style="text-align: left;">Definição</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p><em>&lt;Termo-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definição-1&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"><p><em>&lt;Termo-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definição-2&gt;</em></p></td>
</tr>
</tbody>
</table>
