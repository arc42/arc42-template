**Sobre o arc42**

arc42, o template para documentação de software e arquitetura de
sistemas.

Versão do template {revnumber}. {revremark}, {revdate}

Criado, mantido e © pelo Dr. Peter Hruschka, Dr. Gernot Starke e
colaboradores. Veja <https://arc42.org>.
