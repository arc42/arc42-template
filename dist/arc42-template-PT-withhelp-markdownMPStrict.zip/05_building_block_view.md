# Visão de Blocos de Construção

Conteúdo

A visão de blocos de construção mostra a decomposição estática do
sistema em blocos (módulos, componentes, subsistemas, classes,
interfaces, pacotes, bibliotecas, frameworks, camadas, partições,
níveis, funções, macros, operações, estruturas de dados, …​) bem como
suas dependências (relacionamentos, associações, …​)

Esta visão é obrigatória para toda documentação de arquitetura. Em
analogia a uma casa, esta é a *planta baixa*.

Motivação

Mantenha uma visão geral do seu código-fonte tornando sua estrutura
compreensível por meio de abstração.

Isso permite que você se comunique com suas partes interessadas em um
nível abstrato sem revelar detalhes de implementação.

Forma

A visão de blocos de construção é uma coleção hierárquica de caixas
pretas e caixas brancas (veja a figura abaixo) e suas descrições.

<figure>
<img src="images/05_building_blocks-EN.png"
alt="Hierarquia de blocos de construção" />
</figure>

**Nível 1** é a descrição da caixa branca do sistema geral, juntamente
com descrições de caixa preta de todos os blocos de construção contidos.

**Nível 2** amplia alguns blocos de construção do nível 1. Portanto, ele
contém a descrição da caixa branca dos blocos de construção selecionados
do nível 1, juntamente com descrições de caixa preta de seus blocos de
construção internos.

**Nível 3** amplia os blocos de construção selecionados do nível 2, e
assim por diante.

Mais informações

Consulte [Building Block View](https://docs.arc42.org/section-5/) na
documentação do arc42.

## Visão Sistêmica Geral de Caixa Branca

Aqui você descreve a decomposição geral do sistema usando o seguinte
modelo de caixa branca. Ele contém

- um diagrama de visão geral

- uma motivação para a decomposição

- descrições de caixa preta dos blocos de construção contidos. Para
  isso, oferecemos alternativas:

  - use *uma* tabela para uma visão geral curta e pragmática de todos os
    blocos de construção contidos e suas interfaces

  - use uma lista de descrições de caixa preta dos blocos de construção
    de acordo com o modelo de caixa preta (veja abaixo). Dependendo da
    sua escolha de ferramenta, esta lista pode ser subcapítulos (em
    arquivos de texto), subpáginas (em uma Wiki) ou elementos aninhados
    (em uma ferramenta de modelagem).

- (opcional:) interfaces importantes, que não são explicadas nos modelos
  de caixa preta de um bloco de construção, mas são muito importantes
  para entender a caixa branca. Já que há tantas maneiras de especificar
  interfaces, por que não fornecer um modelo específico para elas? No
  pior caso, você tem que especificar e descrever sintaxe, semântica,
  protocolos, tratamento de erros, restrições, versões, qualidades,
  compatibilidades necessárias e muito mais. Na melhor das hipóteses,
  você conseguirá usar exemplos ou descrições simples.

***&lt;Diagrama de Visão Geral&gt;***

Motivação  
*&lt;explicação textual&gt;*

Blocos de Construção Contidos  
*&lt;Descrição dos blocos de construção contidos (caixas pretas)&gt;*

Interfaces Importantes  
*&lt;Descrição de interfaces importantes&gt;*

Insira suas explicações de caixas pretas do nível 1:

Se você usar a forma tabular, você descreverá apenas suas caixas pretas
com nome e responsabilidade de acordo com o seguinte esquema:

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;"><strong>Nome</strong></th>
<th style="text-align: left;"><strong>Responsabilidade</strong></th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p><em>&lt;caixa preta 1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Texto&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"><p><em>&lt;caixa preta 2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Texto&gt;</em></p></td>
</tr>
</tbody>
</table>

Se você usar uma lista de descrições de caixa preta, então você preenche
um modelo de caixa preta separado para cada bloco de construção
importante. Seu título é o nome da caixa preta.

### &lt;Nome Caixa Preta 1&gt;

Aqui você descreve &lt;caixa preta 1&gt; de acordo com o seguinte modelo
de caixa preta:

- Propósito/Responsabilidade

- Interface(s), quando não são extraídas como parágrafos separados.
  Essas interfaces podem incluir qualidades e características de
  desempenho.

- (Opcional) Características de qualidade/desempenho da caixa preta, por
  exemplo, disponibilidade, comportamento de tempo de execução, …​.

- (Opcional) Local do diretório/arquivo

- (Opcional) Requisitos atendidos (se você precisar de rastreabilidade
  para requisitos).

- (Opcional) Problemas/questões/riscos abertos

*&lt;Propósito/Responsabilidade&gt;*

*&lt;Interface(s)&gt;*

*&lt;(Opcional) Características de Qualidade/Desempenho&gt;*

*&lt;(Opcional) Local do Diretório/Arquivo&gt;*

*&lt;(Opcional) Requisitos Cumpridos&gt;*

*&lt;(opcional) Problemas/Riscos Abertos&gt;*

### &lt;Nome Caixa Preta 2&gt;

*&lt;modelo de caixa preta&gt;*

### &lt;Nome Caixa Preta n&gt;

*&lt;modelo de caixa preta&gt;*

### &lt;Nome Interface 1&gt;

…​

### &lt;Nome Interface m&gt;

## Nível 2

Aqui você pode especificar a estrutura interna de (alguns) blocos de
construção do nível 1 como caixas brancas.

Você tem que decidir quais blocos de construção do seu sistema são
importantes o suficiente para justificar uma descrição tão detalhada.
Por favor, prefira relevância à completude. Especifique blocos de
construção importantes, surpreendentes, arriscados, complexos ou
voláteis. Deixe de fora partes normais, simples, chatas ou padronizadas
do seu sistema

### Caixa Branca *&lt;Bloco de Construção 1&gt;*

…​descreve a estrutura interna do *bloco de construção 1*.

*&lt;modelo de caixa branca&gt;*

### Caixa Branca *&lt;Bloco de Construção 2&gt;*

*&lt;modelo de caixa branca&gt;*

…​

### Caixa Branca *&lt;Bloco de Construção m&gt;*

*&lt;modelo de caixa branca&gt;*

## Nível 3

Aqui você pode especificar a estrutura interna de (alguns) blocos de
construção do nível 2 como caixas brancas.

Quando precisar de níveis mais detalhados de sua arquitetura, copie esta
parte do arc42 para níveis adicionais.

### Caixa Branca &lt;\_Bloco de Construção x.1\_&gt;

Especifica a estrutura interna do *bloco de construção x.1*.

*&lt;modelo de caixa branca&gt;*

### Caixa Branca &lt;\_Bloco de Construção x.2\_&gt;

*&lt;modelo de caixa branca&gt;*

### Caixa Branca &lt;\_Bloco de Construção y.1\_&gt;

*&lt;modelo de caixa branca&gt;*
