# Visão de Blocos de Construção

## Visão Sistêmica Geral de Caixa Branca

***&lt;Diagrama de Visão Geral&gt;***

Motivação  
*&lt;explicação textual&gt;*

Blocos de Construção Contidos  
*&lt;Descrição dos blocos de construção contidos (caixas pretas)&gt;*

Interfaces Importantes  
*&lt;Descrição de interfaces importantes&gt;*

### &lt;Nome Caixa Preta 1&gt;

*&lt;Propósito/Responsabilidade&gt;*

*&lt;Interface(s)&gt;*

*&lt;(Opcional) Características de Qualidade/Desempenho&gt;*

*&lt;(Opcional) Local do Diretório/Arquivo&gt;*

*&lt;(Opcional) Requisitos Cumpridos&gt;*

*&lt;(opcional) Problemas/Riscos Abertos&gt;*

### &lt;Nome Caixa Preta 2&gt;

*&lt;modelo de caixa preta&gt;*

### &lt;Nome Caixa Preta n&gt;

*&lt;modelo de caixa preta&gt;*

### &lt;Nome Interface 1&gt;

…​

### &lt;Nome Interface m&gt;

## Nível 2

### Caixa Branca *&lt;Bloco de Construção 1&gt;*

*&lt;modelo de caixa branca&gt;*

### Caixa Branca *&lt;Bloco de Construção 2&gt;*

*&lt;modelo de caixa branca&gt;*

…​

### Caixa Branca *&lt;Bloco de Construção m&gt;*

*&lt;modelo de caixa branca&gt;*

## Nível 3

### Caixa Branca &lt;\_Bloco de Construção x.1\_&gt;

*&lt;modelo de caixa branca&gt;*

### Caixa Branca &lt;\_Bloco de Construção x.2\_&gt;

*&lt;modelo de caixa branca&gt;*

### Caixa Branca &lt;\_Bloco de Construção y.1\_&gt;

*&lt;modelo de caixa branca&gt;*
