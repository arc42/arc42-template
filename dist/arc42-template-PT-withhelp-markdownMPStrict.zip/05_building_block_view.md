# Visão de Blocos de Construção

## Visão Sistêmica Geral de Caixa Branca

***&lt;Diagrama de Visão Geral>***

Motivação  
*&lt;explicação textual>*

Blocos de Construção Contidos  
*&lt;Descrição dos blocos de construção contidos (caixas pretas)>*

Interfaces Importantes  
*&lt;Descrição de interfaces importantes>*

### &lt;Nome Caixa Preta 1>

*&lt;Propósito/Responsabilidade>*

*&lt;Interface(s)>*

*&lt;(Opcional) Características de Qualidade/Desempenho>*

*&lt;(Opcional) Local do Diretório/Arquivo>*

*&lt;(Opcional) Requisitos Cumpridos>*

*&lt;(opcional) Problemas/Riscos Abertos>*

### &lt;Nome Caixa Preta 2>

*&lt;modelo de caixa preta>*

### &lt;Nome Caixa Preta n>

*&lt;modelo de caixa preta>*

### &lt;Nome Interface 1>

…

### &lt;Nome Interface m>

## Nível 2

### Caixa Branca *&lt;Bloco de Construção 1>*

*&lt;modelo de caixa branca>*

### Caixa Branca *&lt;Bloco de Construção 2>*

*&lt;modelo de caixa branca>*

…

### Caixa Branca *&lt;Bloco de Construção m>*

*&lt;modelo de caixa branca>*

## Nível 3

### Caixa Branca &lt;\_Bloco de Construção x.1\_&gt;

*&lt;modelo de caixa branca>*

### Caixa Branca &lt;\_Bloco de Construção x.2\_&gt;

*&lt;modelo de caixa branca>*

### Caixa Branca &lt;\_Bloco de Construção y.1\_&gt;

*&lt;modelo de caixa branca>*
