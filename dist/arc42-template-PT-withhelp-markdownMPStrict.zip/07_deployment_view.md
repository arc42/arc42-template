# Visão de Implantação

## Nível de Infraestrutura 1

***&lt;Diagrama de Visão Geral&gt;***

Motivação  
*&lt;explicação em forma de texto&gt;*

Características de Qualidade e/ou Desempenho  
*&lt;explicação em forma de texto&gt;*

Mapeamento de Blocos de Construção para Infraestrutura  
*&lt;descrição do mapeamento&gt;*

## Nível de Infraestrutura 2

### *&lt;Elemento de Infraestrutura 1&gt;*

*&lt;diagrama + explicação&gt;*

### *&lt;Elemento de Infraestrutura 2&gt;*

*&lt;diagrama + explicação&gt;*

…​

### *&lt;Elemento de Infraestrutura n&gt;*

*&lt;diagrama + explicação&gt;*
