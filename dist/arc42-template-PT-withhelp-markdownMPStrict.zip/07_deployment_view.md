# Visão de Implantação

## Nível de Infraestrutura 1

***&lt;Diagrama de Visão Geral>***

Motivação  
*&lt;explicação em forma de texto>*

Características de Qualidade e/ou Desempenho  
*&lt;explicação em forma de texto>*

Mapeamento de Blocos de Construção para Infraestrutura  
*&lt;descrição do mapeamento>*

## Nível de Infraestrutura 2

### *&lt;Elemento de Infraestrutura 1>*

*&lt;diagrama + explicação>*

### *&lt;Elemento de Infraestrutura 2>*

*&lt;diagrama + explicação>*

…

### *&lt;Elemento de Infraestrutura n>*

*&lt;diagrama + explicação>*
