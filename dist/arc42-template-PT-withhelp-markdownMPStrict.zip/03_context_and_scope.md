# Contexto e Escopo

## Contexto Negocial

**&lt;Diagrama ou Tabela&gt;**

**&lt;opcionalmente: Explicação das interfaces de domínio externo&gt;**

## Contexto Técnico

**&lt;Diagrama ou Tabela&gt;**

**&lt;opcionalmente: Explicação das interfaces técnicas&gt;**

**&lt;Mapeamento de entrada/saída para canais&gt;**
