# Contexto e Escopo

Conteúdo

Contexto e escopo - como o nome sugere - delimita seu sistema (ou seja,
seu escopo) de todos os seus parceiros de comunicação (sistemas e
usuários vizinhos, ou seja, o contexto do seu sistema). Ele especifica,
portanto, as interfaces externas.

Se necessário, diferencie o contexto de negócios (entradas e saídas
específicas do domínio) do contexto técnico (canais, protocolos,
hardware).

Motivação

As interfaces de domínio e as interfaces técnicas para componentes
externos estão entre os aspectos mais críticos do seu sistema.
Certifique-se de entendê-las completamente.

Forma

Várias opções:

- Diagramas de contexto

- Listas de componentes externos e suas interfaces.

Mais informações

Consulte [Context and Scope](https://docs.arc42.org/section-3/) na
documentação do arc42.

## Contexto Negocial

Conteúdo

Especificação de **todos** os componentes externos (usuários, sistemas
de TI, …​) com explicações de entradas e saídas ou interfaces específicas
do domínio. Opcionalmente, você pode adicionar formatos específicos do
domínio ou protocolos de comunicação.

Motivação

Todas as partes interessadas devem entender quais dados são trocados com
o ambiente do sistema.

Forma

Todos os tipos de diagramas que mostram o sistema como uma caixa preta e
especificam as interfaces de domínio para os componentes externos.

Como alternativa (ou adicionalmente), você pode usar uma tabela. O
título da tabela é o nome do seu sistema, as três colunas contêm o nome
do componente externo, as entradas e as saídas.

**&lt;Diagrama ou Tabela&gt;**

**&lt;opcionalmente: Explicação das interfaces de domínio externo&gt;**

## Contexto Técnico

Conteúdo

Interfaces técnicas (canais e mídias de transmissão) que vinculam seu
sistema ao seu ambiente. Além disso, um mapeamento de entrada/saída
específica de domínio para os canais, ou seja, uma explicação de qual
E/S usa qual canal.

Motivação

Muitas partes interessadas tomam decisões arquiteturais com base nas
interfaces técnicas entre o sistema e seu contexto. Especialmente os
designers de infraestrutura ou hardware decidem essas interfaces
técnicas.

Forma

Por exemplo, diagrama de implantação UML descrevendo canais para
sistemas vizinhos, junto com uma tabela de mapeamento mostrando os
relacionamentos entre canais e entrada/saída.

**&lt;Diagrama ou Tabela&gt;**

**&lt;opcionalmente: Explicação das interfaces técnicas&gt;**

**&lt;Mapeamento de entrada/saída para canais&gt;**
