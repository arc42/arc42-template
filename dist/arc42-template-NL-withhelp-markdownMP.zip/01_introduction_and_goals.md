# Introductie en Doelen {#section-introduction-and-goals}

:::: sidebar
::: title
:::

Beschrijft de relevante requirements en het krachtenveld waar software
architecten en het development team rekening mee moeten houden. Die
bestaan onder ander uit

- het begrijpen van de achterliggende doelen van de business,

- essentiele features,

- essentiele functionele requirements,

- kwaliteits doelen voor de architectuur en

- relevante belanghebbenden en hun verwachtingen
::::

## Requirements Overzicht {#_requirements_overzicht}

:::::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Inhoud
:::

Korte beschrijven van de functionele requirements, drijvende krachten,
uittreksel (of samenvatting) van de requirements. Verwijzing naar de
(hopelijk bestaande) requirements documentatie (met versie nummer en
informatie waar deze te vinden is).
::::

:::: formalpara
::: title
Motivatie
:::

Vanuit het perspectief van de eind gebruikers is een systeem ontwikkeld
of aangepast om een business activiteit beter te ondersteunen en/of om
de kwaliteit van die activiteit te verbeteren.
::::

:::: formalpara
::: title
Vorm
:::

Korte textuele beschrijving, mogelijk in use-case tabel formaat. Dit
overzichts document moet naar het requirements document verwijzen (als
dat bestaat).
::::

Houd deze uittreksels zo kort mogelijk. Zoek een evenwicht tussen
leesbaarheid van dit document en mogelijke dubbelingen met betrekking
tot het requirements document.

:::: formalpara
::: title
Verdere Informatie
:::

Zie [Introductie en Doelen](https://docs.arc42.org/section-1/) in de
arc42 documentatie.
::::
::::::::::::

## Kwaliteits Doelen {#_kwaliteits_doelen}

:::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Inhoud
:::

De top drie (max vijf) kwaliteits doelen aan de architectuur waarvan het
behalen van het grootste belang is voor de primaire belanghebbenden.
::::

We bedoelen hier echt kwaliteits doelen voor de architectuur. Niet te
verwarren met project doelen.

Overweeg dit overzicht met mogelijke onderwerpen (gebaseerd op de ISO
25010 standaard):

![Categorieen van mogelijke Kwaliteits
Requirements](images/01_2_iso-25010-topics-EN-2023.drawio.png)

:::: formalpara
::: title
Motivatie
:::

Het is belangrijk de kwaliteits doelen van je belangrijkste
belanghebbenden te kennen omdat deze invloed hebben op fundamentele
architectuur keuzes. Denk eraan heel concreet te zijn over deze
kwaliteiten, vermijd modewoorden. Alsof je als architect niet weet hoe
de kwaliteit van je werk beoordeeld zal worden...​
::::

:::: formalpara
::: title
Vorm
:::

Een tabel met kwaliteits doelen en concrete scenarios, gesorteerd op
prioriteit.
::::
::::::::::

## Belanghebbenden {#_belanghebbenden}

:::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Inhoud
:::

Expliciet overzicht van belanghebbenden van het systeem, dat wil zeggen
alle personen, rollen of oranisaties die
::::

- de architectuur moeten kennen

- van de architectuur overtuigd moeten worden

- met de architectuur of code moeten werken

- de documentatie van de architectuur nodig hebben voor hun werk

- beslissingen moeten maken over het systeem of de ontwikkeling daarvan

:::: formalpara
::: title
Motivatie
:::

Alle partijen die betrokken zijn bij de ontwikkeling of anderzinds
geraakt worden door het systeem moeten bekend zijn. Anders kan dat later
in het ontwikkelings proces tot nare verassingen zorgen. Deze
belanghebbenden bepalen in een grote mate de omvang en het detail niveau
van de werkzaameheden en de resultaten.
::::

:::: formalpara
::: title
Vorm
:::

Tabel met de rollen, personen en hun verwachting met betrekking tot de
architectuur en haar documentatie.
::::
::::::::::

+-------------+---------------------------+---------------------------+
| Rol/Naam    | Contact persoon           | Verwachtingen             |
+=============+===========================+===========================+
| *\<Rol-1\>* | *\<Contact-1\>*           | *\<Verwachting-1\>*       |
+-------------+---------------------------+---------------------------+
| *\<Rol-2\>* | *\<Contact-2\>*           | *\<Verwachting-2\>*       |
+-------------+---------------------------+---------------------------+
