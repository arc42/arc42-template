# Woordenlijst {#section-glossary}

:::::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Inhoud
:::

De belangrijkste domein en technische termen die belanghebbenden
gebruiken tijdens het bespreken van het systeem.
::::

De woordenlijst kan ook als bron voor vertaalde termen worden gebruikt
bij meertalige teams.

:::: formalpara
::: title
Motivatie
:::

Termen moeten helder worden gedefinieerd zodat alle belanghebbenden
::::

- een gemeenschappelijk en eenduidig begrip hebben van deze termen

- geen gebruik maken van synoniemen of homoniemen

<div>

::: title
Vorm
:::

- Een tabel met kolommen \<Term\> en \<Definitie\>.

- Eventueel meerdere kolommen als er vertalingen nodig zijn.

</div>

:::: formalpara
::: title
Verdere Informatie
:::

See [Glossary](https://docs.arc42.org/section-12/) in the arc42
documentation.
::::
::::::::::::

+----------------------+-----------------------------------------------+
| Term                 | Definitie                                     |
+======================+===============================================+
| *\<Term-1\>*         | *\<definitie-1\>*                             |
+----------------------+-----------------------------------------------+
| *\<Term-2\>*         | *\<definitie-2\>*                             |
+----------------------+-----------------------------------------------+
