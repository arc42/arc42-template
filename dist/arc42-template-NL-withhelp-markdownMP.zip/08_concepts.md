# Cross-cutting Concepten {#section-concepts}

:::::::::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Inhoud
:::

Dit deel beschrijft uitgangspunten en concepten die relevant zijn voor
meerdere delen (=cross-cutting) van het systeem. Dergelijke concepten
zijn vaak van toepassing op meerdere bouwstenen. Ze kunnen meerdere
onderwerpen beslaan, zoals
::::

- modellen, in het bijzonder domein modellen

- architectuur of design patterns

- regels om specifiek technologie te gebruiken

- uitgangspunten, vaak technische afspraken van overkoepelende aard (=
  cross-cutting) aard

- implementatie regels

:::: formalpara
::: title
Motivatie
:::

Concepten vormen de basis van *conceptuele integriteit* (consistentie en
homogeniteit) van de architectuur. Zodoende vormen ze een belangrijk
hulpmiddel om de innerlijke kenmerken van de architectuur vast te
leggen.
::::

Sommige van deze concepten kunnen niet toegekend worden aan individuele
bouwstenen, e.g. security of veiligheid.

:::: formalpara
::: title
Vorm
:::

De vorm kan varieeren:
::::

- concept papers die een structuur beschrijven

- cross-cutting model uittreksels of scenarios waarbij gebruik wordt
  gemaakt van architectuur views

- voorbeeld implementaties, specifiek voor technische concepten

- referenties naar typerend gebruik van standaard frameworks (e.g.
  Hibernate gebruiken voor object/relational mapping)

:::: formalpara
::: title
Structuur
:::

Een mogelijke (maar niet verplicht) structuur van deze paragraaf zou
kunnen bestaan uit:
::::

- Domein concepten

- User Experience concepten (UX)

- Veiligheid en security concepten

- Architectuur en design patterns

- \"Under-de-motorkap\"

- ontwikkel concepten

- operationele concepten

:::: note
::: title
:::

het kan moeilijk zijn om individuele concepten toe te kennen aan een
specifiek onderwerp van deze lijst
::::

![Mogelijke onderwerpen voor cross-cutting
concepten](images/08-concepts-EN.drawio.png)

:::: formalpara
::: title
Verdere informatie
:::

Zie [Concepts](https://docs.arc42.org/section-8/) in de arc42
documentatie.
::::
::::::::::::::::

## *\<Concept 1\>* {#_concept_1}

*\<uitleg\>*

## *\<Concept 2\>* {#_concept_2}

*\<uitleg\>*

...​

## *\<Concept n\>* {#_concept_n}

*\<uitleg\>*
