# Risico's en Technical Debt {#section-technical-risks}

:::::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Inhoud
:::

Een op prioriteit gesorteerde lijst, met bekende technische risico's en
technical dept.
::::

:::: formalpara
::: title
Motivatie
:::

"Risk management is project management for grown-ups" (Tim Lister,
Atlantic Systems Guild.)
::::

Dit zou het motto moeten zijn bij het systematisch bepalen en evalueren
van risico's en technical dept in de architectuur. Management
stakeholder (bijvoorbeeld project managers of project owners) hebben dit
inzicht nodig om keuzes te kunnen maken met betrekking tot risico en
planning.

:::: formalpara
::: title
Vorm
:::

Lijst van risico's en/of technical dept eventueel aangevuld met
maatregelen om deze te minimaliseren, verzachten of te vermijden.
::::

:::: formalpara
::: title
Verdere Informatie
:::

Zie [Risks and Technical Debt](https://docs.arc42.org/section-11/) in de
arc42 documentatie.
::::
::::::::::::
