---
date: 2026 年 9 月
title: "![arc42](images/arc42-logo.png) 範本"
---

# 

**關於 arc42**

arc42，用於記錄軟體與系統架構的範本。

範本版本 9.0-ZH-TW。(以 AsciiDoc 為基礎的版本)，2026 年 9 月

由 Dr. Peter Hruschka、Dr. Gernot Starke
及其他貢獻者建立、維護並持有著作權。 參見 <https://arc42.org。>

<div class="sidebar">

<div class="title">

</div>

> [!NOTE]
> 此版本的範本包含說明與解釋文字。 這些內容用於協助熟悉 arc42
> 並理解相關概念。 若要記錄您自己的系統，建議使用不含說明文字的 *精簡*
> 版本。

</div>

# 簡介與目標

<div class="sidebar">

<div class="title">

</div>

描述軟體架構師與開發團隊必須考量的相關需求與驅動因素。 這些包括：

- 核心業務目標

- 核心功能

- 核心功能需求

- 架構的品質目標

- 相關利害關係人及其期望

</div>

## 需求概述

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

內容

</div>

功能需求、驅動因素，以及需求摘錄（或摘要）的簡短描述。
連結至（現有的）需求文件，並標示版本號及文件存放位置。

</div>

<div class="formalpara">

<div class="title">

動機

</div>

從最終使用者的角度來看，建立或修改系統，是為了改善對業務活動的支援和/或提升品質。

</div>

<div class="formalpara">

<div class="title">

形式

</div>

簡短的文字描述，可能採用表格式使用案例格式。
如果存在需求文件，此概述應引用這些文件。

</div>

保持這些摘要儘可能簡短，並在本文件的可讀性與需求文件可能出現的冗餘之間取得平衡。

<div class="formalpara">

<div class="title">

更多資訊

</div>

參見 arc42 文件中的 [簡介與目標](https://docs.arc42.org/section-1/)。

</div>

</div>

## 品質目標

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

內容

</div>

架構需要滿足主要利害關係人最重要的前三個（最多五個）品質目標，且這些目標的達成具有最高優先順序。
我們真正指的是架構本身的品質目標。請不要將它們與專案目標混為一談，兩者不一定相同。

</div>

請參考以下依 ISO 25010 標準整理的潛在主題概述：

<figure>
<img src="images/01_2_iso-25010-topics-ZH-TW-2023.png"
alt="品質需求類別" />
</figure>

<div class="formalpara">

<div class="title">

動機

</div>

您應了解最重要利害關係人的品質目標，因為這些目標會影響基本的架構決策。
請務必具體描述這些品質，避免使用空泛的流行術語。
如果身為架構師的您不知道工作品質將如何被評估……

</div>

<div class="formalpara">

<div class="title">

形式

</div>

包含品質目標與具體情境、並依優先順序排列的表格。

</div>

</div>

## 利害關係人

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

內容

</div>

系統利害關係人的明確概述，即所有人員、角色或組織：

</div>

- 應了解架構的人

- 必須認同架構的人

- 必須使用架構或程式碼工作的人

- 工作需要依賴架構文件的人

- 必須針對系統或其開發做出決策的人

<div class="formalpara">

<div class="title">

動機

</div>

您應了解所有參與系統開發或受系統影響的相關方，否則在開發流程後期，可能會遇到棘手的意外。
這些利害關係人會決定您的工作及其成果應涵蓋的範圍與詳細程度。

</div>

<div class="formalpara">

<div class="title">

形式

</div>

包含角色名稱、人員姓名，以及他們對架構文件的期望之表格。
請勿在此重複利害關係人的功能需求與品質需求，並在此處說明他們對文件的需求。

</div>

<div class="formalpara">

<div class="title">

範例

</div>

以下利害關係人角色會在許多專案中反覆出現。請以此作為起點，再依實際專案調整角色、名稱與期望。
並非每個專案都包含所有這些角色，有些專案也可能有其他角色。

</div>

| 角色/姓名 | 聯絡方式 | 期望 |
|----|----|----|
| 產品負責人 | 產品管理團隊 | 依據業務價值排列功能優先順序；需要確保第 1 節（需求概述、品質目標）與產品策略保持一致 |
| 最終使用者/客戶 | 透過使用者體驗研究、支援工單等方式代表 | 需要系統易於使用、可靠且快速；推動效能與易用性等品質目標 |
| 軟體架構師 | 架構團隊 | 負責維護本文件，並使用本文件說明及溝通技術決策 |
| 開發團隊 | 工程團隊 | 需要清楚的建構模組（第 5 節）與執行階段情境（第 6 節），以正確實作系統 |
| 維運/SRE | 維運團隊 | 需要部署視圖（第 7 節）與橫切概念（第 8 節，例如監控、日誌記錄），以可靠地執行系統 |
| 資安長/資訊安全 | 資安團隊 | 依據風險（第 11 節）與品質需求（第 10 節）審查架構；需要確認安全性限制已獲得處理的證據 |
| 法令遵循/法務 | 法務/法令遵循團隊 | 需要確認法規限制（第 2 節）已獲遵守的證據，例如資料保護、授權條款 |
| 專案發起人/管理階層 | 指導委員會 | 需要確認架構決策（第 9 節）能支援預算、時程與策略目標 |

</div>

| 角色/姓名    | 聯絡方式         | 期望         |
|--------------|------------------|--------------|
| *\<角色-1\>* | *\<聯絡方式-1\>* | *\<期望-1\>* |
| *\<角色-2\>* | *\<聯絡方式-2\>* | *\<期望-2\>* |

# 架構限制

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

內容

</div>

任何會限制軟體架構師在設計與實作決策，或開發流程決策上的自由度之要求。這些限制有時不只適用於個別系統，也適用於整個組織與公司。

</div>

<div class="formalpara">

<div class="title">

動機

</div>

架構師應清楚知道哪些設計決策可以自由決定，以及哪些地方必須遵守限制。
這些限制都必須加以處理；不過，其中有些限制可能仍有協商空間。

</div>

<div class="formalpara">

<div class="title">

形式

</div>

附有說明的簡單限制表格。
如有需要，您可以將其細分為技術限制、組織與政治限制，以及慣例（例如程式設計或版本控制指南、文件或命名慣例）。

</div>

<div class="formalpara">

<div class="title">

更多資訊

</div>

參見 arc42 文件中的 [架構限制](https://docs.arc42.org/section-2/)。

</div>

</div>

# 脈絡與範圍

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

內容

</div>

脈絡與範圍，顧名思義，就是將您的系統（即您的範圍）與所有通訊方（周邊系統與使用者，也就是您系統的脈絡）區隔開來，藉此界定外部介面。
如有必要，請區分業務脈絡（特定領域的輸入與輸出）與技術脈絡（通道、通訊協定、硬體）。

</div>

<div class="formalpara">

<div class="title">

動機

</div>

與通訊方的領域介面和技術介面是系統最關鍵的部分，請確保您完全了解它們。

</div>

<div class="formalpara">

<div class="title">

形式

</div>

有以下幾種選擇：

</div>

- 系統脈絡圖

- 通訊方及其介面清單

<div class="formalpara">

<div class="title">

更多資訊

</div>

參見 arc42 文件中的 [脈絡與範圍](https://docs.arc42.org/section-3/)。

</div>

</div>

## 業務脈絡

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

內容

</div>

說明**所有**通訊方（例如使用者、IT
系統等），以及特定領域的輸入與輸出或介面。
您可以選擇新增特定領域的格式或通訊協定。

</div>

<div class="formalpara">

<div class="title">

動機

</div>

所有利害關係人都應了解哪些資料在系統與其環境之間交換。

</div>

<div class="formalpara">

<div class="title">

形式

</div>

使用各種圖表，將系統呈現為黑箱，並說明與通訊方之間的領域介面。
或者（或另外）使用表格。表格標題為系統名稱，三個欄位分別為通訊方名稱、輸入與輸出。

</div>

</div>

**\<圖表或表格\>**

**\<可選：外部領域介面的說明\>**

## 技術脈絡

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

內容

</div>

技術介面（通道與傳輸媒體）將您的系統與其環境連接起來。此外，還要將特定領域的輸入/輸出對應至通道，也就是說明哪些輸入/輸出使用哪些通道。

</div>

<div class="formalpara">

<div class="title">

動機

</div>

許多利害關係人會根據系統與其脈絡之間的技術介面做出架構決策。特別是基礎設施或硬體設計師會決定這些技術介面。

</div>

<div class="formalpara">

<div class="title">

形式

</div>

例如，使用 UML
部署圖描述連接至周邊系統的通道，並附上說明通道與輸入/輸出之間關係的對應表。

</div>

</div>

**\<圖表或表格\>**

**\<可選：技術介面的說明\>**

**\<輸入、輸出與通道之間的對應關係\>**

# 解決方案策略

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

內容

</div>

簡要總結並說明形塑系統架構的基本決策與解決方案策略。內容包括：

</div>

- 技術決策

- 系統頂層分解的決策，例如採用架構模式或設計模式

- 如何達成關鍵品質目標的決策

- 相關的組織決策，例如選擇開發流程或將特定任務委託給第三方

<div class="formalpara">

<div class="title">

動機

</div>

這些決策構成您架構的基石，也是許多其他詳細決策或實作規則的基礎。

</div>

<div class="formalpara">

<div class="title">

形式

</div>

請簡短說明這些關鍵決策，以及做出這些決策的原因。
說明應以問題敘述、品質目標與關鍵限制為基礎，並參閱以下章節中的詳細內容。

</div>

<div class="formalpara">

<div class="title">

更多資訊

</div>

參見 arc42 文件中的 [解決方案策略](https://docs.arc42.org/section-4/)。

</div>

</div>

# 建構模組視圖

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

內容

</div>

建構模組視圖顯示系統靜態分解為建構模組（模組、元件、子系統、類別、介面、套件、函式庫、框架、層、分區、階層、函式、巨集、操作、資料結構……），以及這些建構模組之間的相依關係（關係、關聯……）。

</div>

這個視圖是每份架構文件的必要內容。 若以房屋來比喻，它相當於 *平面圖*。

<div class="formalpara">

<div class="title">

動機

</div>

藉由抽象化讓原始程式碼的結構更容易理解，維持對原始程式碼的整體掌握。

</div>

如此一來，您就能在抽象層級與利害關係人溝通，而不揭露實作細節。

<div class="formalpara">

<div class="title">

形式

</div>

建構模組視圖是黑箱與白箱的階層集合（見下圖），以及對這些黑箱與白箱的描述。

</div>

<figure>
<img src="images/05_building_blocks-ZH-TW.png" alt="建構模組階層" />
</figure>

**層級 1** 是整體系統的白箱描述，以及所有包含之建構模組的黑箱描述。

**層級 2** 深入說明層級 1 中的部分建構模組。因此，它包含層級 1
中所選建構模組的白箱描述，以及其內部建構模組的黑箱描述。

**層級 3** 深入說明層級 2 中所選的建構模組，依此類推。

<div class="formalpara">

<div class="title">

更多資訊

</div>

參見 arc42 文件中的 [建構模組視圖](https://docs.arc42.org/section-5/)。

</div>

</div>

## 整體系統白箱

<div class="sidebar">

<div class="title">

</div>

在此，您使用以下白箱範本描述整體系統的分解。內容包括：

- 概覽圖

- 分解的動機

- 所包含建構模組的黑箱描述。對此，我們提供以下替代方案：

  - 使用 *一個* 表格，簡短且務實地概覽所有包含的建構模組及其介面

  - 依照黑箱範本（見下文）列出建構模組的黑箱描述。依您選擇的工具，此清單可以是子章節（在文字文件中）、子頁面（在
    Wiki 中）或巢狀元素（在建模工具中）。

- （選用）重要介面。這些介面未在建構模組的黑箱範本中說明，但對理解白箱非常重要。

由於介面有許多不同的描述方式，因此我們不提供特定的介面範本。
在最壞的情況下，您必須指定並描述語法、語意、通訊協定、錯誤處理、限制、版本、品質、必要的相容性，以及許多其他內容。
在最理想的情況下，您可能只需透過範例或簡單的簽章即可完成說明。

</div>

***\<概覽圖\>***

動機  
*\<文字說明\>*

包含的建構模組  
*\<所包含建構模組（黑箱）的描述\>*

重要介面  
*\<重要介面的描述\>*

<div class="sidebar">

<div class="title">

</div>

插入層級 1 黑箱的說明：

如果您使用表格形式，請依照以下格式，僅描述黑箱的名稱與職責：

| **名稱**     | **職責**   |
|--------------|------------|
| *\<黑箱 1\>* | *\<文字\>* |
| *\<黑箱 2\>* | *\<文字\>* |

如果您使用黑箱描述清單，請為每個重要建構模組填寫一份獨立的黑箱範本，其標題就是黑箱的名稱。

</div>

### \<黑箱 1 的名稱\>

<div class="sidebar">

<div class="title">

</div>

在此，依照以下黑箱範本描述 \<黑箱 1\>：

- 目的/職責

- 介面（一個或多個）；如果介面未另立段落，請在此列出。介面可能包含品質與效能特徵。

- （選用）黑箱的品質/效能特徵，例如可用性、執行階段行為等

- （選用）目錄/檔案位置

- （選用）已滿足的需求（如果需要建立需求追溯性）

- （選用）未解決的議題/問題/風險

</div>

*\<目的/職責\>*

*\<介面（一個或多個）\>*

*\<(選用) 品質/效能特徵\>*

*\<(選用) 目錄/檔案位置\>*

*\<(選用) 已滿足的需求\>*

*\<(選用) 未解決的議題/問題/風險\>*

### \<黑箱 2 的名稱\>

*\<黑箱範本\>*

### \<黑箱 n 的名稱\>

*\<黑箱範本\>*

### \<介面 1 的名稱\>

…​

### \<介面 m 的名稱\>

## 層級 2

<div class="sidebar">

<div class="title">

</div>

在此，您可以將層級 1 中部分建構模組的內部結構以白箱方式詳細描述。

您必須決定系統中哪些建構模組重要到足以進行如此詳細的描述。
請以相關性而非完整性為優先，指定重要、令人意外、具有風險、複雜或易變動的建構模組。
省略系統中一般、簡單、乏味或標準化的部分。

</div>

### 白箱 *\<建構模組 1\>*

<div class="sidebar">

<div class="title">

</div>

……描述 *建構模組 1* 的內部結構。

</div>

*\<白箱範本\>*

### 白箱 *\<建構模組 2\>*

*\<白箱範本\>*

…​

### 白箱 *\<建構模組 m\>*

*\<白箱範本\>*

## 層級 3

<div class="sidebar">

<div class="title">

</div>

在此，您可以將層級 2 中部分建構模組的內部結構以白箱方式詳細描述。

如果需要更詳細的架構層級，請複製 arc42 的這個部分，以建立其他層級。

</div>

### 白箱 \<\_建構模組 x.1\_\>

<div class="sidebar">

<div class="title">

</div>

說明 *建構模組 x.1* 的內部結構。

</div>

*\<白箱範本\>*

### 白箱 \<\_建構模組 x.2\_\>

*\<白箱範本\>*

### 白箱 \<\_建構模組 y.1\_\>

*\<白箱範本\>*

# 執行階段視圖

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

內容

</div>

執行階段視圖以情境形式描述系統建構模組的具體行為與互動，涵蓋以下領域：

</div>

- 重要使用案例或功能：建構模組如何執行這些使用案例或功能？

- 關鍵外部介面的互動：建構模組如何與使用者及相鄰系統協作？

- 操作與管理：啟動、啟動程序、停止

- 錯誤與例外情境

備註：選擇可能情境（序列、工作流程）的主要標準是其
**架構相關性**。描述大量情境並不重要；您應記錄具代表性的選擇。

<div class="formalpara">

<div class="title">

動機

</div>

您應了解系統建構模組（實例）如何在執行階段完成工作並彼此通訊。
您主要在文件中記錄情境，以向較不願意或無法閱讀與理解靜態模型（建構模組視圖、部署視圖）的利害關係人傳達您的架構。

</div>

<div class="formalpara">

<div class="title">

形式

</div>

有許多描述情境的表示法，例如：

</div>

- 以自然語言撰寫的編號步驟清單

- 活動圖或流程圖

- 序列圖

- BPMN 或 EPC（事件流程鏈）

- 狀態機

- …​

<div class="formalpara">

<div class="title">

更多資訊

</div>

參見 arc42 文件中的 [執行階段視圖](https://docs.arc42.org/section-6/)。

</div>

</div>

## \<執行階段情境 1\>

- *\<插入情境的執行階段圖或文字描述\>*

- *\<插入此圖中建構模組實例之間互動關係的重要事項\>*

## \<執行階段情境 2\>

## …​

## \<執行階段情境 n\>

# 部署視圖

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

內容

</div>

部署視圖描述：

</div>

1.  用來執行系統的技術基礎設施，包括地理位置、環境、電腦、處理器、通道、網路拓撲，以及其他基礎設施要素。

2.  將（軟體）建構模組對應至這些基礎設施要素。

系統通常會在不同環境中執行，例如開發環境、測試環境與生產環境。在這種情況下，您應記錄所有相關環境。

尤其當您的軟體以分散式系統的形式，在多台電腦、處理器、伺服器或容器上執行，或是當您設計與建構自己的硬體處理器和晶片時，更應記錄部署視圖。

從軟體角度來看，只需記錄足以呈現建構模組部署的基礎設施要素即可。硬體架構師則可以進一步依其所需的詳細程度描述基礎設施。

<div class="formalpara">

<div class="title">

動機

</div>

沒有硬體，軟體就無法執行。
這個底層基礎設施會影響系統和/或某些橫切概念。因此，有必要了解這些基礎設施。

</div>

<div class="formalpara">

<div class="title">

形式

</div>

最高層級的部署圖可能已經包含在第 3.2
節的技術脈絡中，並將您自己的基礎設施視為一個黑箱。在本節中，可以使用額外的部署圖深入說明這個黑箱：

</div>

- UML
  提供部署圖來表達此視圖。當您的基礎設施較為複雜時，可以使用部署圖，可能還需要使用巢狀圖。

- 如果您的硬體利害關係人偏好其他類型的圖表，而不是部署圖，請讓他們使用任何能夠呈現基礎設施節點與通道的圖表。

<div class="formalpara">

<div class="title">

更多資訊

</div>

參見 arc42 文件中的 [部署視圖](https://docs.arc42.org/section-7/)。

</div>

</div>

## 基礎設施層級 1

<div class="sidebar">

<div class="title">

</div>

描述（通常結合圖表、表格與文字）：

- 系統分佈至多個地點、環境、電腦、處理器等的位置，以及它們之間的實體連線

- 這種部署結構的重要理由或動機

- 此基礎設施的品質與/或效能特徵

- 將軟體產出物對應至此基礎設施的各項要素

如果有多個環境或替代部署，請為所有相關環境複製並調整 arc42 的此部分。

</div>

***\<概覽圖\>***

動機  
*\<文字形式的說明\>*

品質與/或效能特徵  
*\<文字形式的說明\>*

建構模組對應至基礎設施  
*\<對應關係的描述\>*

## 基礎設施層級 2

<div class="sidebar">

<div class="title">

</div>

在此，您可以納入層級 1 中部分基礎設施要素的內部結構。

請針對每個選定的要素，複製層級 1 的結構。

</div>

### *\<基礎設施要素 1\>*

*\<圖表 + 解釋\>*

### *\<基礎設施要素 2\>*

*\<圖表 + 解釋\>*

…​

### *\<基礎設施要素 n\>*

*\<圖表 + 解釋\>*

# 橫切概念

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

內容

</div>

本節描述橫切概念（實務、模式、規範或解決方案構想）。這些概念通常與多個建構模組相關。
它們可能涵蓋許多不同主題，如下圖所示：

</div>

<figure>
<img src="images/08-concepts-ZH-TW.png" alt="橫切概念的潛在主題" />
</figure>

<div class="formalpara">

<div class="title">

動機

</div>

概念構成架構 *概念完整性*（一致性、同質性）的基礎。
因此，它們是實現系統內在品質的重要貢獻。

</div>

這是範本中用來集中且一致地規範此類概念的位置。

許多概念會涉及或影響您的多個建構模組。

<div class="formalpara">

<div class="title">

形式

</div>

形式可以多樣：

</div>

- 具有任何結構的概念文件

- 實作範例，特別是技術概念

- 使用架構視圖標記的橫切模型摘錄或情境

<div class="formalpara">

<div class="title">

結構

</div>

僅為您的系統挑選 **最必要的**
主題，並在本節中為每個主題設定第二層標題（例如 8.1、8.2 等）。

</div>

請勿 **試圖** 涵蓋上述圖表中的所有主題。

<div class="formalpara">

<div class="title">

更多資訊

</div>

系統內的某些主題通常涉及多個建構模組、硬體元素或開發流程。 將此類 *橫切*
主題集中在一個中央位置傳達或記錄，可能比在相關建構模組、硬體元素或開發流程的描述中重複說明更容易。

</div>

某些概念可能涉及系統的 **所有** 元素，其他概念可能僅與少數元素相關。
在上圖中，日誌記錄涉及全部三個元件，而安全性僅與其中兩個元件相關。

參見 arc42 文件中的 [概念](https://docs.arc42.org/section-8/)。

</div>

## *\<概念 1\>*

*\<解釋\>*

## *\<概念 2\>*

*\<解釋\>*

…​

## *\<概念 n\>*

*\<解釋\>*

# 架構決策

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

內容

</div>

重要、成本高、規模大或風險高的架構決策及其理由。
我們所說的「決策」是指基於既定標準選擇替代方案。

</div>

請自行判斷架構決策是否應記錄在此中央章節，或是更適合在本地記錄（例如，記錄在某個建構模組的白箱範本中）。

避免重複。 參見第 4 節，您已在該處記錄架構最重要的決策。

<div class="formalpara">

<div class="title">

動機

</div>

您系統的利害關係人應能理解並追溯您的決策。

</div>

<div class="formalpara">

<div class="title">

形式

</div>

各種選擇：

</div>

- 為每個重要決策撰寫一份 ADR（架構決策紀錄，參見 [Documenting
  Architecture
  Decisions](https://cognitect.com/blog/2011/11/15/documenting-architecture-decisions)）

- 依重要性與後果排序的清單或表格；或

- 針對每個決策，以獨立章節提供更詳細的說明

<div class="formalpara">

<div class="title">

更多資訊

</div>

參見 arc42 文件中的 [架構決策](https://docs.arc42.org/section-9/)。
您將在那裡找到關於 ADR 的連結與範例。

</div>

</div>

# 品質需求

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

內容

</div>

本節包含所有相關的品質需求。

</div>

其中最重要的需求已在第 1.2
節（品質目標）中描述，因此在此僅需引用這些需求。 在第 10
節中，也應記錄重要性較低的品質需求；即使未完全達成，也不會造成高風險（但可能是
*加分項目*）。

<div class="formalpara">

<div class="title">

動機

</div>

由於品質需求會大幅影響架構決策，您應以具體且可衡量的方式，了解對利害關係人真正重要的品質。

</div>

<div>

<div class="title">

更多資訊

</div>

- 參見 arc42 文件中的 [品質需求](https://docs.arc42.org/section-10/)。

- 參見詳盡的 [Q42 品質模型](https://quality.arc42.org)。

</div>

</div>

## 品質需求概述

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

內容

</div>

品質需求的概述或摘要。

</div>

<div class="formalpara">

<div class="title">

動機

</div>

我們經常遇到數十（甚至數百）個詳細的品質需求。
在此概述部分，您應嘗試依照類別或主題進行摘要，例如參考 [ISO
25010:2023](https://www.iso.org/obp/ui/#iso:std:iso-iec:25010:ed-2:v1:en)
或 [Q42](https://quality.arc42.org) 的建議。

</div>

如果這些摘要已經足夠精確、具體且可衡量，您可以跳過第 10.2 節。

<div class="formalpara">

<div class="title">

形式

</div>

使用簡單表格，其中每列包含一個類別或主題，以及品質需求的簡短描述。
或者，您可以使用心智圖來組織這些品質需求。 文獻中也描述了 *品質屬性樹*
的概念：以「品質」這個通用術語作為根節點，並以樹狀結構逐步細化「品質」這個概念。
\[Bass+21\] 為此提出了「品質屬性效用樹」一詞。

</div>

</div>

## 品質情境

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

內容

</div>

品質情境使品質需求具體化，並可據此判斷是否達成（就驗收標準而言）。
請確保您的情境具體且可衡量。

</div>

<figure>
<img src="images/10_stimulus-ZH-TW.png" alt="品質情境" />
</figure>

以下兩種情境特別有用：

- *使用情境*（也稱為應用情境或使用案例情境）描述系統對特定刺激的執行階段回應。
  這也包括描述系統效率或效能的情境。 範例：系統在一秒內回應使用者請求。

- *變更情境* 描述修改或擴展系統，或修改其直接環境時所產生的預期效果。
  範例：新增功能或品質屬性的需求發生變化，並衡量變更所需的工作量或持續時間。

<div class="formalpara">

<div class="title">

形式

</div>

詳細情境通常包含以下資訊：

</div>

簡短格式（Q42 模型偏好的格式）：

- **脈絡/背景**：這是什麼類型的系統或元件？環境或情況為何？

- **來源/刺激**：誰或什麼啟動或觸發行為、反應或動作？

- **度量/驗收標準**：包含 *測量值* 或 *度量* 的回應。

情境的長格式（軟體工程研究所及 \[Bass+21\]
偏好的格式）更為詳細，包含以下資訊：

- **情境 ID**：情境的唯一識別碼。

- **情境名稱**：情境的簡短描述性名稱。

- **來源**：啟動情境的實體（使用者、系統或事件）。

- **刺激**：系統必須處理的觸發事件或條件。

- **環境**：系統經歷刺激時的操作脈絡或條件。

- **產出物**：受刺激影響的系統建構模組或其他元素。

- **回應**：系統對刺激的反應所表現出的結果或行為。

- **回應度量**：評估系統回應的準則或度量。

<div class="formalpara">

<div class="title">

範例

</div>

有關品質需求的詳細範例，請參見 [Q42
品質模型網站](https://quality.arc42.org)。

</div>

<div>

<div class="title">

更多資訊

</div>

- Len Bass、Paul Clements、Rick Kazman：《軟體架構實務》（Software
  Architecture in Practice），第 4 版，Addison-Wesley，2021。

</div>

</div>

# 風險與技術負債

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

內容

</div>

依優先順序排列的已識別技術風險或技術負債清單。

</div>

<div>

<div class="title">

動機

</div>

> 「風險管理，就是成熟大人的專案管理。」
>
> —  Tim Lister Atlantic Systems Guild

</div>

這應成為您在架構中系統性發掘與評估風險及技術負債的座右銘。管理階層利害關係人（例如專案經理、產品負責人）會需要這些資訊，作為整體風險分析與度量規劃的一環。

<div class="formalpara">

<div class="title">

形式

</div>

風險與/或技術負債清單，可能包含用於最小化、緩解或避免風險，以及減少技術負債的建議措施。

</div>

<div class="formalpara">

<div class="title">

更多資訊

</div>

參見 arc42 文件中的
[風險與技術負債](https://docs.arc42.org/section-11/)。

</div>

</div>

# 術語表

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

內容

</div>

利害關係人討論系統時使用的最重要領域與技術術語。

</div>

如果您在多語言團隊中工作，也可以將術語表視為翻譯的依據。

<div class="formalpara">

<div class="title">

動機

</div>

您應清楚定義術語，讓所有利害關係人

</div>

- 對這些術語有相同的理解

- 不使用同義詞和同名異義詞

<div class="formalpara">

<div class="title">

形式

</div>

包含 \<術語\> 與 \<定義\> 欄位的表格。

</div>

如果需要翻譯，也可以增加其他欄位。

<div class="formalpara">

<div class="title">

更多資訊

</div>

參見 arc42 文件中的 [術語表](https://docs.arc42.org/section-12/)。

</div>

</div>

| 術語       | 英文       | 定義       |
|------------|------------|------------|
| \<術語-1\> | \<英文-1\> | \<定義-1\> |
| \<術語-2\> | \<英文-2\> | \<定義-2\> |
