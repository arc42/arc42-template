---
hide:
   - navigation
---

# Arc42 Template


**A propos d’arc42**

arc42, le modèle de documentation de l’architecture des logiciels et des systèmes.

Version du modèle 9.0-FR. (basé sur la version AsciiDoc), Avril 2025

Créé, maintenu et © par Dr. Peter Hruschka, Dr. Gernot Starke et les contributeurs. Voir <https://arc42.org>.

## Introduction et Objectifs {#section-introduction-and-goals}

### Aperçu des spécifications {#_aperçu_des_spécifications}

### Objectifs de Qualité {#_objectifs_de_qualité}

### Parties prenantes {#_parties_prenantes}

 Rôle/Nom         | Contact             | Attentes            |
------------------|---------------------|---------------------|
 *&lt;Role-1&gt;* | *&lt;Contact-1&gt;* | *&lt;Attente-1&gt;* |
 *&lt;Role-2&gt;* | *&lt;Contact-2&gt;* | *&lt;Attente-2&gt;* |

## Contraintes d’Architecture {#section-architecture-constraints}

## Contexte et périmètre {#section-context-and-scope}

### Contexte métier {#_contexte_métier}

**&lt;Schéma ou tableau&gt;**

**&lt;éventuellement : Explication des interfaces de domaines externes&gt;**

### Contexte Technique {#_contexte_technique}

**&lt;Schéma ou tableau&gt;**

**&lt;en option : Explication des interfaces techniques&gt;**

**&lt;Correspondance des entrées/sorties aux canaux&gt;**

## Stratégie de solution {#section-solution-strategy}

## Vue en Briques {#section-building-block-view}

### Niveau 1 : Système global Boîte blanche {#_niveau_1_système_global_boîte_blanche}

***&lt;Schéma d’ensemble&gt;***

Motivation

:   *&lt;texte explicatif&gt;*

Briques contenues

:   *&lt;Description de la brique contenue (boîte noire)&gt;*

Interfaces Importantes

:   *&lt;Description des interfaces importantes&gt;*

#### &lt;Nom boîte noire 1&gt; {#_nom_boîte_noire_1}

*&lt;Objectif/Responsabilité&gt;*

*&lt;Interface(s)&gt;*

*&lt;(Facultatif) Caractéristiques de qualité/performance&gt;*

*&lt;(Facultatif) Emplacement du répertoire/fichier&gt;*

*&lt;(Facultatif) Exigences respectées&gt;*

*&lt;(Facultatif) Questions ouvertes/problèmes/risques&gt;*

#### &lt;Nom boîte noire 2&gt; {#_nom_boîte_noire_2}

*&lt;template boîte noire&gt;*

#### &lt;Nom boîte noire n&gt; {#_nom_boîte_noire_n}

*&lt;template boîte noire&gt;*

#### &lt;Nom interface 1&gt; {#_nom_interface_1}

…​

#### &lt;Nom interface m&gt; {#_nom_interface_m}

### Niveau 2 {#_niveau_2}

#### Boîte blanche *&lt;brique 1&gt;* {#_boîte_blanche_brique_1}

*&lt;template boîte blanche&gt;*

#### Boîte blanche *&lt;brique 2&gt;* {#_boîte_blanche_brique_2}

*&lt;template boîte blanche&gt;*

…​

#### Boîte blanche *&lt;brique n&gt;* {#_boîte_blanche_brique_n}

*&lt;template boîte blanche&gt;*

## Vue Exécution {#section-runtime-view}

### &lt;Scénario d’exécution 1&gt; {#_scénario_dexécution_1}

- *&lt;insérer un diagramme d’exécution ou une description textuelle du scénario&gt;*

- *&lt;insérer une description des aspects notables des interactions entre les instances des briques représentées dans ce diagramme.&gt;*

### &lt;Scénario d’exécution 2&gt; {#_scénario_dexécution_2}

### …​

### &lt;Scénario d’exécution n&gt; {#_scénario_dexécution_n}

## Vue Déploiement {#section-deployment-view}

### Infrastructure Niveau 1 {#_infrastructure_niveau_1}

***&lt;Schéma d’ensemble&gt;***

Motivation

:   *&lt;explication sous forme de texte&gt;*

Caractéristiques de qualité et/ou de performance

:   *&lt;explication sous forme de texte&gt;*

Correspondance des briques vis à vis de l’infrastructure

:   *&lt;description de la correspondance&gt;*

### Infrastructure Niveau 2 {#_infrastructure_niveau_2}

#### *&lt;Infrastructure Element 1&gt;* {#_infrastructure_element_1}

*&lt;schéma + explication&gt;*

#### *&lt;Infrastructure Element 2&gt;* {#_infrastructure_element_2}

*&lt;schéma + explication&gt;*

…​

#### *&lt;Infrastructure Element n&gt;* {#_infrastructure_element_n}

*&lt;schéma + explication&gt;*

## Concepts transversaux {#section-concepts}

### *&lt;Concept 1&gt;* {#_concept_1}

*&lt;explication&gt;*

### *&lt;Concept 2&gt;* {#_concept_2}

*&lt;explication&gt;*

…​

### *&lt;Concept n&gt;* {#_concept_n}

*&lt;explication&gt;*

## Décisions d’architecture {#section-design-decisions}

## Critères de qualité {#section-quality-scenarios}

### Exigences de qualité - Vue d’ensemble {#_exigences_de_qualité_vue_densemble}

### Scénarios Qualité {#_scénarios_qualité}

## Risques et Dettes techniques {#section-technical-risks}

## Glossaire {#section-glossary}

 Terme             | Définition             |
-------------------|------------------------|
 *&lt;Terme-1&gt;* | *&lt;Définition-1&gt;* |
 *&lt;Terme-2&gt;* | *&lt;Définition-2&gt;* |

  [arc42]: images/arc42-logo.png
  [Introduction et Objectifs]: #section-introduction-and-goals {#toc-section-introduction-and-goals}
  [Aperçu des spécifications]: #_aperçu_des_spécifications {#toc-_aperçu_des_spécifications}
  [Objectifs de Qualité]: #_objectifs_de_qualité {#toc-_objectifs_de_qualité}
  [Parties prenantes]: #_parties_prenantes {#toc-_parties_prenantes}
  [Contraintes d’Architecture]: #section-architecture-constraints {#toc-section-architecture-constraints}
  [Contexte et périmètre]: #section-context-and-scope {#toc-section-context-and-scope}
  [Contexte métier]: #_contexte_métier {#toc-_contexte_métier}
  [Contexte Technique]: #_contexte_technique {#toc-_contexte_technique}
  [Stratégie de solution]: #section-solution-strategy {#toc-section-solution-strategy}
  [Vue en Briques]: #section-building-block-view {#toc-section-building-block-view}
  [Niveau 1 : Système global Boîte blanche]: #_niveau_1_système_global_boîte_blanche {#toc-_niveau_1_système_global_boîte_blanche}
  [&lt;Nom boîte noire 1&gt;]: #_nom_boîte_noire_1 {#toc-_nom_boîte_noire_1}
  [&lt;Nom boîte noire 2&gt;]: #_nom_boîte_noire_2 {#toc-_nom_boîte_noire_2}
  [&lt;Nom boîte noire n&gt;]: #_nom_boîte_noire_n {#toc-_nom_boîte_noire_n}
  [&lt;Nom interface 1&gt;]: #_nom_interface_1 {#toc-_nom_interface_1}
  [&lt;Nom interface m&gt;]: #_nom_interface_m {#toc-_nom_interface_m}
  [Niveau 2]: #_niveau_2 {#toc-_niveau_2}
  [Boîte blanche *&lt;brique 1&gt;*]: #_boîte_blanche_brique_1 {#toc-_boîte_blanche_brique_1}
  [Boîte blanche *&lt;brique 2&gt;*]: #_boîte_blanche_brique_2 {#toc-_boîte_blanche_brique_2}
  [Boîte blanche *&lt;brique n&gt;*]: #_boîte_blanche_brique_n {#toc-_boîte_blanche_brique_n}
  [Vue Exécution]: #section-runtime-view {#toc-section-runtime-view}
  [&lt;Scénario d’exécution 1&gt;]: #_scénario_dexécution_1 {#toc-_scénario_dexécution_1}
  [&lt;Scénario d’exécution 2&gt;]: #_scénario_dexécution_2 {#toc-_scénario_dexécution_2}
  [&lt;Scénario d’exécution n&gt;]: #_scénario_dexécution_n {#toc-_scénario_dexécution_n}
  [Vue Déploiement]: #section-deployment-view {#toc-section-deployment-view}
  [Infrastructure Niveau 1]: #_infrastructure_niveau_1 {#toc-_infrastructure_niveau_1}
  [Infrastructure Niveau 2]: #_infrastructure_niveau_2 {#toc-_infrastructure_niveau_2}
  [*&lt;Infrastructure Element 1&gt;*]: #_infrastructure_element_1 {#toc-_infrastructure_element_1}
  [*&lt;Infrastructure Element 2&gt;*]: #_infrastructure_element_2 {#toc-_infrastructure_element_2}
  [*&lt;Infrastructure Element n&gt;*]: #_infrastructure_element_n {#toc-_infrastructure_element_n}
  [Concepts transversaux]: #section-concepts {#toc-section-concepts}
  [*&lt;Concept 1&gt;*]: #_concept_1 {#toc-_concept_1}
  [*&lt;Concept 2&gt;*]: #_concept_2 {#toc-_concept_2}
  [*&lt;Concept n&gt;*]: #_concept_n {#toc-_concept_n}
  [Décisions d’architecture]: #section-design-decisions {#toc-section-design-decisions}
  [Critères de qualité]: #section-quality-scenarios {#toc-section-quality-scenarios}
  [Exigences de qualité - Vue d’ensemble]: #_exigences_de_qualité_vue_densemble {#toc-_exigences_de_qualité_vue_densemble}
  [Scénarios Qualité]: #_scénarios_qualité {#toc-_scénarios_qualité}
  [Risques et Dettes techniques]: #section-technical-risks {#toc-section-technical-risks}
  [Glossaire]: #section-glossary {#toc-section-glossary}