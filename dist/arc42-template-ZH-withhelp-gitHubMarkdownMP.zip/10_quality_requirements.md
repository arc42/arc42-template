# 质量需求

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

内容

</div>

本节包含所有相关的质量需求。

</div>

其中最重要的需求已经在第 1.2
节（质量目标）中描述，因此在这里应该只是引用它们。
在本节中，您还应该捕获重要性较低的质量需求，这些需求如果没有完全实现不会产生高风险（但可能是
*不错的质量需求*）。

<div class="formalpara">

<div class="title">

动机

</div>

由于质量需求将对架构决策产生很大影响，您应该以具体和可测量的方式了解对干系人真正重要的质量。

</div>

<div>

<div class="title">

更多信息

</div>

- 参见 arc42 文档中的 [质量需求](https://docs.arc42.org/section-10/)。

- 参见详尽的 [Q42 质量模型](https://quality.arc42.org)。

</div>

</div>

## 质量需求概述

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

内容

</div>

质量需求的概述或总结。

</div>

<div class="formalpara">

<div class="title">

动机

</div>

我们经常遇到数十（甚至数百）个详细的质量需求。
在这个概述部分，您应该尝试总结，例如按类别或主题（如 [ISO
25010:2023](https://www.iso.org/obp/ui/#iso:std:iso-iec:25010:ed-2:v1:en)
或 [Q42](https://quality.arc42.org) 所建议的）

</div>

如果这些总结描述已经足够精确、具体和可测量，您可以跳过第 10.2 节。

<div class="formalpara">

<div class="title">

形式

</div>

使用简单表格，其中每行包含一个类别或主题以及质量需求的简短描述。
或者，您可以使用思维导图来组织这些质量需求。 文献中也描述了 质量属性树
的概念，它将通用术语 “质量
”作为根节点，按树状结构对其进行细化。\[Bass+21\] 为此提出了
“质量属性效用树 ”这一术语。
《软件架构实践》为此目的引入了术语"质量属性效用树"。

</div>

</div>

## 质量场景

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

内容

</div>

质量场景使质量需求具体化，并允许决定它们是否得到满足（在验收标准的意义上）。
确保您的场景具体且可测量。

</div>

特别有用的两种场景：

- *使用场景*（也称为应用场景或用例场景）描述系统对某种刺激的运行时反应。
  这也包括描述系统效率或性能的场景。 示例：系统在一秒内响应用户请求。

- *变更场景* 描述系统或其直接环境的修改或扩展的期望效果。
  示例：实现附加功能或质量属性的需求发生变化，并测量变更的工作量或持续时间。

<div class="formalpara">

<div class="title">

形式

</div>

详细场景的典型信息包括以下内容：

</div>

简短形式（Q42 模型中推荐的）：

- **上下文/背景**：什么类型的系统或构件，环境或情况是什么？

- **来源/刺激**：谁或什么启动或触发行为、反应或动作。

- **度量/验收标准**：包含 *测量* 或 *度量* 的响应

场景的详细形式（美国卡内基梅隆大学的软件工程研究所及其使用的教材《软件架构实践》推荐的）更详细，包括以下信息：

- **场景 ID**：场景的唯一标识符。

- **场景名称**：场景的简短描述性名称。

- **来源**：启动场景的实体（用户、系统或事件）。

- **刺激**：系统必须处理的触发事件或条件。

- **环境**：系统经历刺激的操作上下文或条件。

- **制品**：受刺激影响的系统构建块或其他元素。

- **响应**：系统对刺激的反应所表现出的结果或行为。

- **响应度量**：评估系统响应的标准或度量。

<div class="formalpara">

<div class="title">

示例

</div>

有关质量需求的详细示例，请参见 [Q42
质量模型网站](https://quality.arc42.org)。

</div>

<div>

<div class="title">

更多信息

</div>

- 伦·巴斯(Len Bass) , 保罗·克莱门茨(Paul Clements), 瑞克·凯兹曼(Rick
  Kazman): "《软件架构实践》（Software Architecture in Practice）",
  第四版, Addison-Wesley 出版, 2021.

</div>

</div>
