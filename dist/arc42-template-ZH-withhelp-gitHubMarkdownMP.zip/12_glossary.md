# 术语表

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

内容

</div>

您的干系人在讨论系统时使用的最重要的领域和技术术语。

</div>

如果您在多语言团队中工作，您也可以将术语表视为翻译的来源。

<div class="formalpara">

<div class="title">

动机

</div>

您应该清楚地定义您的术语，以便所有干系人

</div>

- 对这些术语有相同的理解

- 不使用同义词和同音异义词

<div class="formalpara">

<div class="title">

形式

</div>

包含 \<术语\> 和 \<定义\> 列的表格。

</div>

如果您需要翻译，可能还有更多列。

<div class="formalpara">

<div class="title">

更多信息

</div>

参见 arc42 文档中的 [术语表](https://docs.arc42.org/section-12/)。

</div>

</div>

| 术语       | 英文       | 定义       |
|------------|------------|------------|
| \<术语-1\> | \<英文-1\> | \<定义-1\> |
| \<术语-2\> | \<英文-2\> | \<定义-2\> |
