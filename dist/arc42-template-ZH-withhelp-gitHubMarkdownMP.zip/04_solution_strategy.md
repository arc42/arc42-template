# 解决方案策略

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

内容

</div>

塑造系统架构的基本决策和解决方案策略的简短总结和解释。它包括

</div>

- 技术决策

- 关于系统顶层分解的决策，例如使用架构模式或设计模式

- 关于如何实现关键质量目标的决策

- 相关的组织决策，例如选择开发过程或将某些任务委托给第三方。

<div class="formalpara">

<div class="title">

动机

</div>

这些决策构成了您架构的基石。它们是许多其他详细决策或实现规则的基础。

</div>

<div class="formalpara">

<div class="title">

形式

</div>

做出的决策的起因，以及为什么做出这样的决定，
基于问题陈述、质量目标和关键约束。请参阅以下章节中的详细信息（第5节是结构细节，第8节是跨领域概念）。

</div>

<div class="formalpara">

<div class="title">

更多信息

</div>

参见 arc42 文档中的 [解决方案策略](https://docs.arc42.org/section-4/)。

</div>

</div>
