# 跨领域概念

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

内容

</div>

本节描述跨领域（实践、模式、规则或解决方案思路）。这些概念通常与多个构建块相关。
它们可能包括许多不同主题，如下图所示的主题：

</div>

<figure>
<img src="images/08-concepts-ZH.drawio.png"
alt="跨领域概念的潜在主题" />
</figure>

<div class="formalpara">

<div class="title">

动机

</div>

概念构成架构 *概念完整性*（一致性、同质性）的基础。
因此，它们是实现系统内在质量的重要贡献。

</div>

这是我们在模板中为此类概念的内聚规范提供的位置。

许多这些概念涉及或影响您的多个构建块。

<div class="formalpara">

<div class="title">

形式

</div>

形式可以多样：

</div>

- 具有任何结构的概念文档

- 示例实现，特别是技术概念

- 使用架构视图标记的跨领域模型的摘录或场景

<div class="formalpara">

<div class="title">

结构

</div>

仅为您的系统挑选 **最需要的**
主题，并在此节中为每个主题分配二级标题（例如 8.1、8.2 等）。

</div>

不要 **试图** 涵盖上述图表的所有主题。

<div class="formalpara">

<div class="title">

更多信息

</div>

系统内的某些主题通常涉及多个构建块、硬件元素或开发流程。
在中心位置传达或记录此类 *跨领域*
主题可能更容易，而不是在相关构建块、硬件元素或开发过程的描述中重复它们。

</div>

某些概念可能涉及系统的 **所有** 元素，其他概念可能仅与少数元素相关。
在上图中，日志记录涉及所有三个构件，而安全性仅与两个构件相关。

参见 arc42 文档中的 [概念](https://docs.arc42.org/section-8/)。

</div>

## *\<概念 1\>*

*\<解释\>*

## *\<概念 2\>*

*\<解释\>*

…​

## *\<概念 n\>*

*\<解释\>*
