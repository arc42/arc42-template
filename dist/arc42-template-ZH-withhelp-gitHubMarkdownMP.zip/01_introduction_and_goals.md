# 引言与目标

<div class="sidebar">

<div class="title">

</div>

描述软件架构师和开发团队必须考虑的相关要求和动机,这些包括:

- 潜在的业务目标,

- 关键特性，

- 基本功能需求，

- 架构的质量目标以及相关干系人及其期望

</div>

## 需求概述

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

内容

</div>

功能需求、动机、需求的摘要（或抽象）的简短描述。
链接到（现有的）需求文档（带有版本号和存放位置）。

</div>

<div class="formalpara">

<div class="title">

动机

</div>

从最终用户的角度来看，创建或修改系统是为了改进对业务活动的支持和/或提高质量。

</div>

<div class="formalpara">

<div class="title">

形式

</div>

简短的文本描述，可能采用表格用例格式。
如果需求文档存在，此概述应引用这些文档。

</div>

保持这些摘录尽可能简短。在本文档的可读性与需求文档的潜在冗余之间取得平衡。

<div class="formalpara">

<div class="title">

更多信息

</div>

参见 arc42 文档中的 [引言与目标](https://docs.arc42.org/section-1/).

</div>

</div>

## 质量目标

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

内容

</div>

架构需要满足主要干系人的最重要的前三个（最多五个）质量目标.
我们真正指的是架构的质量目标。不要将它们与项目目标混淆，二者不一定相同.

</div>

考虑以下潜在主题概述 (基于 ISO 25010 标准):

<figure>
<img src="images/01_2_iso-25010-topics-ZH-2023.drawio.png"
alt="质量需求类别" />
</figure>

<div class="formalpara">

<div class="title">

动机

</div>

您应该了解最重要干系人的质量目标，因为它们将影响基本的架构决策。
确保对这些质量要求非常具体，避免流行语。
如果您作为架构师不知道如何评判您工作的质量…​

</div>

<div class="formalpara">

<div class="title">

形式

</div>

包含质量目标和具体场景的表格，按优先级排序

</div>

</div>

## 干系人

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

内容

</div>

系统干系人的明确概述，即所有人员、角色或组织：

</div>

- 应当了解架构的人

- 必须信任架构的人

- 必须依赖架构或代码开展工作的人

- 依赖架构文档工作的人

- 对系统或系统的开发必须做决策的人

<div class="formalpara">

<div class="title">

起因

</div>

您应该了解参与系统开发或受系统影响的所有各方,否则在开发过程的后期，您可能会遇到令人不快的意外。
这些干系人决定了您工作及其结果的范围和详细程度。

</div>

<div class="formalpara">

<div class="title">

形式

</div>

包含角色名称、人员姓名以及他们对架构及其文档期望的表格。

</div>

</div>

| 角色/姓名    | 联系方式         | 期望         |
|--------------|------------------|--------------|
| *\<角色-1\>* | *\<联系方式-1\>* | *\<期望-1\>* |
| *\<角色-2\>* | *\<联系方式-2\>* | *\<期望-2\>* |
