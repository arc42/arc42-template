# 架构约束

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

内容

</div>

任何约束软件架构师在设计和实现决策自由度或开发过程决策的需求。这些约束有时超越个别系统，对整个组织和公司都有效。

</div>

<div class="formalpara">

<div class="title">

动机

</div>

架构师应该明确知道他们在设计决策中的自由度在哪里，以及必须遵守约束的地方。
尽管约束是可以协商讨论的，但必须始终受到关注。

</div>

<div class="formalpara">

<div class="title">

形式

</div>

带有解释的简单约束表格。
如有需要，您可以结合实践将其细分为：技术约束、组织和政治约束以及约定（例如编程或版本控制指南、文档或命名约定）

</div>

<div class="formalpara">

<div class="title">

更多信息

</div>

参见 arc42 文档中的 [架构约束](https://docs.arc42.org/section-2/)。

</div>

</div>
