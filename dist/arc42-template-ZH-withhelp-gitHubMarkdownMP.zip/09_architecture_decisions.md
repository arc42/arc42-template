# 架构决策

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

内容

</div>

重要的、需要付出高成本的、影响较大范围或存在较高风险的架构决策及其缘由注释。
我们所说的"决策"是指基于给定标准选择一个替代方案。

</div>

请运用您的判断来决定是否应该在此中心部分记录架构决策，或者您最好在本地记录它（例如，在一个构建块的白盒模板内）。

避免冗余。 参考第 4 节，您已经在那里捕获了架构的最重要决策。

<div class="formalpara">

<div class="title">

动机

</div>

您系统的干系人应该能够理解和追溯您的决策。

</div>

<div class="formalpara">

<div class="title">

形式

</div>

各种选择：

</div>

- 每个重要决策的 ADR
  ([架构决策记录](https://cognitect.com/blog/2011/11/15/documenting-architecture-decisions))

- 按重要性和后果排序的列表或表格，或：
  每个决策记录都以独立的部分呈现，以体现更多详情

<div class="formalpara">

<div class="title">

更多信息

</div>

参见 arc42 文档中的 [架构决策](https://docs.arc42.org/section-9/)。
您将在那里找到关于 ADR 的链接和示例。

</div>

</div>
