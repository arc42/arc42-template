# 上下文和边界

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

内容

</div>

系统边界和上下文，顾名思义就是将您的系统（即边界范围）与其所有通信方（周边系统和用户，即您系统的上下文）界定清晰。因此，它决定了外部接口的设计。
如有必要，请区分业务上下文（特定领域的输入和输出）和技术上下文（信道、协议、硬件）。

</div>

<div class="formalpara">

<div class="title">

动机

</div>

与通信方的领域接口和技术接口是系统最关键的部分，请确保您完全了解它们

</div>

<div class="formalpara">

<div class="title">

形式

</div>

有以下几种选择:

</div>

- 下文关系图

- 通信方及其接口列表

<div class="formalpara">

<div class="title">

更多信息

</div>

参见 arc42 文档中的 [上下文和边界](https://docs.arc42.org/section-3/)。

</div>

</div>

## 业务上下文

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

内容

</div>

**所有**
通信方（例如：用户、IT系统等）的规范，并解释特定领域的输入和输出或接口。
您可以选择添加特定领域的格式或通信协议。

</div>

<div class="formalpara">

<div class="title">

动机

</div>

所有干系人都应该了解哪些数据在系统间流转。

</div>

<div class="formalpara">

<div class="title">

形式

</div>

将系统显示为黑盒并指定与通信方的域接口的各种图表。
或者您可以（另外）附加一个表格。
此外，您还可以使用表格。表格的标题为系统名称，表格内容包含三列，分别是通信方名称、输入和输出。

</div>

</div>

**\<图表或表格\>**

**\<可选：外部领域接口的解释\>**

## 技术上下文

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

内容

</div>

技术接口（信道和传输介质）将您的系统与其环境连接起来。此外，将特定领域的输入/输出映射到信道上，即解释哪些输入/输出使用哪些信道。

</div>

<div class="formalpara">

<div class="title">

动机

</div>

许多干系人基于系统与其上下文之间的技术接口做出架构决策。特别是基础设施或硬件设计师决定这些技术接口。

</div>

<div class="formalpara">

<div class="title">

形式

</div>

例如，描述信道到相邻系统的 UML
部署图，以及展示信道与输入/输出之间关系的映射表。

</div>

</div>

**\<图表或表格\>**

**\<可选：技术接口的解释\>**

**\<输入、输出与信道之间的映射关系\>**
