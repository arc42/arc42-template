# Глосарій

**Зміст**

Найважливіші предметні та технічні терміни, які ваші зацікавлені сторони
використовують під час обговорення системи.

Ви також можете бачити глосарій як джерело для перекладу, якщо працюєте
в багатомовних командах.

**Мотивація**

Ви повинні чітко визначити свої умови, щоб усі зацікавлені сторони

-   мали однакове розуміння цих термінів

-   не вживати синонімів і омонімів

<!-- -->

-   Таблиця зі стовпцями &lt;Термін&gt; і &lt;Визначення&gt;.

-   Потенційно більше колонок, якщо вам знадобляться переклади.

Див. [Глосарій](https://docs.arc42.org/section-12/) в документації
arc42.

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Термін</th>
<th style="text-align: left;">Визначення</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Термін-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Визначення-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Термін-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Визначення-2&gt;</em></p></td>
</tr>
</tbody>
</table>
