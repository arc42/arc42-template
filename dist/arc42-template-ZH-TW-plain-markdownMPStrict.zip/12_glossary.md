# 術語表

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">術語</th>
<th style="text-align: left;">英文</th>
<th style="text-align: left;">定義</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p>&lt;術語-1&gt;</p></td>
<td style="text-align: left;"><p>&lt;英文-1&gt;</p></td>
<td style="text-align: left;"><p>&lt;定義-1&gt;</p></td>
</tr>
<tr>
<td style="text-align: left;"><p>&lt;術語-2&gt;</p></td>
<td style="text-align: left;"><p>&lt;英文-2&gt;</p></td>
<td style="text-align: left;"><p>&lt;定義-2&gt;</p></td>
</tr>
</tbody>
</table>
