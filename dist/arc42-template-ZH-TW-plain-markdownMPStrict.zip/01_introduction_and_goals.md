# 簡介與目標

## 需求概述

## 品質目標

## 利害關係人

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">角色/姓名</th>
<th style="text-align: left;">聯絡方式</th>
<th style="text-align: left;">期望</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p><em>&lt;角色-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;聯絡方式-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;期望-1&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"><p><em>&lt;角色-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;聯絡方式-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;期望-2&gt;</em></p></td>
</tr>
</tbody>
</table>
