# 

**O arc42**

arc42, šablona pro dokumentaci softwaru a architekturu systému.

Verze šablony 9.0-CZ. (na základě AsciiDoc verze), Leden 2025

Created, maintained and © by Dr. Peter Hruschka, Dr. Gernot Starke and
contributors. Viz <https://arc42.org>.

# Úvod a cíle {#section-introduction-and-goals}

## Přehled požadavků {#_přehled_požadavků}

## Kvalitativní cíle {#_kvalitativní_cíle}

## Strany zainteresované na systému (stakeholder) {#_strany_zainteresované_na_systému_stakeholder}

+--------------+---------------------------+---------------------------+
| Role/Jméno   | Kontakt                   | Očekávání                 |
+==============+===========================+===========================+
| *\<Role-1\>* | *\<Kontakt-1\>*           | *\<Očekávání-1\>*         |
+--------------+---------------------------+---------------------------+
| *\<Role-2\>* | *\<Kontakt-2\>*           | *\<Očekávání-2\>*         |
+--------------+---------------------------+---------------------------+

# Omezení na realizaci systému {#section-architecture-constraints}

# Vymezení a rozsah systému {#section-context-and-scope}

## Firemní kontext {#_firemní_kontext}

**\<vložte diagram nebo tabulku\>**

**\<(volitelně:) vložte vysvětlení externích doménových rozhraní\>**

## Technický kontext {#_technický_kontext}

**\<vložte diagram nebo tabulku\>**

**\<(volitelně:) vložte vysvětlení externích technických rozhraní\>**

**\<mapování doménových vstupu/výstupu na technické kanály\>**

# Strategie řešení {#section-solution-strategy}

# Perspektiva stavebních bloků {#section-building-block-view}

## Celý systém jako white-box {#_celý_systém_jako_white_box}

***\<vložte přehledový diagram celého systému\>***

Motivace

:   *\<popište motivaci\>*

Obsažené stavební bloky

:   *\<popište obsažené stavební bloky (jako black-box)\>*

Důležitá rozhraní

:   *\<popište důležitá rozhraní\>*

### \<Jméno black-boxu 1\> {#_jméno_black_boxu_1}

*\<Účel/Odpovědnost\>*

*\<Rozhraní\>*

*\<(Volitelně) Požadavky na kvalitu/výkon\>*

*\<(Volitelně) Umístění/složky a soubory\>*

*\<(Volitelně) Splněné požadavky\>*

*\<(Volitelně) Nevyřešené body/problémy/rizika\>*

### \<Jméno black-boxu 2\> {#_jméno_black_boxu_2}

*\<šablona black-box\>*

### \<Jméno black-boxu n\> {#_jméno_black_boxu_n}

*\<šablona black-box\>*

### \<Jméno rozhraní 1\> {#_jméno_rozhraní_1}

...​

### \<Jméno rozhraní m\> {#_jméno_rozhraní_m}

## Úroveň 2 {#_úroveň_2}

### white-box *\<stavební blok 1\>* {#_white_box_stavební_blok_1}

*\<šablona white-box\>*

### white-box *\<stavební blok 2\>* {#_white_box_stavební_blok_2}

*\<šablona white-box\>*

...​

### white-box *\<stavební blok m\>* {#_white_box_stavební_blok_m}

*\<šablona white-box\>*

## Úroveň 3 {#_úroveň_3}

### white-box \<\_stavební blok x.1\_\> {#_white_box_stavební_blok_x_1}

*\<šablona white-box\>*

### white-box \<\_stavební blok x.2\_\> {#_white_box_stavební_blok_x_2}

*\<šablona white-box\>*

### white-box \<\_stavební blok y.1\_\> {#_white_box_stavební_blok_y_1}

*\<šablona white-box\>*

# Perspektiva chování za běhu (runtime) {#section-runtime-view}

## \<Scénář runtime 1\> {#_scénář_runtime_1}

- *\<vložte runtime diagram nebo textový popis scénáře\>*

- *\<vložte popis důležitých interakcí mezi instancemi stavebních bloků
  zobrazených v tomto diagramu\>*

## \<Scénář runtime 2\> {#_scénář_runtime_2}

## ...​

## \<Scénář runtime n\> {#_scénář_runtime_n}

# Perspektiva nasazení softwaru (deployment) {#section-deployment-view}

## Úroveň infrastruktury 1 {#_úroveň_infrastruktury_1}

***\<Přehledový diagram\>***

Motivace

:   *\<vysvětlení v textové podobě\>*

Kvalitativní a/nebo výkonnostní vlastnosti

:   *\<vysvětlení v textové podobě\>*

Mapování softwarových artefaktů na prvky infrastruktury

:   *\<popis mapování\>*

## Úroveň infrastruktury 2 {#_úroveň_infrastruktury_2}

### *\<prvek infrastruktury 1\>* {#_prvek_infrastruktury_1}

*\<diagram + vysvětlení\>*

### *\<prvek infrastruktury 2\>* {#_prvek_infrastruktury_2}

*\<diagram + vysvětlení\>*

...​

### *\<prvek infrastruktury n\>* {#_prvek_infrastruktury_n}

*\<diagram + vysvětlení\>*

# Průřezové (cross-cutting) koncepty {#section-concepts}

## *\<Koncept 1\>* {#_koncept_1}

*\<vysvětlení\>*

## *\<Koncept 2\>* {#_koncept_2}

*\<vysvětlení\>*

...​

## *\<Koncept n\>* {#_koncept_n}

*\<vysvětlení\>*

# Rozhodnutí o architektuře {#section-design-decisions}

# Požadavky na kvalitu {#section-quality-scenarios}

## Přehled požadavků na kvalitu {#_přehled_požadavků_na_kvalitu}

## Scénáře kvality {#_scénáře_kvality}

# Rizika a technické dluhy {#section-technical-risks}

# Slovník pojmů {#section-glossary}

+----------------------+-----------------------------------------------+
| Termín               | Definice                                      |
+======================+===============================================+
| *\<termín-1\>*       | *\<definice-1\>*                              |
+----------------------+-----------------------------------------------+
| *\<termín-2\>*       | *\<definice-2\>*                              |
+----------------------+-----------------------------------------------+
