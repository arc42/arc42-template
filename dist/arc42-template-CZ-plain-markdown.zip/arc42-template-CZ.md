# 

**O arc42**

arc42, šablona pro dokumentaci softwaru a architekturu systému.

Verze šablony 8.2 CZ. (na základě AsciiDoc verze), Leden 2023

Created, maintained and © by Dr. Peter Hruschka, Dr. Gernot Starke and
contributors. Viz <https://arc42.org>.

# Úvod a cíle {#section-introduction-and-goals}

## Přehled požadavků {#_p_ehled_po_adavk}

## Kvalitativní cíle {#_kvalitativn_c_le}

## Strany zainteresované na systému (Stakeholder) {#_strany_zainteresovan_na_syst_mu_stakeholder}

+-------------+---------------------------+---------------------------+
| Role/Jméno  | Kontakt                   | Očekávání                 |
+=============+===========================+===========================+
| *\<Role-1>* | *\<Kontakt-1>*            | *\<Očekávání-1>*          |
+-------------+---------------------------+---------------------------+
| *\<Role-2>* | *\<Kontakt-2>*            | *\<Očekávání-2>*          |
+-------------+---------------------------+---------------------------+

# Omezení na realizaci systému {#section-architecture-constraints}

# Vymezení a rozsah systému {#section-system-scope-and-context}

## Firemní kontext {#_firemn_kontext}

**\<vložte diagram nebo tabulku>**

**\<(volitelně:) vložte vysvětlení externích doménových rozhraní>**

## Technický kontext {#_technick_kontext}

**\<vložte diagram nebo tabulku>**

**\<(volitelně:) vložte vysvětlení externích technických rozhraní>**

**\<mapování doménových vstupu/výstupu na technické kanály>**

# Strategie řešení {#section-solution-strategy}

# Perspektiva stavebních bloků {#section-building-block-view}

## Celý systém jako white-box {#_cel_syst_m_jako_white_box}

***\<vložte přehledový diagram celého systému>***

Motivace

:   *\<popište motivaci>*

Obsažené stavební bloky

:   *\<popište obsažené stavební bloky (jako black-box)>*

Důležitá rozhraní

:   *\<popište důležitá rozhraní>*

### \<Jméno black-boxu 1> {#__jm_no_black_boxu_1}

*\<Účel/Odpovědnost>*

*\<Rozhraní>*

*\<(Volitelně) Požadavky na kvalitu/výkon>*

*\<(Volitelně) Umístění/složky a soubory>*

*\<(Volitelně) Splněné požadavky>*

*\<(Volitelně) Nevyřešené body/problémy/rizika>*

### \<Jméno black-boxu 2> {#__jm_no_black_boxu_2}

*\<šablona black-box>*

### \<Jméno black-boxu n> {#__jm_no_black_boxu_n}

*\<šablona black-box>*

### \<Jméno rozhraní 1> {#__jm_no_rozhran_1}

...

### \<Jméno rozhraní m> {#__jm_no_rozhran_m}

## Úroveň 2 {#__rove_2}

### white-box *\<stavební blok 1>* {#_white_box_emphasis_stavebn_blok_1_emphasis}

*\<šablona white-box>*

### white-box *\<stavební blok 2>* {#_white_box_emphasis_stavebn_blok_2_emphasis}

*\<šablona white-box>*

...

### white-box *\<stavební blok m>* {#_white_box_emphasis_stavebn_blok_m_emphasis}

*\<šablona white-box>*

## Úroveň 3 {#__rove_3}

### white-box \<\_stavební blok x.1\_\> {#_white_box_stavebn_blok_x_1}

*\<šablona white-box>*

### white-box \<\_stavební blok x.2\_\> {#_white_box_stavebn_blok_x_2}

*\<šablona white-box>*

### white-box \<\_stavební blok y.1\_\> {#_white_box_stavebn_blok_y_1}

*\<šablona white-box>*

# Perspektiva chování za běhu (runtime) {#section-runtime-view}

## \<Scénář runtime 1> {#__sc_n_runtime_1}

-   *\<vložte runtime diagram nebo textový popis scénáře>*

-   *\<vložte popis důležitých interakcí mezi instancemi stavebních
    bloků zobrazených v tomto diagramu>*

## \<Scénář runtime 2> {#__sc_n_runtime_2}

## ... {#_}

## \<Scénář runtime n> {#__sc_n_runtime_n}

# Perspektiva nasazení softwaru (deployment) {#section-deployment-view}

## Úroveň infrastruktury 1 {#__rove_infrastruktury_1}

***\<Přehledový diagram>***

Motivace

:   *\<vysvětlení v textové podobě>*

Kvalitativní a/nebo výkonnostní vlastnosti

:   *\<vysvětlení v textové podobě>*

Mapování softwarových artefaktů na prvky infrastruktury

:   *\<popis mapování>*

## Úroveň infrastruktury 2 {#__rove_infrastruktury_2}

### *\<prvek infrastruktury 1>* {#__emphasis_prvek_infrastruktury_1_emphasis}

*\<diagram + vysvětlení>*

### *\<prvek infrastruktury 2>* {#__emphasis_prvek_infrastruktury_2_emphasis}

*\<diagram + vysvětlení>*

...

### *\<prvek infrastruktury n>* {#__emphasis_prvek_infrastruktury_n_emphasis}

*\<diagram + vysvětlení>*

# Průřezové (cross-cutting) koncepty {#section-concepts}

## *\<Koncept 1>* {#__emphasis_koncept_1_emphasis}

*\<vysvětlení>*

## *\<Koncept 2>* {#__emphasis_koncept_2_emphasis}

*\<vysvětlení>*

...

## *\<Koncept n>* {#__emphasis_koncept_n_emphasis}

*\<vysvětlení>*

# Rozhodnutí o architektuře {#section-design-decisions}

# Požadavky na kvalitu {#section-quality-scenarios}

## Strom kvality {#_strom_kvality}

## Scénáře kvality {#_sc_n_e_kvality}

# Rizika a technické dluhy {#section-technical-risks}

# Slovník pojmů {#section-glossary}

+-----------------------+-----------------------------------------------+
| Termín                | Definice                                      |
+=======================+===============================================+
| *\<termín-1>*         | *\<definice-1>*                               |
+-----------------------+-----------------------------------------------+
| *\<termín-2>*         | *\<definice-2>*                               |
+-----------------------+-----------------------------------------------+
