# Runtime View

## \<Runtime Scenario 1\>

  - *\<insert runtime diagram or textual description of the scenario\>*

  - *\<insert description of the notable aspects of the interactions
    between the building block instances depicted in this diagram.\>*

## \<Runtime Scenario 2\>

## …

## \<Runtime Scenario n\>
