# Архітектурні обмеження {#section-architecture-constraints}
