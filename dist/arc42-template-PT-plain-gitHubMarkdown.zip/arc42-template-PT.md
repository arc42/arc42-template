---
date: Setembro de 2024
title: Modelo ![arc42](images/arc42-logo.png)
---

# 

**Sobre o arc42**

arc42, o template para documentação de software e arquitetura de
sistemas.

Versão do template 8.2-PT. (based upon AsciiDoc version), Setembro de
2024

Criado, mantido e © pelo Dr. Peter Hruschka, Dr. Gernot Starke e
colaboradores. Veja <https://arc42.org>.

# Introdução e Objetivos

## Visão Geral dos Requisitos

## Objetivos de Qualidade

## Partes Interessadas

| Função/Nome    | Contato         | Expectativas        |
|----------------|-----------------|---------------------|
| *\<Função-1\>* | *\<Contato-1\>* | *\<Expectativa-1\>* |
| *\<Função-2\>* | *\<Contato-2\>* | *\<Expectativa-2\>* |

# Restrições Arquiteturais

# Contexto e Escopo

## Contexto Negocial

**\<Diagrama ou Tabela\>**

**\<opcionalmente: Explicação das interfaces de domínio externo\>**

## Contexto Técnico

**\<Diagrama ou Tabela\>**

**\<opcionalmente: Explicação das interfaces técnicas\>**

**\<Mapeamento de entrada/saída para canais\>**

# Estratégia de Solução

# Visão de Blocos de Construção

## Visão Sistêmica Geral de Caixa Branca

***\<Diagrama de Visão Geral\>***

Motivação  
*\<explicação textual\>*

Blocos de Construção Contidos  
*\<Descrição dos blocos de construção contidos (caixas pretas)\>*

Interfaces Importantes  
*\<Descrição de interfaces importantes\>*

### \<Nome Caixa Preta 1\>

*\<Propósito/Responsabilidade\>*

*\<Interface(s)\>*

*\<(Opcional) Características de Qualidade/Desempenho\>*

*\<(Opcional) Local do Diretório/Arquivo\>*

*\<(Opcional) Requisitos Cumpridos\>*

*\<(opcional) Problemas/Riscos Abertos\>*

### \<Nome Caixa Preta 2\>

*\<modelo de caixa preta\>*

### \<Nome Caixa Preta n\>

*\<modelo de caixa preta\>*

### \<Nome Interface 1\>

…​

### \<Nome Interface m\>

## Nível 2

### Caixa Branca *\<Bloco de Construção 1\>*

*\<modelo de caixa branca\>*

### Caixa Branca *\<Bloco de Construção 2\>*

*\<modelo de caixa branca\>*

…​

### Caixa Branca *\<Bloco de Construção m\>*

*\<modelo de caixa branca\>*

## Nível 3

### Caixa Branca \<\_Bloco de Construção x.1\_\>

*\<modelo de caixa branca\>*

### Caixa Branca \<\_Bloco de Construção x.2\_\>

*\<modelo de caixa branca\>*

### Caixa Branca \<\_Bloco de Construção y.1\_\>

*\<modelo de caixa branca\>*

# Visão de Tempo de Execução

## \<Cenário de Tempo de Execução 1\>

- *\<inserir diagrama de tempo de execução ou descrição textual do
  cenário\>*

- *\<inserir descrição dos aspectos notáveis ​​das interações entre as
  instâncias do bloco de construção descritas neste diagrama.\>*

## \<Cenário de Tempo de Execução 2\>

## …​

## \<Cenário de Tempo de Execução n\>

# Visão de Implantação

## Nível de Infraestrutura 1

***\<Diagrama de Visão Geral\>***

Motivação  
*\<explicação em forma de texto\>*

Características de Qualidade e/ou Desempenho  
*\<explicação em forma de texto\>*

Mapeamento de Blocos de Construção para Infraestrutura  
*\<descrição do mapeamento\>*

## Nível de Infraestrutura 2

### *\<Elemento de Infraestrutura 1\>*

*\<diagrama + explicação\>*

### *\<Elemento de Infraestrutura 2\>*

*\<diagrama + explicação\>*

…​

### *\<Elemento de Infraestrutura n\>*

*\<diagrama + explicação\>*

# Conceitos Transversais

## *\<Conceito 1\>*

*\<explicação\>*

## *\<Conceito 2\>*

*\<explicação\>*

…​

## *\<Conceito n\>*

*\<explicação\>*

# Decisões Arquiteturais

# Requisitos de qualidade

## Árvore de qualidade

## Cenários de Qualidade

# Riscos e Débitos Técnicos

# Glossário

| Termo         | Definição         |
|---------------|-------------------|
| *\<Termo-1\>* | *\<definição-1\>* |
| *\<Termo-2\>* | *\<definição-2\>* |
