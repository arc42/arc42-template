# Restricciones de la Arquitectura
