Glosario
========

**Contenido.**

Los términos técnicos y de dominio más importantes que serán utilizados
por las partes relacionadas al discutir el sistema.

También se puede usar el glosario como fuente para traducciones si se
trabaja en equipos multi-lenguaje.

**Motivación.**

Deberían definirse claramente los términos, para que todas las partes
relacionadas:

-   Tengan un entendimiento idéntico de dichos términos

-   No usen sinónimos y homónimos

<!-- -->

-   Crear una tabla con las columnas &lt;Término&gt; y
    &lt;Definición&gt;.

-   Se pueden agregar más columnas en caso de que se requieran
    traducciones.

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th>Término</th>
<th>Definición</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><p><em>&lt;Término-1&gt;</em></p></td>
<td><p><em>&lt;definicion-1&gt;</em></p></td>
</tr>
<tr class="even">
<td><p><em>&lt;Término-2&gt;</em></p></td>
<td><p><em>&lt;definicion-2&gt;</em></p></td>
</tr>
</tbody>
</table>
