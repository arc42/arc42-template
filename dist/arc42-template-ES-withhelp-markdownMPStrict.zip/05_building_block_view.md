# Vista de Bloques

Contenido

La vista de bloques muestra la descomposición estática del sistema en
bloques de construcción (módulos, componentes, subsistemas, clases,
interfases, paquetes, bibliotecas, marcos de desarrollo, capas,
particiones, funciones, macros, operaciones, estructuras de datos,…​) así
como sus dependencias (relaciones, asociaciones,…​)

Esta vista es obligatoria para cualquier documentación de arquitectura.
Es la analogía al plano de una casa.

Motivación

Mantener una visión general de su código fuente haciendo su estructura
comprensible de manera abstracta.

Esto permite comunicar a las partes interesades en un nivel abstracto
sin entrar en detalles de implementación.

Forma

La vista de bloques comprende una colección jerárquica de cajas negras y
cajas blancas (ver figura de abajo) y sus descripciones.

<figure>
<img src="images/05_building_blocks-ES.png"
alt="Jerarquía de bloques de construcción" />
</figure>

**Nivel 1** comprende la descripción de Caja Blanca del sistema en
general junto con las descripciones de Caja Negra de todos los bloques
contenidos.

**Nivel 2** hace zoom a los bloques de construcción del Nivel 1.
Entonces contiene la descripción de Caja Blanca de los bloques de
construcción selecionadas del nivel 1,junto con las descripciones de
caja negra de sus bloques de construcción internas.

**Nivel 3** Hace zoom a los bloques selectos del nivel 2, y así
sucesivamente.

## Sistema General de Caja Blanca

Aquí se describe la descomposición del sistema en general usando la
siguiente plantilla de caja blanca. Contiene:

- Un diagrama general

- La motivación para la descomposición

- Descripciones de caja negra de los bloques de construcción contenidos.
  Para estos se ofrecen las siguientes alternativas:

  - Usar *una* tabla para una revisión pragmática y corta de todos los
    bloques de construcción contenidos y sus interfaces

  - Usar una lista de descripciones de caja negra de los bloques de
    construcción acorde a la plantilla de caja negra (ver abajo).
    Dependiendo de la herramienta utilizada, esta lista podría constar
    de sub-capítulos (en archivos de texto), sub-páginas (en un wiki) o
    elementos anidados (en una herramienta de modelado).

- (opcional:) Interfases importantes, que no están explicadas en las
  plantillas de caja negra de un bloque de construcción, pero que son
  muy importantes para entender la caja blanca. En el peor de los casos
  se deberá especificar y desribir la sintaxis, semántica, protocolos,
  manejo de errores, restricciones, versiones, calidades,
  compatibilidades necesarias, entre otras. En el mejor de los casos
  bastará con ejemplos o la firma de los mismos.

***&lt;Diagrama general&gt;***

Motivación  
*&lt;Explicación en texto&gt;*

Bloques de construcción contenidos  
*&lt;Desripción de los bloques de construcción contenidos (Cajas
negras)&gt;*

Interfases importantes  
*&lt;Descripción de las interfases importantes&gt;*

Inserte las explicaciones de las cajas negras del nivel 1:

Si usa la forma tabular solo describa las cajas negras con nombre y
responsabilidad acorde al siguiente esquema:

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;"><strong>Nombre</strong></th>
<th style="text-align: left;"><strong>Responsabilidad</strong></th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p><em>&lt;caja negra 1&gt;</em></p></td>
<td style="text-align: left;"><p> <em>&lt;Texto&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"><p><em>&lt;caja negra 2&gt;</em></p></td>
<td style="text-align: left;"><p> <em>&lt;Texto&gt;</em></p></td>
</tr>
</tbody>
</table>

Si utiliza una lista de descripciones de cajas negras entonces llene una
plantilla de caja negra por cada bloque de construcción importante. El
título es el nombre de la caja negra.

### &lt;Caja Negra 1&gt;

Aqui se describe la &lt;caja negra 1&gt; acorde a la siguiente
plantilla:

- Propósito/Responsabilidad

- Interfases, cuando no son extraídas como párrafos separados. Estas
  interfases pueden incluir características de calidad y rendimiento.

- (Opcional) Características de Calidad / Rendimiento de la caja negra,
  por ejemplo, disponibilidad, comportamiento en ejecución, …​

- (Opcional) Ubicación archivo/directorio

- (Opcional) Requerimientos satisfechos (si se necesita contar con la
  trazabilidad a los requerimientos).

- (Opcional) Incidentes/problemas/riesgos abiertos

*&lt;Propósito/Responsabilidad&gt;*

*&lt;Interfase(s)&gt;*

*&lt;(Opcional) Características de Calidad/Performance&gt;*

*&lt;(Opcional) Ubicación Archivo/Directorio&gt;*

*&lt;(Opcional) Requerimientos Satisfechos&gt;*

*&lt;(Opcional) Riesgos/Problemas/Incidentes Abiertos&gt;*

### &lt;Caja Negra 2&gt;

*&lt;plantilla de caja negra&gt;*

### &lt;Caja Negra N&gt;

*&lt;Plantilla de caja negra&gt;*

### &lt;Interfase 1&gt;

…​

### &lt;Interfase m&gt;

## Nivel 2

Aquí se especifica la estructura interna de (algunos) bloques de
construcción del nivel 1 como cajas blancas.

Debe decidir cuales bloques de construcción del sistema son lo
suficientemente importantes para justificar una descripción detallada.
Prefiera la relevancia sobre la completitud. Especifique bloques de
construcción importantes, sorprendentes, riesgosos, complejos o
volátiles. Deje fuera las partes normales, simples, estándares o
aburridas del sistema.

### Caja Blanca *&lt;bloque de construcción 1&gt;*

…​Describe la estructura interna de *bloque de construcción 1*.

*&lt;plantilla de caja blanca&gt;*

### Caja Blanca *&lt;bloque de construcción 2&gt;*

*&lt;plantilla de caja blanca&gt;*

…​

### Caja Blanca *&lt;bloque de construcción m&gt;*

*&lt;plantilla de caja blanca&gt;*

## Nivel 3

Aqui se especifica la estructura interna de (algunos) de los bloques de
construcción del nivel 2 como cajas blancas.

Cuando la arquitectura requiera más niveles detallados copiar esta
sección para niveles adicionales.

### Caja Blanca &lt;\_bloque de construcción x.1\_&gt;

Especifica la estructura interna de *bloque de construcción x.1*.

*&lt;plantilla de caja blanca&gt;*

### Caja Blanca &lt;\_bloque de construcción x.2\_&gt;

*&lt;plantilla de caja blanca&gt;*

### Caja Blanca &lt;\_bloque de construcción y.1\_&gt;

*&lt;plantilla de caja blanca&gt;*
