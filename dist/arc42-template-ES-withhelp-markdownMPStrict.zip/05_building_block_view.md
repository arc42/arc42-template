# Vista de Bloques

## Sistema General de Caja Blanca

***&lt;Diagrama general>***

Motivación  
*&lt;Explicación en texto>*

Bloques de construcción contenidos  
*&lt;Desripción de los bloques de construcción contenidos (Cajas
negras)>*

Interfases importantes  
*&lt;Descripción de las interfases importantes>*

### &lt;Caja Negra 1>

*&lt;Propósito/Responsabilidad>*

*&lt;Interfase(s)>*

*&lt;(Opcional) Características de Calidad/Performance>*

*&lt;(Opcional) Ubicación Archivo/Directorio>*

*&lt;(Opcional) Requerimientos Satisfechos>*

*&lt;(Opcional) Riesgos/Problemas/Incidentes Abiertos>*

### &lt;Caja Negra 2>

*&lt;plantilla de caja negra>*

### &lt;Caja Negra N>

*&lt;Plantilla de caja negra>*

### &lt;Interfase 1>

…

### &lt;Interfase m>

## Nivel 2

### Caja Blanca *&lt;bloque de construcción 1>*

*&lt;plantilla de caja blanca>*

### Caja Blanca *&lt;bloque de construcción 2>*

*&lt;plantilla de caja blanca>*

…

### Caja Blanca *&lt;bloque de construcción m>*

*&lt;plantilla de caja blanca>*

## Nivel 3

### Caja Blanca &lt;\_bloque de construcción x.1\_&gt;

*&lt;plantilla de caja blanca>*

### Caja Blanca &lt;\_bloque de construcción x.2\_&gt;

*&lt;plantilla de caja blanca>*

### Caja Blanca &lt;\_bloque de construcción y.1\_&gt;

*&lt;plantilla de caja blanca>*
