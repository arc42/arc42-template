# Глосарій

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Термін</th>
<th style="text-align: left;">Визначення</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Термін-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Визначення-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Термін-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Визначення-2&gt;</em></p></td>
</tr>
</tbody>
</table>
