# Вступ і цілі

## Огляд вимог

## Цілі якості

## Зацікавлені сторони

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Роль/Ім’я</th>
<th style="text-align: left;">Контакт</th>
<th style="text-align: left;">Очікування</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Роль-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Контакт-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Очікування-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Роль-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Контакт-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Очікування-2&gt;</em></p></td>
</tr>
</tbody>
</table>
