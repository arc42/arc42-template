# Building Block View

## Whitebox Overall System

***\<Overview Diagram>***

Motivazione  
*\<spiegazione testuale>*

Contenuto dei Building Blocks  
*\<Descrizione del contenuto del building block (black boxes)>*

Important Interfaces  
*\<Descrizione delle interfacce importanti>*

### \<Nome black box 1>

*\<Scopo/responsabilità>*

*\<Interfacce>*

*\<(Facoltativo) Caratteristiche di qualità/prestazionali>*

*\<(Facoltativo) percorso file/directory>*

*\<(Facoltativo) Requisiti soddisfatti>*

*\<(Facoltativo) Bug noti/Rischi/problemi>*

### \<Nome black box 2>

*\<black box template>*

### \<Nome black box n>

*\<black box template>*

### \<Nome interface 1>

…

### \<Nome interface m>

## Livello 2

### White Box *\<building block 1>*

*\<white box template>*

### White Box *\<building block 2>*

*\<white box template>*

…

### White Box *\<building block m>*

*\<white box template>*

## Livello 3

### White Box \<\_building block x.1\_\>

*\<white box template>*

### White Box \<\_building block x.2\_\>

*\<white box template>*

### White Box \<\_building block y.1\_\>

*\<white box template>*
