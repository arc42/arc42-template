# Introduzione e obiettivi

## Panoramica dei requisiti

## Obiettivi di qualità

## Stakeholders

| Rouolo/Nome   | Contatto         | Aspettative          |
|---------------|------------------|----------------------|
| *\<Ruolo-1\>* | *\<Contatto-1\>* | *\<Aspettatiive-1\>* |
| *\<Ruolo-2\>* | *\<Contatto-2\>* | *\<Aspettatiive-2\>* |
