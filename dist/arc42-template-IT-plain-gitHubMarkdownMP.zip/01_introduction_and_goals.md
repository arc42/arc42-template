# Introduzione e obiettivi

## Panoramica dei requisiti

## Obiettivi di qualità

## Stakeholders

| Rouolo/Nome       | Contatto             | Aspettative              |
|-------------------|----------------------|--------------------------|
| *&lt;Ruolo-1&gt;* | *&lt;Contatto-1&gt;* | *&lt;Aspettatiive-1&gt;* |
| *&lt;Ruolo-2&gt;* | *&lt;Contatto-2&gt;* | *&lt;Aspettatiive-2&gt;* |
