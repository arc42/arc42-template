# Deployment View

## Livello infrastruttura 1

***\<Overview Diagram\>***

Motivatione  
*\<spiegazione in forma di testo\>*

Requsiti di qualità e/o di prestazioni  
*\<spiegazione in forma di testo\>*

Mappatura dei Building Blocks nella Architettura  
*\<descrizione della mappatura\>*

## Livello infrastruttura 2

### *\<Elemento infrastruttura 1\>*

*\<diagramma + spiegazione\>*

### *\<Elemento infrastruttura 2\>*

*\<diagramma + spiegazione\>*

…

### *\<Elemento infrastruttura n\>*

*\<diagramma + spiegazione\>*
