# Ambito e contesto del sistema

## Contesto di Business

**\<Diagramma o Tabella>**

**\<opzionale: spiegazione delle interfacce del dominio esterno>**

## Contesto Tecnico

**\<Diagramma o Tabella>**

**\<opzionale: Spiegazione delle interfacce tecniche>**

**\<Mappatura Input/Output sui canali di comunicazione>**
