# Glossario

| Termine         | Definizione         |
|-----------------|---------------------|
| *\<Termine-1\>* | *\<definizione-1\>* |
| *\<Termine-2\>* | *\<definizione-2\>* |
