# Glossario

| Termine             | Definizione             |
|---------------------|-------------------------|
| *&lt;Termine-1&gt;* | *&lt;definizione-1&gt;* |
| *&lt;Termine-2&gt;* | *&lt;definizione-2&gt;* |
