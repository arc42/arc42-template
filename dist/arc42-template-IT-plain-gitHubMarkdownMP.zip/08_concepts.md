# Concetti trasversali

## *\<Concetto 1>*

*\<spiegazione>*

## *\<Concetto 2>*

*\<spiegazione>*

…

## *\<Concetto n>*

*\<spiegazione>*
