Glosario {#section-glossary}
========

**Contenido.**

Los términos técnicos y de dominio más importantes que serán utilizados
por las partes relacionadas al discutir el sistema.

También se puede usar el glosario como fuente para traducciones si se
trabaja en equipos multi-lenguaje.

**Motivación.**

Deberían definirse claramente los términos, para que todas las partes
relacionadas:

-   Tengan un entendimiento idéntico de dichos términos

-   No usen sinónimos y homónimos

**Forma.**

Crear una tabla con las columnas &lt;Término&gt; y &lt;Definición&gt;.

Se pueden agregar más columnas en caso de que se requieran traducciones.

+-----------------------------------+-----------------------------------+
| Término                           | Definición                        |
+===================================+===================================+
| &lt;Término-1&gt;                 | &lt;definicion-1&gt;              |
+-----------------------------------+-----------------------------------+
| &lt;Término-2&gt;                 | &lt;definicion-2&gt;              |
+-----------------------------------+-----------------------------------+


