# Alcance y Contexto del Sistema {#section-context-and-scope}

:::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Contenido
:::

El alcance y contexto del sistema - como lo sugiere el nombre - delimita
al sistema (es decir, el alcance) de todos sus socios de comunicación
(Usuarios y sistemas vecinos, es decir, el contexto del sistema). System
scope and context - as the name suggests - delimits your system (i.e.
your scope) from all its communication partners (neighboring systems and
users, i.e. the context of your system). Con ello se especifican las
interfaces externas.
::::

Si es necesario, diferenciar el contexto de negocio (Entradas y salidas
específicas del dominio) del contexto técnico (canales, protocolos,
hardware).

:::: formalpara
::: title
Motivación
:::

Las interfases de dominio y las interfases técnicas a los socios de
comunicación son de los aspectos más críticos del sistema. Se debe
asegurar el entendimiento de ellos.
::::

:::: formalpara
::: title
Forma
:::

Varias opciones:
::::

- Diagramas de contexto

- Listas de socios de comunicación y sus interfases.
::::::::::

## Contexto de Negocio {#_contexto_de_negocio}

:::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Contenido
:::

La especificación de **todos** los socios de comunicación (usuarios,
sistemas, ...​) con explicaciones de las entradas y salidas específicas
del dominio o interfases. Opcionalmente puede agregar formatos
específicos de dominio o protocolos de comunicación
::::

:::: formalpara
::: title
Motivación
:::

Todas las partes interesadas deben entender que datos son intercambiados
con el ambiente del sistema.
::::

:::: formalpara
::: title
Forma
:::

Cualquier forma de diagramas que muestren al sistema como una caja negra
y especifiquen las interfases de dominio a los socios de comunicación.
::::

De manera alternativa (o adicional) se puede utilizar una tabla. El
título de la tabla es el nombre del sistema, las tres columnas contienen
el nombre del socio de comunicación, las entradas y las salidas
::::::::::

**\<Diagrama o Tabla\>**

**\<optionally: Explanation of external domain interfaces\>**

## Contexto Técnico {#_contexto_técnico}

:::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Contenido
:::

Las interfases técnicas (medios de transmisión y canales) enlanzando al
sistema con su ambiente. De manera adicional el mapeo de las
entradas/salidas específicas del dominio a los canales, es decir, una
explicación acerca de que entrada/salida utiliza cual canal.
::::

:::: formalpara
::: title
Motivación
:::

Muchas partes relacionadas realizan decisiones arquitectónicas basadas
en las interfases técnicas entre el sistema y su contexto. Especialmente
los diseñadores de infraestructura o hardware deciden estas interfases
técnicas.
::::

:::: formalpara
::: title
Forma
:::

Por ejemplo, diagramas UML de despligue describiendo los canales a
sistemas vecinos, junto con una tabla de mapeo mostrando las relaciones
entre los canales y las entradas/salidas.
::::
::::::::::

**\<Diagrama o Tabla\>**

**\<Opcional: Explicación de las interfases técnicas\>**

**\<Mapeo de Entrada/Salida a canales\>**
