Apéndice. Incidentes abiertos {#_ap_ndice_incidentes_abiertos}
=============================

La siguiente tabla contiene una lista de todos los incidentes abiertos
identificados relacionados con este doucmento

La lista de todas los incidentes cerrados se pueden ver directamente en
Jira.

  ID                     Prioridad   Creado      Asignado a             Resumen
  ---------------------- ----------- ----------- ---------------------- --------------------------------------------------------------------

  : Incidentes abiertos


