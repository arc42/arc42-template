# Kockázatok és technikai adósságok {#section-technical-risks}

:::::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Tartalom
:::

Az azonosított technikai kockázatok vagy technikai adósságok listája,
prioritás szerint rendezve.
::::

:::: formalpara
::: title
Motiváció
:::

„A kockázatkezelés felnőttek projektmenedzsmentje" (Tim Lister, Atlantic
Systems Guild.)
::::

Ez legyen az irányelv a kockázatok és technikai adósságok szisztematikus
felderítéséhez és értékeléséhez az architektúrában, amelyre a vezetői
szintű érdekelt feleknek (pl. projektvezetők, terméktulajdonosok)
szükségük van az átfogó kockázatelemzés és méréstervezés részeként.

:::: formalpara
::: title
Forma
:::

Kockázatok és/vagy technikai adósságok listája, valószínűleg javasolt
intézkedésekkel a kockázatok minimalizálására, mérséklésére vagy
elkerülésére, illetve a technikai adósságok csökkentésére.
::::

:::: formalpara
::: title
További információ
:::

Lásd [Kockázatok és technikai
adósság](https://docs.arc42.org/section-11/) az arc42 dokumentációban.
::::
::::::::::::
