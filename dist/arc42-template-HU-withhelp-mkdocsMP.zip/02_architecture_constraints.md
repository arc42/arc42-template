# Architekturális megkötések {#section-architecture-constraints}

:::::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Tartalom
:::

Minden olyan követelmény, amely korlátozza a szoftverarchitekteket a
tervezési és megvalósítási döntéseikben, illetve a fejlesztési
folyamatra vonatkozó döntéseikben. Ezek a megkötések néha túlmutatnak az
egyes rendszereken, és egész szervezetekre vagy vállalatokra érvényesek.
::::

:::: formalpara
::: title
Motiváció
:::

Az architekteknek pontosan tudniuk kell, hol szabadok a tervezési
döntéseikben, és hol kell betartaniuk a megkötéseket. A megkötésekkel
mindig foglalkozni kell; bár lehetnek tárgyalhatók.
::::

:::: formalpara
::: title
Forma
:::

Egyszerű táblázatok megkötésekkel és magyarázatokkal. Szükség esetén
feloszthatók technikai korlátokra, szervezeti és politikai megkötésekre,
valamint konvenciókra (pl. programozási vagy verziókezelési irányelvek,
dokumentációs vagy elnevezési konvenciók).
::::

:::: formalpara
::: title
További információ
:::

Lásd [Architekturális megkötések](https://docs.arc42.org/section-2/) az
arc42 dokumentációban.
::::
::::::::::::
