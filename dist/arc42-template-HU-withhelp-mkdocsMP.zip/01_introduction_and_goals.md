# Bevezetés és célok {#section-introduction-and-goals}

:::: sidebar
::: title
:::

Leírja azokat a követelményeket és hajtóerőket, amelyeket a
szoftverarchitekteknek és a fejlesztőcsapatnak figyelembe kell venniük.
Ezek a következők:

- alapvető üzleti célok,

- lényeges funkciók,

- lényeges funkcionális követelmények,

- az architektúra minőségi céljai és

- a releváns érdekelt felek és elvárásaik
::::

## Követelmények áttekintése {#_követelmények_áttekintése}

:::::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Tartalom
:::

A funkcionális követelmények rövid leírása, hajtóerők, a követelmények
kivonata (vagy összefoglalása). Hivatkozás a (remélhetőleg létező)
követelmény-dokumentumokra (verziószámmal és az elérhetőség
megjelölésével).
::::

:::: formalpara
::: title
Motiváció
:::

A végfelhasználók szemszögéből a rendszert egy üzleti tevékenység jobb
támogatása és/vagy a minőség javítása érdekében hozzák létre vagy
módosítják.
::::

:::: formalpara
::: title
Forma
:::

Rövid szöveges leírás, valószínűleg táblázatos használati eset
formátumban. Ha léteznek követelmény-dokumentumok, ez az áttekintés
hivatkozzon azokra.
::::

Tartsa ezeket a kivonatokat a lehető legrövidebben. Egyensúlyozzon a
dokumentum olvashatósága és a követelmény-dokumentumokkal való esetleges
redundancia között.

:::: formalpara
::: title
További információ
:::

Lásd [Bevezetés és célok](https://docs.arc42.org/section-1/) az arc42
dokumentációban.
::::
::::::::::::

## Minőségi célok {#_minőségi_célok}

:::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Tartalom
:::

Az architektúra három (legfeljebb öt) legfontosabb minőségi célja,
amelyek teljesülése a legfontosabb érdekelt felek számára a legnagyobb
jelentőséggel bír. Valóban az architektúra minőségi céljairól van szó.
Ne keverje össze ezeket a projekt céljaival. Nem feltétlenül azonosak.
::::

Tekintse át a lehetséges témák alábbi áttekintését (az ISO 25010
szabvány alapján):

![Minőségi követelmények
kategóriái](images/01_2_iso-25010-topics-HU-2023.drawio.png)

:::: formalpara
::: title
Motiváció
:::

Ismernie kell a legfontosabb érdekelt felek minőségi céljait, mivel ezek
alapvető architekturális döntéseket befolyásolnak. Legyen nagyon konkrét
ezekkel a minőségi jellemzőkkel kapcsolatban, kerülje a divatos
szavakat. Ha architektként nem tudja, hogyan fogják munkája minőségét
megítélni...​
::::

:::: formalpara
::: title
Forma
:::

Táblázat minőségi célokkal és konkrét forgatókönyvekkel, prioritás
szerint rendezve
::::
::::::::::

## Érdekelt felek {#_érdekelt_felek}

:::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Tartalom
:::

A rendszer érdekelt feleinek explicit áttekintése, azaz minden személy,
szerepkör vagy szervezet, amely
::::

- ismernie kell az architektúrát

- meg kell győzni az architektúráról

- az architektúrával vagy a kóddal kell dolgoznia

- munkájához szüksége van az architektúra dokumentációjára

- a rendszerrel vagy annak fejlesztésével kapcsolatos döntéseket kell
  hoznia

:::: formalpara
::: title
Motiváció
:::

Ismernie kell minden, a rendszer fejlesztésében érintett vagy a rendszer
által érintett felet. Ellenkező esetben kellemetlen meglepetések érhetik
a fejlesztési folyamat során. Ezek az érdekelt felek határozzák meg
munkája és annak eredményei terjedelmét, valamint részletességi
szintjét.
::::

:::: formalpara
::: title
Forma
:::

Táblázat szerepkörökkel, személynevekkel és az architektúrával, illetve
annak dokumentációjával kapcsolatos elvárásaikkal.
::::
::::::::::

+-------------------+---------------------------+---------------------------+
| Szerepkör/Név     | Elérhetőség               | Elvárások                 |
+===================+===========================+===========================+
| *\<Szerepkör-1\>* | *\<Elérhetőség-1\>*       | *\<Elvárás-1\>*           |
+-------------------+---------------------------+---------------------------+
| *\<Szerepkör-2\>* | *\<Elérhetőség-2\>*       | *\<Elvárás-2\>*           |
+-------------------+---------------------------+---------------------------+
