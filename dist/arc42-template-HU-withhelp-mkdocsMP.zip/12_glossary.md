# Szójegyzék {#section-glossary}

:::::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Tartalom
:::

A legfontosabb szakterületi és technikai kifejezések, amelyeket az
érdekelt felek a rendszer megvitatásakor használnak.
::::

A szójegyzék fordítási forrásként is szolgálhat, ha többnyelvű
csapatokban dolgozik.

:::: formalpara
::: title
Motiváció
:::

Egyértelműen meg kell határoznia a kifejezéseket, hogy minden érdekelt
fél
::::

- azonos módon értse ezeket a kifejezéseket

- ne használjon szinonimákat és homonimákat

:::: formalpara
::: title
Forma
:::

Táblázat \<Kifejezés\> és \<Meghatározás\> oszlopokkal.
::::

Szükség esetén további oszlopok fordításokhoz.

:::: formalpara
::: title
További információ
:::

Lásd [Szójegyzék](https://docs.arc42.org/section-12/) az arc42
dokumentációban.
::::
::::::::::::

+----------------------+-----------------------------------------------+
| Kifejezés            | Meghatározás                                  |
+======================+===============================================+
| *\<Kifejezés-1\>*    | *\<meghatározás-1\>*                          |
+----------------------+-----------------------------------------------+
| *\<Kifejezés-2\>*    | *\<meghatározás-2\>*                          |
+----------------------+-----------------------------------------------+
