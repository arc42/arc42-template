# Kontextus és hatókör {#section-context-and-scope}

:::::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Tartalom
:::

A kontextus és hatókör -- ahogy a neve is sugallja -- elhatárolja a
rendszert (azaz a hatókört) az összes kommunikációs partnerétől
(szomszédos rendszerek és felhasználók, azaz a rendszer kontextusa).
Ezáltal meghatározza a külső interfészeket.
::::

Szükség esetén különítse el az üzleti kontextust (szakterület-specifikus
bemenetek és kimenetek) a technikai kontextustól (csatornák,
protokollok, hardver).

:::: formalpara
::: title
Motiváció
:::

A kommunikációs partnerek felé mutató szakterületi és technikai
interfészek a rendszer legkritikusabb szempontjai közé tartoznak.
Győződjön meg róla, hogy teljesen megérti őket.
::::

:::: formalpara
::: title
Forma
:::

Különböző lehetőségek:
::::

- Kontextus-diagramok

- Kommunikációs partnerek és interfészeik listája.

:::: formalpara
::: title
További információ
:::

Lásd [Kontextus és hatókör](https://docs.arc42.org/section-3/) az arc42
dokumentációban.
::::
::::::::::::

## Üzleti kontextus {#_üzleti_kontextus}

:::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Tartalom
:::

Az **összes** kommunikációs partner (felhasználók, IT-rendszerek, ...​)
specifikációja a szakterület-specifikus bemenetek és kimenetek, illetve
interfészek magyarázatával. Opcionálisan hozzáadhatók
szakterület-specifikus formátumok vagy kommunikációs protokollok.
::::

:::: formalpara
::: title
Motiváció
:::

Minden érdekelt félnek meg kell értenie, milyen adatok cserélődnek a
rendszer környezetével.
::::

:::: formalpara
::: title
Forma
:::

Bármilyen diagram, amely a rendszert fekete dobozként mutatja, és
meghatározza a szakterületi interfészeket a kommunikációs partnerek
felé.
::::

Alternatívaként (vagy kiegészítésként) használhat táblázatot is. A
táblázat címe a rendszer neve, a három oszlop tartalmazza a
kommunikációs partner nevét, a bemeneteket és a kimeneteket.
::::::::::

**\<Diagram vagy táblázat\>**

**\<opcionális: Külső szakterületi interfészek magyarázata\>**

## Technikai kontextus {#_technikai_kontextus}

:::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Tartalom
:::

Technikai interfészek (csatornák és átviteli közegek), amelyek a
rendszert a környezetéhez kapcsolják. Emellett a szakterület-specifikus
bemenet/kimenet leképezése a csatornákra, azaz annak magyarázata, hogy
melyik I/O melyik csatornát használja.
::::

:::: formalpara
::: title
Motiváció
:::

Sok érdekelt fél a rendszer és kontextusa közötti technikai interfészek
alapján hoz architekturális döntéseket. Különösen az infrastruktúra-
vagy hardvertervezők döntik el ezeket a technikai interfészeket.
::::

:::: formalpara
::: title
Forma
:::

Pl. UML telepítési diagram, amely a szomszédos rendszerek felé mutató
csatornákat írja le, kiegészítve egy leképezési táblázattal, amely a
csatornák és a bemenet/kimenet közötti kapcsolatokat mutatja.
::::
::::::::::

**\<Diagram vagy táblázat\>**

**\<opcionális: Technikai interfészek magyarázata\>**

**\<Bemenet/kimenet leképezése csatornákra\>**
