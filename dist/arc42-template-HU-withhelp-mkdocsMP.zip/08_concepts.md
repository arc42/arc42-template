# Keresztmetszeti koncepciók {#section-concepts}

:::::::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Tartalom
:::

Ez a fejezet a keresztmetszeti koncepciókat (gyakorlatok, minták,
szabályozások vagy megoldási ötletek) írja le. Az ilyen koncepciók
gyakran több építőelemhez kapcsolódnak. Számos különböző témát
tartalmazhatnak, mint például az alábbi ábrán bemutatottak:
::::

![A keresztmetszeti koncepciók lehetséges
témái](images/08-concepts-HU.drawio.png)

:::: formalpara
::: title
Motiváció
:::

A koncepciók alkotják az architektúra *fogalmi integritásának*
(konzisztencia, homogenitás) alapját. Ezáltal fontos hozzájárulást
jelentenek a rendszer belső minőségeinek eléréséhez.
::::

Ez a sablon azon helye, amelyet az ilyen koncepciók egységes
specifikációjára biztosítottunk.

Ezek közül sok koncepció több építőelemhez kapcsolódik vagy hat rájuk.

:::: formalpara
::: title
Forma
:::

A forma változatos lehet:
::::

- koncepciódokumentumok bármilyen struktúrával

- példamegvalósítások, különösen technikai koncepciókhoz

- keresztmetszeti modellrészletek vagy forgatókönyvek az architekturális
  nézetek jelöléseivel

:::: formalpara
::: title
Struktúra
:::

Válassza ki **csak** a rendszer számára leginkább szükséges témákat, és
rendeljen hozzájuk egy 2. szintű címsort ebben a fejezetben (pl. 8.1,
8.2 stb).
::::

NE PRÓBÁLJA meg lefedni a fent említett diagram összes témáját.

:::: formalpara
::: title
További információ
:::

Egyes témák a rendszerekben gyakran több építőelemet, hardverelemet vagy
fejlesztési folyamatot érintenek. Könnyebb lehet az ilyen
*keresztmetszeti* témákat egy központi helyen kommunikálni vagy
dokumentálni, ahelyett hogy megismételnénk őket az érintett építőelemek,
hardverelemek vagy fejlesztési folyamatok leírásában.
::::

Bizonyos koncepciók **minden** elemre vonatkozhatnak, mások csak
néhányra lehetnek relevánsak. A fenti ábrán a naplózás mindhárom
komponenst érinti, míg a biztonság csak két komponens számára releváns.

Lásd [Koncepciók](https://docs.arc42.org/section-8/) az arc42
dokumentációban.
::::::::::::::

## *\<1. koncepció\>* {#_1_koncepció}

*\<magyarázat\>*

## *\<2. koncepció\>* {#_2_koncepció}

*\<magyarázat\>*

...​

## *\<n. koncepció\>* {#_n_koncepció}

*\<magyarázat\>*
