# Bouwstenen View

Inhoud

De bouwstenen view toont de statische decompositie van het systeem in
bouwstenen (modules, componenten, subsystemen, classes, interfaces,
packages, libraries, frameworks, lagen, partitions, lagen, functies,
macros, operaties, data structuren, …​) en hun onderlinge
afhankelijkheden (relaties, associaties, …​).

Deze view is verplicht voor iedere architectuur documentatie. In termen
van een huis is dit het *grond plan*.

Motivatie

Hou een overzicht van de source code bij door de structuur begrijpelijk
te maken door middel van abstracties.

Dit zorgt ervoor dat het mogelijk is om op een abstract niveau te
communiceren met de belanghebbenden zonder daarbij op implementatie
details in te hoeven gaan.

Vorm

De bouwstenen view is een hiërarchische verzameling van 'black boxes' en
'white boxes' (zie het onderstaande plaatje) met de bijbehorende
beschrijvingen.

<figure>
<img src="images/05_building_blocks-EN.png"
alt="Hiërarchie van bouwstenen" />
</figure>

**Niveau 1** is een 'white box' beschijving van het gehele systeem
gecombineerd met 'black box' beschrijvingen van alle ingesloten
bouwstenen.

**Niveau 2** zoomt in op sommige bouwstenen uit niveau 1. Zodoende bevat
het de 'white box' beschrijving van specifieke bouwstenen uit niveau 1,
gecombineerd met 'black box' beschrijvingen van hun interne bouwstenen.

**Niveau 3** zoomt in op geslecteerde bouwstenen uit niveau 2, en zo
verder.

Verdere Informatie

Zie [Building Block View](https://docs.arc42.org/section-5/) in de arc42
documentatie.

## Gehele whitebox Systeem

Hier wordt de decompositie van het gehele systeem beschreven aan de hand
van het volgende 'white box' template. Die bestaat uit

- een overzichts diagram

- een motivatie voor de decompositie

- 'black box' beschrijvingen van ingesloten bouwstenen. Hiervoor zijn er
  verschillende alternatieven:

  - gebruik *één* tabel for een korte en pragmatisch overzicht van alle
    ingesloten bouwstenen en hun interfaces.

  - gebruik een lijst met 'black box' beschrijvingen van de bouwstenen
    aan de hand van het 'black box' template (zie hieronder).
    Afhankelijk van de gebruikte tool kan deze lijst in de vorm van een
    sub-hoofdstuk (in tekst bestanden), sub-pagina’s (in een Wiki) of
    geneste elementen (in een modelleer tool) zijn.

- (optioneel:) belangrijke interfaces die niet in de 'black box'
  templates van de bouwstenen worden uitgelegd maar desondanks van
  belang zijn om de 'white box' goed te kunnen begrijpen. Omdat er zo
  veel verschillende manieren zijn om interfaces te specificeren wordt
  er geen specifiek template aangeboden. In het ergste geval moeten
  syntax, semantiek, protocollen, error afhandeling, beperkingen,
  versies, kwaliteits attributen, benodigde compatibiliteit en vele
  andere zaken gespecificeerd en beschreven worden. In het beste geval
  zijn voorbeelden of simpele beschrijvingen voldoende.

***&lt;Overzichts Diagram&gt;***

Motivatie  
*&lt;tekstuele uitleg&gt;*

Ingesloten bouwstenen  
*&lt;Beschrijving van ingesloten bouwstenen ('black boxes')&gt;*

Belangrijke Interfaces  
*&lt;Beschrijving van belangrijke interfaces&gt;*

Voeg hier de uitleg van de 'black boxes' van niveau 1 toe:

In tabel vorm moeten hier enkel de 'black boxes' met hun naam een
verantwoordelijkheden worden beschreven:

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;"><strong>Naam</strong></th>
<th style="text-align: left;"><strong>Verantwoordelijkeid</strong></th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p><em>&lt;black box 1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Tekst&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"><p><em>&lt;black box 2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Tekst&gt;</em></p></td>
</tr>
</tbody>
</table>

In het geval er een lijst met 'black box' beschrijvingen wordt gebruikt,
vul dan een aparte 'black box' template in voor iedere belangrijke
bouwsteen. De kop bij die sectie is dan de naam van de specifieke 'black
box'.

### &lt;Naam black box 1&gt;

Beschrijf hier &lt;'black box' 1&gt; Aan de hand van de onderstaande
'black box' template:

- Doel/Verantwoordelijkheid

- Interface(s), als ze niet als aparte paragraven worden geadresseerd.
  Deze interface beschrijvingen kunnen kwaliteit en prestatie
  karakteristieken bevatten.

- (Optioneel) Kwaliteits-/Prestatie karakteristieken van de 'black box',
  bijvoorbeeld beschikbaarheid, run time gedrag, …​.

- (Optioneel) directories/bestand locaties

- (Optioneel) Vervulde requirements (als er traceerbaarheid van de
  requirements is vereist)

- (Optioneel) Open issues/problemen/risico’s

*&lt;Doel/Verantwoordelijkheid&gt;*

*&lt;Interface(s)&gt;*

*&lt;((Optioneel) Kwaliteits-/Prestatie karakteristieken&gt;*

*&lt;(Optioneel) directories/bestand locaties&gt;*

*&lt;(Optioneel) Vervulde requirements&gt;*

*&lt;(Optioneel) Open issues/problemen/risico’s&gt;*

## &lt;Naam black box 2&gt;

*&lt;black box template&gt;*

### &lt;Naam black box n&gt;

*&lt;black box template&gt;*

### &lt;Naam interface 1&gt;

…​

### &lt;Naam interface m&gt;

## Niveau 2

Hier kunnen de innerlijke structuren van (sommige) bouwstenen uit niveau
1 als 'white boxes' worden gespecificeerd.

Er moet een keuze gemaakt worden voor welke bouwstenen het
gerechtvaardigd is om zo’n gedetailleerde beschrijving te maken. Geeft
de voorkeur aan relevantie boven compleetheid. Beschrijf belangrijke,
verassende, risicovolle, complexe of vluchtige bouwstenen. Laat normale,
simpele, saaie of gestandardiseerde delen van het systeem buiten
beschouwing.

### White Box *&lt;bouwsteen 1&gt;*

…​beschrijft de interne structuur van *bouwsteen 1*.

*&lt;white box template&gt;*

### White Box *&lt;bouwsteen 2&gt;*

*&lt;white box template&gt;*

…​

### White Box *&lt;bouwsteen m&gt;*

*&lt;white box template&gt;*

## Niveau 3

Hier kan de interne structuur van (sommige) niveau 2 bouwstenen als
'white boxes' worden beschreven.

Als er meer gedetailleerde niveaus van de architectuur nodig zijn,
kopieer dan dit deel van arc42 voor aanvullende niveaus.

### White Box *&lt;bouwsteen x.1&gt;*

Specificeer de interne structuur van *bouwsteen x.1*.

*&lt;white box template&gt;*

### White Box *&lt;bouwsteen x.2&gt;*

*&lt;white box template&gt;*

### White Box *&lt;bouwsteen y.1&gt;*

*&lt;white box template&gt;*
