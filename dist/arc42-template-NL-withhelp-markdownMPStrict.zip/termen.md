<table>
<caption>Vertalingen</caption>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">EN term</th>
<th style="text-align: left;">NL term</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p>Abstract</p></td>
<td style="text-align: left;"><p>Beschrijving</p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p>Building block</p></td>
<td style="text-align: left;"><p>Bouwsteen</p></td>
</tr>
<tr class="odd">
<td style="text-align: left;"><p>Constraints</p></td>
<td style="text-align: left;"><p>Beperkingen</p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p>Channel</p></td>
<td style="text-align: left;"><p>Kanaal</p></td>
</tr>
<tr class="odd">
<td style="text-align: left;"><p>Excerpt(s)</p></td>
<td style="text-align: left;"><p>Uittreksel(s)</p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p>Extract</p></td>
<td style="text-align: left;"><p>Samenvatting</p></td>
</tr>
<tr class="odd">
<td style="text-align: left;"><p>Feature</p></td>
<td style="text-align: left;"><p>Eigenschap</p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p>Key quality goals</p></td>
<td style="text-align: left;"><p>Meest balangrijke kwaliteits doelen</p></td>
</tr>
<tr class="odd">
<td style="text-align: left;"><p>Level</p></td>
<td style="text-align: left;"><p>Niveau</p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p>Stakeholder(s)</p></td>
<td style="text-align: left;"><p>Belanghebbende(n)</p></td>
</tr>
</tbody>
</table>

Vertalingen
