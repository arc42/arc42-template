# Woordenlijst

**Inhoud**

De belangrijkste domein en technische termen die belanghebbenden
gebruiken tijdens het bespreken van het systeem.

De woordenlijst kan ook als bron voor vertaalde termen worden gebruikt
bij meertalige teams.

**Motivatie**

Termen moeten helder worden gedefinieerd zodat alle belanghebbenden

-   een gemeenschappelijk en eenduidig begrip hebben van deze termen

-   geen gebruik maken van synoniemen of homoniemen

<!-- -->

-   Een tabel met kolommen &lt;Term&gt; en &lt;Definitie&gt;.

-   Eventueel meerdere kolommen als er vertalingen nodig zijn.

See [Glossary](https://docs.arc42.org/section-12/) in the arc42
documentation.

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Term</th>
<th style="text-align: left;">Definitie</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Term-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definitie-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Term-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;definitie-2&gt;</em></p></td>
</tr>
</tbody>
</table>
