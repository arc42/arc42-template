# Context en Systeem Scope

## Business Context

**&lt;Diagram of Tabel>**

**&lt;optioneel: Uitleg van de externe domein interfaces>**

## Technische Context

**&lt;Diagram of Tabel>**

**&lt;optioneel: Uitleg van technische interfaces>**

**&lt;Mapping Input/Output naar kanalen>**
