# Runtime View

**Inhoud**

De runtime view beschrijft concreet gedrag en de interacties tussen de
bouwstenen van het systeem vanuit de volgende gebieden:

-   belangrijke use cases of eigenschappen: op welke manier voeren de
    bouwstenen deze uit?

-   interactie bij kritieke externe interfaces: hoe werken bouwstenen
    samen met gebruikers en aanpalende systemen?

-   operations en administrie: uitvoeren, starten, stoppen

-   error en uitzonderlijke (exception) scenarios

Het primaire criterium bij de keuze van mogelijke scenarios (sequences,
workflows) is de relevantie met betrekking tot de architectuur. Het is
uitdrukkelijk **niet** van belang om een groot aantal scenarios te
beschrijven. Beschrijf liever een representatieve doorsnede.

**Motivatie**

Beschrijft hoe (instanties van) bouwstenen van het systeem hun taken
uitvoeren en hoe ze *at runtime* communiceren.

De scenarios zullen hoofdzakelijk beschreven worden om de architectuur
aan belanghebbenden te communiceren die minder behoefte of kunde hebben
om statische modellen (bouwstenen view, deploy view) te lezen en te
doorgronden.

**Vorm**

Er zijn meerdere manieren om de schenarios vast te leggen, bijvoorbeeld

-   (uitgeschreven) opsomming van de stappen

-   activiteiten of flow diagrammen

-   sequence diagrammen

-   BPMN of EPCs (event process chains)

-   state machines

-   …

Zie [Runtime View](https://docs.arc42.org/section-6/) in de arc42
documentatie.

## &lt;Runtime Scenario 1>

-   *&lt;voeg een runtime diagram of een tekstuele beschrijving van het
    scenario toe>*

-   *&lt;voeg een beschrijving toe van bijzondere aspecten van de
    interactie tussen de instanties van de bouwstenen die in dit diagram
    worden weergegeven>*

## &lt;Runtime Scenario 2>

## …

## &lt;Runtime Scenario n>
