# Runtime View

## &lt;Runtime Scenario 1&gt;

-   *&lt;voeg een runtime diagram of een tekstuele beschrijving van het
    scenario toe&gt;*

-   *&lt;voeg een beschrijving toe van bijzondere aspecten van de
    interactie tussen de instanties van de bouwstenen die in dit diagram
    worden weergegeven&gt;*

## &lt;Runtime Scenario 2&gt;

## …​

## &lt;Runtime Scenario n&gt;
