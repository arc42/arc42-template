---
date: March 2023
title: "![arc42](images/arc42-logo.png) Template"
---

# 

**About arc42**

arc42, the Template for documentation of software and system
architecture.

By Dr. Gernot Starke, Dr. Peter Hruschka and contributors.

Template Revision: 7.0 IT (based on asciidoc), April 2021

© We acknowledge that this document uses material from the arc 42
architecture template, <https://www.arc42.org>. Created by Dr. Peter
Hruschka & Dr. Gernot Starke.

<div class="sidebar">

<div class="title">

</div>

> [!NOTE]
> This version of the template contains some help and explanations. It
> is used for familiarization with arc42 and the understanding of the
> concepts. For documentation of your own system you use better the
> *plain* version.

</div>

# Introduzione e obiettivi

<div class="sidebar">

<div class="title">

</div>

Descrive i requisiti rilevanti e le forze trainanti che gli architetti
del software e il team di sviluppo devono considerare. Questi includono

- obiettivi di business sottostanti, caratteristiche essenziali e
  requisiti funzionali per il sistema

- obiettivi di qualità per l’architettura

- stakeholder rilevanti e le loro aspettative

</div>

## Panoramica dei requisiti

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenuti

</div>

Breve descrizione dei requisiti funzionali, forze trainanti, estratto (o
abstract) dei requisiti. Collegamento ai documenti dei requisiti (si
spera esistenti) (con il numero di versione e le informazioni su dove
trovarlo).

</div>

<div class="formalpara">

<div class="title">

Motivazione

</div>

Dal punto di vista degli utenti finali un sistema viene creato o
modificato per migliorare il supporto di un’attività di business e/o
migliorare la qualità.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Breve descrizione testuale, casi d’uso in forma tabellare. Se esistono
documenti sui requisiti, questa panoramica dovrebbe fare riferimento a
questi documenti.

</div>

Mantieni questi estratti il ​​più brevi possibile. Bilancia la leggibilità
di questo documento con la potenziale ridondanza rispetto ai documenti
dei requisiti.

</div>

## Obiettivi di qualità

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenuti

</div>

I principali tre (massimo cinque) obiettivi di qualità per
l’architettura la cui realizzazione è della massima importanza per i
principali stakeholder, Intendiamo davvero obiettivi di qualità per
l’architettura. Non confonderli con gli obiettivi del progetto. Non sono
necessariamente identici.

</div>

<div class="formalpara">

<div class="title">

Motivazione

</div>

Dovresti conoscere gli obiettivi di qualità dei tuoi stakeholder più
importanti, poiché influenzeranno le decisioni architettoniche
fondamentali. Assicurati di essere molto concreto su queste qualità,
evita le parole d’ordine. Se tu come architetto non sai come verrà
giudicata la qualità del tuo lavoro

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Una tabella con obiettivi di qualità e scenari concreti, ordinati per
priorità

</div>

</div>

## Stakeholders

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenuti

</div>

Panoramica esplicita degli stakeholder del sistema, ovvero tutte le
persone, i ruoli o le organizzazioni che

</div>

- dovrebbero conoscere l’architettura

- devono essere convinti dell’architettura

- devono lavorare con l’architettura o con il codice

- necessitano della documentazione dell’architettura per il loro lavoro

- devono prendere decisioni sul sistema o sul suo sviluppo

<div class="formalpara">

<div class="title">

Motivazione

</div>

È necessario conoscere tutte le parti coinvolte nello sviluppo del
sistema o interessate dal sistema. Altrimenti, potresti ricevere brutte
sorprese più avanti nel processo di sviluppo. Questi stakeholder
determinano la portata e il livello di dettaglio del tuo lavoro e dei
suoi risultati.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Tabella con i nomi dei ruoli, i nomi delle persone e le loro aspettative
rispetto all’architettura e alla sua documentazione

</div>

</div>

| Rouolo/Nome   | Contatto         | Aspettative          |
|---------------|------------------|----------------------|
| *\<Ruolo-1\>* | *\<Contatto-1\>* | *\<Aspettatiive-1\>* |
| *\<Ruolo-2\>* | *\<Contatto-2\>* | *\<Aspettatiive-2\>* |

# Vincoli di architettura

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenuti

</div>

Qualsiasi requisito che limiti gli architetti del software nella loro
libertà di decisioni di progettazione e implementazione o decisione sul
processo di sviluppo. Questi vincoli a volte vanno oltre i singoli
sistemi e sono validi per intere organizzazioni e aziende.

</div>

<div class="formalpara">

<div class="title">

Motivazione

</div>

Gli architetti dovrebbero sapere esattamente dove sono liberi nelle loro
decisioni di progettazione e dove devono aderire ai vincoli. I vincoli
devono essere sempre affrontati; possono essere negoziabili però.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Semplici tabelle di vincoli con spiegazioni. Se necessario puoi
suddividerli in file vincoli tecnici, vincoli organizzativi e politici e
convenzioni (ad es. linee guida di programmazione o di controllo delle
versioni, documentazione o convenzioni di denominazione)

</div>

</div>

# Ambito e contesto del sistema

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenuti

</div>

L’ambito e il contesto del sistema, come suggerisce il nome, delimitano
il sistema (ovvero l’ambito) da tutti i suoi partner di comunicazione
(sistemi e utenti vicini, ovvero il contesto del tuo sistema). In tal
modo specifica le interfacce esterne.

</div>

Se necessario, differenziare il contesto di business (input e output
specifici del dominio) dal contesto tecnico (canali, protocolli,
hardware).

<div class="formalpara">

<div class="title">

Motivazione

</div>

Le interfacce di dominio e le interfacce tecniche per i partner di
comunicazione sono tra gli aspetti più critici del sistema. Assicurati
di capirli completamente.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Diverse opzioni:

</div>

- Diagrammi di contesto

- Elenchi di partner di comunicazione e loro interfacce.

</div>

## Contesto di Business

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenuti

</div>

Specifica di **tutti** i partner di comunicazione (utenti, sistemi IT,
…​) con spiegazioni di input e output specifici del dominio o interfacce.
Facoltativamente è possibile aggiungere formati specifici del dominio o
protocolli di comunicazione.

</div>

<div class="formalpara">

<div class="title">

Motivazione

</div>

Tutti gli stakeholder dovrebbero capire quali dati vengono scambiati con
l’ambiente del sistema.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Tutti i tipi di diagrammi che mostrano il sistema come una scatola nera
e specificano le interfacce di dominio per i partner di comunicazione.

</div>

In alternativa (o in aggiunta) puoi usare una tabella. Il titolo della
tabella è il nome del sistema, le tre colonne contengono il nome del
partner di comunicazione, gli ingressi e le uscite.

</div>

**\<Diagramma o Tabella\>**

**\<opzionale: spiegazione delle interfacce del dominio esterno\>**

## Contesto Tecnico

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenuti

</div>

Interfacce tecniche (canali e mezzi di trasmissione) che collegano il
sistema al suo ambiente. Oltre alla mappatura dell’input/output
specifico del dominio sui canali di comunicazione, ad es. una
spiegazione con I/O dell’utilizza del canale di comunicazione.

</div>

<div class="formalpara">

<div class="title">

Motivazione

</div>

Spesso, gli stakeholders prendono decisioni architetturali in base alle
interfacce tecniche tra il sistema e il suo contesto. Sono,
principalmente i progettisti di infrastrutture o hardware che decidono
queste interfacce tecniche.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Esempio: un deployment diagram UML che descrive i canali di
comunicazione dei sistemi vicini, insieme a una tabella di mappatura che
mostra le relazioni tra canali e input/output.

</div>

</div>

**\<Diagramma o Tabella\>**

**\<opzionale: Spiegazione delle interfacce tecniche\>**

**\<Mappatura Input/Output sui canali di comunicazione\>**

# Strategia della soluzione

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenuti

</div>

Un breve riassunto e spiegazione delle decisioni fondamentali e delle
strategie di soluzione che modellano l’architettura del sistema. Questi
includono

</div>

- decisioni tecnologiche

- decisioni sulla scomposizione di primo livello del sistema, ad es.
  utilizzo di un modello architetturale o di un modello di progettazione

- decisioni su come raggiungere gli obiettivi chiave di qualità

- decisioni organizzative rilevanti, ad es. selezionare un processo di
  sviluppo o delegare determinati compiti a terzi.

<div class="formalpara">

<div class="title">

Motivazione

</div>

Queste decisioni costituiscono le pietre angolari della tua
architettura. Sono la base per molte altre decisioni dettagliate o
regole di attuazione.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Mantieni breve la spiegazione di queste decisioni chiave.

</div>

Motiva ciò che hai deciso e perché lo hai deciso in questo modo, in base
alla dichiarazione del problema, agli obiettivi di qualità e ai vincoli
chiave. Fare riferimento ai dettagli nelle sezioni seguenti.

</div>

# Building Block View

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenuti

</div>

La visualizzazione building block mostra la scomposizione statica del
sistema in building block (moduli, componenti, sottosistemi, classi,
interfacce, pacchetti, librerie, framework, livelli, partizioni,
livelli, funzioni, macro, operazioni, strutture dei dati, …​) così come
le loro dipendenze (relazioni, associazioni, …​)

</div>

Questa vista dovrebbe essere obbligatoria per ogni documentazione
sull’architettura. In analogia con una casa, questa è la *pianta dei
piani*.

<div class="formalpara">

<div class="title">

Motivazione

</div>

Mantieni una panoramica del tuo codice sorgente rendendone comprensibile
la struttura tramite astrazioni di essa.

</div>

Ciò consente di comunicare con gli stakeholder a livello astratto senza
rivelare i dettagli di implementazione.

<div class="formalpara">

<div class="title">

Forma

</div>

è una raccolta gerarchica di black box e white box (vedi figura sotto) e
le loro descrizioni.

</div>

<figure>
<img src="images/05_building_blocks-IT.png"
alt="Gerarchia dei building blocks" />
</figure>

**Livello 1** è la descrizione della white box del sistema complessivo
insieme alle descrizioni delle black box di tutti i building block
contenuti.

**Livello 2** entra nel dettaglio dei building block di livello 1.
Quindi contiene la descrizione della white box dei building block
selezionati del livello 1, insieme alle descrizioni della black box dei
building block interni.

**Livello 3** entra nel dettaglio dei building block di livello 2, e
cosi via..

</div>

## Whitebox Overall System

<div class="sidebar">

<div class="title">

</div>

Qui descrivi la scomposizione dell’intero sistema utilizzando il
seguente template white box. Contiene

- un diagramma generico

- una motivazione per la decomposizione

- descrizioni in black box dei building blocks contenuti. Per questi ti
  offriamo alternative:

  - usa la tabella *one* per una panoramica breve e pragmatica di tutti
    gli elementi costitutivi contenuti e delle loro interfacce

  - utilizzare un elenco di descrizioni delle black box dei building box
    secondo il template black box (vedi sotto). A seconda dello
    strumento scelto, questo elenco potrebbe essere sottocapitoli (in
    file di testo), sottopagine (in un Wiki) o elementi nidificati (in
    uno strumento di modellazione).

- (opzionale) interfacce importanti, che non sono spiegate nelle black
  box di un building block, ma sono molto importanti per comprendere la
  white box. Poiché ci sono così tanti modi per specificare le
  interfacce, non forniamo un template specifico per loro. Nel peggiore
  dei casi devi specificare e descrivere sintassi, semantica,
  protocolli, gestione degli errori, restrizioni, versioni, qualità,
  compatibilità necessarie e molte altre cose. Nel migliore dei casi te
  la caverai con esempi o semplici firme.

</div>

***\<Overview Diagram\>***

Motivazione  
*\<spiegazione testuale\>*

Contenuto dei Building Blocks  
*\<Descrizione del contenuto del building block (black boxes)\>*

Important Interfaces  
*\<Descrizione delle interfacce importanti\>*

<div class="sidebar">

<div class="title">

</div>

Inserisci le spiegazioni delle black box dal livello 1:

Se usi la forma tabulare descriveresti solo le black box con nome e
responsabilità secondo il seguente schema:

| **Nome**          | **Responsibilità** |
|-------------------|--------------------|
| *\<black box 1\>* |  *\<Text\>*        |
| *\<black box 2\>* |  *\<Text\>*        |

Se si utilizza un elenco di descrizioni delle black box, si compila un
template di black box separato per ogni building block importante. Il
titolo è il nome della black box.

</div>

### \<Nome black box 1\>

<div class="sidebar">

<div class="title">

</div>

Qui descrivi la \<black box 1\> secondo il seguente template di scatola
nera:

- Scopo/responsabilità

- Interfacce, quando non vengono estratte come paragrafi separati.
  Queste interfacce possono includere caratteristiche di qualità e
  prestazionali.

- (Facoltativo) Caratteristiche di qualità/prestazionali della black
  box, ad esempio disponibilità, comportamento in fase di esecuzione, …​.

- (Facoltativo) percorso file/directory

- (Facoltativo) Requisiti soddisfatti (se è necessaria la tracciabilità
  dei requisiti).

- (Facoltativo) Bug noti/Rischi/problemi

</div>

*\<Scopo/responsabilità\>*

*\<Interfacce\>*

*\<(Facoltativo) Caratteristiche di qualità/prestazionali\>*

*\<(Facoltativo) percorso file/directory\>*

*\<(Facoltativo) Requisiti soddisfatti\>*

*\<(Facoltativo) Bug noti/Rischi/problemi\>*

### \<Nome black box 2\>

*\<black box template\>*

### \<Nome black box n\>

*\<black box template\>*

### \<Nome interface 1\>

…​

### \<Nome interface m\>

## Livello 2

<div class="sidebar">

<div class="title">

</div>

Qui puoi specificare la struttura interna di (alcuni) building block dal
livello 1 come white box.

Devi decidere quali building block del tuo sistema sono abbastanza
importanti da giustificare una descrizione così dettagliata. Si prega di
preferire la pertinenza alla completezza. Specifica i building blocks
importanti, sorprendenti, rischiosi, complessi o volatili. Tralascia le
parti normali, semplici, noiose o standardizzate del tuo sistema

</div>

### White Box *\<building block 1\>*

<div class="sidebar">

<div class="title">

</div>

…​descrive la struttura interna del *building block 1*.

</div>

*\<white box template\>*

### White Box *\<building block 2\>*

*\<white box template\>*

…​

### White Box *\<building block m\>*

*\<white box template\>*

## Livello 3

<div class="sidebar">

<div class="title">

</div>

Qui puoi specificare la struttura interna di (alcuni) building block dal
livello 2 come white box.

Quando hai bisogno di livelli più dettagliati della tua architettura,
copia questa parte di arc42 per livelli aggiuntivi.

</div>

### White Box \<\_building block x.1\_\>

<div class="sidebar">

<div class="title">

</div>

Specifica la struttura interna del *building block x.1*.

</div>

*\<white box template\>*

### White Box \<\_building block x.2\_\>

*\<white box template\>*

### White Box \<\_building block y.1\_\>

*\<white box template\>*

# Runtime View

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenuti

</div>

La runtime view descrive il comportamento concreto e le interazioni dei
building block del sistema sotto forma di scenari dalle seguenti aree:

</div>

- importanti casi d’uso o funzionalità: come vengono eseguiti dai
  building block?

- interazioni alle interfacce esterne critiche: in che modo i building
  block cooperano con gli utenti e i sistemi vicini?

- funzionamento e amministrazione: lancio, avvio, arresto

- errori e scenari di eccezione

Nota: il criterio principale per la scelta dei possibili scenari
(sequenze, flussi di lavoro) è la loro **rilevanza architettonica**.
**Non** è importante descrivere un gran numero di scenari. Dovresti
piuttosto documentare una selezione rappresentativa.

<div class="formalpara">

<div class="title">

Motivazione

</div>

È necessario comprendere in che modo (istanze di) building block del
sistema eseguono il proprio lavoro e comunicano in fase di esecuzione.
Acquisirai principalmente scenari nella tua documentazione per
comunicare la tua architettura alle parti interessate che sono meno
disposte o in grado di leggere e comprendere i modelli statici (building
block view, deployment view).

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Ci sono molte notazioni per descrivere gli scenari, ad es.

</div>

- elenco numerato di passaggi (in linguaggio naturale)

- activity diagram o diagrammi di flusso

- sequence diagram

- BPMN o EPC (catene di processi di eventi)

- state diagram

- …​

</div>

## \<Runtime Scenario 1\>

- *\<inserire un runtime diagram o una descrizione testuale dello
  scenario\>*

- *\<inserire la descrizione degli aspetti degni di nota delle
  interazioni tra i istanze di building block illustrate in questo
  diagramma.\>*

## \<Runtime Scenario 2\>

## …​

## \<Runtime Scenario n\>

# Deployment View

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenuti

</div>

La Deployment View descrive:

</div>

1.  l’infrastruttura tecnica utilizzata per eseguire il sistema, con
    elementi dell’infrastruttura come posizioni geografiche, ambienti,
    computer, processori, canali e topologie di rete, nonché altri
    elementi dell’infrastruttura e

2.  la mappatura dei building block (software) di tali elementi
    dell’infrastruttura.

Spesso i sistemi vengono eseguiti in ambienti diversi, ad es. ambiente
di sviluppo, ambiente di test, ambiente di produzione. In questi casi è
necessario documentare tutti gli ambienti rilevanti.

Documentare in particolare la Deployment View quando il software viene
eseguito come sistema distribuito con più di un computer, processore,
server o container o quando si progettano e si costruiscono processori e
chip hardware personalizzati.

Dal punto di vista del software è sufficiente acquisire quegli elementi
dell’infrastruttura necessari per mostrare la distribuzione dei building
block. Gli architetti hardware possono andare oltre e descrivere
l’infrastruttura con qualsiasi livello di dettaglio di cui hanno bisogno
per acquisire.

<div class="formalpara">

<div class="title">

Motivazione

</div>

Il software non funziona senza hardware. Questa infrastruttura
sottostante può e influenzerà il tuo sistema e/o alcuni concetti
trasversali. Pertanto, è necessario conoscere l’infrastruttura.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Può essere che il Deployment View di livello più alto sia già contenuto
nella sezione 3.2. come contesto tecnico con la propria infrastruttura
come UNA scatola nera. In questa sezione lo farai ingrandire questa
scatola nera utilizzando Deployment View aggiuntivi:

</div>

- UML offre diagrammi di distribuzione per esprimere quella vista.
  Usalo, probabilmente con diagrammi annidati, quando la tua
  infrastruttura è più complessa.

- Quando i tuoi stakeholder (hardware) preferiscono altri tipi di
  diagrammi piuttosto che il Deployment View, lascia che utilizzino
  qualsiasi tipo che sia in grado di mostrare nodi e canali
  dell’infrastruttura.

</div>

## Livello infrastruttura 1

<div class="sidebar">

<div class="title">

</div>

Descrivi (di solito in una combinazione di diagrammi, tabelle e testo):

- la distribuzione del sistema in più posizioni, ambienti, computer,
  processori, .. così come le connessioni fisiche tra di loro

- una giustificazione o motivazione importante per questa struttura di
  distribuzione

- Caratteristiche di qualità e/o prestazioni dell’infrastruttura

- la mappatura degli artefatti software agli elementi
  dell’infrastruttura

Per più ambienti o distribuzioni alternative, copia quella sezione di
arc42 per tutti gli ambienti pertinenti.

</div>

***\<Overview Diagram\>***

Motivatione  
*\<spiegazione in forma di testo\>*

Requsiti di qualità e/o di prestazioni  
*\<spiegazione in forma di testo\>*

Mappatura dei Building Blocks nella Architettura  
*\<descrizione della mappatura\>*

## Livello infrastruttura 2

<div class="sidebar">

<div class="title">

</div>

Qui puoi includere la struttura interna di (alcuni) elementi
dell’infrastruttura dal livello 1.

Si prega di copiare la struttura dal livello 1 per ogni elemento
selezionato.

</div>

### *\<Elemento infrastruttura 1\>*

*\<diagramma + spiegazione\>*

### *\<Elemento infrastruttura 2\>*

*\<diagramma + spiegazione\>*

…​

### *\<Elemento infrastruttura n\>*

*\<diagramma + spiegazione\>*

# Concetti trasversali

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenuto

</div>

Questa sezione descrive le normative generali e principali e le idee di
soluzione che sono rilevante in più parti (= trasversali) del sistema.
Tali concetti sono spesso correlati a più building blocks. Possono
includere molti argomenti diversi, come

</div>

- modello di domonio

- modelli di architettura o modelli di design

- regole per l’utilizzo di una tecnologia specifica

- decisioni principali, spesso tecniche, di decisioni generali

- regole di implementazione

<div class="formalpara">

<div class="title">

Motivazione

</div>

I concetti costituiscono la base per l '\_ integrità concettuale\_
(coerenza, omogeneità) dell’architettura. Pertanto, sono un contributo
importante per raggiungere le qualità interne del tuo sistema.

</div>

Alcuni di questi concetti non possono essere assegnati a singoli
building blocks (ad es. sicurezza o protezione). Questo è il posto nel
template che abbiamo fornito per una specifica coerente di tali
concetti.

<div class="formalpara">

<div class="title">

Forma

</div>

Le forme possono eessere varie:

</div>

- documenti concettuali con qualsiasi tipo di struttura

- estratti di modelli trasversali o scenari che utilizzano le notazioni
  delle viste dell’architettura

- implementazioni di esempio, soprattutto per concetti tecnici

- riferimento all’uso tipico di framework standard (es. utilizzo di
  Hibernate per object/relational mapping)

<div class="formalpara">

<div class="title">

Struttura

</div>

Una struttura potenziale (ma non obbligatoria) per questa sezione
potrebbe essere:

</div>

- Concetti di dominio

- Concetti sull’esperienza utente (UX)

- Concetti di sicurezza e protezione

- Architettura e modelli di design

- "Sotto il cappuccio"

- concetti di sviluppo

- concetti operativi

Nota: potrebbe essere difficile assegnare concetti individuali a un
argomento specifico in questo elenco.

<figure>
<img src="images/08-concepts-EN.drawio.png"
alt="Possibili argomenti per concetti trasversali" />
</figure>

</div>

## *\<Concetto 1\>*

*\<spiegazione\>*

## *\<Concetto 2\>*

*\<spiegazione\>*

…​

## *\<Concetto n\>*

*\<spiegazione\>*

# Decisioni di progettazione

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenuti

</div>

Decisioni di architettura importanti, costose, su larga scala o
rischiose, inclusi i razionali. Con "decisioni" si intende selezionare
un’alternativa in base a determinati criteri.

</div>

Si prega di utilizzare il proprio giudizio per decidere se una decisione
architetturale debba essere documentata qui in questa sezione centrale o
se è meglio documentarlo localmente (ad es. all’interno del whitebox di
un building block).

Evita la ridondanza. Fare riferimento alla sezione 4, dove sono già
state acquisite le decisioni più importanti della propria architettura.

<div class="formalpara">

<div class="title">

Motivazione

</div>

Gli stakeholder del tuo sistema dovrebbero essere in grado di
comprendere e ripercorrere le tue decisioni.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

Diverse opzioni:

</div>

- Elenco o tabella, ordinati per importanza e conseguenze oppure:

- più dettagliato sotto forma di sezioni separate per le decisioni

- ADR (architecture decision record) per ogni decisione importante

</div>

# Requisiti di Qualità

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenuto

</div>

Questa sezione contiene tutti i requisiti di qualità come albero di
qualità con scenari. I più importanti sono già stati descritti nella
sezione 1.2. (obiettivi di qualità)

</div>

Qui puoi anche acquisire i requisiti di qualità con una priorità minore,
il che non creerà rischi elevati quando non sono pienamente raggiunti.

<div class="formalpara">

<div class="title">

Motivazione

</div>

Poiché i requisiti di qualità avranno molta influenza sulle decisioni
architetturali, dovresti sapere per ogni stakeholder cosa è veramente
importante per loro, concreto e misurabile.

</div>

</div>

## Albero di qualità

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenuto

</div>

L’albero della qualità (come definito in ATAM – Architecture Tradeoff
Analysis Method) con scenari di qualità/valutazione come foglie.

</div>

<div class="formalpara">

<div class="title">

Motivazione

</div>

La struttura ad albero con le priorità fornisce una panoramica per un
numero talvolta elevato di requisiti di qualità.

</div>

<div class="formalpara">

<div class="title">

Forma

</div>

L’albero della qualità è una panoramica di alto livello degli obiettivi
e dei requisiti di qualità:

</div>

- espande il termine "qualità" con la forma di un’albero. Usa "qualità"
  o "utilità" come radice

- una mappa mentale con categorie di qualità come rami principali

In ogni caso l’albero dovrebbe includere collegamenti agli scenari della
sezione successiva.

</div>

## Scenari di qualità

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenuti

</div>

Concretizzazione dei requisiti di qualità (a volte vaghi o impliciti)
utilizzando scenari (di qualità).

</div>

Questi scenari descrivono cosa dovrebbe accadere quando uno stimolo
arriva al sistema.

Per gli architetti, due tipi di scenari sono importanti:

- Gli scenari di utilizzo (chiamati anche scenari di applicazione o
  scenari di casi d’uso) descrivono la reazione di runtime del sistema a
  un determinato stimolo. Ciò include anche scenari che descrivono
  l’efficienza o le prestazioni del sistema. Esempio: il sistema
  risponde alla richiesta di un utente entro un secondo.

- Gli scenari di cambiamento descrivono una modifica del sistema o
  dell’ambiente circostante. Esempio: sono implementate funzionalità
  aggiuntive o requisiti per una modifica dell’attributo di qualità.

<div class="formalpara">

<div class="title">

Motivazione

</div>

Gli scenari rendono concreti i requisiti di qualità e consentono di
misurare o decidere più facilmente se sono soddisfatti.

</div>

Soprattutto quando vuoi valutare la tua architettura usando metodi come
ATAM devi descrivere i tuoi obiettivi di qualità (dalla sezione 1.2) più
precisamente fino a un livello di scenari che possono essere discussi e
valutati.

<div class="formalpara">

<div class="title">

Forma

</div>

Testo tabulare o testo in formato libero.

</div>

</div>

# Rischi e debiti tecnici

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenuti

</div>

Un elenco di rischi tecnici o debiti tecnici identificati, ordinati per
priorità

</div>

<div class="formalpara">

<div class="title">

Motivazione

</div>

“La gestione del rischio è la gestione del progetto per adulti” (Tim
Lister, Atlantic Systems Guild.)

</div>

Questo dovrebbe essere il tuo motto per il rilevamento e la valutazione
sistematica dei rischi e dei debiti tecnici nell’architettura, che
saranno necessari agli stakeholder del management (ad esempio i project
manager, i proprietari dei prodotti) come parte dell’analisi complessiva
dei rischi e della pianificazione delle misurazioni.

<div class="formalpara">

<div class="title">

Forma

</div>

Elenco dei rischi e/o dei debiti tecnici, possibilmente comprendendo le
misure suggerite per minimizzare, mitigare o evitare i rischi o ridurre
i debiti tecnici.

</div>

</div>

# Glossario

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Contenuti

</div>

Il dominio più importante e i termini tecnici utilizzati dagli
stakeholder quando discutono del sistema.

</div>

Puoi anche vedere il glossario come fonte per le traduzioni se lavori in
team multilingue.

<div class="formalpara">

<div class="title">

Motivazione

</div>

Dovresti definire chiaramente i tuoi termini, in modo che tutte le parti
interessate

</div>

- abbiano una comprensione identica di questi termini

- non utilizzino sinonimi e omonimi

<div>

<div class="title">

Forma

</div>

- Una tabella con colonne \<Termine\> e \<Definizione\>.

- Potenzialmente più colonne nel caso tu abbia bisogno di traduzioni.

</div>

</div>

| Termine         | Definizione         |
|-----------------|---------------------|
| *\<Termine-1\>* | *\<definizione-1\>* |
| *\<Termine-2\>* | *\<definizione-2\>* |
