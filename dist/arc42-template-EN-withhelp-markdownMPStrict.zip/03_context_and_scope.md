# Context and Scope

## Business Context

**&lt;Diagram or Table>**

**&lt;optionally: Explanation of external domain interfaces>**

## Technical Context

**&lt;Diagram or Table>**

**&lt;optionally: Explanation of technical interfaces>**

**&lt;Mapping Input/Output to Channels>**
