# Introduction and Goals

Describes the relevant requirements and the driving forces that software
architects and development team must consider. These include

- underlying business goals,

- essential features,

- essential functional requirements,

- quality goals for the architecture and

- relevant stakeholders and their expectations

## Requirements Overview

Contents

Short description of the functional requirements, driving forces,
extract (or abstract) of requirements. Link to (hopefully existing)
requirements documents (with version number and information where to
find it).

Motivation

From the point of view of the end users a system is created or modified
to improve support of a business activity and/or improve the quality.

Form

Short textual description, probably in tabular use-case format. If
requirements documents exist this overview should refer to these
documents.

Keep these excerpts as short as possible. Balance readability of this
document with potential redundancy w.r.t to requirements documents.

Further Information

See [Introduction and Goals](https://docs.arc42.org/section-1/) in the
arc42 documentation.

## Quality Goals

Contents

The top three (max five) quality goals for the architecture whose
fulfillment is of highest importance to the major stakeholders. We
really mean quality goals for the architecture. Don’t confuse them with
project goals. They are not necessarily identical.

Consider this overview of potential topics (based upon the ISO 25010
standard):

<figure>
<img src="images/01_2_iso-25010-topics-EN-2023.drawio.png"
alt="Categories of Quality Requirements" />
</figure>

Motivation

You should know the quality goals of your most important stakeholders,
since they will influence fundamental architectural decisions. Make sure
to be very concrete about these qualities, avoid buzzwords. If you as an
architect do not know how the quality of your work will be judged…​

Form

A table with quality goals and concrete scenarios, ordered by priorities

## Stakeholders

Contents

Explicit overview of stakeholders of the system, i.e. all person, roles
or organizations that

- should know the architecture

- have to be convinced of the architecture

- have to work with the architecture or with code

- need the documentation of the architecture for their work

- have to come up with decisions about the system or its development

Motivation

You should know all parties involved in development of the system or
affected by the system. Otherwise, you may get nasty surprises later in
the development process. These stakeholders determine the extent and the
level of detail of your work and its results.

Form

Table with role names, person names, and their expectations with respect
to the architecture documentation (!). Do not repeat stakeholders'
functional and quality requirements. Identify their documentation needs
here.

Example

The following stakeholder roles recur across many projects. Use it as a
starting point, then adapt the roles, names and expectations to your
actual project. Not every project has all of these roles, and some will
have additional ones.

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">Role/Name</th>
<th style="text-align: left;">Contact</th>
<th style="text-align: left;">Expectations</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p>Product Owner</p></td>
<td style="text-align: left;"><p>Product Management</p></td>
<td style="text-align: left;"><p>Prioritizes features by business value;
needs Section 1 (Requirements Overview, Quality Goals) kept aligned with
product strategy</p></td>
</tr>
<tr>
<td style="text-align: left;"><p>End Users / Customers</p></td>
<td style="text-align: left;"><p>represented via UX research, support
tickets</p></td>
<td style="text-align: left;"><p>Need the system to be usable, reliable
and fast; drive quality goals such as performance and usability</p></td>
</tr>
<tr>
<td style="text-align: left;"><p>Software Architect(s)</p></td>
<td style="text-align: left;"><p>Architecture Team</p></td>
<td style="text-align: left;"><p>Own and maintain this documentation;
use it to justify and communicate technical decisions</p></td>
</tr>
<tr>
<td style="text-align: left;"><p>Development Team</p></td>
<td style="text-align: left;"><p>Engineering Team</p></td>
<td style="text-align: left;"><p>Need clear building blocks (Section 5)
and runtime scenarios (Section 6) to implement correctly</p></td>
</tr>
<tr>
<td style="text-align: left;"><p>Operations / SRE</p></td>
<td style="text-align: left;"><p>Ops Team</p></td>
<td style="text-align: left;"><p>Need the deployment view (Section 7)
and cross-cutting concepts (Section 8, e.g. monitoring, logging) to run
the system reliably</p></td>
</tr>
<tr>
<td style="text-align: left;"><p>Security Officer / InfoSec</p></td>
<td style="text-align: left;"><p>Security Team</p></td>
<td style="text-align: left;"><p>Review the architecture against risks
(Section 11) and quality requirements (Section 10); need evidence that
security constraints are addressed</p></td>
</tr>
<tr>
<td style="text-align: left;"><p>Compliance / Legal</p></td>
<td style="text-align: left;"><p>Legal/Compliance Team</p></td>
<td style="text-align: left;"><p>Need evidence that regulatory
constraints (Section 2) are respected, e.g. data protection,
licensing</p></td>
</tr>
<tr>
<td style="text-align: left;"><p>Project Sponsor / Management</p></td>
<td style="text-align: left;"><p>Steering Committee</p></td>
<td style="text-align: left;"><p>Need confidence that architecture
decisions (Section 9) support budget, timeline and strategic
goals</p></td>
</tr>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">Role/Name</th>
<th style="text-align: left;">Contact</th>
<th style="text-align: left;">Expectations</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p><em>&lt;Role-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Contact-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Expectation-1&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"><p><em>&lt;Role-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Contact-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Expectation-2&gt;</em></p></td>
</tr>
</tbody>
</table>
