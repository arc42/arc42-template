# Cross-cutting Concepts {#section-concepts}

## *&lt;Concept 1&gt;* {#_concept_1}

*&lt;explanation&gt;*

## *&lt;Concept 2&gt;* {#_concept_2}

*&lt;explanation&gt;*

…​

## *&lt;Concept n&gt;* {#_concept_n}

*&lt;explanation&gt;*

  [Cross-cutting Concepts]: #section-concepts {#toc-section-concepts}
  [*&lt;Concept 1&gt;*]: #_concept_1 {#toc-_concept_1}
  [*&lt;Concept 2&gt;*]: #_concept_2 {#toc-_concept_2}
  [*&lt;Concept n&gt;*]: #_concept_n {#toc-_concept_n}
