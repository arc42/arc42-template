**About arc42**

arc42, the template for documentation of software and system architecture.

Template Version 9.0-EN. (based upon AsciiDoc version), July 2025

Created, maintained and © by Dr. Peter Hruschka, Dr. Gernot Starke and contributors. See <https://arc42.org>.


0. [Runtime View](06_runtime_view.md)

0. [Building Block View](05_building_block_view.md)

0. [Introduction and Goals](01_introduction_and_goals.md)

0. [Deployment View](07_deployment_view.md)

0. [Architecture Constraints](02_architecture_constraints.md)

0. [Risks and Technical Debts](11_technical_risks.md)

0. [Cross-cutting Concepts](08_concepts.md)

0. [Architecture Decisions](09_architecture_decisions.md)

0. [Glossary](12_glossary.md)

0. [Quality Requirements](10_quality_requirements.md)

0. [Context and Scope](03_context_and_scope.md)

0. [Solution Strategy](04_solution_strategy.md)
