# Szójegyzék

Tartalom

A legfontosabb szakterületi és technikai kifejezések, amelyeket az
érdekelt felek a rendszer megvitatásakor használnak.

A szójegyzék fordítási forrásként is szolgálhat, ha többnyelvű
csapatokban dolgozik.

Motiváció

Egyértelműen meg kell határoznia a kifejezéseket, hogy minden érdekelt
fél

- azonos módon értse ezeket a kifejezéseket

- ne használjon szinonimákat és homonimákat

Forma

Táblázat &lt;Kifejezés&gt; és &lt;Meghatározás&gt; oszlopokkal.

Szükség esetén további oszlopok fordításokhoz.

További információ

Lásd [Szójegyzék](https://docs.arc42.org/section-12/) az arc42
dokumentációban.

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">Kifejezés</th>
<th style="text-align: left;">Meghatározás</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p><em>&lt;Kifejezés-1&gt;</em></p></td>
<td
style="text-align: left;"><p><em>&lt;meghatározás-1&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"><p><em>&lt;Kifejezés-2&gt;</em></p></td>
<td
style="text-align: left;"><p><em>&lt;meghatározás-2&gt;</em></p></td>
</tr>
</tbody>
</table>
