# Kontextus és hatókör

Tartalom

A kontextus és hatókör – ahogy a neve is sugallja – elhatárolja a
rendszert (azaz a hatókört) az összes kommunikációs partnerétől
(szomszédos rendszerek és felhasználók, azaz a rendszer kontextusa).
Ezáltal meghatározza a külső interfészeket.

Szükség esetén különítse el az üzleti kontextust (szakterület-specifikus
bemenetek és kimenetek) a technikai kontextustól (csatornák,
protokollok, hardver).

Motiváció

A kommunikációs partnerek felé mutató szakterületi és technikai
interfészek a rendszer legkritikusabb szempontjai közé tartoznak.
Győződjön meg róla, hogy teljesen megérti őket.

Forma

Különböző lehetőségek:

- Kontextus-diagramok

- Kommunikációs partnerek és interfészeik listája.

További információ

Lásd [Kontextus és hatókör](https://docs.arc42.org/section-3/) az arc42
dokumentációban.

## Üzleti kontextus

Tartalom

Az **összes** kommunikációs partner (felhasználók, IT-rendszerek, …​)
specifikációja a szakterület-specifikus bemenetek és kimenetek, illetve
interfészek magyarázatával. Opcionálisan hozzáadhatók
szakterület-specifikus formátumok vagy kommunikációs protokollok.

Motiváció

Minden érdekelt félnek meg kell értenie, milyen adatok cserélődnek a
rendszer környezetével.

Forma

Bármilyen diagram, amely a rendszert fekete dobozként mutatja, és
meghatározza a szakterületi interfészeket a kommunikációs partnerek
felé.

Alternatívaként (vagy kiegészítésként) használhat táblázatot is. A
táblázat címe a rendszer neve, a három oszlop tartalmazza a
kommunikációs partner nevét, a bemeneteket és a kimeneteket.

**&lt;Diagram vagy táblázat&gt;**

**&lt;opcionális: Külső szakterületi interfészek magyarázata&gt;**

## Technikai kontextus

Tartalom

Technikai interfészek (csatornák és átviteli közegek), amelyek a
rendszert a környezetéhez kapcsolják. Emellett a szakterület-specifikus
bemenet/kimenet leképezése a csatornákra, azaz annak magyarázata, hogy
melyik I/O melyik csatornát használja.

Motiváció

Sok érdekelt fél a rendszer és kontextusa közötti technikai interfészek
alapján hoz architekturális döntéseket. Különösen az infrastruktúra-
vagy hardvertervezők döntik el ezeket a technikai interfészeket.

Forma

Pl. UML telepítési diagram, amely a szomszédos rendszerek felé mutató
csatornákat írja le, kiegészítve egy leképezési táblázattal, amely a
csatornák és a bemenet/kimenet közötti kapcsolatokat mutatja.

**&lt;Diagram vagy táblázat&gt;**

**&lt;opcionális: Technikai interfészek magyarázata&gt;**

**&lt;Bemenet/kimenet leképezése csatornákra&gt;**
