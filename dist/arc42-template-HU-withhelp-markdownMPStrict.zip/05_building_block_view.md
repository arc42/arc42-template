# Építőelem-nézet

Tartalom

Az építőelem-nézet a rendszer statikus dekompozícióját mutatja
építőelemekre (modulok, komponensek, alrendszerek, osztályok,
interfészek, csomagok, könyvtárak, keretrendszerek, rétegek, partíciók,
szintek, függvények, makrók, műveletek, adatstruktúrák, …​), valamint
azok függőségeit (kapcsolatok, asszociációk, …​).

Ez a nézet minden architektúra-dokumentációban kötelező. Egy ház
analógiájával élve ez az *alaprajz*.

Motiváció

Őrizze meg a forráskód áttekinthetőségét azáltal, hogy szerkezetét
absztrakcióval érthetővé teszi.

Ez lehetővé teszi, hogy absztrakt szinten kommunikáljon az érdekelt
felekkel, anélkül, hogy a megvalósítás részleteit felfedné.

Forma

Az építőelem-nézet fekete dobozok és fehér dobozok hierarchikus
gyűjteménye (lásd az alábbi ábrát) és azok leírásai.

<figure>
<img src="images/05_building_blocks-HU.png"
alt="Építőelemek hierarchiája" />
</figure>

Az **1. szint** a teljes rendszer fehér doboz leírása a benne található
összes építőelem fekete doboz leírásával együtt.

A **2. szint** ráközelít az 1. szint néhány építőelemére. Így az 1.
szint kiválasztott építőelemeinek fehér doboz leírását tartalmazza, azok
belső építőelemeinek fekete doboz leírásával együtt.

A **3. szint** ráközelít a 2. szint kiválasztott építőelemeire, és így
tovább.

További információ

Lásd [Építőelem-nézet](https://docs.arc42.org/section-5/) az arc42
dokumentációban.

## Fehér doboz Teljes rendszer

Itt írja le a teljes rendszer dekompozícióját az alábbi fehér doboz
sablon segítségével. Ez tartalmazza:

- egy áttekintő diagramot

- a dekompozíció motivációját

- a tartalmazott építőelemek fekete doboz leírásait. Ehhez a következő
  alternatívákat kínáljuk:

  - használjon *egy* táblázatot az összes tartalmazott építőelem és
    interfészük rövid és pragmatikus áttekintéséhez

  - használja a fekete doboz sablon szerinti fekete doboz leírások
    listáját (lásd alább). Az eszközválasztástól függően ez a lista
    lehet alfejezet (szöveges fájlokban), aloldal (wikiben) vagy
    beágyazott elem (modellező eszközben).

- (opcionális:) olyan fontos interfészek, amelyeket nem a fekete doboz
  sablonok magyaráznak meg, de nagyon fontosak a fehér doboz
  megértéséhez. Mivel az interfészek megadásának oly sok módja létezik,
  nem adunk meg hozzájuk specifikus sablont. A legrosszabb esetben meg
  kell adnia és le kell írnia a szintaxist, szemantikát, protokollokat,
  hibakezelést, korlátozásokat, verziókat, minőségi jellemzőket,
  szükséges kompatibilitásokat és sok mást. A legjobb esetben elegendőek
  lesznek a példák vagy egyszerű szignatúrák.

***&lt;Áttekintő diagram&gt;***

Motiváció  
*&lt;szöveges magyarázat&gt;*

Tartalmazott építőelemek  
*&lt;A tartalmazott építőelemek (fekete dobozok) leírása&gt;*

Fontos interfészek  
*&lt;Fontos interfészek leírása&gt;*

Illessze be az 1. szint fekete dobozainak magyarázatát:

Ha táblázatos formát használ, a fekete dobozokat csak név és felelősség
szerint írja le a következő séma szerint:

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 66%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;"><strong>Név</strong></th>
<th style="text-align: left;"><strong>Felelősség</strong></th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p><em>&lt;fekete doboz
1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Szöveg&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"><p><em>&lt;fekete doboz
2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Szöveg&gt;</em></p></td>
</tr>
</tbody>
</table>

Ha fekete doboz leírások listáját használja, minden fontos építőelemhez
külön fekete doboz sablont tölt ki. A címsora az adott fekete doboz
neve.

### &lt;Fekete doboz 1 neve&gt;

Itt írja le a &lt;fekete doboz 1&gt;-et a következő fekete doboz sablon
szerint:

- Cél/Felelősség

- Interfész(ek), ha nem külön bekezdésbe vannak kiemelve. Ezek az
  interfészek tartalmazhatnak minőségi és teljesítményjellemzőket.

- (Opcionális) Minőségi/Teljesítményjellemzők a fekete dobozra
  vonatkozóan, pl. rendelkezésre állás, futásidejű viselkedés, …​.

- (Opcionális) Könyvtár/fájl elérési út

- (Opcionális) Teljesített követelmények (ha nyomon követhetőség
  szükséges a követelményekhez).

- (Opcionális) Nyitott kérdések/problémák/kockázatok

*&lt;Cél/Felelősség&gt;*

*&lt;Interfész(ek)&gt;*

*&lt;(Opcionális) Minőségi/Teljesítményjellemzők&gt;*

*&lt;(Opcionális) Könyvtár/Fájl elérési út&gt;*

*&lt;(Opcionális) Teljesített követelmények&gt;*

*&lt;(Opcionális) Nyitott kérdések/Problémák/Kockázatok&gt;*

### &lt;Fekete doboz 2 neve&gt;

*&lt;fekete doboz sablon&gt;*

### &lt;Fekete doboz n neve&gt;

*&lt;fekete doboz sablon&gt;*

### &lt;Interfész 1 neve&gt;

…​

### &lt;Interfész m neve&gt;

## 2. szint

Itt adhatja meg az 1. szint (néhány) építőelemének belső szerkezetét
fehér dobozként.

El kell döntenie, hogy a rendszer mely építőelemei elég fontosak ahhoz,
hogy ilyen részletes leírást kapjanak. Részesítse előnyben a relevanciát
a teljességgel szemben. Írja le a fontos, meglepő, kockázatos, összetett
vagy instabil építőelemeket. Hagyja ki a rendszer normális, egyszerű,
unalmas vagy szabványos részeit.

### Fehér doboz *&lt;1. építőelem&gt;*

…​az *1. építőelem* belső szerkezetét írja le.

*&lt;fehér doboz sablon&gt;*

### Fehér doboz *&lt;2. építőelem&gt;*

*&lt;fehér doboz sablon&gt;*

…​

### Fehér doboz *&lt;m. építőelem&gt;*

*&lt;fehér doboz sablon&gt;*

## 3. szint

Itt adhatja meg a 2. szint (néhány) építőelemének belső szerkezetét
fehér dobozként.

Ha az architektúrában részletesebb szintekre van szükség, másolja le az
arc42 ezen részét a további szintekhez.

### Fehér doboz &lt;\_x.1 építőelem\_&gt;

Az *x.1 építőelem* belső szerkezetét adja meg.

*&lt;fehér doboz sablon&gt;*

### Fehér doboz &lt;\_x.2 építőelem\_&gt;

*&lt;fehér doboz sablon&gt;*

### Fehér doboz &lt;\_y.1 építőelem\_&gt;

*&lt;fehér doboz sablon&gt;*
