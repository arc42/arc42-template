# Bevezetés és célok

Leírja azokat a követelményeket és hajtóerőket, amelyeket a
szoftverarchitekteknek és a fejlesztőcsapatnak figyelembe kell venniük.
Ezek a következők:

- alapvető üzleti célok,

- lényeges funkciók,

- lényeges funkcionális követelmények,

- az architektúra minőségi céljai és

- a releváns érdekelt felek és elvárásaik

## Követelmények áttekintése

Tartalom

A funkcionális követelmények rövid leírása, hajtóerők, a követelmények
kivonata (vagy összefoglalása). Hivatkozás a (remélhetőleg létező)
követelmény-dokumentumokra (verziószámmal és az elérhetőség
megjelölésével).

Motiváció

A végfelhasználók szemszögéből a rendszert egy üzleti tevékenység jobb
támogatása és/vagy a minőség javítása érdekében hozzák létre vagy
módosítják.

Forma

Rövid szöveges leírás, valószínűleg táblázatos használati eset
formátumban. Ha léteznek követelmény-dokumentumok, ez az áttekintés
hivatkozzon azokra.

Tartsa ezeket a kivonatokat a lehető legrövidebben. Egyensúlyozzon a
dokumentum olvashatósága és a követelmény-dokumentumokkal való esetleges
redundancia között.

További információ

Lásd [Bevezetés és célok](https://docs.arc42.org/section-1/) az arc42
dokumentációban.

## Minőségi célok

Tartalom

Az architektúra három (legfeljebb öt) legfontosabb minőségi célja,
amelyek teljesülése a legfontosabb érdekelt felek számára a legnagyobb
jelentőséggel bír. Valóban az architektúra minőségi céljairól van szó.
Ne keverje össze ezeket a projekt céljaival. Nem feltétlenül azonosak.

Tekintse át a lehetséges témák alábbi áttekintését (az ISO 25010
szabvány alapján):

<figure>
<img src="images/01_2_iso-25010-topics-HU-2023.drawio.png"
alt="Minőségi követelmények kategóriái" />
</figure>

Motiváció

Ismernie kell a legfontosabb érdekelt felek minőségi céljait, mivel ezek
alapvető architekturális döntéseket befolyásolnak. Legyen nagyon konkrét
ezekkel a minőségi jellemzőkkel kapcsolatban, kerülje a divatos
szavakat. Ha architektként nem tudja, hogyan fogják munkája minőségét
megítélni…​

Forma

Táblázat minőségi célokkal és konkrét forgatókönyvekkel, prioritás
szerint rendezve

## Érdekelt felek

Tartalom

A rendszer érdekelt feleinek explicit áttekintése, azaz minden személy,
szerepkör vagy szervezet, amely

- ismernie kell az architektúrát

- meg kell győzni az architektúráról

- az architektúrával vagy a kóddal kell dolgoznia

- munkájához szüksége van az architektúra dokumentációjára

- a rendszerrel vagy annak fejlesztésével kapcsolatos döntéseket kell
  hoznia

Motiváció

Ismernie kell minden, a rendszer fejlesztésében érintett vagy a rendszer
által érintett felet. Ellenkező esetben kellemetlen meglepetések érhetik
a fejlesztési folyamat során. Ezek az érdekelt felek határozzák meg
munkája és annak eredményei terjedelmét, valamint részletességi
szintjét.

Forma

Táblázat szerepkörökkel, személynevekkel és az architektúrával, illetve
annak dokumentációjával kapcsolatos elvárásaikkal.

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">Szerepkör/Név</th>
<th style="text-align: left;">Elérhetőség</th>
<th style="text-align: left;">Elvárások</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p><em>&lt;Szerepkör-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Elérhetőség-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Elvárás-1&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"><p><em>&lt;Szerepkör-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Elérhetőség-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Elvárás-2&gt;</em></p></td>
</tr>
</tbody>
</table>
