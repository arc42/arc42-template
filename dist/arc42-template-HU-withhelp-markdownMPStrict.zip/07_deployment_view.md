# Telepítési nézet

Tartalom

A telepítési nézet a következőket írja le:

1.  a rendszer futtatásához használt technikai infrastruktúrát,
    beleértve az infrastruktúra-elemeket, mint földrajzi helyszínek,
    környezetek, számítógépek, processzorok, csatornák és hálózati
    topológiák, valamint egyéb infrastruktúra-elemek, és

2.  a (szoftver) építőelemek leképezését ezekre az
    infrastruktúra-elemekre.

A rendszerek gyakran különböző környezetekben futnak, pl. fejlesztői
környezet, tesztkörnyezet, éles környezet. Ilyen esetekben dokumentálja
az összes releváns környezetet.

Különösen akkor dokumentálja a telepítési nézetet, ha a szoftver
elosztott rendszerként fut egynél több számítógépen, processzoron,
szerveren vagy konténerben, illetve ha saját hardverprocesszorokat és
chipeket tervez és épít.

Szoftver szempontból elegendő csak azokat az infrastruktúra-elemeket
rögzíteni, amelyek szükségesek az építőelemek telepítésének
bemutatásához. A hardverarchitektek túlmehetnek ezen, és az
infrastruktúrát bármilyen részletességi szintig leírhatják.

Motiváció

A szoftver nem fut hardver nélkül. Ez az alapul szolgáló infrastruktúra
befolyásolja, és befolyásolni is fogja a rendszert és/vagy néhány
keresztmetszeti koncepciót. Ezért szükséges az infrastruktúra ismerete.

Forma

Lehetséges, hogy a legfelső szintű telepítési diagram már a 3.2.
fejezetben megjelent technikai kontextusként, ahol saját
infrastruktúráját EGY fekete dobozként ábrázolja. Ebben a fejezetben
további telepítési diagramok segítségével részletesebben megvizsgálhatja
(belenagyíthat) ebbe a fekete dobozba:

- Az UML telepítési diagramokat kínál ennek a nézetnek a kifejezésére.
  Használja ezeket, esetleg beágyazott diagramokkal, ha az
  infrastruktúra összetettebb.

- Ha a (hardver) érdekelt felek más jellegű diagramokat részesítenek
  előnyben a telepítési diagram helyett, engedje, hogy bármilyen
  diagramot használjanak, amely képes az infrastruktúra csomópontjait és
  csatornáit megjeleníteni.

További információ

Lásd [Telepítési nézet](https://docs.arc42.org/section-7/) az arc42
dokumentációban.

## 1. infrastruktúra-szint

Írja le (általában diagramok, táblázatok és szöveg kombinációjával):

- a rendszer elosztását több helyszínre, környezetre, számítógépre,
  processzorra stb., valamint a közöttük lévő fizikai kapcsolatokat

- a telepítési struktúra fontos indoklásait vagy motivációit

- az infrastruktúra minőségi és/vagy teljesítményjellemzőit

- a szoftver-artefaktumok leképezését az infrastruktúra-elemekre

Több környezet vagy alternatív telepítés esetén kérjük, másolja és
adaptálja az arc42 ezen fejezetét az összes releváns környezethez.

***&lt;Áttekintő diagram&gt;***

Motiváció  
*&lt;szöveges magyarázat&gt;*

Minőségi és/vagy teljesítményjellemzők  
*&lt;szöveges magyarázat&gt;*

Építőelemek leképezése az infrastruktúrára  
*&lt;a leképezés leírása&gt;*

## 2. infrastruktúra-szint

Itt megadhatja az 1. szint (néhány) infrastruktúra-elemének belső
szerkezetét.

Kérjük, másolja az 1. szint struktúráját minden kiválasztott elemhez.

### *&lt;1. infrastruktúra-elem&gt;*

*&lt;diagram + magyarázat&gt;*

### *&lt;2. infrastruktúra-elem&gt;*

*&lt;diagram + magyarázat&gt;*

…​

### *&lt;n. infrastruktúra-elem&gt;*

*&lt;diagram + magyarázat&gt;*
