# 引言与目标

## 需求概述

## 质量目标

## 干系人

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">角色/姓名</th>
<th style="text-align: left;">联系方式</th>
<th style="text-align: left;">期望</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;角色-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;联系方式-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;期望-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;角色-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;联系方式-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;期望-2&gt;</em></p></td>
</tr>
</tbody>
</table>
