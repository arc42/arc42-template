# 术语表

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">术语</th>
<th style="text-align: left;">英文</th>
<th style="text-align: left;">定义</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p>&lt;术语-1&gt;</p></td>
<td style="text-align: left;"><p>&lt;英文-1&gt;</p></td>
<td style="text-align: left;"><p>&lt;定义-1&gt;</p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p>&lt;术语-2&gt;</p></td>
<td style="text-align: left;"><p>&lt;英文-2&gt;</p></td>
<td style="text-align: left;"><p>&lt;定义-2&gt;</p></td>
</tr>
</tbody>
</table>
