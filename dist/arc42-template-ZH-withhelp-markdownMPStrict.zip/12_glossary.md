# 术语表

内容

您的干系人在讨论系统时使用的最重要的领域和技术术语。

如果您在多语言团队中工作，您也可以将术语表视为翻译的来源。

动机

您应该清楚地定义您的术语，以便所有干系人

- 对这些术语有相同的理解

- 不使用同义词和同音异义词

形式

包含 &lt;术语&gt; 和 &lt;定义&gt; 列的表格。

如果您需要翻译，可能还有更多列。

更多信息

参见 arc42 文档中的 [术语表](https://docs.arc42.org/section-12/)。

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">术语</th>
<th style="text-align: left;">英文</th>
<th style="text-align: left;">定义</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p>&lt;术语-1&gt;</p></td>
<td style="text-align: left;"><p>&lt;英文-1&gt;</p></td>
<td style="text-align: left;"><p>&lt;定义-1&gt;</p></td>
</tr>
<tr>
<td style="text-align: left;"><p>&lt;术语-2&gt;</p></td>
<td style="text-align: left;"><p>&lt;英文-2&gt;</p></td>
<td style="text-align: left;"><p>&lt;定义-2&gt;</p></td>
</tr>
</tbody>
</table>
